#include "paneldimensionsdialog.h"
#include "ui_paneldimensionsdialog.h"

PanelDimensionsDialog::PanelDimensionsDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::PanelDimensionsDialog)
{
    ui->setupUi(this);
}

PanelDimensionsDialog::PanelDimensionsDialog(QWidget *parent, CPanelGroup data)
    : QDialog(parent)
    , ui(new Ui::PanelDimensionsDialog)
{
    ui->setupUi(this);
    QString txt = "Panel Dimensions:\n\n";
    txt += "Panel No. |   Width  |  Height\n";
    txt += "          |          |         \n";
    char buffer[200];

    for (unsigned int i=0; i<data.size(); i++) {
        CRect3d r = data[i].boundingRect();
        sprintf(buffer, "   %2d        %6d     %6d\n", i, int(r.width()+0.5), int(r.height()+0.5));
        txt += QString::fromUtf8(buffer);
    }

    ui->textEdit->setText(txt);
    ui->textEdit->setReadOnly(true);
}

PanelDimensionsDialog::~PanelDimensionsDialog()
{
    delete ui;
}
