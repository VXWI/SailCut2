#ifndef PANELDIMENSIONSDIALOG_H
#define PANELDIMENSIONSDIALOG_H

#include <QDialog>
#include "sailcpp/panel.h"
#include "sailcpp/panelgroup.h"

namespace Ui {
class PanelDimensionsDialog;
}

class PanelDimensionsDialog : public QDialog
{
    Q_OBJECT

public:
    explicit PanelDimensionsDialog(QWidget *parent = nullptr);
    PanelDimensionsDialog(QWidget *parent, CPanelGroup data);
    ~PanelDimensionsDialog();

private:
    Ui::PanelDimensionsDialog *ui;
};

#endif // PANELDIMENSIONSDIALOG_H
