#ifndef WINDOWWIDGET_H
#define WINDOWWIDGET_H

#include <QWidget>
#include <string.h>
#include "sailcpp/sailwindow.h"

namespace Ui {
class WindowWidget;
}

class WindowWidget : public QWidget
{
    Q_OBJECT

public:
    explicit WindowWidget(QWidget *parent = nullptr);

    ~WindowWidget();
    void setValues(std::string title, SailWindow sailWindow);
    SailWindow getValues();
    bool check();
    bool generate();

private:
    Ui::WindowWidget *ui;
    struct SailWindow _sailWindow;
};

#endif // WINDOWWIDGET_H
