/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "saildoc.h"
#include <QFile>

/** This contains all the input and output functions
 *  to read and write the sail, hull, rig, boat data to file.
 */

/**************************************************************************

                       construction / destruction

**************************************************************************/

/** Constructs an empty CSailDoc object.
 */
CSailDoc::CSailDoc()
        : QDomDocument("Sailcut")
{
    top = createElement("CSailDoc");
    appendChild(top);
}


/** Constructs a CSailDoc from a given XML file.
 *
 * @param filename
 */
CSailDoc::CSailDoc( const QString &filename )
{
    QFile f( filename );

    if ( !f.open(QIODevice::ReadOnly) )
        throw read_error("CSailDoc::CSailDoc : cannot open file for read access!");

    if ( !setContent( &f ) )
    {
        f.close();
        throw read_error("CSailDoc::CSailDoc : cannot set XML content from file!");
    }

    f.close();

    top = documentElement();
}



/** Creates an element with the given name and type.
 *
 * @param type a string containing the type of the element
 * @param name a string containing the name of the element
 */
QDomElement CSailDoc::createElement(const QString &type, const QString &name)
{
    QDomElement e = createElement(type);
    e.setAttribute("name", name);
    return e;
}


/** Creates an element with the given name, type and value.
 *
 * @param type a string containing the type of the element
 * @param name a string containing the name of the element
 * @param value a string containing the name of the element
 */
QDomElement CSailDoc::createElement(const QString &type, const QString &name, const QString &value)
{
    QDomElement e = createElement(type,name);
    e.setAttribute("value", value);
    return e;
}


/** Looks for an element with a given name and type in the current XML document.
 *
 * @param parent the parent node
 * @param type a string containing the type of the element
 * @param name a string containing the name of the element
 */
QDomElement CSailDoc::findElement(const QDomNode &parent, const QString &type, const QString &name)
{
    QDomNamedNodeMap attr;
    QDomNode n = parent.firstChild();

    while ( !n.isNull() )
    {
        if (n.nodeName() == type)
        {
            attr = n.toElement().attributes();
            if (attr.namedItem("name").nodeValue() == name)
                return n.toElement();
        }
        n = n.nextSibling();
    }

    // we didn't find the element, throw an exception
    throw doc_element_error(QString("CSailDoc::findElement(" + type + "," + name + ") : did not find requested element").toStdString());

    n.clear();
    return n.toElement();
}


/**************************************************************************

                                Input

**************************************************************************/

/** Reads a boolr value from an XML document.
 *
 * @param parent the parent node
 * @param i the integer
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, bool &b, const QString &name )
{
    QDomElement e = findElement( parent, "bool", name);
    QDomNamedNodeMap attr = e.attributes();
    QString s = attr.namedItem("value").nodeValue();
    b = s.toLower() == "true";
}

/** Reads an integer value from an XML document.
 *
 * @param parent the parent node
 * @param i the integer
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, int &i, const QString &name )
{
    QDomElement e = findElement( parent, "int", name);
    QDomNamedNodeMap attr = e.attributes();
    i = attr.namedItem("value").nodeValue().toInt();
}


/** Reads an unsigned integer value from an XML document.
 *
 * @param parent the parent node
 * @param i the unsigned integer
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, unsigned int &i, const QString &name )
{
    int temp;
    get(parent, temp, name);
    i = temp;
}


/** Reads a real value from an XML document.
 *
 * @param parent the parent node
 * @param r the real value
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, real &r, const QString &name )
{
    QDomElement e = findElement( parent, "real", name);
    QDomNamedNodeMap attr = e.attributes();
    r = attr.namedItem("value").nodeValue().toDouble();
}


/** Reads a std::string value from an XML document.
 *
 * @param parent the parent node
 * @param s the string
 * @param name the name of the string
 */
void CSailDoc::get
( const QDomNode &parent, string &s, const QString &name )
{
    QDomElement e = findElement( parent, "string", name);
    QDomNamedNodeMap attr = e.attributes();
    s = attr.namedItem("value").nodeValue().toStdString();
}


/** Reads a QString string value from an XML document.
 *
 * @param parent the parent node
 * @param s the string
 * @param name the name of the string
 */
void CSailDoc::get
( const QDomNode &parent, QString &s, const QString &name )
{
    QDomElement e = findElement( parent, "string", name);
    QDomNamedNodeMap attr = e.attributes();
    s = attr.namedItem("value").nodeValue();
}


/** Reads a CPoint3D point with x,y,z coordinates from an XML document.
 *
 * @param parent the parent node
 * @param p the 3D point
 * @param name the name of the 3D point
 */
void CSailDoc::get
( const QDomNode &parent, CPoint3d &p, const QString &name )
{
    QDomElement e = findElement( parent, "CPoint3d", name);
    get
    (e, p.x(), "x");
    get
    (e, p.y(), "y");
    get
    (e, p.z(), "z");
}


/** Reads an enumPanelGroupType enumerated Panel Group Type from an XML document.
 *
 * @param parent the parent node
 * @param t the enumPanelGroupType
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, enumPanelGroupType &t, const QString &name )
{
    QDomElement e = findElement( parent, "enumPanelGroupType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("SAIL"))
    {
        t = SAIL;
    }
    else if (!s.compare("RIG"))
    {
        t = RIG;
    }
    else if (!s.compare("HULL"))
    {
        t = HULL;
    }
    else
    {
        throw invalid_argument("CSailDoc::get : unknown panel group type");
    }
}


/** Reads an enumSailCut enumerated Sail Cut type from an XML document.
 *
 * @param parent the parent node
 * @param c the enumSailCut
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, enumSailCut &c, const QString &name )
{
    QDomElement e = findElement( parent, "enumSailCut", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("CROSS"))
        c = CROSS;
    if (!s.compare("CROSS2"))
        c = CROSS2;
    if (!s.compare("TWIST"))
        c = TWIST;
    if (!s.compare("HORIZONTAL"))
        c = HORIZONTAL;
    if (!s.compare("VERTICAL"))
        c = VERTICAL;
    if (!s.compare("RADIAL"))
        c = RADIAL;
    if (!s.compare("MITRE"))
        c = MITRE;
    if (!s.compare("MITRE2"))
        c = MITRE2;
    if (!s.compare("RADIALBOTTOM"))
        c = RADIALBOTTOM;
}


/** Reads an enumSailType enumerated Sail Type from an XML document.
 *
 * @param parent the parent node
 * @param t the enumSailType
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, enumSailType &t, const QString &name )
{
    QDomElement e = findElement( parent, "enumSailType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("MAINSAIL"))
        t = MAINSAIL;
    else if (!s.compare("JIB"))
        t = JIB;
    else if (!s.compare("WING"))
        t = WING;
    else if (!s.compare("SYMETRIC"))
        t = SYMMETRIC;
    else if (!s.compare("ASSYMETRIC"))
        t = ASYMMETRIC;
}


/** Reads an enumBoatElementType enumerated Boat Element Type from an XML document.
 *
 * @param parent the parent node
 * @param t the enumBoatElementType
 * @param name the name of the value
 */
void CSailDoc::get
( const QDomNode &parent, enumBoatElementType &t, const QString &name )
{
    QDomElement e = findElement( parent, "enumBoatElementType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("HULLDEF"))
        t = HULLDEF;
    if (!s.compare("SAILDEF"))
        t = SAILDEF;
    if (!s.compare("RIGDEF"))
        t = RIGDEF;
    if (!s.compare("PANELGROUP"))
        t = PANELGROUP;
}

void CSailDoc::get
    (const QDomNode &parent, enumInterpolationMethod &t, const QString &name )  {

    QDomElement e = findElement( parent, "enumInterpolationMethod", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("INTERPOL"))
        t = INTERPOL;
    if (!s.compare("INTERPOL2"))
        t = INTERPOL2;

}

void CSailDoc::get
    (const QDomNode &parent, enumCrossMeasurementType &t, const QString &name )  {

    QDomElement e = findElement( parent, "enumCrossMeasurementType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("ERS"))
        t = ERS;
    if (!s.compare("LUFF_LEECH_POINTS"))
        t = LUFF_LEECH_POINTS;
    if (!s.compare("IRC"))
        t = IRC;
    if (!s.compare("IOR"))
        t = IOR;
    if (!s.compare("LUFF_FOLD"))
        t = LUFF_FOLD;
}

void CSailDoc::get(const QDomNode &parent, enumProfileSubType &t, const QString &name ) {
    QDomElement e = findElement( parent, "enumProfileSubType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("PROFILE_DEFAULT"))
        t = PROFILE_DEFAULT;
    if (!s.compare("PROFILE_CIRCLE"))
        t = PROFILE_CIRCLE;
    if (!s.compare("PROFILE_ELLIPSE"))
        t = PROFILE_ELLIPSE;
    if (!s.compare("PROFILE_ELLIPSE_FLAT"))
        t = PROFILE_ELLIPSE_FLAT;

}

void CSailDoc::get(const QDomNode &parent, enumPatchStyles &t, const QString &name ) {
    QDomElement e = findElement( parent, "enumPatchStyles", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("PATCH_STYLE_FAN"))
        t = PATCH_STYLE_FAN;
    if (!s.compare("PATCH_STYLE_PLAIN"))
        t = PATCH_STYLE_BLOCK;
    if (!s.compare("PATCH_STYLE_BLOCK"))
        t = PATCH_STYLE_BLOCK;
    if (!s.compare("PATCH_STYLE_RADIAL"))
        t = PATCH_STYLE_RADIAL;

}

void CSailDoc::get(const QDomNode &parent, enumPatchType &t, const QString &name ) {
    QDomElement e = findElement( parent, "enumPatchType", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("PATCH_TYPE_NONE"))
        t = PATCH_TYPE_NONE;
    if (!s.compare("PATCH_SPINNAKER_HEAD"))
        t = PATCH_SPINNAKER_HEAD;
    if (!s.compare("PATCH_SPINNAKER_CLEW"))
        t = PATCH_SPINNAKER_CLEW;
    // TODO add more types as they become supported
    if (!s.compare("PATCH_JIB_TACK"))
        t = PATCH_JIB_TACK;
    if (!s.compare("PATCH_JIB_CLEW"))
        t = PATCH_JIB_CLEW;
    if (!s.compare("PATCH_JIB_HEAD"))
        t = PATCH_JIB_HEAD;
    if (!s.compare("PATCH_MAIN_TACK"))
        t = PATCH_MAINSAIL_TACK;
    if (!s.compare("PATCH_MAIN_CLEW"))
        t = PATCH_MAINSAIL_CLEW;
    if (!s.compare("PATCH_MAIN_HEAD"))
        t = PATCH_MAINSAIL_HEAD;

    if (!s.compare("PATCH_MAINSAIL_REEF1"))
        t = PATCH_MAINSAIL_REEF1;

    if (!s.compare("PATCH_MAINSAIL_REEF2"))
        t = PATCH_MAINSAIL_REEF2;

}

void CSailDoc::get(const QDomNode &parent, enumSailWindowAlign &t, const QString &name ) {
    QDomElement e = findElement( parent, "enumSailWindowAlign", name);
    QString s = e.attributes().namedItem("value").nodeValue();

    if (!s.compare("SWA_BOTTOM_SEAM"))
        t = SWA_BOTTOM_SEAM;
    if (!s.compare("SWA_TOP_SEAM"))
        t = SWA_TOP_SEAM;
    if (!s.compare("SWA_FOOT"))
        t = SWA_FOOT;
    if (!s.compare("SWA_LEECH_PERP"))
        t = SWA_LEECH_PERP;
    if (!s.compare("SWA_HORIZONTAL"))
        t = SWA_HORIZONTAL;


}

void CSailDoc::get(const QDomNode &parent, struct SailWindow &sw, const QString &name ) {
    QDomElement e = findElement( parent, "SailWindow", name);
    get(e, sw.generate, "generate");
    get(e, sw.panelNo, "panelNo");
    get(e, sw.width, "width");
    get(e, sw.height, "height");
    get(e, sw.xPos, "xPos");
    get(e, sw.yPos, "yPos");
    get(e, sw.alignment, "alignment");

}


/** Reads a CHullDef hull definition from an XML document.
 *
 * @param parent the parent node
 * @param d the hull definition
 * @param name the name of the hull definition
 */
void CSailDoc::get
( const QDomNode &parent, CHullDef &d, const QString &name )
{
    QDomElement e = findElement( parent, "CHullDef", name);

    get(e, d.hullID, "hullID");

    /** read hull bottom data */
    get(e, d.BLWL, "BLWL");
    get(e, d.BfwdHeight, "BfwdHeight");
    get(e, d.BaftHeight, "BaftHeight");
    get(e, d.BSlopeA, "BSlopeA");
    get(e, d.BBW, "BBW");
    get(e, d.BBWPos, "BBWPos");
    get(e, d.BaftW, "BaftW");
    get(e, d.BDeadriseA, "BDeadriseA");
    get(e, d.BSweepA, "BSweepA");
    get(e, d.BfwdShape, "BfwdShape");
    get(e, d.BaftShape, "BaftShape");

    /** read hull deck data */
    get(e, d.DfwdHeight, "DfwdHeight");
    get(e, d.DaftHeight, "DaftHeight");
    get(e, d.DSlopeA, "DSlopeA");

    /** read hull stem angle */
    get(e, d.StemA, "StemA");

    /** read hull transom angle */
    get(e, d.TransomA, "TransomA");

    /** read hull side planks data */
    get(e, d.NBPlank, "NBPlank");
    get(e, d.TopPlankA, "TopPlankA");
    get(e, d.LowPlankA, "lowPlankA");
    // get(e, d.AutoPlank, "AutoPlank");
    //
}


/** Reads a CSailDef sail definition from an XML document.
 *  NEW members are added at the end of the list
 *  See also CSailDoc::put(QDomNode &parent, const CSailDef &d, const QString &name )
 *
 * @param parent the parent node
 * @param d the sail definition
 * @param name the name of the sail definition
 */
void CSailDoc::get
( const QDomNode &parent, CSailDef &d, const QString &name )
{
    QDomElement e = findElement( parent, "CSailDef", name);

    d.luffTapeDistance = 0;
    d.footTapeDistance = 0;

    /** read sail cut layout and type */
    get(e, d.sailCut, "sailCut");
    get(e, d.sailType, "sailType");

    /** read sail boat data */
    get(e, d.LOA, "LOA");
    get(e, d.foreI, "foreI");
    get(e, d.foreJ, "foreJ");
    get(e, d.tackX, "tackX");
    get(e, d.tackY, "tackY");

    /** read sail sides */
    get(e, d.luffL, "luffL");
    get(e, d.rake, "rake");
    get(e, d.gaffDeg, "gaffDeg");
    get(e, d.gaffL, "gaffL");
    get(e, d.footL, "footL");
    get(e, d.leechL, "leechL");

    /** read sail shape of sides */
    get(e, d.luffR, "luffR");
    get(e, d.gaffR, "gaffR");
    get(e, d.leechR, "leechR");
    get(e, d.footR, "footR");

    get(e, d.luffRP, "luffRP");
    get(e, d.gaffRP, "gaffRP");
    get(e, d.leechRP, "leechRP");
    get(e, d.footRP, "footRP");

    /** read sail cloth width, seam and hems width */
    get(e, d.clothW, "clothW");
    get(e, d.seamW, "seamW");
    get(e, d.leechHemW, "leechHemW");
    get(e, d.hemsW, "hemsW");

    /** read sail twist */
    get(e, d.twistDeg, "twistDeg");

    /** read sail mould */
    get(e, d.mould, "mould");

    /** read sail sheeting angle */
    get(e, d.sheetDeg, "sheetDeg");

    /** NOTE : we maintain backward file format compatibility by adding below
     * all new members in the order they are introduced in CSailDoc::put
     */
    try
    {
        /** read Sail ID */
        get(e, d.sailID, "sailID");

        /** read Radial sections */
        get(e, d.nbSections, "nbSections");

        /** read Radial gores */
        get(e, d.nbGores, "nbGores");

        /** read Luff gores */
        get(e, d.nbLuffGores, "nbLuffGores");

        /** read Wing dihedral angle */
        get(e, d.dihedralDeg, "dihedralDeg");

        /** read Foot hem width */
        get(e, d.footHemW, "footHemW");
    }
    catch (doc_element_error const&)
    {
        /** catch read error to avoid killing the program */
    }
cout << "reading new stuff" << endl;

	d.footPanelSections = 1;
	d.splitPanelNos = "";
	d.speedSeamLeechHeight = 0;
    d.lensFoot = false;

    d.filletPanelWidth = 0;
    d.speedPanelWidth = 0;
    d.generateSpeedSeam = true;

    d.printBottomSeam = false;

    try
    {
        //
        get(e, d.footPanelSections, "footPanelSections");
        get(e, d.splitPanelNos, "splitPanelNos");
        get(e, d.speedSeamLeechHeight, "speedSeamLeechHeight");
    }
    catch (doc_element_error const&)
    {
        /** catch read error to avoid killing the program */
    	cout << "new stuff read exception" << endl;

    }


    try
    {
        //
    	get(e, d.footPanelSections, "footPanelSections");
    	get(e, d.splitPanelNos, "splitPanelNos");
    	get(e, d.speedSeamLeechHeight, "speedSeamLeechHeight");

    	get(e, d.filletPanelWidth, "filletPanelWidth");
    	get(e, d.speedPanelWidth, "speedPanelWidth");
    	get(e, d.generateSpeedSeam, "generateSpeedSeam");

        //get(e, d.headPanelLeechDistance, "headPanelLeechDistance");
        //get(e, d.headPanelLeechDistanceFrom, "headPanelLeechDistanceFrom");
        //get(e, d.headPanelLuffDistance, "headPanelLuffDistance");
        //get(e, d.headPanelLuffDistanceFrom, "headPanelLuffDistanceFrom");;
        get(e, d.straightLineLeech, "straightLineLeech");
        get(e, d.clothAlignsWithLeech, "clothAlignsWithLeech");
        get(e, d.leechTurnPos, "leechTurnPos");
        get(e, d.radialHead, "radialHead");;
    }
    catch (doc_element_error const&)
    {
        /** catch read error to avoid killing the program */
    	cout << "new stuff read exception" << endl;

    }


    try {
        get(e, d.printBottomSeam, "printBottomSeam");
    }  catch (doc_element_error const&x) {
        try {
            // try older name for this field
            get(e, d.printBottomSeam, "seamAtBottom");
        }  catch (doc_element_error const&x1) {
            cout << "new stuff read exception" << endl;
        }
    }

    try {
        get(e, d.luffTapeDistance, "luffTapeDistance");
        get(e, d.footTapeDistance, "footTapeDistance");
    }  catch (doc_element_error const&x) {
        d.luffTapeDistance = 0;
        d.footTapeDistance = 0;
        cout << "new stuff read exception" << endl;
    }

    cout << "luffTapeDistance = " << d.luffTapeDistance << endl;

    try {
        get(e, d.battenGroup, "battenGroup");
    }
    catch (doc_element_error const&)
    {
        /** catch read error to avoid killing the program */
        cout << "new stuff read exception" << endl;

    }

    try {
        get(e, d.interpolMethod, "interpolMethod");
    } catch (doc_element_error const&) {
        d.interpolMethod = INTERPOL;
    }

    try {
        get(e, d.interpol2Strength, "interpol2Stength");
    } catch (doc_element_error const&) {
        d.interpol2Strength = DEFAULT_INTERPOL_STRENGTH;
    }

    try {
        get(e, d.interpol2RP, "interpol2RP");
    } catch (doc_element_error const&) {
        d.interpol2RP = 50;
    }

    try {
        get(e, d.lensFoot, "lensFoot");
    } catch (doc_element_error const&) {
        d.lensFoot = false;
    }

    try {
        get(e, d.footEdgeAtZeroZ, "footEdgeAtZeroZ");
    }  catch (doc_element_error const&) {
        d.footEdgeAtZeroZ = true;
    }

    try {
        get(e, d.crossMeasurementType, "crossMeasurementType");
    }  catch (doc_element_error const&) {
        d.crossMeasurementType = ERS;
    }

    try {
        get(e, d.minTopWidth, "minTopWidth");
    }  catch (doc_element_error const&) {
        d.minTopWidth = 0;
    }

    try {
        get(e, d.profileSubType, "profileSubType");
    }  catch (doc_element_error const&) {
        d.profileSubType = PROFILE_DEFAULT;
    }

    try {
        get(e, d.luffOffset, "luffOffset");
    } catch (doc_element_error const&) {
        d.luffOffset = 0;
    }

    try {
        get(e, d.luffOffsetRP, "luffOffsetRP");
    } catch (doc_element_error const&) {
        d.luffOffsetRP = 50;
    }

    try {
        get(e, d.bottomPanelHeight, "bottomPanelHeight");
    } catch (doc_element_error const&) {
        d.bottomPanelHeight = 1;
    }

    // fix for straightLineLeech erroniously set in some saildef files
    if (d.sailType != MAINSAIL) {
        d.straightLineLeech = false;
    }

    // patches
    d.patches.clear();
    try {
        QDomElement e1 = findElement( e, "Patches", "patches");
        get_vector(e1, d.patches, "patch");
    } catch (doc_element_error const&) {
        cout << "no patch data found" << endl;
    }

    try {
        get(e, d.panelWidthAdjustments, "panelWidthAdjustments");
    } catch (doc_element_error const&) {
        d.panelWidthAdjustments = "";
    }

    try {
        get(e, d.notes, "notes");
    } catch (doc_element_error const&) {
        d.notes = "";
    }

    try {
        get(e, d.battenHollowPC, "battenHollowPC");
    } catch (doc_element_error const&) {
        d.battenHollowPC = 0;
    }

    try {
        get(e, d.window1, "window1");
    } catch (doc_element_error const&) {
        // swallow exception
    }

    try {
        get(e, d.window2, "window2");
    } catch (doc_element_error const&) {
        // swallow exception
    }

    try {
        get(e, d.curvedSpeedSeam, "curvedSpeedSeam");
    } catch (doc_element_error const&) {
        d.curvedSpeedSeam = false;
    }

    cout << "returning" << endl;
}


/** Reads a CSide sail side from an XML document.
 *
 * @param parent the parent node
 * @param s the sail side
 * @param name the name of the sail side
 */
void CSailDoc::get
( const QDomNode &parent, CSide &s, const QString &name )
{
    QDomElement e = findElement( parent, "CSide", name);
    get_vector(e, s, "point");
}


/** Reads a CPanel sail panel from an XML document.
 *
 * @param parent the parent node
 * @param p the panel
 * @param name the name of the panel
 */
void CSailDoc::get
( const QDomNode &parent, CPanel &p, const QString &name )
{
    QDomElement e = findElement( parent, "CPanel", name);
    get(e, p.top, "top");
    get(e, p.bottom, "bottom");
    get(e, p.left, "left");
    get(e, p.right, "right");

    int temp;
    get(e, temp, "hasHems");
    p.hasHems = (temp != 0);

    if (p.hasHems)
    {
        get(e, p.cutTop, "cutTop");
        get(e, p.cutBottom, "cutBottom");
        get(e, p.cutLeft, "cutLeft");
        get(e, p.cutRight, "cutRight");
    }

}


/** Reads a CPanelGroup from an XML document.
 *
 * @param parent the parent node
 * @param g the panel group
 * @param name the name of the panel group
 */
void CSailDoc::get
( const QDomNode &parent, CPanelGroup &g, const QString &name )
{
    QDomElement e = findElement( parent, "CPanelGroup", name);
    get_vector(e, g, "panel");
    get(e, g.title, "title");
    get_vector(e, g.child, "child");

    /* NOTE : we maintain backward file format compatibility
     * by adding below all new members in the order they were introduced
     */
    try
    {
        get(e, g.type, "type");
    }
    catch (doc_element_error const&)
    {
        // to avoid killing the program
    }
}


/** Reads a CProfile sail profile from an XML document.
 *
 * @param parent the parent node
 * @param p the profile
 * @param name the name of the profile
 */
void CSailDoc::get
( const QDomNode &parent, CProfile &p, const QString &name )
{
    QDomElement e = findElement( parent, "CProfile", name);
    real depth=0,kluff=0,kleech=0;
    get(e, depth, "depth");
    get(e, kleech, "kleech");
    get(e, kluff, "kluff");

    p = CProfile(depth,kleech,kluff);
}


void CSailDoc::get
    ( const QDomNode &parent, struct Patch &p, const QString &name )
{
    QDomElement e = findElement( parent, "Patch", name);
    get(e, p.baseDimension, "baseDimension");
    get(e, p.dimension1, "dimension1");
    get(e, p.dimension2, "dimension2");
    get(e, p.numSections, "numSections");
    get(e, p.overlap, "overlap");
    get(e, p.patchStyle, "patchStyle");
    get(e, p.patchType, "patchType");
    get(e, p.underPatches, "underPatches");

    try {
        get(e, p.luffHeight, "luffHeight");
    } catch (doc_element_error const&) {
        p.luffHeight = 0;
    }

    try {
        get(e, p.leechHeight, "leechHeight");
    } catch (doc_element_error const&) {
        p.leechHeight = 0;
    }

}


/** Reads a CBoatDef boat definition from an XML document.
 *
 * @param parent the parent node
 * @param d the boat definition
 * @param name the name of the boat definition
 */
void CSailDoc::get
( const QDomNode &parent, CBoatDef &d, const QString &name )
{
    QDomElement e = findElement( parent, "CBoatDef", name);
    get_vector(e, d, "element");
}


/** Reads a CBoatElement from an XML document.
 *
 * @param parent the parent node
 * @param s the boat element
 * @param name the name of the boat element
 */
void CSailDoc::get
( const QDomNode &parent, CBoatElement &s, const QString &name )
{
    QDomElement e = findElement( parent, "CBoatElement", name);
    get(e, (CPanelGroup&)s, "panelgroup");
    get(e, s.type, "type");
    get(e, s.filename, "filename");
    get(e, s.origin, "origin");
}


/** Reads a CSailMould sail mould from an XML document.
 *
 * @param parent the parent node
 * @param m the mould
 * @param name the name of the mould
 */
void CSailDoc::get
( const QDomNode &parent, CSailMould &m, const QString &name )
{
    QDomElement e = findElement( parent, "CSailMould", name);
    get(e, m.vertpos, "vertpos");
    try {
        get(e, m.bottomDepth, "bottomDepth");
    } catch (doc_element_error const&) {
        m.bottomDepth = 0;
    }
    get_vector(e, m.profile, "profile");
}


/** Reads a CPrefs set of preferences from an XML document.
 *
 * @param parent the parent node
 * @param p the preferences
 * @param name the name of the preferences
 */
void CSailDoc::get
( const QDomNode &parent, CPrefs &p, const QString &name )
{
    QDomElement e = findElement( parent, "CPrefs", name);
    try
    {
        get(e, p.language, "language");
        get_vector(e, p.mruDocuments, "mruDocuments");
        get(e, p.mainWindowHeight, "mainWindowHeight");
        get(e, p.mainWindowWidth, "mainWindowWidth");
    }
    catch (doc_element_error const&)
    {
        // we do not let this kill the program
    }
}


/** Reads a CRigDef rig definition from an XML document.
 *
 * @param parent the parent node
 * @param d the rig definition
 * @param name the name of the rig definition
 */
void CSailDoc::get
( const QDomNode &parent, CRigDef &d, const QString &name )
{
    QDomElement e = findElement( parent, "CRigDef", name);

    get(e, d.rigID, "rigID");

    /** read fore triangle data */
    get(e, d.foreI, "foreI");
    get(e, d.foreJ, "foreJ");
    /** read mast data */
    get(e, d.MHeight, "MHeight");
    get(e, d.MCord, "MCord");
    get(e, d.MWidth, "MWidth");
    get(e, d.MRakeM, "MRakeM");
    get(e, d.MRakeD, "MRakeD");
    get(e, d.MBase, "MBase");
    get(e, d.MRnd, "MRnd");
    get(e, d.MRndPos, "MRndPos");
    /** read shrouds data */
    get(e, d.CSH, "CSH");
    get(e, d.CSB, "CSB");
    get(e, d.LSB, "LSB");
    /** read spreaders data */
    get(e, d.SPNB, "SPNB");
    get(e, d.SPH[0], "SPH0");
    get(e, d.SPH[1], "SPH1");
    get(e, d.SPH[2], "SPH2");
    get(e, d.SPH[3], "SPH3");
    get(e, d.SPW[0], "SPW0");
    get(e, d.SPW[1], "SPW1");
    get(e, d.SPW[2], "SPW2");
    get(e, d.SPW[3], "SPW3");
    /** read mainsail data */
    get(e, d.BAD, "BAD");
    get(e, d.HAD, "HAD");
    //
}


/**************************************************************************

                                Output

**************************************************************************/

/** Puts a boolean value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const bool &b, const QString &name )
{
    QDomElement e = createElement("bool",name,QString::fromStdString(b==true?"true":"false"));
    parent.appendChild(e);
}


/** Puts an integer value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const int &i, const QString &name )
{
    QDomElement e = createElement("int",name,QString::number(i));
    parent.appendChild(e);
}


/** Puts an unsigned integer value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const unsigned int &i, const QString &name )
{
    put(parent, int(i), name);
}


/** Puts a real value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const real &r, const QString &name )
{
    QDomElement e = createElement("real",name, QString::number(r));
    parent.appendChild(e);
}


/** Puts a std::string value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const string &s, const QString &name )
{
    QDomElement e = createElement("string", name, QString::fromStdString(s));
    parent.appendChild(e);
}


/** Puts a QString value to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const QString &s, const QString &name )
{
    QDomElement e = createElement("string", name, s);
    parent.appendChild(e);
}


/** Puts a CPoint3d to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CPoint3d &p, const QString &name )
{
    QDomElement e = createElement("CPoint3d",name);
    parent.appendChild(e);

    put(e, p.x(), "x");
    put(e, p.y(), "y");
    put(e, p.z(), "z");
}


/** Puts an enumBoatElementType enumerated Boat Element Type to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const enumBoatElementType &t, const QString &name )
{
    QString value;
    switch (t)
    {
    case HULLDEF:
        value = "HULLDEF";
        break;
    case SAILDEF:
        value = "SAILDEF";
        break;
    case RIGDEF:
        value = "RIGDEF";
        break;
    case PANELGROUP:
        value = "PANELGROUP";
        break;
    }
    QDomElement e = createElement("enumBoatElementType",name,value);
    parent.appendChild(e);
}


/** Puts an enumPanelGroupType enumerated Panel Group Type to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const enumPanelGroupType &t, const QString &name )
{
    QString value;
    switch (t)
    {
    case SAIL:
        value = "SAIL";
        break;
    case RIG:
        value = "RIG";
        break;
    case HULL:
        value = "HULL";
        break;
    }
    QDomElement e = createElement("enumPanelGroupType",name,value);
    parent.appendChild(e);
}


/** Puts an enumSailCut enumerated Sail Cut Type to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const enumSailCut &c, const QString &name )
{
    QString value;
    switch (c)
    {
    case CROSS:
        value = "CROSS";
        break;
    case CROSS2:
        value = "CROSS2";
        break;
    case TWIST:
        value = "TWIST";
        break;
    case HORIZONTAL:
        value = "HORIZONTAL";
        break;
    case VERTICAL:
        value = "VERTICAL";
        break;
    case RADIAL:
        value = "RADIAL";
        break;
    case MITRE:
        value = "MITRE";
        break;
    case MITRE2:
        value = "MITRE2";
        break;
    case RADIALBOTTOM:
        value = "RADIALBOTTOM";
        break;
    }
    QDomElement e = createElement("enumSailCut",name,value);
    parent.appendChild(e);
}


/** Puts an enumSailType enumerated Sailf Type to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const enumSailType &t, const QString &name )
{
    QString value;
    switch (t)
    {
    case MAINSAIL:
        value = "MAINSAIL";
        break;
    case JIB:
        value = "JIB";
        break;
    case WING:
        value = "WING";
        break;
    case SYMMETRIC:
        value = "SYMETRIC";
        break;
    case ASYMMETRIC:
        value = "ASSYMETRIC";
        break;
    }
    QDomElement e = createElement("enumSailType",name,value);
    parent.appendChild(e);
}

void CSailDoc::put(QDomNode &parent, const enumInterpolationMethod &t, const QString &name ) {
    QString value;
    switch (t)
    {
    case INTERPOL:
        value = "INTERPOL";
        break;
    case INTERPOL2:
        value = "INTERPOL2";
        break;
    }
    QDomElement e = createElement("enumInterpolationMethod",name,value);
    parent.appendChild(e);
}

void CSailDoc::put(QDomNode &parent, const enumCrossMeasurementType &t, const QString &name ) {
    QString value;
    switch (t)
    {
    case ERS:
        value = "ERS";
        break;
    case LUFF_LEECH_POINTS:
        value = "LUFF_LEECH_POINTS";
        break;
    case IRC:
        value = "IRC";
        break;
    case IOR:
        value = "IOR";
        break;
    case LUFF_FOLD:
        value = "LUFF_FOLD";
        break;
    }
    QDomElement e = createElement("enumCrossMeasurementType",name,value);
    parent.appendChild(e);
}

void CSailDoc::put(QDomNode &parent, const enumProfileSubType &t, const QString &name) {
    QString value;
    switch (t)
    {
    case PROFILE_CIRCLE:
        value = "PROFILE_CIRCLE";
        break;
    case PROFILE_ELLIPSE:
        value = "PROFILE_ELLIPSE";
        break;
    case PROFILE_ELLIPSE_FLAT:
        value = "PROFILE_ELLIPSE_FLAT";
        break;
    case PROFILE_DEFAULT:
        value = "PROFILE_DEFAULT";
        break;
    }
    QDomElement e = createElement("enumProfileSubType",name,value);
    parent.appendChild(e);

}

void CSailDoc::put(QDomNode &parent, const enumPatchStyles &t, const QString &name) {
    QString value;
    switch (t)
    {
    case PATCH_STYLE_FAN:
        value = "PATCH_STYLE_FAN";
        break;
    case PATCH_STYLE_BLOCK:
        value = "PATCH_STYLE_BLOCK";
        break;
    case PATCH_STYLE_RADIAL:
        value = "PATCH_STYLE_RADIAL";
        break;
    }
    QDomElement e = createElement("enumPatchStyles",name,value);
    parent.appendChild(e);

}

void CSailDoc::put(QDomNode &parent, const enumPatchType &t, const QString &name) {
    QString value;
    switch (t)
    {
    case PATCH_TYPE_NONE:
        value = "PATCH_TYPE_NONE";
        break;
    case PATCH_SPINNAKER_CLEW:
        value = "PATCH_SPINNAKER_CLEW";
        break;
    case PATCH_SPINNAKER_HEAD:
        value = "PATCH_SPINNAKER_HEAD";
        break;

    case PATCH_JIB_TACK:
        value = "PATCH_JIB_TACK";
        break;
    case PATCH_JIB_CLEW:
        value = "PATCH_JIB_CLEW";
        break;
    case PATCH_JIB_HEAD:
        value = "PATCH_JIB_HEAD";
        break;

    case PATCH_MAINSAIL_TACK:
        value = "PATCH_MAIN_TACK";
        break;
    case PATCH_MAINSAIL_CLEW:
        value = "PATCH_MAIN_CLEW";
        break;
    case PATCH_MAINSAIL_HEAD:
        value = "PATCH_MAIN_HEAD";
        break;

    case PATCH_MAINSAIL_REEF1:
        value = "PATCH_MAINSAIL_REEF1";
        break;
    case PATCH_MAINSAIL_REEF2:
        value = "PATCH_MAINSAIL_REEF2";
        break;

    default:
        value="ZZZ";
        break;
    // TODO add more types as they become supported
    }
    QDomElement e = createElement("enumPatchType",name,value);
    parent.appendChild(e);

}

void CSailDoc::put(QDomNode &parent, const enumSailWindowAlign &t, const QString &name) {
    QString value;
    switch (t)
    {
    case SWA_BOTTOM_SEAM:
        value = "SWA_BOTTOM_SEAM";
        break;
    case SWA_TOP_SEAM:
        value = "SWA_TOP_SEAM";
        break;
    case SWA_FOOT:
        value = "SWA_FOOT";
        break;

    case SWA_LEECH_PERP:
        value = "SWA_LEECH_PERP";
        break;

    case SWA_HORIZONTAL:
        value = "SWA_HORIZONTAL";
        break;
    }

    QDomElement e = createElement("enumSailWindowAlign",name,value);
    parent.appendChild(e);

}

void CSailDoc::put(QDomNode &parent, const struct SailWindow &sw, const QString &name ) {
    QDomElement e = createElement("SailWindow",name);
    parent.appendChild(e);

    put(e, sw.generate, "generate");
    put(e, sw.panelNo, "panelNo");
    put(e, sw.width, "width");
    put(e, sw.height, "height");
    put(e, sw.xPos, "xPos");
    put(e, sw.yPos, "yPos");
    put(e, sw.alignment, "alignment");

}

/** Puts a CHullDef hull definition to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CHullDef &d, const QString &name )
{
    QDomElement e = createElement("CHullDef",name);
    parent.appendChild(e);

    put(e, d.hullID, "hullID");

    /** write hull bottom data */
    put(e, d.BLWL, "BLWL");
    put(e, d.BfwdHeight, "BfwdHeight");
    put(e, d.BaftHeight, "BaftHeight");
    put(e, d.BSlopeA, "BSlopeA");
    put(e, d.BBW, "BBW");
    put(e, d.BBWPos, "BBWPos");
    put(e, d.BaftW, "BaftW");
    put(e, d.BDeadriseA, "BDeadriseA");
    put(e, d.BSweepA, "BSweepA");
    put(e, d.BfwdShape, "BfwdShape");
    put(e, d.BaftShape, "BaftShape");

    /** write hull deck data */
    put(e, d.DfwdHeight, "DfwdHeight");
    put(e, d.DaftHeight, "DaftHeight");
    put(e, d.DSlopeA, "DSlopeA");

    /** write hull stem angle */
    put(e, d.StemA, "StemA");

    /** write hull transom angle */
    put(e, d.TransomA, "TransomA");

    /** write hull side planks data */
    put(e, d.NBPlank, "NBPlank");
    put(e, d.TopPlankA, "TopPlankA");
    put(e, d.LowPlankA, "lowPlankA");
    // put(e, d.AutoPlank, "AutoPlank");
    //
}


/** Puts a CSailDef sail definition to an XML document.
 *  NEW members shall be added at THE END OF THE LIST in order
 *  to maintain backward comaptibility of files.
 *
 *  See also CSailDoc::get(QDomNode &parent, const CSailDef &d, const QString &name )
 */
void CSailDoc::put(QDomNode &parent, const CSailDef &d, const QString &name )
{
    QDomElement e = createElement("CSailDef",name);
    parent.appendChild(e);

    /** write Sail cut and Sail type */
    put(e, d.sailCut, "sailCut");
    put(e, d.sailType, "sailType");

    /** write Sail Boat data */
    put(e, d.LOA, "LOA");
    put(e, d.foreI, "foreI");
    put(e, d.foreJ, "foreJ");
    put(e, d.tackX, "tackX");
    put(e, d.tackY, "tackY");

    /** write Sides of the sail */
    put(e, d.luffL, "luffL");
    put(e, d.rake, "rake");
    put(e, d.gaffDeg, "gaffDeg");
    put(e, d.gaffL, "gaffL");
    put(e, d.footL, "footL");
    put(e, d.leechL, "leechL");

    /** write Shape of sail sides */
    put(e, d.luffR, "luffR");
    put(e, d.gaffR, "gaffR");
    put(e, d.leechR, "leechR");
    put(e, d.footR, "footR");

    put(e, d.luffRP, "luffRP");
    put(e, d.gaffRP, "gaffRP");
    put(e, d.leechRP, "leechRP");
    put(e, d.footRP, "footRP");
    put(e, d.minTopWidth, "minTopWidth");

    /** write sail Cloth width, Seam and Hems width */
    put(e, d.clothW, "clothW");
    put(e, d.seamW, "seamW");
    put(e, d.leechHemW, "leechHemW");
    put(e, d.hemsW, "hemsW");

    /** write sail Twist angle*/
    put(e, d.twistDeg, "twistDeg");

    /** write sail Sheeting angle*/
    put(e, d.sheetDeg, "sheetDeg");

    /** write sail Mould */
    put(e, d.mould, "mould");

    //** NOTE: this is the point at which sail data evolutions start */

    /** write sail ID */
    put(e, d.sailID, "sailID");

    /** write sail Radial sections */
    put(e, d.nbSections, "nbSections");

    /** write sail Radial gores */
    put(e, d.nbGores, "nbGores");

    /** write sail Luff gores */
    put(e, d.nbLuffGores, "nbLuffGores");

    /** write sail Wing dihedral angle */
    put(e, d.dihedralDeg, "dihedralDeg");

    /** write sail Foot hem width */
    put(e, d.footHemW, "footHemW");

    /** NOTE: write here below future new elements of sail */
    //
    put(e, d.footPanelSections, "footPanelSections");
    put(e, d.splitPanelNos, "splitPanelNos");
    put(e, d.speedSeamLeechHeight, "speedSeamLeechHeight");

    put(e, d.filletPanelWidth, "filletPanelWidth");
    put(e, d.speedPanelWidth, "speedPanelWidth");
    put(e, d.generateSpeedSeam, "generateSpeedSeam");
    put(e, d.lensFoot, "lensFoot");
    put(e, d.footEdgeAtZeroZ, "footEdgeAtZeroZ");
    //put(e, d.headPanelLeechDistance, "headPanelLeechDistance");
    //put(e, d.headPanelLeechDistanceFrom, "headPanelLeechDistanceFrom");
    //put(e, d.headPanelLuffDistance, "headPanelLuffDistance");
    //put(e, d.headPanelLuffDistanceFrom, "headPanelLuffDistanceFrom");;

    put(e, d.printBottomSeam, "printBottomSeam");
    put(e, d.luffTapeDistance, "luffTapeDistance");
    put(e, d.footTapeDistance, "footTapeDistance");
    put(e, d.straightLineLeech, "straightLineLeech");
    put(e, d.clothAlignsWithLeech, "clothAlignsWithLeech");
    put(e, d.leechTurnPos, "leechTurnPos");
    put(e, d.radialHead, "radialHead");;

    put(e, d.interpolMethod, "interpolMethod");
    put(e, d.interpol2Strength, "interpol2Stength");
    put(e, d.interpol2RP, "interpol2RP");

    put(e, d.crossMeasurementType, "crossMeasurementType");

    put (e, d.battenGroup, "battenGroup");

    put(e, d.profileSubType, "profileSubType");

    put(e, d.luffOffset, "luffOffset");
    put(e, d.luffOffsetRP, "luffOffsetRP");
    put(e, d.bottomPanelHeight, "bottomPanelHeight");
    put(e, d.panelWidthAdjustments, "panelWidthAdjustments");
    // notes
    put(e, d.notes, "notes");
    // batten hollow
    put(e, d.battenHollowPC, "battenHollowPC");
    // patches
    QDomElement e1 = createElement("Patches","patches");
    e.appendChild(e1);

    put_vector(e1, d.patches, "patch");

    put(e, d.window1, "window1");
    put(e, d.window2, "window2");

    put(e, d.curvedSpeedSeam, "curvedSpeedSeam");

}


/** Puts a CSide sail side to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CSide &s, const QString &name )
{
    QDomElement e = createElement("CSide",name);
    parent.appendChild(e);

    put_vector(e, s, "point");
}


/** Puts a CPanel sail panel to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CPanel &p, const QString &name )
{
    QDomElement e = createElement("CPanel",name);
    parent.appendChild(e);

    put(e, p.left, "left");
    put(e, p.top, "top");
    put(e, p.right, "right");
    put(e, p.bottom, "bottom");

    put(e, p.hasHems, "hasHems");

    if (p.hasHems)
    {
        put(e, p.cutLeft, "cutLeft");
        put(e, p.cutTop, "cutTop");
        put(e, p.cutRight, "cutRight");
        put(e, p.cutBottom, "cutBottom");
    }

    if (p.bottomSeam[0] != p.bottom[0]) {
        put(e, p.bottomSeam, "bottomSeam");
    }

    if (p.footTape[0] != p.bottom[0]) {
        put(e, p.footTape, "footTapeDistance");
    }

    if (p.luffTape[0] != p.left[0]) {
        put(e, p.luffTape, "luffTapeDistance");
    }

    if (p.aftBattenPoints.size() >0) {
        put(e, p.aftBattenPoints, "aftBattenPoints");
    }

    if (p.aftBattenHemPoints.size() >0) {
        put(e, p.aftBattenHemPoints, "aftBattenHemPoints");
    }

}


/** Puts a CPanelGroup to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CPanelGroup &g, const QString &name )
{
    QDomElement e = createElement("CPanelGroup",name);
    parent.appendChild(e);

    put_vector(e, g, "panel");
    put(e, g.title, "title");
    put_vector(e, g.child, "child");
    put(e, g.type, "type");
}


/** Puts a CProfile sail profile to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CProfile &p, const QString &name )
{
    QDomElement e = createElement("CProfile",name);
    parent.appendChild(e);

    put(e, p.getDepth(), "depth");
    put(e, p.getLeech(), "kleech");
    put(e, p.getLuff(), "kluff");
}

/** Puts a CProfile sail profile to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const struct Patch &p, const QString &name )
{
    QDomElement e = createElement("Patch",name);
    parent.appendChild(e);

    put(e, p.baseDimension, "baseDimension");
    put(e, p.dimension1, "dimension1");
    put(e, p.dimension2, "dimension2");
    put(e, p.numSections, "numSections");
    put(e, p.overlap, "overlap");
    put(e, p.patchStyle, "patchStyle");
    put(e, p.patchType, "patchType");
    put(e, p.underPatches, "underPatches");
    put(e, p.luffHeight, "luffHeight");
    put(e, p.leechHeight, "leechHeight");

}


/** Puts a CSailMould sail mould to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CSailMould &m, const QString &name )
{
    QDomElement e = createElement("CSailMould",name);
    parent.appendChild(e);

    put(e, m.vertpos, "vertpos");
    put(e, m.bottomDepth, "bottomDepth");
    put_vector(e, m.profile, "profile");
}


/** Put a CBoatDef boat definition to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CBoatDef &d, const QString &name )
{
    QDomElement e = createElement("CBoatDef",name);
    parent.appendChild(e);

    put_vector(e, d, "element");
}


/** Put a CBoatElement elements of a boat (sail, hull, rig) to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CBoatElement &s, const QString &name )
{
    QDomElement e = createElement("CBoatElement",name);
    parent.appendChild(e);

    put(e, s.filename, "filename");
    put(e, s.type, "type");
    put(e, s.origin, "origin");
    put(e, (CPanelGroup&)s, "panelgroup");
}


/** Puts a CPrefs preferences to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CPrefs& p, const QString& name)
{
    QDomElement e = createElement("CPrefs",name);
    parent.appendChild(e);

    put(e, p.language, "language");
    put_vector(e, p.mruDocuments, "mruDocuments");
    put(e, p.mainWindowHeight, "mainWindowHeight");
    put(e, p.mainWindowWidth, "mainWindowWidth");
}


/** Puts a CRigDef rig definition to an XML document.
 */
void CSailDoc::put(QDomNode &parent, const CRigDef &d, const QString &name )
{
    QDomElement e = createElement("CRigDef",name);
    parent.appendChild(e);

    put(e, d.rigID, "rigID");

    /** write rig fore triangle */
    put(e, d.foreI, "foreI");
    put(e, d.foreJ, "foreJ");
    /** write rig mast data*/
    put(e, d.MHeight, "MHeight");
    put(e, d.MCord, "MCord");
    put(e, d.MWidth, "MWidth");
    put(e, d.MRakeM, "MRakeM");
    put(e, d.MRakeD, "MRakeD");
    put(e, d.MBase, "MBase");
    put(e, d.MRnd, "MRnd");
    put(e, d.MRndPos, "MRndPos");
    /** write rig shrouds data */
    put(e, d.CSH, "CSH");
    put(e, d.CSB, "CSB");
    put(e, d.LSB, "LSB");
    /** write rig spreaders data */
    put(e, d.SPNB, "SPNB");
    put(e, d.SPH[0], "SPH0");
    put(e, d.SPH[1], "SPH1");
    put(e, d.SPH[2], "SPH2");
    put(e, d.SPH[3], "SPH3");
    put(e, d.SPW[0], "SPW0");
    put(e, d.SPW[1], "SPW1");
    put(e, d.SPW[2], "SPW2");
    put(e, d.SPW[3], "SPW3");
    /** write rig mainsail data */
    put(e, d.BAD, "BAD");
    put(e, d.HAD, "HAD");
    //
}


/** Writes the CSailDoc document to file.
 *
 * @throws an exception if writing failed.
 */
void CSailDoc::toFile(const QString &filename)
{
    QFile f( filename );

    if ( !f.open(QIODevice::WriteOnly) )
        throw write_error("CSailDoc::toFile : cannot open file for write access!");

    f.write(toByteArray());
    f.close();
}

void CSailDoc::get (const QDomNode &parent, CBattenGroup &g, const QString &name ) {
    QDomElement e = findElement( parent, "CBattenGroup", name);

    QDomNamedNodeMap attr = e.attributes();
    int n = attr.namedItem("value").nodeValue().toInt();

    for (int i=0; i<n; i++) {
        CBatten b = CBatten();
        get(e, b, QString::number(i));
        g.addBatten(b);
    }
}

void CSailDoc::get (const QDomNode &parent, CBatten &b, const QString &name ) {
    QDomElement e = findElement( parent, "CBatten", name);

    get(e, b.name, "name");
    get(e, b.percentHeight, "percentHeight");
    get(e, b.battenLength, "battenLength");
    b.fullLength = b.battenLength == 0;
    try {
        get(e, b.angle, "angle");
    } catch (doc_element_error const&) {
        int a = 0;
        get(e, a, "angle");
        b.angle = double(a);
    }

    b.inwardOffset = 0;
    try {
        get(e, b.inwardOffset, "inwardOffset");
    } catch (doc_element_error const&) {
        // swallow exception
    }

}

void CSailDoc::put(QDomNode &parent, const CBattenGroup &g, const QString &name) {
    int n = g.numBattens();
    if (n > 0) {
        QDomElement e = createElement("CBattenGroup",name, QString::number(n));
        parent.appendChild(e);

        for (int i=0; i< n; i++) {
            put(e, (const_cast<CBattenGroup&>(g)).getBatten(i), QString::number(i));
        }
    }
}

void CSailDoc::put(QDomNode &parent, const CBatten &b, const QString &name) {
    QDomElement e = createElement("CBatten",name);
    parent.appendChild(e);

    put(e, b.name, "name");
    put(e, b.percentHeight, "percentHeight");
    put(e, b.fullLength ? 0 : b.battenLength, "battenLength");
    put(e, b.angle, "angle");
    put(e, b.inwardOffset, "inwardOffset");
}

void CSailDoc::put(QDomNode &parent, const CBattenPoints &d, const QString &name ) {
    QDomElement e = createElement("CBattenPoints",name);
    parent.appendChild(e);

    put_vector(e, d, "battenPoint");
}

void CSailDoc::put(QDomNode &parent, const battenPoint &b, const QString &name ) {
    QDomElement e = createElement("battenPoint",name);
    parent.appendChild(e);
    put(e, b.battenId, "battenId");
    put(e, b.point, "point");
}
