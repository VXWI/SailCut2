#ifndef PATCHWIDGET_H
#define PATCHWIDGET_H


#include <QGroupBox>
#include "sailcpp/patchdefs.h"
#include "sailcpp/sailcalc.h"

enum enumPatchWidgetDisplayStyle {PATCH_WIDGET_DISPLAY_STYLE_ALL, PATCH_WIDGET_DISPLAY_STYLE_PLAIN,
                                   PATCH_WIDGET_DISPLAY_STYLE_FAN, PATCH_WIDGET_DISPLAY_STYLE_REEF_FAN};

namespace Ui {
class PatchWidget;
}

class PatchWidget : public QGroupBox
{
    Q_OBJECT

public:
    explicit PatchWidget(QWidget *parent = nullptr);
    ~PatchWidget();

    void setDisplayStyle(enum enumPatchWidgetDisplayStyle);
    void hideDimension2(void);
    void setDimension1Title(std::string s);
    void setDimension2Title(std::string s);
    void setValues(struct Patch);
    struct Patch getValues(void);
    bool check(void);
    bool generate(void);
    void setGenerate(bool);

private:
    Ui::PatchWidget *ui;
    struct Patch data;
};

#endif // PATCHWIDGET_H
