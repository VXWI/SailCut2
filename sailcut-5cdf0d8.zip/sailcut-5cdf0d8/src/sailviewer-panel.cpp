/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include <stdio.h>
#include "batteninfodialog.h"
#include "camberinfodialog.h"
#include "broadseamsinfodialog.h"
#include "sailviewer-panel.h"
#include "sailcpp/panelgroup.h"

//#include <QApplication>
//#include <QGroupBox>
//#include <QLabel>
//#include <QLayout>
//#include <QPushButton>
//#include <QString>
//#include <QMessageBox>


/**
 * Constructs a CSailViewerPanel object.
 *
 * @param parent The parent widget
 * @param viewMode The viewing mode (shaded or wireframe)
 * @param show_sliders Should the elevation and azimuth sliders be displayed?
 * @param show_labeling Should the "Labeling" button be displayed?
 */
CSailViewerPanel::CSailViewerPanel(QWidget *parent, enumViewMode viewMode, bool show_sliders, bool show_labeling)
        : QWidget(parent), showSliders(show_sliders)
{

    /* parameters groupbox */
    if (showSliders)
    {
        /* display parameters groupbox */
        grpParams = new QGroupBox( this );
        QGridLayout* grpParamsLayout = new QGridLayout( grpParams );
        lblAzimuthStatic = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblAzimuthStatic, 0, 0 );
        lblAzimuth = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblAzimuth, 0, 1 );
        lblElevationStatic = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblElevationStatic, 1, 0 );
        lblElevation = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblElevation, 1, 1 );
        lblRollStatic = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblRollStatic, 2, 0 );
        lblRoll = new QLabel( grpParams );
        grpParamsLayout->addWidget( lblRoll, 2, 1 );

    }
    else
    {
        grpParams = NULL;
        lblAzimuthStatic = NULL;
        lblAzimuth = NULL;
        lblElevationStatic = NULL;
        lblElevation = NULL;
        lblRoll = NULL;
        lblRollStatic = NULL;
    }

    /* the drawing area */
    sailView = new CSailViewer(this, viewMode, showSliders);
    sailView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    /* controls groupbox */
    grpControls = new QGroupBox( this );
    QVBoxLayout *grpControlsLayout = new QVBoxLayout( grpControls );

    btnResetView = new QPushButton( grpControls );
    grpControlsLayout->addWidget( btnResetView );
    btnZoomIn = new QPushButton( grpControls );
    grpControlsLayout->addWidget( btnZoomIn );
    btnZoomOut = new QPushButton( grpControls );
    grpControlsLayout->addWidget( btnZoomOut );
    if (viewMode == WIREFRAME && show_labeling)
    {
        btnLabeling = new QPushButton( grpControls );
        grpControlsLayout->addWidget( btnLabeling );
    }
    else
    {
        btnLabeling = NULL;
    }
    if (viewMode == WIREFRAME || viewMode == SHADED) {
        btnBattens = new QPushButton( grpControls );
        grpControlsLayout->addWidget( btnBattens );
        btnCambers = new QPushButton( grpControls );
        grpControlsLayout->addWidget( btnCambers );
        btnBroadseams = new QPushButton( grpControls );
        grpControlsLayout->addWidget( btnBroadseams );

        if (!show_sliders) {
            btnPanelDimensions = new QPushButton( grpControls );
            grpControlsLayout->addWidget( btnPanelDimensions );
        } else {
            btnPanelDimensions = NULL;
        }
    } else {
        btnCambers = NULL;
        btnBattens = NULL;
        btnBroadseams = NULL;
    }


    /* put it all together */
    QHBoxLayout *layout = new QHBoxLayout( this );
    layout->addWidget( sailView );

    QVBoxLayout *vbox = new QVBoxLayout();
    vbox->addWidget( grpControls );
    vbox->addItem( new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding) );
    if (showSliders)
    {
        vbox->addWidget( grpParams );
    }
    layout->addLayout( vbox );

    QList<QPushButton *> buttonsList = this->findChildren<QPushButton *>();
    for (int i = 0; i < buttonsList.count(); i++){
        buttonsList.at(i)->setStyleSheet(QString::fromUtf8("QPushButton:disabled { color: lightGray }"));
    }

    /* set language */
    connect(qApp, SIGNAL(languageChanged()),
            this, SLOT(languageChange()));
    changeLanguage(); //languageChange();

    /* connect signals */
    connect( sailView, SIGNAL( azimuthChanged(real) ), this, SLOT(slotAzimuth(real)) );
    connect( sailView, SIGNAL( elevationChanged(real) ), this, SLOT(slotElevation(real)) );
    connect( sailView, SIGNAL( rollChanged(real) ), this, SLOT(slotRoll(real)) );

    if (btnLabeling)
    {
        connect( (QWidget*) btnLabeling, SIGNAL( clicked() ), sailView, SLOT( slotLabeling() ));
    }
    connect( (QWidget*) btnResetView, SIGNAL( clicked() ), sailView, SLOT( slotResetView() ));
    connect( (QWidget*) btnZoomIn, SIGNAL( clicked() ), sailView, SLOT( slotZoomIn() ));
    connect( (QWidget*) btnZoomOut, SIGNAL( clicked() ), sailView, SLOT( slotZoomOut() ));
    if (viewMode == WIREFRAME || viewMode == SHADED) {
        connect( (QWidget*) btnCambers, SIGNAL( clicked() ), this, SLOT( slotCambers() ));
        connect( (QWidget*) btnBattens, SIGNAL( clicked() ), this, SLOT( slotBattens() ));
        connect( (QWidget*) btnBroadseams, SIGNAL( clicked() ), this, SLOT( slotBroadseams()) );
        if (!show_sliders) {
            connect( (QWidget*) btnPanelDimensions, SIGNAL( clicked() ), this, SLOT( slotPanelDimensions()) );
        }
    }
}


/**
 * We received a keypress, we pass it down to the CSailViewer.
 */
void CSailViewerPanel::keyPressEvent ( QKeyEvent * e )
{
    sailView->keyPressEvent(e);
}


/**
 * Sets the strings of the subwidgets using the current language.
 */
void CSailViewerPanel::languageChange() {
    changeLanguage();
}

void CSailViewerPanel::changeLanguage(){
    if (showSliders)
    {
        grpParams->setTitle( tr( "Display parameters" ) );
        lblElevationStatic->setText( tr( "elevation" ) );
        lblAzimuthStatic->setText( tr( "azimuth" ) );
        lblRollStatic->setText( tr( "roll" ) );
    }
    grpControls->setTitle( tr( "Controls" ) );
    btnResetView->setText( tr( "Reset view" ) );
    if (btnLabeling)
    {
        btnLabeling->setText( tr( "Labelling" ) );
    }
    btnZoomIn->setText( tr( "Zoom in" ) );
    btnZoomOut->setText( tr( "Zoom out" ) );

    if (btnBattens) {
        btnBattens->setText(tr("Batten Info."));
    }

    if (btnCambers) {
        btnCambers->setText( tr( "Cambers" ) );
    }
    if (btnBroadseams) {
        btnBroadseams->setText(tr("Broadseam Info."));
    }

    if (btnPanelDimensions) {
        btnPanelDimensions->setText(tr("Panel Dimensions"));
    }
}


/**
 * Change the displayed object.
 *
 * @param obj the new object to display
 */
void CSailViewerPanel::setObject(const CPanelGroup &obj)
{
    sailView->setObject(obj);
    data = obj;
}


/**
 * The azimuth was changed, update the corresponding label.
 *
 * @param azimuth
 */
void CSailViewerPanel::slotAzimuth(real azimuth)
{
    if (lblAzimuth)
    {
        lblAzimuth->setText(QString::number(azimuth) + " " +tr("deg"));
    }
}


/**
 * The elevation changed, update the corresponding label.
 *
 * @param elevation
 */
void CSailViewerPanel::slotElevation(real elevation)
{
    if (lblElevation)
    {
        lblElevation->setText(QString::number(elevation) + " " +tr("deg"));
    }
}

/**
 * The roll changed, update the corresponding label.
 *
 * @param roll
 */
void CSailViewerPanel::slotRoll(real roll)
{
    if (lblRoll)
    {
        lblRoll->setText(QString::number(roll) + " " +tr("deg"));
    }
}



void CSailViewerPanel::slotCambers() {
    CamberInfoDialog(this, camberArray).exec();
}

void CSailViewerPanel::setCambers(camberAtHeight *cambers, vector<CSide> stripes) {
    if (cambers != NULL) {
        for (int i=0; i<NUM_CAMBER_POINTS; i++) {
            camberArray[i].height = cambers[i].height;
            camberArray[i].baseCamber = cambers[i].baseCamber;
            camberArray[i].baseCamberMM = cambers[i].baseCamberMM;
            camberArray[i].combinedCamber = cambers[i].combinedCamber;
            camberArray[i].combinedCamberMM = cambers[i].combinedCamberMM;
            camberArray[i].arcLength = cambers[i].arcLength;
            camberArray[i].maxPos = cambers[i].maxPos;
            camberArray[i].chordLength = cambers[i].chordLength;
            camberArray[i].sailHeight = cambers[i].sailHeight;
        }

        if (showSliders)
            sailView->setCamberStripes(stripes);
    }

    if (btnCambers != NULL) {
        btnCambers->setEnabled(cambers != NULL);
    }
}

void CSailViewerPanel::slotBattens() {
    CBattenInfoDialog(this, battenGroup).exec();
}

void CSailViewerPanel::setBattenGroup(CBattenGroup & bg) {
    if (bg.numBattens() > 0) {
        battenGroup.updateAll(bg);
    }

    if (btnBattens != NULL) {
        btnBattens->setEnabled(bg.numBattens() != 0);
    }
}

void CSailViewerPanel::slotBroadseams() {
    BroadseamsInfoDialog(this, broadseams).exec();
}

void CSailViewerPanel::slotPanelDimensions() {
    PanelDimensionsDialog(this, data).exec();
}

void  CSailViewerPanel::setBroadseaminfo(vector<broadseamInfo> broadseams) {
    if (btnBroadseams != NULL) {
        btnBroadseams->setEnabled(broadseams.size() != 0);
        this->broadseams = broadseams;
    }
}
