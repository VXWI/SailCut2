/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef SAILVIEWER_PANEL_H
#define SAILVIEWER_PANEL_H

#include <QApplication>
#include <QGroupBox>
#include <QLabel>
#include <QLayout>
#include <QPushButton>
#include <QString>
#include <QMessageBox>
#include "sailviewer.h"
#include "sailcpp/camberStruct.h"
#include "sailcpp/battengroup.h"
#include "sailcpp/broadseamsStruct.h"
#include "paneldimensionsdialog.h"

// forward definitions
class QGroupBox;
class QLabel;
class QPushButton;


/** The main dialog of the Sailcut application.
 */
class CSailViewerPanel : public QWidget
{
    Q_OBJECT

public:
    CSailViewerPanel(QWidget *parent, const enumViewMode viewMode, bool show_sliders, bool show_labeling = true);

    void setObject(const CPanelGroup &obj);
    void keyPressEvent ( QKeyEvent * e );
    void setCambers(camberAtHeight *cambers, vector<CSide> s);
    void setBattenGroup(CBattenGroup&);
    void setBroadseaminfo(vector<broadseamInfo> broadseams);

    // slots
public slots:
    virtual void languageChange();
    virtual void slotAzimuth(real azimuth);
    virtual void slotElevation(real azimuth);
    virtual void slotRoll(real roll);
    virtual void slotCambers();
    virtual void slotBattens();
    virtual void slotBroadseams();
    virtual void slotPanelDimensions();

    // member variables
protected:
    void changeLanguage();
    /** groupbox for parameters */
    QGroupBox* grpParams;
    /** label for current azimuth */
    QLabel* lblAzimuth;
    /** label for current elevation */
    QLabel* lblElevation;
    /** label for current roll */
    QLabel* lblRoll;
    /** static label saying "elevation" */
    QLabel* lblElevationStatic;
    /** static label saying "azimuth" */
    QLabel* lblAzimuthStatic;
    /** label for current roll saying "roll" */
    QLabel* lblRollStatic;
    /** groupbox for the view controls */
    QGroupBox* grpControls;
    /** Reset View button */
    QPushButton* btnResetView;
    /** Labeling button */
    QPushButton* btnLabeling;
    /** Zoom In button */
    QPushButton* btnZoomIn;
    /** Zoom Out button */
    QPushButton* btnZoomOut;
    /** Cambers button */
    QPushButton* btnCambers;
    /** Battens button */
    QPushButton* btnBattens;
    /** Broadseams button */
    QPushButton* btnBroadseams;
    QPushButton* btnPanelDimensions;

    /** display area for the 3d sail */
    CSailViewer *sailView;

private:
    bool showSliders;
    camberAtHeight camberArray[NUM_CAMBER_POINTS];
    vector<CSide> camberStripes;
    CBattenGroup battenGroup;
    vector<broadseamInfo> broadseams;
    CPanelGroup data;
};

#endif
