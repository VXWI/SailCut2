/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "sailwriter-dxf.h"
#include <QFile>
#include "ui_formdxfparams.h"

CFormDxfParams::CFormDxfParams( QWidget *parent, struct DxfParams *p) : QDialog(parent) {
    setupUi(this);
    setModal(true);

    params = p;

    for (unsigned int i=0; i< 8; i++) {
        cbDrawColour->addItem((colours[i]));
        cbTextColour->addItem((colours[i]));
        cbCutColour->addItem((colours[i]));
    }
    cbDrawColour->setCurrentIndex(5); // Blue
    cbTextColour->setCurrentIndex(5); // Blue
    cbCutColour->setCurrentIndex(1); // Red

    sbFontSize->setRange(7,15);
    sbFontSize->setSingleStep(1);
    sbFontSize->setValue(9);

    sbDrawLayer->setRange(0,10);
    sbDrawLayer->setSingleStep(1);
    sbDrawLayer->setValue(0);

    sbCutLayer->setRange(0,10);
    sbCutLayer->setSingleStep(1);
    sbCutLayer->setValue(1);

    panelPrefixLineEdit->setText("");
    printAllLeechCheckBox->setChecked(false);
    if (!p->isGaffSail) {
        printThroatPointCheckBox->hide();
        p->DxFPrintThoatPoint = false;
    }
    ;
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);

}

bool CFormDxfParams::check() {
    params->DxfDrawColour = QString::number(cbDrawColour->currentIndex());
    params->DxfTextColour = QString::number(cbTextColour->currentIndex());
    params->DxfCutColour = QString::number(cbCutColour->currentIndex());

    params->DxfFontSize = sbFontSize->value();
    params->DxfDrawLayer = sbDrawLayer->value();
    params->DxfCutLayer = sbCutLayer->value();

    params->DxfPanelPrefix = panelPrefixLineEdit->text();
    params->DxfPrintAllLeech = printAllLeechCheckBox->isChecked();
    params->DxfExportTopPatches = exportTopPatchesCheckBox->isChecked();
    params->DxfExportUnderPatches = exportUnderpatchesCheckBox->isChecked();

    if (params->isGaffSail) {
        params->DxFPrintThoatPoint = printThroatPointCheckBox->isChecked();
    }

    return true;
}

void CFormDxfParams::accept() {
    if (check()) {
        QDialog::accept();

    }
}

/***********************************

           DXF components

***********************************/

/** Write a DXF atom to the file output stream.
 *
 * @param out the output stream
 * @param code atom code
 * @param content atom content
 */
void CSailDxfWriter::writeAtom(ofstream &out, int code, const QString& content) const
{
    out << code << endl << string(content.toLocal8Bit()) << endl;
}


/** Open the given file, then write comment and header section.
 *
 * @param out the output stream
 * @param filename the output file name
 */
void CSailDxfWriter::writeBegin(ofstream &out, const QString &filename) const
{
    out.open(QFile::encodeName(filename),ios::out);
    if (!out.is_open())
        throw write_error("CSailDxfWriter::writeBegin : unable to write to specified file");

    // write comment
    writeAtom(out, DXF_COMMENT, "DXF created by Sailcut CAD");

    // write header section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "HEADER");
    writeAtom(out, DXF_ENTITY, "ENDSEC");
}


/** Write end of file then close file.
 *
 * @param out the output stream
 */
void CSailDxfWriter::writeEnd(ofstream &out) const
{
    writeAtom(out, DXF_ENTITY, "EOF");
    out.close();
}


/** Write a triangular face to the file output stream.
 *
 * @param out the output stream
 * @param p0 first point
 * @param p1 second point
 * @param p2 third point
 * @param layer
 */
void CSailDxfWriter::writeFace(ofstream &out, CPoint3d p0, CPoint3d p1, CPoint3d p2, unsigned int layer) const
{
    // skip empty face
    real area = CVector3d(p1 -p0).cross(p2 - p0).norm();
    //cout << "area : " << area << endl;
    if ( area < EPS )
    {
        cout << "CSailDxfWriter::writeFace : skipping empty face" << endl;
        return;
    }

    writeAtom(out, DXF_ENTITY, "3DFACE");
    // set the layer
    writeAtom(out, DXF_LAYER, QString::number(layer));
    // set the points
    writeAtom(out, DXF_X, QString::number(p0.x()));
    writeAtom(out, DXF_Y, QString::number(p0.y()));
    writeAtom(out, DXF_Z, QString::number(p0.z()));

    writeAtom(out, DXF_X + 1, QString::number(p1.x()));
    writeAtom(out, DXF_Y + 1, QString::number(p1.y()));
    writeAtom(out, DXF_Z + 1, QString::number(p1.z()));

    writeAtom(out, DXF_X + 2, QString::number(p2.x()));
    writeAtom(out, DXF_Y + 2, QString::number(p2.y()));
    writeAtom(out, DXF_Z + 2, QString::number(p2.z()));

    // duplicate last point for stupid AutoCAD
    writeAtom(out, DXF_X + 3, QString::number(p2.x()));
    writeAtom(out, DXF_Y + 3, QString::number(p2.y()));
    writeAtom(out, DXF_Z + 3, QString::number(p2.z()));
}


/** Write a DXF layer to the file output stream.
 *
 * @param out the output stream
 * @param layer
 * @param color the color
 */
void CSailDxfWriter::writeLayer(ofstream &out, unsigned int layer, const QString &color) const
{
    writeAtom(out, DXF_ENTITY, "LAYER");
    writeAtom(out, DXF_NAME, QString::number(layer));
    writeAtom(out, DXF_FLAG, "64");
    writeAtom(out, DXF_COLOR, color);
    writeAtom(out, DXF_LINE, "CONTINUOUS");
}


/** Write a DXF Polyline header to the file output stream.
 *
 * @param out the output stream
 * @param layer
 * @param color the color
 */
void CSailDxfWriter::writePolyline(ofstream &out, unsigned int layer, const QString &color) const
{
    writeAtom(out, DXF_ENTITY, "POLYLINE");
    // set the layer
    writeAtom(out, DXF_LAYER, QString::number(layer));
    // set color
    writeAtom(out, DXF_COLOR, color);
    // set vertice follows flag
    writeAtom(out, 66, "1");
    // set line type
    writeAtom(out, DXF_LINE, "CONTINUOUS");
}


/** Write a 2D DXF Vertex to the file output stream.
 *
 * @param out the output stream
 * @param pt point
 * @param layer
 */
void CSailDxfWriter::writeVertex(ofstream &out, CPoint3d pt, unsigned int layer) const
{
    writeAtom(out, DXF_ENTITY, "VERTEX");
    // set the layer
    writeAtom(out, DXF_LAYER, QString::number(layer));
    // set 3D flag
    //writeAtom(out, DXF_FLAG, "32"); // flag 3D vertex

    // set the points
    writeAtom(out, DXF_X, QString::number(pt.x()));
    writeAtom(out, DXF_Y, QString::number(pt.y()));
    //writeAtom(out, DXF_Z, QString::number(pt.z())); // for 3D
}

void CSailDxfWriter::writeText(ofstream &out, CPoint3d p, const QString& text, int textSize, unsigned int layer, real rotation) const {
    writeAtom(out, DXF_ENTITY, "TEXT");
    // set the layer
    writeAtom(out, DXF_LAYER, QString::number(layer));
    // x coord
    writeAtom(out, DXF_X, QString::number(p.x()));
    // y coord
    writeAtom(out, DXF_Y, QString::number(p.y()));
    // z coord
    writeAtom(out, DXF_Z, QString::number(layer));
   // text height
    writeAtom(out, DXF_TEXTHEIGHT, QString::number(textSize));
    // text rotation
    writeAtom(out, DXF_TEXT_ROTATION, QString::number(rotation));
    // set text
    writeAtom(out, DXF_TEXTSTRING, text);

}

/***********************************

           2D DXF export

***********************************/


CSailDxfWriter2d::CSailDxfWriter2d(enum Dxf2dType format, struct DxfParams *p) : type(format) {
    DxfDrawLayer = p->DxfDrawLayer;
    DxfCutLayer =  p->DxfCutLayer;
    DxfDrawColour = p->DxfDrawColour;
    DxfCutColour = p->DxfCutColour;
    DxfTextColour = p->DxfTextColour;
    DxFPanelPrefix = p->DxfPanelPrefix;
    DxfFontSize = p->DxfFontSize;
    DxfPrintAllLeech = p->DxfPrintAllLeech;
    DxfExportTopPatches = p->DxfExportTopPatches;
    DxfExportUnderPatches = p->DxfExportUnderPatches;
    DxFPrintThoatPoint = p->DxFPrintThoatPoint;


};

void CSailDxfWriter2d::writeDxf(const CPanelGroup &sail, const QString &filename, const DxfParams *params) const {

    DxfDrawLayer = params->DxfDrawLayer;
    DxfCutLayer = params->DxfCutLayer;
    DxfDrawColour = params->DxfDrawColour;
    DxfCutColour = params->DxfCutColour;
    DxfTextColour = params->DxfTextColour;
    DxfPrintAllLeech = params->DxfPrintAllLeech;

    write(sail, filename);
}


/** Writes a CPanelGroup to a simple DXF file.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter2d::write(const CPanelGroup &sail, const QString &filename) const
{

    switch (type)
    {
    case NORMAL:
        writeNormal(sail, filename);
        break;
    case BLOCKS:
        writeBlocks(sail, filename);
        break;
    case SPLIT:
        writeSplit(sail, filename);
        break;
    }
}

/** Writes a CPanelGroup to a simple 2D DXF file, one panel per layer.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter2d::writeNormal(const CPanelGroup &sail, const QString &filename) const
{
    ofstream out;
    unsigned int pn;

    // open file, write comment and header
    writeBegin(out, filename);

    // write tables section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "TABLES");
    writeAtom(out, DXF_ENTITY, "TABLE");
    writeAtom(out, DXF_NAME, "LAYER");
    writeAtom(out, DXF_FLAG, "6");

    for (pn = 0; pn < sail.size(); pn++)
        writeLayer(out, pn+1, DXF_GREEN);

    writeAtom(out, DXF_ENTITY, "ENDTAB");
    writeAtom(out, DXF_ENTITY, "ENDSEC");

    // write entities section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "ENTITIES");

    // loop over panels ////////
    for (pn = 0; pn < sail.size(); pn++)
        writePanel(out, sail[pn], pn+1, pn+1, pn);

    writeAtom(out, DXF_ENTITY, "ENDSEC");

    // end of file
    writeEnd(out);
}


/** Writes a CPanelGroup to a 2D DXF file with one block per panel on different layer.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter2d::writeBlocks(const CPanelGroup &sail, const QString &filename) const
{
    ofstream out;
    unsigned int pn;

    // open file, write comment and header
    writeBegin(out, filename);

    // write tables section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "TABLES");
    writeAtom(out, DXF_ENTITY, "TABLE");
    writeAtom(out, DXF_NAME, "LAYER");
    writeAtom(out, DXF_FLAG, "16");
    for (pn = 0; pn < sail.size(); pn++)
        writeLayer(out, pn+1, DXF_GREEN);
    writeAtom(out, DXF_ENTITY, "ENDTAB");
    writeAtom(out, DXF_ENTITY, "ENDSEC");

    // write entities section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "BLOCKS");
    for (pn = 0; pn < sail.size(); pn++)
    {
        writeAtom(out, DXF_ENTITY, "BLOCK");
        writeAtom(out, 100, "AcDbEntity");
        writeAtom(out, DXF_LAYER, QString::number(pn+1));
        writeAtom(out, 100, "AcDbBlockBegin");
        writeAtom(out, DXF_NAME, "panel "+QString::number(pn+1));
        writeAtom(out, DXF_FLAG, "1");
        writeAtom(out, DXF_X, "0");
        writeAtom(out, DXF_Y, "0");
        writeAtom(out, DXF_Z, "0");
        writeAtom(out, 3, "panel "+QString::number(pn+1));

        writePanel(out, sail[pn], pn+1, pn+1, pn);

        writeAtom(out, DXF_ENTITY, "ENDBLCK");
        writeAtom(out, 100, "AcDbBlockEnd");
    }
    writeAtom(out, DXF_ENTITY, "ENDSEC"); // end of BLOCKS section

    // end of file
    writeEnd(out);
}


/** Writes a CPanelGroup to a 2D DXF file with one file per panel.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter2d::writeSplit(const CPanelGroup &sail, const QString &basename) const
{
    //cout << "Not implemented yet" << endl;

    ofstream out;
    unsigned int pn;

    for (pn = 0; pn < sail.size(); pn++)
    {
        bool fWriteFile = false;
        QString filename = basename;
        switch (sail[pn].patchType) {
        case PATCH_SPINNAKER_HEAD_UNDERPATCH:
        case PATCH_SPINNAKER_CLEW_UNDERPATCH:
        case PATCH_MAINSAIL_HEAD_UNDERPATCH:
        case PATCH_MAINSAIL_TACK_UNDERPATCH:
        case PATCH_JIB_HEAD_UNDERPATCH:
        case PATCH_JIB_TACK_UNDERPATCH:
        case PATCH_MAINSAIL_THROAT_UNDERPATCH:
            if (DxfExportUnderPatches) {
                filename.replace(".dxf", QString("-UP.dxf"));
                fWriteFile = true;
            }
            break;
        case PATCH_SPINNAKER_HEAD:
        case PATCH_SPINNAKER_CLEW:
        case PATCH_MAINSAIL_HEAD:
        case PATCH_MAINSAIL_CLEW:
        case PATCH_MAINSAIL_TACK:
        case PATCH_MAINSAIL_REEF1:
        case PATCH_MAINSAIL_REEF2:
        case PATCH_MAINSAIL_THROAT:
        case PATCH_JIB_HEAD:
        case PATCH_JIB_CLEW:
        case PATCH_JIB_TACK:
            if (DxfExportTopPatches) {
                filename.replace(".dxf", QString("-P.dxf"));
                fWriteFile = true;
            }
            break;
        default:
            fWriteFile = true;
            break;
        }

        filename.replace(".dxf", QString("-%1.dxf").arg(pn));

        if (fWriteFile) {
            // open file, write comment and header
            writeBegin(out, filename);

            // write tables section
            writeAtom(out, DXF_ENTITY, "SECTION");
            writeAtom(out, DXF_NAME, "TABLES");
            writeAtom(out, DXF_ENTITY, "TABLE");
            writeAtom(out, DXF_NAME, "LAYER");
            writeAtom(out, DXF_FLAG, "6");
            //        writeLayer(out, 1, DXF_CYAN);
            // cout << "DXF_BLACK = " << DXF_BLACK << "  DxfTextColour = " << DxfTextColour.toStdString() << endl;
            if (DxfTextColour != DXF_BLACK)
                writeLayer(out, 0, DxfTextColour);
            //writeLayer(out, 1, DXF_BLACK);
            writeLayer(out, 1, DXF_CYAN);
            writeAtom(out, DXF_ENTITY, "ENDTAB");
            writeAtom(out, DXF_ENTITY, "ENDSEC");

            // write entities section
            writeAtom(out, DXF_ENTITY, "SECTION");
            writeAtom(out, DXF_NAME, "ENTITIES");
            writePanel(out, sail[pn], DxfDrawLayer, DxfCutLayer, pn);
            writeAtom(out, DXF_ENTITY, "ENDSEC");

            // end of file
            writeEnd(out);
        }
    }
}


/** Write a single 2D DXF developed panel draw and cut edges to the file output stream.
 *
 * @param out the output stream
 * @param panel the panel to be written
 * @param layer the layer on which the panel is written
 */
void CSailDxfWriter2d::writePanel(ofstream &out, const CPanel &panel, unsigned int drawLayer, unsigned int cutLayer, unsigned int panelNo) const
{
    //writeAtom(out, DXF_COMMENT, panel.label.name);
    CSide top = panel.top;
    CSide btm = panel.bottom;
    CSide left = panel.left;
    CSide right = panel.right;

    CSide ctop = panel.cutTop;
    CSide cbtm = panel.cutBottom;
    CSide cleft = panel.cutLeft;
    CSide cright = panel.cutRight;

    CPoint3d pt;
    CVector3d V;
    unsigned int i=0;
    int j=0;

    //// polyline header for draw line
//    writePolyline(out, drawLayer, DXF_BLUE);


    if (panel.bPrintLeft) {
        //// polyline header for draw line
        writePolyline(out, drawLayer, DxfDrawColour);
        // left edge
        pt = left[0];
        writeVertex(out, pt, drawLayer);

        for (i = 1; i < left.size(); i++)
        {
            V= left[i] - pt;
            if (V.norm()> EPS)
            {
                pt = left[i];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
    }

    if (panel.bPrintLuffTape) {
        //// polyline header for draw line
        writePolyline(out, drawLayer, DxfDrawColour);
        // luff tape assembly line
        pt = panel.luffTape[0];
        writeVertex(out, pt, drawLayer);

        for (i = 1; i < panel.luffTape.size(); i++)
        {
            V= panel.luffTape[i] - pt;
            if (V.norm()> EPS)
            {
                pt = panel.luffTape[i];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
    }

    //// polyline header for draw line

    if (panel.bPrintTop) {
        writePolyline(out, drawLayer, DxfDrawColour);
        unsigned int iStart = 0;
        // we would only print left if
        // we had a luff hem - very unlikely
        // we''l allow for it
        if (panel.bPrintLeft) {
            iStart = 1;
            pt = top[0];
            writeVertex(out, pt, drawLayer);
        }

        // panel top edge
        for (i = iStart; i < top.size(); i++)
        {
            V = top[i] - pt;
            if (V.norm() > EPS)
            {
                pt = top[i];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
    }

    // right side of panel
    if (panel.bPrintRight) {
        // if right and cut right are different
        if (DxfPrintAllLeech || panel.panelType == PANEL_SPINNAKER_FOOT_LEFT) {
            // draw full right line
            writePolyline(out, drawLayer, DxfDrawColour);
            for (j = right.size()-1; j > - 1; j--) {
                writeVertex(out, right[j], drawLayer);
            }
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        } else if (!panel.isRadialSpinnaker()) {
            // draw panel right edge top and bottom
            writePolyline(out, drawLayer, DxfDrawColour);
            CVector3d v = right[1]-right[0];
            CPoint3d p =  v * (20 / v.norm());
            p = p + right[0];
            writeVertex(out, right[0], drawLayer);
            writeVertex(out, p, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

            writePolyline(out, drawLayer, DxfDrawColour);
            v = right[right.size()-1]-right[right.size()-2];
            p =  v * (20 / v.norm());
            p = right[right.size()-1] - p;
            writeVertex(out, right[right.size()-1], drawLayer);
            writeVertex(out, p, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        }

    }

/*    for (j = right.size()-1; j > - 1; j--)
    {
        V = right[j] - pt;
        if (V.norm() > EPS)
        {
            pt = right[j];
            writeVertex(out, pt, drawLayer);
        }
    }
*/


    // write bottom seam
    if (panel.panelType == PANEL_VERTICAL_LEECH) {
        writePolyline(out, drawLayer, DxfDrawColour);
        // panel bottom edge
        for (j = panel.bottom.size()-1; j > -1; j--)
        {
            V = panel.bottom[j] - pt;
            if (V.norm() > EPS)
            {
                pt = panel.bottom[j];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

    } else if ((panel.bottomSeam[0] - panel.bottom[0]).norm() > .5) {
        //// polyline header for draw line
        writePolyline(out, drawLayer, DxfDrawColour);

        for (j = panel.bottomSeam.size()-1; j > -1; j--)
        {
            V = panel.bottomSeam[j] - pt;
            if (V.norm() > EPS)
            {
                pt = panel.bottomSeam[j];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

    } else if (panel.bPrintBottom ){
        //// polyline header for draw line
        writePolyline(out, drawLayer, DxfDrawColour);
        // panel bottom edge
        for (j = btm.size()-1; j > -1; j--)
        {
            V = btm[j] - pt;
            if (V.norm() > EPS)
            {
                pt = btm[j];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
    }

    if (panel.bPrintFootTape) {
        //// polyline header for draw line
        writePolyline(out, drawLayer, DxfDrawColour);
        // luff tape assembly line
        pt = panel.footTape[panel.footTape.size()-1];
        //writeVertex(out, pt, drawLayer);

        for (j = panel.footTape.size()-1; j > -1; j--)
        {
            V= panel.footTape[j] - pt;
            if (V.norm()> EPS)
            {
                pt = panel.footTape[j];
                writeVertex(out, pt, drawLayer);
            }
        }
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
    }



    // close the circuit to start point
   // pt = left[0];
   // writeVertex(out, pt, layer);


    // aft batten pocket points
    for (unsigned int i=0; i<panel.aftBattenPoints.size(); i++) {
        writePolyline(out, drawLayer, DxfDrawColour);
        pt = panel.aftBattenPoints.at(i).point;
        writeVertex(out, pt, drawLayer);
        pt = CPoint3d(pt.x()-20, pt.y()+7, 0);
        writeVertex(out, pt, drawLayer);
        pt = CPoint3d(pt.x(), pt.y()-14, 0);
        writeVertex(out, pt, drawLayer);
        pt = panel.aftBattenPoints.at(i).point;
        writeVertex(out, pt, drawLayer);
        writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

    }

    //fore batten pocket points
    for (unsigned int i=0; i<panel.foreBattenPoints.size(); i++) {
        if (panel.foreBattenPoints.at(i).bFullLength) {
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.foreBattenPoints.at(i).point;
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+20, pt.y()+7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x(), pt.y()-14, 0);
            writeVertex(out, pt, drawLayer);
            pt = panel.foreBattenPoints.at(i).point;
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        }
    }

    // luff reef points
    for (unsigned int i=0; i<panel.luffReefPoints.size(); i++) {
        if (panel.panelType == PANEL_VERTICAL_LUFF || panel.panelType == PANEL_VERTICAL_LUFF_GAFF ) {
            int n = panel.cutBottom.nearestPointIndex(panel.luffReefPoints.at(i));
            real dist = (panel.luffReefPoints.at(i)-panel.cutBottom[n]).norm();
            int d = int ((dist-5) / 2);
            int yMove = min(d,20);
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.luffReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+7, pt.y()-yMove, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-7, pt.y()-yMove, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-7, pt.y()+yMove, 0);
            writeVertex(out, pt, drawLayer);
            pt = panel.luffReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        } else {
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.luffReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+20, pt.y()+7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+20, pt.y()-7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-20, pt.y()-7, 0);
            writeVertex(out, pt, drawLayer);
            pt = panel.luffReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        }
    }

    // leech reef points
    for (unsigned int i=0; i<panel.leechReefPoints.size(); i++) {
        if (panel.panelType == PANEL_VERTICAL_LEECH) {
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.leechReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-7, pt.y()+20, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+7, pt.y()+20, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+7, pt.y()-20, 0);
            writeVertex(out, pt, drawLayer);
            pt = panel.leechReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        } else {
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.leechReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-20, pt.y()+7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()-20, pt.y()-7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+20, pt.y()-7, 0);
            writeVertex(out, pt, drawLayer);
            pt = panel.leechReefPoints.at(i);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line
        }

    }

    // throat point

    if (DxFPrintThoatPoint) {
        switch (panel.panelType) {
        case PANEL_GAFF_THROAT:
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.throatPoint;
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+20, pt.y(), 0);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line


            pt = CPoint3d(pt.x(), pt.y()+7, 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x(), pt.y()-14, 0);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

            break;
        case PANEL_VERTICAL_LUFF_GAFF:
            writePolyline(out, drawLayer, DxfDrawColour);
            pt = panel.throatPoint;
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x(), pt.y()-20, 0);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

            pt = CPoint3d(pt.x()-7, pt.y(), 0);
            writeVertex(out, pt, drawLayer);
            pt = CPoint3d(pt.x()+14, pt.y(), 0);
            writeVertex(out, pt, drawLayer);
            writeAtom(out, DXF_ENTITY, "SEQEND"); // end draw line

            break;
        default:
            break;
        }
    }

    // panel no
    int xStart, rightIdx;
    if ((ctop.back().x()-ctop.front().x()) < 50) {
        // for the head of a symmetrical spinnaker
        // where top/cutTop are not used
        // in this case we'll come down from the top a bit and print in the cxentre
        xStart = 0;
        rightIdx = ctop.size()-1;
    } else {
        xStart = max(ctop.front().x(),top.front().x());
        double dist = (ctop.front() - ctop.back()).norm();
        double step = dist / real(ctop.size()-1);
        rightIdx = int(ceil(50/step));
    }

    real angle = 0;
    CPoint3d p2;
    QString suffix = "";

    //if (panel.panelType == PANEL_SPINNAKER_TOP) {
    //    // FIXME!!!
    //    int len = (DxFPanelPrefix.length()+1) * DxfFontSize*.8;
    //    p2 = CPoint3d(panel.cutLeft.back().x()-len/2, panel.cutLeft.back().y() - 30, 0);
    //} else {
        // we will probabaly need to rotate the text so that it always prints along top edge
        // base ideal print point
        CPoint3d printPoint, p1;
        CVector3d v1,v2;
        real x,y;

        if (panel.panelType == PANEL_SPINNAKER_TOP || panel.panelType == PANEL_GAFF_TOP || panel.patchType == PATCH_SPINNAKER_HEAD || panel.patchType == PATCH_SPINNAKER_HEAD_UNDERPATCH) {
            // special processing for top panel of gaff sail
            // or spinnaker top patch
            x = cleft[1].x() - cleft.front().x();
            y = cleft[1].y() - cleft.front().y();
            real printY = cleft[0].y()-DxfFontSize - (8.4 *y / x);
            printPoint = CPoint3d(cleft[0].x()+30, printY, 0);
            // a point at left 0 and same y
            p1 = CPoint3d(cleft[0].x(), printY, 0);
            if (panel.patchType == PATCH_SPINNAKER_HEAD || panel.patchType == PATCH_SPINNAKER_HEAD_UNDERPATCH) {
                suffix = "-HP";
            }
        } else if (panel.patchType == PATCH_SPINNAKER_CLEW || panel.patchType == PATCH_SPINNAKER_CLEW_UNDERPATCH) {
            printPoint = CPoint3d(30, cbtm[0].y()+3, 0);
            // a point at left 0 and same y
            p1 = CPoint3d(cbtm[0].x(), cbtm[0].y()+3, 0);
            x = panel.cutBottom.back().x() - panel.cutBottom.front().x();
            y = panel.cutBottom.back().y() - panel.cutBottom.front().y();
            suffix = "-CP";
        } else {
            printPoint = CPoint3d(xStart+5, ctop[0].y()-3-DxfFontSize, 0);
            // a point at left 0 and same y
            p1 = CPoint3d(ctop[0].x(), ctop[0].y()-3-DxfFontSize, 0);
            x = panel.cutTop[rightIdx].x() - panel.cutTop.front().x();
            y = panel.cutTop[rightIdx].y() - panel.cutTop.front().y();
        }
        // make a vector
        v1 = printPoint - p1;
        angle = atan(y/x);
        // rotate vector using angle just calculated
        v2 = CMatrix::rot3d(2, angle)*v1;
        // our actual print point
        p2 = p1 + v2;
    //}

    writeText(out, p2, DxFPanelPrefix+QString::number(panelNo)+suffix, DxfFontSize, DxfDrawLayer, angle*180/PI);


    //// polyline header for cut line
    writePolyline(out, cutLayer, DxfCutColour);

    // left edge
    pt = cleft[0];
    writeVertex(out, pt, cutLayer);

    for (i = 1; i < cleft.size(); i++)
    {
        V= cleft[i] - pt;
        if (V.norm()> EPS)
        {
            pt = cleft[i];
            writeVertex(out, pt, cutLayer);
        }
    }

    // panel top edge
    for (i = 0; i < ctop.size(); i++)
    {
        V = ctop[i] - pt;
        if (V.norm() > EPS)
        {
            pt = ctop[i];
            writeVertex(out, pt, cutLayer);
        }
    }

    // panel right edge
    for (j = cright.size()-1; j > - 1; j--)
    {
        V = cright[j] - pt;
        if (V.norm() > EPS)
        {
            pt = cright[j];
            writeVertex(out, pt, cutLayer);
        }
    }

    // panel bottom edge
    for (j = cbtm.size()-1; j > -1; j--)
    {
        V = cbtm[j] - pt;
        if (V.norm() > EPS)
        {
            pt = cbtm[j];
            writeVertex(out, pt, cutLayer);
        }
    }
    // close the circuit to start point
    pt = cleft[0];
    writeVertex(out, pt, cutLayer);


    writeAtom(out, DXF_ENTITY, "SEQEND"); // end cut line
}



/***********************************

           3D DXF export

***********************************/

/** Writes a 3D CPanelGroup to a 3D DXF file.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter3d::write(const CPanelGroup &sail, const QString &filename) const
{
    switch (type)
    {
    case NORMAL:
        writeNormal(sail, filename);
        break;
    case SPLIT:
        writeSplit(sail, filename);
        break;
    }
}

/** Writes a 3D CPanelGroup to a 3D DXF file with one panel per layer.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter3d::writeNormal(const CPanelGroup &sail, const QString &filename) const
{
    ofstream out;
    unsigned int pn;

    // open file, write comment and header
    writeBegin(out, filename);

    // write tables section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "TABLES");
    writeAtom(out, DXF_ENTITY, "TABLE");
    writeAtom(out, DXF_NAME, "LAYER");
    writeAtom(out, DXF_FLAG, "6");
    for (pn = 0; pn < sail.size(); pn++)
        writeLayer(out, pn + 1, (pn % 2) ? DXF_YELLOW : DXF_CYAN);
    writeAtom(out, DXF_ENTITY, "ENDTAB");
    writeAtom(out, DXF_ENTITY, "ENDSEC");

    // write entities section
    writeAtom(out, DXF_ENTITY, "SECTION");
    writeAtom(out, DXF_NAME, "ENTITIES");
    for (pn = 0; pn < sail.size(); pn++)
        writePanel(out, sail[pn], pn + 1);
    writeAtom(out, DXF_ENTITY, "ENDSEC");

    // end of file
    writeEnd(out);
}


/** Write a single 3D DXF panel to the file output stream.
 *
 * @param out the output stream
 * @param panel the number of the panel to be written
 * @param layer the layer on which the panel is written
 */
void CSailDxfWriter3d::writePanel(ofstream &out, const CPanel &panel, unsigned int layer) const
{
    //writeAtom(out, DXF_COMMENT, panel.label.name);
    //writeAtom(out, DXF_COMMENT, QString("panel : ") + QString::number(panel));
    CSide top = panel.top;
    CSide btm = panel.bottom;
    CSide left = panel.left;
    CSide right = panel.right;
    CPoint3d pt;
    unsigned int i=0;

    // left triangle fan
    pt = (left[0]+left[left.size()-1])*0.5;
    for (i = 1; i < left.size(); i++)
        writeFace(out, pt, left[i-1], left[i], layer);

    // panel triangle strip
    for (i = 1; i < top.size(); i++)
    {
        writeFace(out, top[i-1], btm[i-1], top[i], layer);
        writeFace(out, top[i], btm[i], btm[i-1], layer);
    }

    // right triangle fan
    pt = (right[0]+right[right.size()-1])*0.5;
    for (i = 1; i < right.size(); i++)
        writeFace(out, pt, right[i-1], right[i], layer);
}


/** Writes a 3D CPanelGroup to a 3D DXF file with one file per panel.
 *
 * @param sail the sail to write
 * @param filename the file to write to
 */
void CSailDxfWriter3d::writeSplit(const CPanelGroup &sail, const QString &basename) const
{
    ofstream out;

    for (unsigned int pn = 0; pn < sail.size(); pn++)
    {
        QString filename = basename;
        filename.replace(".dxf", QString("-%1.dxf").arg(pn));

        // open file, write comment and header
        writeBegin(out, filename);

        // write tables section
        writeAtom(out, DXF_ENTITY, "SECTION");
        writeAtom(out, DXF_NAME, "TABLES");
        writeAtom(out, DXF_ENTITY, "TABLE");
        writeAtom(out, DXF_NAME, "LAYER");
        writeAtom(out, DXF_FLAG, "6");
 //       writeLayer(out, 1, DxfTextColour);
       writeLayer(out, 1, DXF_CYAN);
        writeAtom(out, DXF_ENTITY, "ENDTAB");
        writeAtom(out, DXF_ENTITY, "ENDSEC");

        // write entities section
        writeAtom(out, DXF_ENTITY, "SECTION");
        writeAtom(out, DXF_NAME, "ENTITIES");
        writePanel(out, sail[pn], 1);
        writeAtom(out, DXF_ENTITY, "ENDSEC");

        // end of file
        writeEnd(out);
    }
}
