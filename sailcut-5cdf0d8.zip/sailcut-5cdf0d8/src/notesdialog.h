#ifndef NOTESDIALOG_H
#define NOTESDIALOG_H

#include <QDialog>
#include "sailcpp/saildef.h"

namespace Ui {
class NotesDialog;
}

class NotesDialog : public QDialog
{
    Q_OBJECT

public:
    //explicit NotesDialog(QWidget *parent = nullptr);
    NotesDialog( QWidget* , CSailDef* );
    ~NotesDialog();
    virtual void accept();

private:
    CSailDef *sailDef;
    Ui::NotesDialog *ui;
};

#endif // NOTESDIALOG_H
