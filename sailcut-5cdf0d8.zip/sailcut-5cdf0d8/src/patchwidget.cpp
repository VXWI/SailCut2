#include "patchwidget.h"
#include "ui_patchwidget.h"

PatchWidget::PatchWidget(QWidget *parent)
    : QGroupBox(parent)
    , ui(new Ui::PatchWidget)
{
    ui->setupUi(this);
}

PatchWidget::~PatchWidget()
{
    delete ui;
}

void PatchWidget::setDisplayStyle(enum enumPatchWidgetDisplayStyle style) {
    //QSize zeroSize = QSize(0, 0);
    //QSize s = this->size();

    switch (style) {
    case PATCH_WIDGET_DISPLAY_STYLE_PLAIN:
        ui->plainPatchRadionButton->hide();
        ui->fanPatchRadioButton->hide();
        ui->baseDimLabel->hide();
        ui->baseDimLineEdit->hide();
        ui->numSectionsLabel->hide();
        ui->numSectionsSpinBox->hide();
        ui->overlapLabel->hide();
        ui->overlapLineEdit->hide();

        ui->reefLeechHeightLabel->hide();
        ui->reefLeechHeightLineEdit->hide();
        ui->reefLuffHeightLabel->hide();
        ui->reefLuffHeightLineEdit->hide();
/*
        ui->reefLeechHeightLabel->resize(zeroSize);
        ui->reefLeechHeightLineEdit->resize(zeroSize);
        ui->reefLuffHeightLabel->resize(zeroSize);
        ui->reefLuffHeightLineEdit->resize(zeroSize);

        ui->plainPatchRadionButton->resize(zeroSize);
        ui->fanPatchRadioButton->resize(zeroSize);
        ui->baseDimLabel->resize(zeroSize);
        ui->baseDimLineEdit->resize(zeroSize);
        ui->numSectionsLabel->resize(zeroSize);
        ui->numSectionsSpinBox->resize(zeroSize);
        ui->overlapLabel->resize(zeroSize);
        ui->overlapLineEdit->resize(zeroSize); */
        this->setMaximumHeight(130);
        this->setMinimumHeight(130);
        break;
    case PATCH_WIDGET_DISPLAY_STYLE_FAN:
        ui->plainPatchRadionButton->hide();
        ui->fanPatchRadioButton->hide();
        ui->underPatchesLabel->hide();
        ui->underPatchesLineEdit->hide();

        ui->reefLeechHeightLabel->hide();
        ui->reefLeechHeightLineEdit->hide();
        ui->reefLuffHeightLabel->hide();
        ui->reefLuffHeightLineEdit->hide();
/*
        ui->reefLeechHeightLabel->resize(zeroSize);
        ui->reefLeechHeightLineEdit->resize(zeroSize);
        ui->reefLuffHeightLabel->resize(zeroSize);
        ui->reefLuffHeightLineEdit->resize(zeroSize);


        ui->plainPatchRadionButton->resize(zeroSize);
        ui->fanPatchRadioButton->resize(zeroSize);
        ui->underPatchesLabel->resize(zeroSize);
        ui->underPatchesLineEdit->resize(zeroSize);
*/
        this->setMaximumHeight(225);
        this->setMinimumHeight(225);

        break;
    case PATCH_WIDGET_DISPLAY_STYLE_REEF_FAN:
        ui->plainPatchRadionButton->hide();
        ui->fanPatchRadioButton->hide();
        ui->underPatchesLabel->hide();
        ui->underPatchesLineEdit->hide();
/*
        ui->plainPatchRadionButton->resize(zeroSize);
        ui->fanPatchRadioButton->resize(zeroSize);
        ui->underPatchesLabel->resize(zeroSize);
        ui->underPatchesLineEdit->resize(zeroSize);
*/
        this->setMaximumHeight(250);
        this->setMinimumHeight(250);

        break;
    default: // STYLE_ALL
        this->setMaximumHeight(300);
        this->setMinimumHeight(300);
        break;
    }
}

void PatchWidget::hideDimension2(void) {
    ui->dimension2Label->hide();
    ui->dimension2LineEdit->hide();
}

void PatchWidget::setDimension1Title(std::string s) {
    ui->dimension1Label->setText(QString::fromStdString(s));
}

void PatchWidget::setDimension2Title(std::string s) {
    ui->dimension2Label->setText(QString::fromStdString(s));
}

void PatchWidget::setValues(struct Patch patchData) {
    data = patchData;

    // TODO set ui fields
    ui->dimension1LineEdit->setText(QString::number(patchData.dimension1));
    ui->dimension2LineEdit->setText(QString::number(patchData.dimension2));
    ui->underPatchesLineEdit->setText(QString::fromStdString(patchData.underPatches));

    if (data.patchStyle == PATCH_STYLE_FAN) {
        ui->numSectionsSpinBox->setValue(patchData.numSections);
        ui->overlapLineEdit->setText(QString::number(patchData.overlap));
        ui->baseDimLineEdit->setText(QString::number(patchData.baseDimension));
    }

    if (patchData.patchType == PATCH_MAINSAIL_REEF1 || patchData.patchType == PATCH_MAINSAIL_REEF2) {
        ui->reefLuffHeightLineEdit->setText(QString::number(patchData.luffHeight));
        ui->reefLeechHeightLineEdit->setText(QString::number(patchData.leechHeight));
    }
}

struct Patch PatchWidget::getValues() {
    QString txt;
    bool bValid = true;

    txt = ui->dimension1LineEdit->text();
    data.dimension1 = txt.toInt(&bValid);
    txt = ui->dimension2LineEdit->text();
    data.dimension2 = txt.toInt(&bValid);

    data.underPatches = ui->underPatchesLineEdit->text().toStdString();

    if (data.patchStyle == PATCH_STYLE_FAN) {
        data.numSections = ui->numSectionsSpinBox->value();
        txt = ui->overlapLineEdit->text();
        data.overlap = txt.toInt(&bValid);
        txt = ui->baseDimLineEdit->text();
        data.baseDimension = txt.toInt(&bValid);
    }

    if (data.patchType == PATCH_MAINSAIL_REEF1 || data.patchType == PATCH_MAINSAIL_REEF2) {
        txt = ui->reefLuffHeightLineEdit->text();
        data.luffHeight = txt.toInt(&bValid);
        txt = ui->reefLeechHeightLineEdit->text();
        data.leechHeight = txt.toInt(&bValid);
    }

    return data;
}

bool PatchWidget::check() {
    bool flag = true;
    QString txt;
    int tmpInt;
    bool bTest;

    /** Create four palettes for levels of warning. */
    QPalette palStd, palHi, palLo, palRel;
    palStd = ui->dimension1LineEdit->palette();
    palLo = palHi = palRel = palStd;
    palLo.setColor( QPalette::Text, Qt::magenta); // too low value
    palHi.setColor( QPalette::Text, Qt::red );    // too high value
    palRel.setColor( QPalette::Text, Qt::blue );  // related value to be checked

    txt = ui->dimension1LineEdit->text();

    if (txt.length() == 0) {
        data.dimension1 = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->dimension1LineEdit->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            ui->dimension1LineEdit->setPalette(palLo);
        } else {
            data.dimension1 = tmpInt;
        }
    }

    txt = ui->dimension2LineEdit->text();

    if (txt.length() == 0) {
        data.dimension2 = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->dimension2LineEdit->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            ui->dimension2LineEdit->setPalette(palLo);
        } else {
            data.dimension2 = tmpInt;
        }
    }

    string s = ui->underPatchesLineEdit->text().toStdString();
    SplitsToInts(s, bTest);

    if (!bTest) {
        ui->underPatchesLineEdit->setPalette(palHi);
        flag = false;
    } else {
        data.underPatches = s;
    }

    // fields for fan style
    if (data.patchStyle == PATCH_STYLE_FAN) {
        // numSections;
        data.numSections = ui->numSectionsSpinBox->value();

        // overlap;
        txt = ui->overlapLineEdit->text();

        if (txt.length() == 0) {
            data.overlap = 0;
        } else {
            tmpInt = txt.toInt(&bTest);
            if (!bTest) {
                flag = false;
                ui->overlapLineEdit->setPalette(palHi);
            } else if (tmpInt < 5){
                flag = false;
                ui->overlapLineEdit->setPalette(palLo);
            } else {
                data.overlap = tmpInt;
            }
        }

        // baseDimension;
        txt = ui->baseDimLineEdit->text();

        if (txt.length() == 0) {
            data.baseDimension = 0;
        } else {
            tmpInt = txt.toInt(&bTest);
            if (!bTest) {
                flag = false;
                ui->baseDimLineEdit->setPalette(palHi);
            } else if (tmpInt < 50){
                flag = false;
                ui->baseDimLineEdit->setPalette(palLo);
            } else {
                data.baseDimension = tmpInt;
            }
        }
    }

    // reef info
    if (data.patchType == PATCH_MAINSAIL_REEF1 || data.patchType == PATCH_MAINSAIL_REEF2) {
        // luffHeight;
        txt = ui->reefLuffHeightLineEdit->text();

        if (txt.length() == 0) {
            data.luffHeight = 0;
        } else {
            tmpInt = txt.toInt(&bTest);
            if (!bTest) {
                flag = false;
                ui->reefLuffHeightLineEdit->setPalette(palHi);
            } else if (tmpInt < 1){
                flag = false;
                ui->reefLuffHeightLineEdit->setPalette(palLo);
            } else {
                data.luffHeight = tmpInt;
            }
        }
        // leechHeight;
        txt = ui->reefLeechHeightLineEdit->text();

        if (txt.length() == 0) {
            data.leechHeight = 0;
        } else {
            tmpInt = txt.toInt(&bTest);
            if (!bTest) {
                flag = false;
                ui->reefLeechHeightLineEdit->setPalette(palHi);
            } else if (tmpInt < 1){
                flag = false;
                ui->reefLeechHeightLineEdit->setPalette(palLo);
            } else {
                data.leechHeight = tmpInt;
            }
        }

        if (data.leechHeight < data.luffHeight) {
            flag = false;
            ui->reefLuffHeightLineEdit->setPalette(palHi);
            ui->reefLeechHeightLineEdit->setPalette(palHi);
        }
    }


    return flag;
}

bool PatchWidget::generate(void) {
    return ui->generateCheckBox->isChecked();
}

void PatchWidget::setGenerate(bool b) {
    ui->generateCheckBox->setChecked(b);
}
