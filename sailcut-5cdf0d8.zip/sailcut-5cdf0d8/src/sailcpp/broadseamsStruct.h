#ifndef BROADSEAMSSTRUCT_H
#define BROADSEAMSSTRUCT_H
// structure for broadseams at various heights
struct broadseamInfo {
    int         panelNo;
    double      delta;
    int         index;
    double      percentage;
};


#endif // BROADSEAMSSTRUCT_H
