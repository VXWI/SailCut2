/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef SAILWORKER_H
#define SAILWORKER_H

#include "panelgroup.h"
#include "saildef.h"

// forward declarations
class CPanelGroup;
class CSeam;


struct camberRatio {
    real percentDepth;
    real ratio;
};

struct crossHeights {
    real quarterHeight;
    real halfHeight;
    real threeQuarterHeight;
    CPoint3d quarterLuffPoint;
    CPoint3d quarterLeechPoint;
    CPoint3d halfLuffPoint;
    CPoint3d halfLeechPoint;
    CPoint3d threeQuarterLuffPoint;
    CPoint3d threeQuarterLeechfPoint;
    real panelQuarterCrossHeight;
    real panelHalfCrossHeight;
    real panelThreeQuarterCrossHeight;
};

struct reefPoint {
    CPoint3d luffReefPoint;
    CPoint3d leechReefPoint;
};

const camberRatio camberRatios[] = {
    {0, 0},
    {1, 0.0266645336989626},
    {2, 0.10663255671825311},
    {3, 0.23982746607373429},
    {4, 0.42612202599454463},
    {5, 0.665339016073645},
    {6, 0.9572521275021018},
    {7, 1.3015870965142255},
    {8, 1.6980230614833118},
    {9, 2.146194127715745},
    {10, 2.6456911219380004},
    {11, 3.1960635167872624},
    {12, 3.796821504327113},
    {13, 4.44743819671794},
    {14, 5.147351931681712},
    {15, 5.895968660291686},
    {16, 6.692664394876175},
    {17, 7.536787695408108},
    {18, 8.427662173639462},
    {19, 9.364588995369516},
    {20, 10.346849362585829},
    {21, 11.373706958722124},
    {22, 12.44441034190919},
    {23, 13.558195272799225},
    {24, 14.714286965287883},
    {25, 15.911902250201521},
    {26, 17.15025164372966},
    {27, 18.428541314035314},
    {28, 19.745974941049397},
    {29, 21.10175546592619},
    {30, 22.495086727999094},
    {31, 23.925174988312847},
    {32, 25.391230339920767},
    {33, 26.892468006118094},
    {34, 28.428109528637037},
    {35, 29.997383848560105},
    {36, 31.599528283320495},
    {37, 33.23378940365512},
    {38, 34.89942381477482},
    {39, 36.59569884631284},
    {40, 38.32189315582832},
    {41, 40.07729725077539},
    {42, 41.86121393391997},
    {43, 43.67295867719062},
    {44, 45.51185992891274},
    {45, 47.37725935928634},
    {46, 49.26851204884946},
    {47, 51.18498662451984},
    {48, 53.1260653476339},
    {49, 55.091144158213524},
    {50, 57.079632679489634},
    {51, 59.09095418649858},
    {52, 61.12454554235438},
    {53, 63.17985710558196},
    {54, 65.25635261167903},
    {55, 67.3535090318631},
    {56, 69.47081641175035},
    {57, 71.60777769251152},
    {58, 73.76390851685514},
    {59, 75.93873702200136},
    {60, 78.13180362163266}
};

const int DEPTH_RATIO_TABLE_SIZE = 60;

enum enumEdgeType { LUFF_EDGE, GAFF_EDGE, FOOT_EDGE, LEECH_EDGE, BATTEN_HOLLOW };
enum enumCrossHeight {QUARTER_HEIGHT, HALF_HEIGHT, THREEQUARTER_HEIGHT};
enum enumZpanelSupressCalc {ZPSC_NONE, ZPSC_FOOT, ZPSC_LUFF_FOOT, ZPSC_TOP, ZPSC_LEFT, ZPSC_RIGHT};

class layout_error : public runtime_error
{
public:
    layout_error(const string &message) : runtime_error(message)
    {
        cout << "in sailworker:" << what()  << endl;
    }
};

/** The CSailWorker class does all the sail-related calculations like laying the panels.
 *  It is used to create the sail from a CSailDef definition.
 *
 * @ingroup SailCpp
 * @see CSailDef, CPanelGroup
 */
class CSailWorker : public CSailDef
{
public:
    CSailWorker(const CSailDef &s);

    /** The area of the sail. */
    real Area();
    /** The head to clew diagonal length. */
    real Diagonal();
    /** The computation of the width as per IRC rule. */
    real IRCwidth( const real &h );
    /** The computation of the sail width at any height. */
    real SailWidth( const real &h );
    /** The length of the leech measured along its curved edge. */
    real LeechLength( const real &h );
    /** The length of the luff measured along its curved edge. */
    real LuffLength( const real &h );
    /** The maximum width of the sail perpendicular to the luff. */
    real SailLP( );

	real TackToSailLPIntersect();
	
    /** Find the Point on the leech at a given %age height */
    CPoint3d LeechPoint( real &h );
    CPoint3d LuffPoint( real &h );
    real CrossMeasurementAtDistanceFromHead(const real &distanceFromHead);
    void IsafCrossMeasurement(crossHeights &crossHeight, bool toNearestPoint = true);
    int maxPanelHeight(void);
    int maxPanelWidth(void);
    int HeadToLeechTurnPointDistance(void) const;
    unsigned int CalculateFootMedian(void);
    unsigned int CalculateLeechLength(bool isTriangular);
    unsigned int CalculateFootLength(void);
    unsigned int CalculateLuffLength(void);
    unsigned int CalculateLeechRoundDistance(void);
    void mapBattensToPanel(int, CBattenGroup&, CPanel&) const;
    real distanceBetween(CPoint3d p1, CPoint3d p2) const;
    bool isGaffMainsail(void);
    void LuffFoldCrossMeasurements(crossHeights &crossHeight);
    bool validateSymmetricalSpinnakerLuff(void) ;

    CPanelGroup makeSail() const;
    CPanelGroup makeSail(CPanelGroup &flatsail, CPanelGroup &dispsail, CPanelGroup &flattened) const;

    /** The Tack 3D point. */
    CPoint3d tack;
    /** The Head 3D point. */
    CPoint3d head;
    /** The Peak 3D point. */
    CPoint3d peak;
    /** The Clew 3D point. */
    CPoint3d clew;
    CPoint3d leechTurnPoint;
    /** throat point for gaff mansails */
    CPoint3d throat;
    /** top points */
    CPoint3d topFront;
    CPoint3d topBack;
    mutable CPanelGroup m_flattened ;

protected:
    /** The Cross cut and Horizontal cut layout of sail's panels. */
    CPanelGroup Layout0( CPanelGroup &flatsail, CPanelGroup &dispsail ) const; 
    /** The Cross cut and Horizontal cut layout of sail's panels with addditional
     * lower panel for dinghy sails */
    CPanelGroup LayoutHorizontalSpinnaker( CPanelGroup &flatsail, CPanelGroup &dispsail , CPanelGroup &flattened) const;
    CPanelGroup LayoutRadialBottomSpinnaker( CPanelGroup &flatsail, CPanelGroup &dispsail , CPanelGroup &flattened) const;
    CPanelGroup LayoutCross2( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    int LayoutCross2Foot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const;
    int LayoutSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const;
    int LayoutStraightSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const;
    int LayoutCurvedSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev ) const;
    int LayoutSpeedSeamMultiPanelFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const;
    /** The Twist cut layout of sail's panels. */
    CPanelGroup LayoutTwist( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Vertical cut layout of sail's panels. */
    CPanelGroup LayoutVertical( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Radial cut layout of sail's panels. */
    CPanelGroup LayoutRadial( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Mitre cut layout of sail's panels perpendicular to leech and foot. */
    CPanelGroup LayoutMitre( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Mitre 2 cut layout of sail's panels parralel to foot and leech. */
    CPanelGroup LayoutMitre2( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Tri Radial cut layout of sail's panels. */
    CPanelGroup LayoutTriRadial( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;
    /** The Wing cut layout of sail's panels. */
    CPanelGroup LayoutWing( CPanelGroup &flatsail, CPanelGroup &dispsail ) const;

    /** The type of sail Edge for an intersection. */
    enumEdgeType Edge;
     /** The intersection of a line defined by a point and a vector with an edge. */
    CPoint3d EdgeIntersect( const enumEdgeType &Edge, const CPoint3d &pt1, const CVector3d &v1 , bool bBattenHollow=false) const;
    /** The horizontal intersection with forward edge. */
    CPoint3d FwdIntersect( const CPoint3d &pt1 ) const;
    /** The horizontal intersection with aft edge. */
    CPoint3d AftIntersect( const CPoint3d &pt1 ) const;
    /** The intersection of a line defined by a point and a vector with the mitre line. */
    CPoint3d MitreIntersect( const CPoint3d &pt1, const CVector3d &v1 ) const;
    /**  Fill aCSide with points of curved edge */
    CSide FillCurvedEdge( const enumEdgeType &Edge, const CSide &side, const CVector3d &v ) const;

    /** The mitre intersection point with luff. */
    CPoint3d mitreLuffPt;

    /** The depth of the sail at a point. */
    CPoint3d Zpoint( const CPoint3d &p1, enum enumZpanelSupressCalc zpsc = ZPSC_NONE ) const;
    /** The depth of the sail at all points of a panel. */
    CPanel Zpanel( const CPanel &p1, enum enumZpanelSupressCalc zpsc = ZPSC_NONE ) const;

    CPoint3d FootPanelTopLeftPoint( unsigned int pn ) const;
    CPoint3d FootPanelTopRightPoint( unsigned int pn ) const;
    CPoint3d FootPanelBottomLeftPoint( unsigned int pn ) const;
    CPoint3d FootPanelBottomRightPoint( unsigned int pn ) const;
    real SpeedSeamLuffPoint(void) const;
    real SpeedSeamLeechPoint(void) const;
    CPoint3d IntermediatePoint(CPoint3d leftPoint, CPoint3d rightPoint, unsigned int pn, unsigned int totalPanels) const;
    CPoint3d FootPoint(CPoint3d p1) const;
    CVector3d LowerLeechVector(void) const;
    CPanel layoutLensFootPanel(CPanel flatpanel) const;

    /** splits processing */
    unsigned int getSplits(unsigned int *panelWidth, bool genSpeedSeam = true, int fillerPanelWidth=0, int speedPanelWidth=0) const;
    /* calculate broadseam allowance */
    unsigned int calculateBroadSeamAllowance(void) const;

    real calculateLeechPoint(real e, real h, int ep) const;

    void dumpRight(CPanel p) const;

    real ratioFromDepth(real depth) const;
    real depthFromRatio(real ratio) const;
    CPoint3d calculateNearestLuffPoint(CPoint3d leechPoint) const;
    CPoint3d calculateLeechPoint(CPoint3d pHigh, CPoint3d pLow, real startPercent);
    CPoint3d calculateLuffPoint(CPoint3d pHigh, CPoint3d pLow, real startPercent);
    real calculateDistanceAroundLuffCurve(CPoint3d pStart, CPoint3d pEnd);
    real calculate3dDistance(CPoint3d pStart, CPoint3d pEnd, enum enumZpanelSupressCalc zpsc = ZPSC_NONE) const;
    void CalculateBattenPositions(void) const ;
    real calculateSideLength(CSide) const;
    int findBattenIndexAtHeight(real height) const ;
    int findBattenIndexAtHeight(CPoint3d p) const ;
    void calculateSailCambers() const;
    CPoint3d calculateNearestPointInZ(CPoint3d pStart, CPoint3d pEnd) const;
    real calculateSymetricalSpinnakerCrossMeasurement(CPoint3d pStart, CPoint3d pEnd) const;
    CPanel layoutSymetricalSpinnakerClewPatch(real patchSize, enumPatchType patchType) const;
    CPanel layoutSymetricalSpinnakerHeadPatch(real patchSize, enumPatchType patchType = PATCH_SPINNAKER_HEAD) const;

    void layoutPatches( CPanelGroup &sail, CPanelGroup &flatsail ) const;
    CPanel layoutMainsailHeadPatch(int luffDimension, int leechDimension, enumPatchType patchType) const;
    CPanel layoutJibHeadPatch(int leechDimension, enumPatchType patchType) const;
    CPanel layoutMainsailClewFanPatch(Patch patchData) const;
    CPanel layoutJibClewFanPatch(Patch patchData) const;
    CPanel layoutJibTackPatch(int dimension, enumPatchType patchType) const;
    CPanel layoutMainsailTackPatch(int height, int width, enumPatchType patchType) const;
    CPanel layoutPartialFanPatch(Patch patchData) const;
    CPanel developPartialFanPatch(CPanel p, Patch patchData) const;
    CPanel layoutThroatPatch(int dimension, enumPatchType patchType) const;

    CPanel developMainsailClewFanPatch(CPanel p, Patch patchData) const;
    CPanel developJibClewFanPatch(CPanel p, Patch patchData) const;
    CPanel developBlockHeadPatch(CPanel p) const;
    CPanel developBlockTackPatch(CPanel p) const;
    CPanel developThroatPatch(CPanel p) const;
    CPanel layoutSailWindow(CPanelGroup sail,  SailWindow *sw) const;

    vector<broadseamInfo> calculateBroadseams(CPanelGroup &flatsail) const;
    real calculatePanelCrossMeasurement(CPoint3d p);
    CPanelGroup layoutRadialClewPatches(int numGores, real patchSize, real baseDimension, real seamW) const;
    CPanelGroup flattenSail(CPanelGroup &flatsail) const;

    struct reefPoint calculateReefPoint(Patch patchData) const;
    void mapReefPointsToPanel(vector<struct reefPoint>&, CPanel&) const;

    /** Foot vector. */
    CVector3d footV;
    /** Unitary vector perpendicular to foot. */
    CVector3d footVP;
    /** Gaff vector. */
    CVector3d gaffV;
    /** Unitary vector perpendicular to gaff. */
    CVector3d gaffVP;
    /** Leech vector. */
    CVector3d leechV;
    /** Unitary vector perpendicular to leech. */
    CVector3d leechVP;
    /** Luff vector. */
    CVector3d luffV;
    /** Unitary vector perpendicular to luff. */
    CVector3d luffVP;
    /** Mitre vector. */
    CVector3d mitreV;
    /** top of sail vector
     *  this will be same as gaff vector for a traingular sail */
    CVector3d topV;
    CVector3d topVP;
    /** vertical vector used in Zpoint foot calculation
     */
    CVector3d vertV;

    /** The foot straight 3D line. */
    CSubSpace footLine;
    /** The gaff straight 3D line. */
    CSubSpace gaffLine;
    /** The leech straight 3D line. */
    CSubSpace leechLine;
    /** The luff straight 3D line. */
    CSubSpace luffLine;
    /** The mitre straight 3D line. */
    CSubSpace mitreLine;

    mutable bool bTrace;
    mutable bool bUseBattensForLeech;

    mutable CPanelGroup m_sail, m_dispsail, m_flatsail;

    mutable real luffOffsetRadius;
    mutable CPoint3d luffOffsetCentrePoint;

    mutable vector<struct reefPoint> reefPointsList;
};

#endif
