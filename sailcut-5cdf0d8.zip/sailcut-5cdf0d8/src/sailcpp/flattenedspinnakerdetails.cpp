#include "flattenedspinnakerdetails.h"

/**
 * @brief FlattenedSpinnakerDetails::FlattenedSpinnakerDetails
 *
 * class to perform calculations of various values for a flattened
 * view of a spinnaker
 */
FlattenedSpinnakerDetails::FlattenedSpinnakerDetails() {}

/**
 * @brief FlattenedSpinnakerDetails::getValues
 * @param pg
 * @return
 */
struct flattenedSpinnakerValues FlattenedSpinnakerDetails::getValues(CPanelGroup &pg) {
    struct flattenedSpinnakerValues values;
    double leechLength = 0;
    double footMedian = 0;
    double xMin = 100000000;

    for (unsigned int i=0; i<pg.size();i++) {
        leechLength += pg[i].left.arcLength();
        footMedian += pg[i].right.arcLength();
        for (unsigned int j=0; j<pg[i].left.size();j++) {
            if (pg[i].left[j].x() < xMin) {
                xMin = pg[i].left[j].x();
            }
        }

    }

    CPoint3d p0 = pg.front().bottom.front();
    CPoint3d p1 = pg.back().top.front();
    values.leechLengthStraightLine = (p1-p0).norm();
    values.leechLength = std::round(leechLength);
    values.footMedian = std::round(footMedian);

    CPoint3d pMidHeight = p0 + (p1-p0)*0.5;

    // calculate mid-point of half foot
    p0 = pg[0].bottom.front();
    p1 = pg[0].bottom.back();
    double halfFoot = p1.x()-p0.x();
    CPoint3d pMidFoot = p0 + (p1-p0)*0.5;

    double a = (pMidFoot-p0).norm();
    double b = (pg.back().top.front() - pMidFoot).norm();
    double c = values.leechLengthStraightLine;
    double angle = Atriangle(a,b,c);
    double x = tan(angle) * (c/2);
    CPoint3d pMid = CPoint3d(pMidHeight.x()+x, pMidHeight.y(), pMidHeight.z());

    CPoint3d pLowLeft = getLeftPointBelow(pMidHeight, pg);
    CPoint3d pLowRight = getRightPointBelow(pMidHeight, pg);
    CPoint3d pHighLeft = getLeftPointAbove(pMidHeight, pg);
    CPoint3d pHighRight = getRightPointAbove(pMidHeight, pg);

    CPoint3d pLeft = findCentrePoint(pMid.y(), pLowLeft, pHighLeft);
    CPoint3d pRight = findCentrePoint(pMid.y(), pLowRight, pHighRight);

    double halfMidGirth = (pRight-pLeft).norm();
    double centreToRight = (pRight-pMid).norm();
    values.fullnessFactor = std::round(centreToRight/halfFoot * 100);

    values.leechRound = std::round(pg[0].bottom.front().x()-xMin);
    values.halfMidGirth = std::round(halfMidGirth);
    values.centreRound = std::round(halfMidGirth - values.leechRound - 2 * (pMid.x()-pMidHeight.x()));

    // head angle
    CPanel panel = pg.back();
    double ha = atan(abs(panel.right.back().x() - panel.right.front().x())
                     / abs(panel.right.back().y() - panel.right.front().y()));
    //int idx = panel.left.size()-1;
    //ha += atan(abs(panel.left[idx].x() - panel.left[idx-1].x())
    //          / abs(panel.left[idx].y() - panel.left[idx-1].y()));

    values.partHeadAngle = std::round(ha * 180 / PI);

    return values;
}

/**
 * @brief FlattenedSpinnakerDetails::getLeftPointBelow find point on left side of
 * flattened sail which level with or below the reference point
 * @param p reference point
 * @param pg a CPanelGroup representing the flattened view of the spinnaker
 * @return the point
 */
CPoint3d FlattenedSpinnakerDetails::getLeftPointBelow(CPoint3d p, CPanelGroup &pg) {
    for (unsigned int i = pg.size(); i > 0; i--) {
        CPanel pnl = pg[i-1];
        for (unsigned int j = pnl.left.size(); j > 0; j--) {
            if (pnl.left[j-1].y() <= p.y()) {
                return pnl.left[j-1];
            }
        }
    }

    return CPoint3d(0,0,0);
}

/**
 * @brief FlattenedSpinnakerDetails::getRightPointBelow find point on right side of
 * flattened sail which level with or below the reference point
 * @param p reference point
 * @param pg a CPanelGroup representing the flattened view of the spinnaker
 * @return the point
 */
CPoint3d FlattenedSpinnakerDetails::getRightPointBelow(CPoint3d p, CPanelGroup &pg) {
    for (unsigned int i = pg.size(); i > 0; i--) {
        CPanel pnl = pg[i-1];
        for (unsigned int j = pnl.right.size(); j > 0; j--) {
            if (pnl.right[j-1].y() <= p.y()) {
                return pnl.right[j-1];
            }
        }
    }

    return CPoint3d(0,0,0);
}

/**
 * @brief FlattenedSpinnakerDetails::getLeftPointAbove find point on left side of
 * flattened sail which level with or above the reference point
 * @param p reference point
 * @param pg a CPanelGroup representing the flattened view of the spinnaker
 * @return the point
 */
CPoint3d FlattenedSpinnakerDetails::getLeftPointAbove(CPoint3d p, CPanelGroup &pg) {
    for (unsigned int i = 0; i < pg.size(); i++) {
        CPanel pnl = pg[i];
        for (unsigned int j = 0; j < pnl.left.size(); j++) {
            if (pnl.left[j].y() >= p.y()) {
                return pnl.left[j];
            }
        }
    }

    return CPoint3d(0,0,0);
}

/**
 * @brief FlattenedSpinnakerDetails::getRightPointAbove find point on right side of
 * flattened sail which level with or above the reference point
 * @param p reference point
 * @param pg a CPanelGroup representing the flattened view of the spinnaker
 * @return the point
 */
CPoint3d FlattenedSpinnakerDetails::getRightPointAbove(CPoint3d p, CPanelGroup &pg) {
    for (unsigned int i = 0; i < pg.size(); i++) {
        CPanel pnl = pg[i];
        for (unsigned int j = 0; j < pnl.right.size(); j++) {
            if (pnl.right[j].y() >= p.y()) {
                return pnl.right[j];
            }
        }
    }

    return CPoint3d(0,0,0);
}

/**
 * @brief FlattenedSpinnakerDetails::findCentrePoint find a point which lies on a straight line
 * between to defined points and has a give y value
 * @param y the y value of the point we're looking for
 * @param p1 first point
 * @param p2 second point
 * @return the intermediate point
 */
CPoint3d FlattenedSpinnakerDetails::findCentrePoint(double y, CPoint3d p1, CPoint3d p2) {
    CPoint3d pLow, pHigh;

    if (p1.y() < p2.y()) {
        pLow = p1;
        pHigh = p2;
    } else {
        pLow = p2;
        pHigh = p1;
    }

    double yLow = pLow.y();
    double yHigh = pHigh.y();

    CPoint3d pMid = pLow + (pHigh-pLow) * ((y-yLow)/(yHigh-yLow));
    return pMid;
}

