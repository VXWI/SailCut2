/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <cmath>

#include "sailcalc.h"


/** Compute the normalised roach or round of a sail side
 *  Return the value of the normalised round at position X
 *  X is the relative position of the point along the straight edge
 *  P is the position of the maximum round in percent of the edge length
 *  The curve is a parabola on either side of the point P
 *
 * @author Robert Laine alias Sailcuter
 */
real RoundP( const real &x, const int &p )
{
    /*
      X (0..1) is the relative position of the point along the edge
      P is the integer position of the maximum round in percent of the edge length
      The curve is a parabola on either side of the point P
      Return Y (0..1) is the value of the normalised round at position X
    */

    real p1 = .5, x1 = 0 , y = 0;

    p1 = real(p) / 100;
    // limit the position of maximum round of side
    if (p1 < 0.01)
        p1=0.01;
    if (p1 > 0.99)
        p1=0.99;

    // limit the computation of the domain 0..1
    if ( x <= 0 )
        y = 0;
    else if ( x >= 1 )
        y = 0;
    else if ( x > p1 )
    {
        x1 = (x - p1) / (1 - p1);
        y  = 1 - x1 * x1;
    }
    else
    {
        x1 = 1 - x / p1;
        y  = 1 - (x1 * x1);
    }
    //
    return y;
}


/** Compute the angle of a 2D triangle from its 3 sides length
 *  a, b and c are the length of the sides of the triangle
 *  Return the angle in radian opposite to side a of the triangle
 *
 * @author Robert Laine alias Sailcuter
 */
real Atriangle( const real &a, real const &b, const real &c )
{
    real per = 0, AA = 0;
    per = (a + b + c) / 2;

    if ( per <= EPS )
        AA = PI /3;
    else if ( fabs(per-a) <= EPS )
        AA = PI;
    else
        AA = 2 * atan (sqrt ((per-b) * (per-c) / (per * (per-a)) ) ) ;
    //
    return AA;
}


/** Compute the angle of a 3D triangle.
 *  The triangle is defined by 3d points pta, ptb, ptc
 *  Return the angle AA in radian at point pta of the triangle
 *
 * @author Robert Laine alias Sailcuter
 */
real Atriangle3d ( const CPoint3d &pta, const CPoint3d &ptb, const CPoint3d &ptc )
{
    real AA=0, a=0, b=0, c=0, per=0;

    a = sqrt( (ptc.x()-ptb.x()) * (ptc.x()-ptb.x())
              +(ptc.y()-ptb.y()) * (ptc.y()-ptb.y())
              +(ptc.z()-ptb.z()) * (ptc.z()-ptb.z()) );
    b = sqrt( (pta.x()-ptc.x()) * (pta.x()-ptc.x())
              +(pta.y()-ptc.y()) * (pta.y()-ptc.y())
              +(pta.z()-ptc.z()) * (pta.z()-ptc.z()) );
    c = sqrt( (ptb.x()-pta.x()) * (ptb.x()-pta.x())
              +(ptb.y()-pta.y()) * (ptb.y()-pta.y())
              +(ptb.z()-pta.z()) * (ptb.z()-pta.z()) );

    per =(a + b + c)/2;

    if ( per <= EPS )
        AA = PI /3;
    else if ( fabs(per-a) <= EPS )
        AA = PI;
    else
        AA = 2 * atan (sqrt ((per-b) * (per-c) / (per * (per-a)) ) ) ;
    //
    return AA;
}


/** Compute the distance from a point pta
 *    to the line defined by the 2 points ptb and ptc
 *  The two points ptb and ptc defining the baseline also define
 *    its positive direction from point ptb toward point ptc.
 *  It is assumed that the 3 points pta, ptb, ptc define a plane
 *    not far from the X-Y plane.
 *  The sign of d is positive if the point pta
 *    is left of the line ptb=>ptc
 *  The sign of d is negative if pta is right of the line.
 *
 * @author Robert Laine alias Sailcuter
 */
real Distance3d(const CPoint3d &pta, const CPoint3d &ptb, const CPoint3d &ptc)
{
    real d;
    CVector3d Va = CVector3d( pta - ptb );
    CVector3d Vb = CVector3d( ptc - ptb).unit();
    CVector3d Vd = Vb.cross(Va);
    d = Vd.norm();
    if ( Vd.z() < 0 )
        d = -d;
    //
    return d;
}


/** Calculates logical viewport rectangle to match
 *  the ratio of the device viewport.
 */
CRect3d calcLRect(const CRect3d& viewRect, const CRect3d& objRect, const CPoint3d center, real zoom )
{
    CRect3d lRect;

    // avoid division by zero errors
    if ((viewRect.height() == 0) || (viewRect.width() == 0))
    {
        lRect.min = center;
        lRect.max = center;
        return lRect;
    }

    // set correct aspect ratio
    lRect = objRect.expandToRatio(viewRect.width() / viewRect.height());

    // recenter view
    return (lRect + (center - lRect.center())) * (1/zoom);
}

real StraightP( const real &x, const int &p )
{
    /*
      X (0..1) is the relative position of the point along the edge
      P is the integer position of the maximum round in percent of the edge length
      The leech is a straight line on either side of the point P
      Return Y (0..1) is the value of the normalised round at position X
    */

    real p1 = .5,  y = 0;

    p1 = real(p) / 100;
    // limit the position of maximum round of side
    if (p1 < 0.01)
        p1=0.01;
    if (p1 > 0.99)
        p1=0.99;

    // limit the computation of the domain 0..1
    if ( x <= 0 )
        y = 0;
    else if ( x >= 1 )
        y = 0;
    else if ( x > p1 )
    {
        y  = (1 - x) / (1 - p1);
    }
    else
    {
        y  = x /p1;
    }
    //
    return y;
}

/**
 * @brief intersectionOfTwoLines calculates the intersectuin of two lines. NOTE that
 * although we use CPoint3d this method only works in a 2d plane. This function
 * uses the formulae taken from https://en.wikipedia.org/wiki/Line%E2%80%93line_intersection
 * @param line1start start point of line 1
 * @param line1end end point of line 1
 * @param line2start start point of line 2
 * @param line2end end point of line 2
 * @return the intersection point
 */
CPoint3d intersectionOfTwoLines(CPoint3d line1start, CPoint3d line1end, CPoint3d line2start, CPoint3d line2end) {
    real x1 = line1start.x(), y1 = line1start.y();
    real x2 = line1end.x(), y2 = line1end.y();
    real x3 = line2start.x(), y3 = line2start.y();
    real x4 = line2end.x(), y4 = line2end.y();

    real px = ( (x1*y2 - y1*x2) * (x3 - x4) - (x1 -x2) * (x3*y4 - y3*x4) ) /
              ( (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4) );

    real py = ( (x1*y2 - y1*x2) * ( y3 - y4) - (y1 - y2) * (x3*y4 - y3*x4) ) /
              ( (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)   );

    CPoint3d p = CPoint3d(px, py, 0);

     return p;
}

/*
 * calculate chord height at a given point
 * radius radius of circle
 * depth depth of chord at mid point
 * p the point at which we perform the calculation
 * */
real CalculateChordHeight(double radius, double depth, double p) {
     double p1 = p <= 0.5 ? p : 1 - p;

     if (p1 == 0) {
        return 0;
     } else {
        // calculate x distance from centre of circle
        real x = 0.5-p1;

        // get y by Pythagarus
        real y = sqrt(radius*radius-x*x);

        // subtract part of radius below chord to get height
        double h = y - (radius-depth);
        if (std::isnan(h)) {
            cout << "h is Nan!!" << endl;
        }
        return h;
     }
}

/*
 * Solve a triangle given side, side and non-included angle (SSA)
 * l length of first side
 * m length of second side
 * angleM angle between m and third side
 * returns length of third side
 * */
real SolveSSA(const real l, const real m, const real angleM) {
     // caclulate 2nd angle
     double s = sin(angleM);
     double sinL = l*s/m;
     double angleL = asin(sinL);
     // calculate 3rd angle
     double angleN = PI - angleM - angleL;
     double n = sin(angleN) * m / s;

     return n;
}

/**
 * @brief SplitsToInts tales a comma-seperated list of numbers and returns a vector of ints
 * @param s the input list
 * @param bTest will be set to false if an invalid int is encountered
 * @param allowNegatives if true the negative numbers are allowed
 * @param allowW if true then first character will be ignored if it is 'W' or 'w'
 * @return the vector of ints
 */
vector<int> SplitsToInts(string s, bool &bTest, bool allowNegatives, bool allowW) {
    int i = 0;
    vector<int> ans;
    ans.clear();
    bTest = true;

    if (s.length() > 0) {
        char * pch;
        char * cstr = new char [s.size()+1];
        strncpy (cstr, s.c_str(), s.size());
        cstr[s.size()] = '\0';
        char *cstrOrig = cstr;
        if (allowW && (s[0] == 'W' || s[0] =='w')) {
            ++cstr;
        }

        pch = strtok (cstr,",");
        while (pch != NULL)
        {
            string str = string(pch);

            bool firstChar = allowNegatives;
            string::iterator it = str.begin();
            // Iterating in string with loop
            while (it != str.end())
            {
                if (firstChar) {
                    if (!((*it == '-') || isdigit(*it))) {
                        bTest = false;
                        delete[] cstrOrig;
                        return ans;
                    }
                } else if (!isdigit(*it)) {
                    bTest = false;
                    delete[] cstrOrig;
                    return ans;
                }
                // Increment the iterator
                it++;
                firstChar = false;
            }

            i = std::stoi(str);
            ans.push_back(i);

            pch = strtok (NULL, ",");
        }
        delete[] cstrOrig;
    }


    return ans;
}

/**
 * @brief SolveASAtriangle
 * @param angleA the first angle
 * @param sideC the include side
 * @param angleB the second angle
 * @return a struct containing the values of the other two sides and the third angle
 */
struct ASAresults SolveASAtriangle (real angleA, real sideC, real angleB) {
    struct ASAresults result;

    result.angleC = PI - angleA - angleB;
    result.sideA = sin(angleA) * sideC / sin(result.angleC);
    result.sideB = sin(angleB) * sideC / sin(result.angleC);

    return result;
}
