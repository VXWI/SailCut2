/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <cmath>
#include <iostream>
#include "sailcalc.h"

#include "sailmould.h"

using namespace std;

/**************************************************************************
                             CProfile class
***************************************************************************

                       construction / destruction

**************************************************************************/

/** The constructor.
 *
 * @param rDepth
 * @param rLeech
 * @param rLuff
 */
//CProfile::CProfile( real rDepth, real rLeech, real rLuff)
//    : depth(rDepth), kleech(rLeech), kluff(rLuff)
//{
//    calcMax();
//}

CProfile::CProfile( real rDepth, real rLeech, real rLuff, real rchord, enumProfileType pt, enumProfileSubType pst)
    : depth(rDepth), kleech(rLeech), kluff(rLuff), zmax(0), chord(rchord), radius(-1), profileType(pt), profileSubType(pst) {
    calcMax();
}

/**************************************************************************

                               operators

**************************************************************************/

/** Assignment operator.
 */
/*CProfile& CProfile::operator=( const CProfile &copy )
{
    if (&copy == this)
        return *this;

    depth = copy.depth;
    kleech = copy.kleech;
    kluff = copy.kluff;
    xmax = copy.xmax;
    zmax = copy.zmax;
    chord = copy.chord;
    profileType = copy.profileType;

    return *this;
}
*/

/**************************************************************************

                            member functions

**************************************************************************/

/** Compute the depth of the profile at a point located at dX along the cord
 *  where dX is bteween 0 and 1
 @author Robert Laine
 */
real CProfile::z( real dX ) {
    if (profileType == AERODYNAMIC) {
        return aerodynamicZ(dX);
    } else {
        return symetricalZ(dX);
    }
}

/**
 * @brief CProfile::symetricalZ calculate z height along a profile for a
 * symetrical spinnaker.
 * will use profileSubType to determine which profile algorithm to use
 * (ellipse, circle or default)
 * @param dX position along chord 0 to 1
 * @return z height as a percentage of chord
 */
real CProfile::symetricalZ( real dX ) {
    switch (profileSubType) {
    case PROFILE_ELLIPSE:
    case PROFILE_ELLIPSE_FLAT: {
        if (depth == 0) {
            return 0;
        } else {
            real pc = .89+kluff/200;
            real x1 = 0.5 / depth;
            real a = x1/pc, b = depth / pc;
            //real x0 = - x1;
            real x2 = dX > 0.5 ? 1 - dX : dX;

            if (profileSubType == PROFILE_ELLIPSE_FLAT) {
                if (x2 >= FLAT_PARAM) {
                    x2 = 0.5;
                } else {
                    x2 *= 0.5/FLAT_PARAM;
                }
            }

            // scale input value
            real x = x2 * 2 * x1;

            // adjust for elipse origin being 0
            x -= x1;

            // calculate y at dX = 0 or 1
            real y0 = b/ a * sqrt(a*a - x1*x1);

            // calculate y
            real y = b/ a * sqrt(a*a - x*x);

            real d = y - y0;

            //real scale = (b - y0) / b;

            real ret = d * depth / (b - y0);
            if (std::isnan(ret)) {
                cout << "ret is NAN" << endl;
            }

            return ret;
        }
    }

    case PROFILE_CIRCLE: {
        if (dX == 0 || depth == 0) {
            return 0;
        } else {
            // first, calculate circdle radius
            if (radius < 0) {
                real chord = 1.0;
                real tanA = (chord/2.0) / depth;
                real angleA = atan(tanA);
                real angleB = PI - 2.0*angleA;
                radius = (chord/2.0) / sin(angleB);
            }
            real ret = CalculateChordHeight(radius, depth, dX);

            return ret;
        }
    }
    default: {
        real x = dX;
        if (x >= 1) {
            return 0;
        }
        if (x <= 0) {
            return 0;
        }

        if (x > 0.5) {
            x = 1- x;
        }

        x = x * xmax / 0.5;

        real ret = aerodynamicZ(x);

        return ret;
        }
    } // end switch
}

real CProfile::aerodynamicZ( real dX )
{
    /*
       dX = absiss 0 to 1 along the cord of the profile
       kluff = luff shape factor
       kleech = leech shape factor
       depth = depth of the profile
       profile function is obtained by integrating twice the equation
         d2z/dx2 = kd * (-a*(1-X)^kluff - kleech * X)
       giving first the slope of the profile
         dz/dx = kd * (a*(1-X)^(kluff+1)/(kluff+1) - kleech/2 * X^2 + c)
       and finally the depth of the profile
         z = kd * (-a*(1-X)^(kluff+2)/((kluff+1)*(kluff+2)) - kleech/6 * X^3 +c * X + b)
         b and c are such that z=0 for X=0 AND X=1
         kd is such that the value of z at dX=xmax (max depth) is equal to depth
    */

    if (depth == 0) {
        return 0;
    } else {
        real a=1, b=0, c=0, kd=1, z=.1 ;
        a = 1 + kluff/4 ;// specific to family of profile
        b = a / ((kluff+2)*(kluff+1));
        c = kleech/6 - b;

        if (dX <= 0)  /* point is outside profile range */
            z = 0;
        else if (dX >= 1)  /* point is outside profile range */
            z = 0;
        else
        { /* point is inside profile range */
            /* compute depth normalisation coefficient */
            kd = depth / zmax;
            /* compute real depth z at point dX */
            z = kd * (-a*pow(1-dX,kluff+2)/((kluff+1)*(kluff+2)) - kleech/6 * pow(dX,3) + c * dX + b );
        }
        return z;
    }
}

/** Compute the slope of the profile at a point located at dX along the cord
 @author Robert Laine
 */
real CProfile::slope( real dX )
{
    if (profileType == AERODYNAMIC) {
        /*
       dX = absiss 0 to 1 along the cord of the profile
       kluff = luff shape factor
       kleech = leech shape factor
       depth = depth of the profile
       profile function is obtained by integrating twice the equation
         d2z/dx2 = kd * (-a*(1-X)^kluff - kleech * X)
       giving first the slope of the profile
         dz/dx = kd * (a*(1-X)^(kluff+1)/(kluff+1) - kleech/2 * X^2 + c)
       and finally the depth of the profile
         z = kd * (-a*(1-X)^(kluff+2)/((kluff+1)*(kluff+2)) - kleech/6 * X^3 +c * X + b)
         b and c are such that z=0 for X=0 AND X=1
         kd is such that the value of z at dX=xmax (max depth) is equal to depth
    */

        real a=1, b=0, c=0, kd=1, dz=.1 , x=0;
        a = 1 + kluff/4 ;// specific to family of profile
        b = a / ((kluff+2)*(kluff+1));
        c = kleech/6 - b;
        x = dX;

        if (x <= 0)  /* point is outside profile range */
            x = 0;
        else if (x >= 1)  /* point is outside profile range */
            x = 1;

        /* compute depth normalisation coefficient */
        kd = depth / zmax;
        /* compute real slope dz at point dX */
        dz = kd * ( a * pow(1-x,kluff+1) / (kluff+1) - kleech/2 * pow(x,2) + c );

        return dz;
    } else { // for symmetrical spinnakers
        real d = 0.0001;
        real h = z(d);

        real a = h /d;

        return a;
    }
}

/** Compute the camber of the profile at a point located at dX along the cord
 @author Robert Laine
 */
real CProfile::camber( real dX )
{
    /*
       dX = absiss 0 to 1 along the cord of the profile
       kluff = luff shape factor
       kleech = leech shape factor
       depth = depth of the profile
       profile function is obtained by integrating twice the equation
         d2z/dx2 = kd * (-a*(1-X)^kluff - kleech * X)
       giving first the slope of the profile
         dz/dx = kd * (a*(1-X)^(kluff+1)/(kluff+1) - kleech/2 * X^2 + c)
       and finally the depth of the profile
         z = kd * (-a*(1-X)^(kluff+2)/((kluff+1)*(kluff+2)) - kleech/6 * X^3 +c * X + b)
         b and c are such that z=0 for X=0 AND X=1
         kd is such that the value of z at dX=xmax (max depth) is equal to depth
    */

    real a=1, b=0, c=0, kd=1, dz=.1 , d2z=.1, camb=.1, x=0;
    a = 1 + kluff/4 ;// specific to family of profile
    b = a / ((kluff+2)*(kluff+1));
    c = kleech/6 - b;
    x = dX;

    if (x <= 0)  /* point is outside profile range */
        x = 0;
    else if (x >= 1)  /* point is outside profile range */
        x = 1;

    /* compute depth normalisation coefficient */
    kd = depth / zmax;
    /* compute real slope dz at point dX */
    dz = kd * ( a * pow(1-x,kluff+1) / (kluff+1) - kleech/2 * pow(x,2) + c );
    /* compute real d2z at point dX */
    d2z = kd * ( -a * pow(1-x,kluff) - kleech * x );
    /* compute real camber at point dX */
    camb = d2z / pow((1 + pow(dz,2)),1.5);

    return camb;
}

/** Compute the absiss x of the point of maximum depth of a profile
 *
 * @author Robert Laine
 */
void CProfile::calcMax()
{
    if (profileType == SYMMETRICAL && profileSubType != PROFILE_DEFAULT) {
        xmax = 0.5;
    } else {
        /* kluff = luff shape factor
       kleech = leech shape factor
       Profile function is defined by integrating twice the equation
         d2z/dx2 = kd * (-a*(1-x)^kluff - kleech * x)
         dz/dx = kd * (a*(1-x)^(kluff+1)/(kluff+1) - kleech/2 * x^2 + c)
         z = kd * (-a*(1-x)^(kluff+2)/((kluff+1)*(kluff+2)) - kleech/6 * x^3 +c * x + b)
         b and c are such that z=0 for x=0 AND x=1
    */

        real a=1, b=0, c=0;
        a = 1 + kluff/4;
        b = a / ((kluff+2)*(kluff+1));
        c = kleech/6 - b;

        /* scan from 16% point until slope become <= 0 */
        real x=.16, dz=.1;
        int n=16, step=8;
        while ((dz>0) && (n<60))
        {
            x = real(n)/100;
            dz = a*pow( 1-x, kluff+1)/(kluff+1) - kleech/2 * (x * x) + c;
            while ((dz<=0) && (step>1))
            {
                /* too big a step, go back halfway*/
                /* switch to fine stepping */
                step = step/2;
                if (step<2)
                {
                    step = 2;
                }
                n = n - step;
                x = real(n)/100;
                dz = a*pow( 1-x, kluff+1)/(kluff+1) - kleech/2 * (x * x) + c;
                if (dz>0)
                {
                    step = 1;
                }
            }
            n = n + step;
        }

        // we store xmax and zmax
        xmax = x;
        zmax = -a*pow(1-xmax,kluff+2)/ ((kluff+1)*(kluff+2)) - kleech/6 * pow(xmax,3) + c * xmax +b;
    }
}


/**************************************************************************
                             CSailMould class
***************************************************************************

                       construction / destruction

**************************************************************************/

/**  Set the default vertical position of max depth
 *  and the 3 profiles factors [depth, kleech, kluff]
 */
CSailMould::CSailMould()
{
    vertpos = 40;
    profileType = AERODYNAMIC;
    profile.resize(3);
    profile[0] = CProfile( 0.02, 0.00, 0 );
    profile[1] = CProfile( 0.08, 0.04, 3 );
    profile[2] = CProfile( 0.06, 0.03, 5 );
    topProfile = CProfile(0.0, 0.00, 0);

    bUseInterpol2 = false;
}


/**************************************************************************

                               operators

**************************************************************************/

/** Assignment operator.
 */
/*CSailMould & CSailMould::operator=( const CSailMould &copy )
{
    if (&copy == this)
        return *this;

    profile = copy.profile;
    topProfile = copy.topProfile;
    vertpos = copy.vertpos;
    physicalHeight = copy.physicalHeight;
    circleCentre = copy.circleCentre;
    circleRadius = copy.circleRadius;
    strength = copy.strength;
    profileType = copy.profileType;
    return *this;
}
*/

/**************************************************************************

                            member functions

**************************************************************************/

/** Interpolate the depth and coefficients of the profile at height h
  @author Robert Laine
 */
CProfile CSailMould::interpol ( const real h ) const
{
    if ( profile.size() < 3)
        cout << "profile < 3 !!" << endl;

    CProfile p;
    real pv = real(vertpos) / 100;
    real pv2 = real(vertpos2) / 100;
    real dpth = 0;
    real hr;

    if ( h <= 0 )   // at or below lower profile
    {
        /*p = profile[0];*/
        hr = h / pv;
        dpth = profile[0].getDepth() + (profile[1].getDepth()-profile[0].getDepth()) * hr;
        if ( dpth < 0 ) dpth = 0;
        p = CProfile( dpth, profile[0].getLeech() , profile[0].getLuff(),
                     profile[0].getChord(), profile[0].getProfileType(), profile[0].getProfileSubType());
    }
    else if ( h < pv )   // below max depth
    {
        hr = h / pv;
        dpth = profile[0].getDepth() + (profile[1].getDepth()-profile[0].getDepth()) * (1-(1-hr)*(1-hr));
        if ( dpth < 0 ) dpth = 0;
        p = CProfile( dpth ,
                      profile[0].getLeech() + (profile[1].getLeech()-profile[0].getLeech()) * hr,
                      profile[0].getLuff()  + (profile[1].getLuff()-profile[0].getLuff()) * hr,
                      profile[0].getChord(), profile[0].getProfileType(), profile[0].getProfileSubType());
    } else if (h < pv2) { // above max and below upper profile
        hr = (h-pv) / (pv2-pv);
        dpth = profile[1].getDepth() + (profile[2].getDepth()-profile[1].getDepth()) * hr*hr;
        if ( dpth < 0 ) dpth = 0;
        p = CProfile( dpth ,
                     profile[1].getLeech() + (profile[2].getLeech()-profile[1].getLeech()) * hr,
                     profile[1].getLuff()  + (profile[2].getLuff()-profile[1].getLuff()) * hr,
                     profile[1].getChord(), profile[1].getProfileType(), profile[1].getProfileSubType());
    }
    else if ( h < 1 )   // above upper profile and below peak
    {
        hr = (h-pv2) / (1-pv2);
        dpth = profile[2].getDepth() + (topProfile.getDepth()-profile[2].getDepth()) * hr*hr;
        if ( dpth < 0 ) dpth = 0;
        p = CProfile( dpth ,
                      profile[2].getLeech() + (topProfile.getLeech()-profile[2].getLeech()) * hr,
                      profile[2].getLuff()  + (topProfile.getLuff()-profile[2].getLuff()) * hr,
                     profile[2].getChord(), profile[2].getProfileType(), profile[2].getProfileSubType());

    }
    else  // peak and above
    {
        p = profile[2] ;//topProfile;
    }

    return p;
}

/** Interpolate the depth and coefficients of the profile at height h where h is the
 *  fractional height 0..1
  @author Robert Laine
 */
CProfile CSailMould::interpol2 ( const real h, const real chord) const
{
    if ( profile.size() < 3)
        cout << "profile < 3 !!" << endl;

    CProfile p;
    real pv = real(vertpos) / 100;
    real dpth = 0;
    real hr;

    if ( h < pv )   // below max depth
    {
        if (profileType == AERODYNAMIC) {
            return interpol(h);
        } else {
            real physicalDepth0 = profile[0].physicalDepth();
            real physicalDepth1 = profile[1].physicalDepth();

            if (h== 0) {
                p = profile[0];
            }
            else if ( h < 0 )   // at or below lower profile
            {
                /*p = profile[0];*/
                //hr = h / pv;
                hr = abs(h) / (footDepth / physicalHeight);
                dpth = baseProfile.getDepth() + (profile[0].getDepth()-baseProfile.getDepth()) * (1-hr);
                //if ( dpth < 0 ) dpth = 0;
                p = CProfile( dpth, profile[0].getLeech() , profile[0].getLuff(),
                             chord, profile[0].getProfileType(), profile[0].getProfileSubType());
            }
            else if ( h < pv )   // below max depth
            {
                hr = h / pv;
                //            dpth = profile[0].getDepth() + (profile[1].getDepth()-profile[0].getDepth()) * (1-(1-hr)*(1-hr));
                dpth = physicalDepth0 + (physicalDepth1-physicalDepth0) * (1-(1-hr)*(1-hr));
                dpth = dpth / chord;
                if ( dpth < 0 ) dpth = 0;
                p = CProfile( dpth ,
                             profile[0].getLeech() + (profile[1].getLeech()-profile[0].getLeech()) * hr,
                             profile[0].getLuff()  + (profile[1].getLuff()-profile[0].getLuff()) * hr,
                             chord, profile[0].getProfileType(), profile[0].getProfileSubType());

            }
        }
    }
    else // above max depth
    {
        hr = (h - pv);
        real halfChord = 1 - pv;
        // pd 1 is profile height in mm at profile 1
        real pd1 = profile[1].physicalDepth();
        // straightLineHeight is the profileheight a height h if
        // we were just drawing a straight lenel beween pd1 and head
        real straightLineHeight = pd1 * (halfChord-hr)/halfChord;
        real point = (hr+halfChord) / (2 * halfChord);
        //real localCamber = straightLineHeight / chord;
        // old calculation used arc of circle
        //point = physicalHeight * real(hr);
        //real physicalDepth = calculateChordHeight( circleRadius, pd1, point);

        // new calculation using porabola
        // old and new produce very, very similar results
        real rp = RoundP(point, interpolRP);
        // physical depth in mm at our height
        real physicalDepth = pd1 * rp;

        // calculate depth in mm allowing for strength factor
        dpth = (straightLineHeight+(physicalDepth-straightLineHeight)*strength);
        dpth = dpth/chord ;

        if ( dpth < 0 ) dpth = 0;

        if (profile[2].getDepth() > profile[1].getDepth()) {
            real h3 = real(vertpos2)/100.0;
            if (h >= h3) {
                p = CProfile( dpth ,
                             profile[2].getLeech(),
                             profile[2].getLuff(),
                             chord, profile[1].getProfileType(), profile[1].getProfileSubType());
            } else {
                real h4 = (h - (real)vertpos/100.0);
                real d = ((real)vertpos2/100.0 -(real)vertpos/100.0);

                p = CProfile( dpth ,
                             profile[1].getLeech() + (profile[2].getLeech()-profile[1].getLeech()) * h4/d,
                             profile[1].getLuff()  + (profile[2].getLuff()-profile[1].getLuff()) * h4/d,
                             chord, profile[1].getProfileType(), profile[1].getProfileSubType());
            }
        } else {
            p = CProfile( dpth ,
                     profile[1].getLeech() + (topProfile.getLeech()-profile[1].getLeech()) * hr,
                     profile[1].getLuff()  + (topProfile.getLuff()-profile[1].getLuff()) * hr,
                     chord, profile[1].getProfileType(), profile[1].getProfileSubType());
        }
    }

    return p;
}

CProfile CSailMould::interpol2Gaff( const real h, const real hGaff, const real chord ) const {
    if ( profile.size() < 3)
        cout << "profile < 3 !!" << endl;

    CProfile p;
    real pv = real(vertpos) / 100;
    real dpth = 0;
    real hr;

    if ( h < pv ) {  // below max depth
        return interpol2(h, chord);
    } else {
        hr = (h - pv);
        real halfChord = hGaff - pv;
        // pd 1 is profile height in mm at profile 1
        real pd1 = profile[1].physicalDepth();
        // straightLineHeight is the profileheight a height h if
        // we were just drawing a straight lenel beween pd1 and head
        real straightLineHeight = pd1 * (halfChord-hr)/halfChord;
        real point = (hr+halfChord) / (2 * halfChord);
        //real localCamber = straightLineHeight / chord;
        // old calculation used arc of circle
        //point = physicalHeight * real(hr);
        //real physicalDepth = calculateChordHeight( circleRadius, pd1, point);

        // new calculation using porabola
        // old and new produce very, very similar results
        real rp = RoundP(point, interpolRP);
        // physical depth in mm at our height
        real physicalDepth = pd1 * rp;

        // calculate depth in mm allowing for strength factor
        dpth = (straightLineHeight+(physicalDepth-straightLineHeight)*strength);
        dpth = dpth/chord ;

        if ( dpth < 0 ) dpth = 0;

        //real d1 = profile[1].getDepth();
        //real d2 = profile[2].getDepth();
        if (profile[2].getDepth() > profile[1].getDepth()) {
            real h3 = real(vertpos2)/100.0;
            if (h >= h3) {
                p = CProfile( dpth ,
                             profile[2].getLeech(),
                             profile[2].getLuff(),
                             chord, profile[1].getProfileType(), profile[1].getProfileSubType());
            } else {
                real h4 = (h - (real)vertpos/100.0);
                real d = ((real)vertpos2/100.0 -(real)vertpos/100.0);

                p = CProfile( dpth ,
                             profile[1].getLeech() + (profile[2].getLeech()-profile[1].getLeech()) * h4/d,
                             profile[1].getLuff()  + (profile[2].getLuff()-profile[1].getLuff()) * h4/d,
                             chord, profile[1].getProfileType(), profile[1].getProfileSubType());
            }
        } else {
            p = CProfile( dpth ,
                         profile[1].getLeech() + (topProfile.getLeech()-profile[1].getLeech()) * hr,
                         profile[1].getLuff()  + (topProfile.getLuff()-profile[1].getLuff()) * hr,
                         chord, profile[1].getProfileType(), profile[1].getProfileSubType());
        }

    }

    return p;
}

/*
 * set chord values of all profiles
 * set physical height of sail from tack to peak
 * perform circle calculation (not currently used)
 * footChord the chord width at the foot
 * chord1 the chord width at max chord depth point
 * chord2 the chord width at 75%
 * topChord the chord width at the head od the sail
 * height the physical height of the sail from tack to peak
 */
void CSailMould::setValuesForInterpol2 (const real footChord, const real chord1, const real chord2, const real topChord, const real height, const real istrength, const int intrp)  {
    profile[0] = CProfile(profile[0].getDepth(), profile[0].getLeech(), profile[0].getLuff(), footChord, profile[0].getProfileType(), profile[0].getProfileSubType());
    profile[1] = CProfile(profile[1].getDepth(), profile[1].getLeech(), profile[1].getLuff(), chord1, profile[1].getProfileType(), profile[1].getProfileSubType());
    profile[2] = CProfile(profile[2].getDepth(), profile[2].getLeech(), profile[2].getLuff(), chord2, profile[2].getProfileType(), profile[2].getProfileSubType());
    topProfile = CProfile(topProfile.getDepth(), profile[2].getLeech(), profile[2].getLuff(), topChord, topProfile.getProfileType(), topProfile.getProfileSubType());
    physicalHeight = height;
    baseProfile = CProfile(bottomDepth, profile[0].getLeech(), profile[0].getLuff(), footChord, profile[0].getProfileType(), profile[0].getProfileSubType());
    interpolRP = intrp;
    bUseInterpol2 = true;

    /*
     * if profile2 is deeper than profile1 then ignore the supplied strength value
     * and calculate one instead
     * */
    if (profile[2].getDepth() > profile[1].getDepth()) {
        // calculate strength from cambers
        CProfile pSave = profile[2];
        profile[2] = CProfile(profile[1].getDepth(), profile[2].getLeech(), profile[2].getLuff(), chord2, profile[2].getProfileType(), profile[2].getProfileSubType());
        real h = real(vertpos2) /100.0;
        // get height of profile 2 if strength were 1
        strength = 1;
        CProfile p = interpol2(h, chord2);
        real depth1 = p.physicalDepth();
        // get height if strength were 0
        strength = 0;
        p = interpol2(h, chord2);
        // calcuate what strength value would give us our profile2 camber depth
        real depth2 = p.physicalDepth();
        real depth3 = pSave.physicalDepth();
        // set strength
        // if calculated value is > 1 then strength = 1
        strength = min(1.0, (depth3-depth2)/(depth1-depth2));
        profile[2] = pSave;
    } else {
        strength = istrength;
    }

    // calculate 3rd point for circle
    CPoint3d pV1 = CPoint3d(profile[1].physicalDepth(), height * real(vertpos)/ 100.0, 0);
    CPoint3d topPoint = CPoint3d(0, height, 0);
    real baseDist = (topPoint - pV1).norm();

    real cosA = profile[1].physicalDepth() / baseDist;
//    real angleA = acos(cosA);
    circleRadius = baseDist / 2 /cosA;

    // circle calc
    circleCentre = CPoint3d(pV1.x()-circleRadius, pV1.y(),0);
//    chordLength = 2 * (height - pV1.y());
}

void CSailMould::setProfileType (enumProfileType pt, enumProfileSubType pst) {
    profileType = pt;
    profileSubType = pst;
    profile[0] = CProfile(profile[0].getDepth(), profile[0].getLeech(), profile[0].getLuff(), profile[0].getChord(), pt, pst);
    profile[1] = CProfile(profile[1].getDepth(), profile[1].getLeech(), profile[1].getLuff(), profile[1].getChord(), pt, pst);
    profile[2] = CProfile(profile[2].getDepth(), profile[2].getLeech(), profile[2].getLuff(), profile[2].getChord(), pt, pst);
    topProfile = CProfile(topProfile.getDepth(), topProfile.getLeech(), topProfile.getLuff(), topProfile.getChord(), pt, pst);
}

enumProfileType CSailMould::getProfileType() {
    return profileType;
}

bool CSailMould::useInterpol2() {
    return bUseInterpol2;
}
