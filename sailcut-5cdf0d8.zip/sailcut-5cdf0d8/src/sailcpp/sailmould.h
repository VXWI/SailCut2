/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef SAILMOULD_H
#define SAILMOULD_H

#include <geocpp/geocpp.h>
#include <vector>

enum enumProfileType {AERODYNAMIC, SYMMETRICAL};
enum enumProfileSubType {PROFILE_DEFAULT, PROFILE_ELLIPSE, PROFILE_ELLIPSE_FLAT, PROFILE_CIRCLE};

#define FLAT_PARAM 0.45

using namespace std;

/** Class used to work on sail profiles.
 *
 * @ingroup SailCpp
 * @see CSailMould
 */
class CProfile
{
public:
    //CProfile( real rDepth=0.05, real rLeech=0.02, real rLuff=1);
    CProfile( real rDepth=0.05, real rLeech=0.02, real rLuff=1, real chord = 1, enumProfileType pt = AERODYNAMIC, enumProfileSubType pst = PROFILE_DEFAULT);

    //CProfile& operator=( const CProfile & );
    real z( real dX );
    real slope( real dX );
    real camber( real dX );

    /** Accessor for the depth */
    real getDepth() const
    {
        return depth;
    }
    /** Accessor for the leech */
    real getLeech() const
    {
        return kleech;
    }
    /** Accessor for the luff */
    real getLuff() const
    {
        return kluff;
    }
    /** Accessor for xmax */
    real getMaxPos() const
    {
        return xmax;
    }
    /** Accessor for zmax */
    real getMaxDepth() const
    {
        return zmax;
    }
    /* chord accessor */
    real getChord() const
    {
        return chord;
    }

    enumProfileType getProfileType() const {
        return profileType;
    }

    enumProfileSubType getProfileSubType() const {
        return profileSubType;
    }

    real physicalDepth() const {
        return chord * depth;
    }

    /** Set the depth */
    void setDepth( real ndepth )
    {
        *this=CProfile( ndepth, kleech, kluff, chord, profileType );
    }
    /** Set the leech */
    void setLeech( real nkleech )
    {
        *this=CProfile( depth, nkleech, kluff, chord, profileType );
    }
    /** Set the luff */
    void setLuff( real nkluff )
    {
        *this=CProfile( depth, kleech, nkluff, chord, profileType );
    }

    /* set chord */
    void setChord( real nchord )
    {
        *this = CProfile( depth, kleech, kluff, nchord, profileType );
    }

    void setProfileType(enumProfileType ptype) {
        *this = CProfile( depth, kleech, kluff, chord, ptype );
    }
protected:
    void calcMax();

    // member variables
    /** depth */
    real depth;
    /** leech coefficient */
    real kleech;
    /** luff coefficient */
    real kluff;
    /** x location of maximum z */
    real xmax;
    /** maximum depth z */
    real zmax;
    /* chord */
    real chord;

    /** radius of curve used for symmetrical spinnakers */
    real radius;

    enumProfileType profileType;
    enumProfileSubType profileSubType;
    real aerodynamicZ( real dX );
    real symetricalZ( real dX );
};


/** Class used to store the profile for a sail.
 *
 * see CFormMould, CProfile
 */
class CSailMould
{
public:
    CSailMould();

    //CSailMould & operator=( const CSailMould & );
    CProfile interpol( const real h ) const;
    CProfile interpol2( const real h, const real chord ) const;
    CProfile interpol2Gaff( const real h, const real h1, const real chord ) const;
    void setValuesForInterpol2 (const real footChord, const real chord1, const real chord2, const real topChord, const real height, const real strength, const int interpolRP);
    void setProfileType (enumProfileType pt, enumProfileSubType pst = PROFILE_DEFAULT);
    enumProfileType getProfileType(void);
    bool useInterpol2(void);
    /** the mould's profiles ( top, middle, bottom ) */
    //  CProfile profile[3];
    vector<CProfile> profile;
    CProfile topProfile;
    CProfile baseProfile;

    /** vertical position of profile[1] in percent */
    int vertpos;
    /** vertical position of profile[2] in percent */
    int vertpos2 = 75;

    /** physical height of sail i.e. tack to peak distance*/
    real physicalHeight;
    /** centre of circle used in interpol2*/
    CPoint3d circleCentre;
    /** radius of circle used in interpol2 */
    real circleRadius;
    real strength;
    /** physical depth of curve below tack height */
    real footDepth = 1;
    real bottomDepth = 0;

private:
    enumProfileType profileType;
    enumProfileSubType profileSubType;
    int interpolRP;
    bool bUseInterpol2 = false;
};

#endif
