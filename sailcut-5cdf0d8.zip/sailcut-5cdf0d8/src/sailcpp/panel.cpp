/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <cmath>

#include "panel.h"
#include "sailcalc.h"

/*****************************************************************************

                              CPanelLabel class

*****************************************************************************/

/** Default constructor */
CPanelLabel::CPanelLabel()
        : name("new panel"), height(5), color(1), origin(CPoint3d(0,0,0)), direction(CVector3d(0,0,0))
{}


/** Copy constructor.
 */
//CPanelLabel::CPanelLabel( const CPanelLabel &lb )
//        : name(lb.name), height(lb.height), color(lb.color), origin(lb.origin), direction(lb.direction)
//{}


/** Rotates a label around a point.
 */
CPanelLabel CPanelLabel::rotate( const CPoint3d &p , const CMatrix &m ) const
{
    CPanelLabel lb;

    lb.name = name;
    lb.height = height;
    lb.color = color;
    lb.origin = p + m*(origin-p);
    lb.direction = m*direction;

    return lb;
}

// operators

/** Performs a 3D translation of a label by a given vector.
 */
CPanelLabel CPanelLabel::operator+ ( const CVector3d &transl ) const
{
    CPanelLabel lb;

    lb.name = name;
    lb.height = height;
    lb.color = color;
    lb.origin = origin + transl;
    lb.direction = direction;

    return lb;
}


/** Performs an assignment.
 */
/*CPanelLabel& CPanelLabel::operator= (const CPanelLabel &lb)
{
    if (&lb == this)
        return *this;

    name = lb.name;
    height = lb.height;
    color = lb.color;
    origin = lb.origin;
    direction = lb.direction;

    return *this;
}
*/

/*
CBattenPoints::CBattenPoints(const CBattenPoints &bp) {
    int n = bp.size();
    if (n > 0) {
        resize(n);
        for (int i=0; i<n; i++) {
            battenPoint *p = new battenPoint();
            p->battenId = bp.at(i).battenId;
            p->point = CPoint3d(bp.at(i).point);
            at(i)= *p;
        }
    }
}
*/
/** Constructs a set of batten points with a given number of points.
 */
CBattenPoints::CBattenPoints( unsigned int nbpoints )
{
    if (nbpoints == 0) {
        clear();
    } else {
        resize(nbpoints);
    }
}

/** Rotates a set of batten points around a point.
 */
CBattenPoints CBattenPoints::rotate( const CPoint3d &p, const CMatrix &m ) const
{
    CBattenPoints s( 0 );

    for (unsigned int i = 0 ; i < size() ; i++) {
        battenPoint* bp = new battenPoint();
        bp->battenId = at(i).battenId;
        bp->point = p + m * (at(i).point - p);
        bp->bFullLength = at(i).bFullLength;
        s.push_back(*bp);
    }

    return s;
}

CBattenPoints CBattenPoints::operator+ (const CVector3d &transl) const {
    //cout << "CBattenPoints::operator+ " << endl;
    CBattenPoints ret( size() );
    for (unsigned int i = 0 ; i < size() ; i++) {
        ret[i].point = transl + at(i).point;
        ret[i].battenId = at(i).battenId;
        ret[i].bFullLength = at(i).bFullLength;
    }
    return ret;

}

/*****************************************************************************

                              CPanel class

*****************************************************************************/

/**
 * @brief CPanel::CPanel constructor
 * @param widthPoint number of points in top and bottom sides
 * @param heightPoints number of points in left and right sides
 */
CPanel::CPanel(int widthPoint, int heightPoints)
        : left(heightPoints), right(heightPoints), top(widthPoint), bottom(widthPoint),
        cutLeft(heightPoints), cutRight(heightPoints), cutTop(widthPoint), cutBottom(widthPoint),
        hasHems(false), luffTape(heightPoints), footTape(widthPoint), bottomSeam(widthPoint),
    bPrintLeft(false), bPrintBottom(false), bPrintTop(true), bPrintFootTape(false), bPrintLuffTape(false),
    bLeechPanel(false), bLuffPanel(false), bFootPanel(false), patchType(PATCH_TYPE_NONE), panelType(PANEL_CROSS_CUT)
{}


/** Copy constructor.
 */
/*CPanel::CPanel( const CPanel &p )
        : label(p.label), left(p.left), right(p.right), top(p.top), bottom(p.bottom),
        cutLeft(p.cutLeft), cutRight(p.cutRight), cutTop(p.cutTop), cutBottom(p.cutBottom),
        hasHems(p.hasHems), luffTape(p.luffTape), footTape(p.footTape), bottomSeam(p.bottomSeam),
        aftBattenPoints(p.aftBattenPoints), foreBattenPoints(p.foreBattenPoints), aftBattenHemPoints(p.aftBattenHemPoints),
    bPrintLeft(p.bPrintLeft), bPrintBottom(p.bPrintBottom), bPrintTop(p.bPrintTop), bPrintFootTape(p.bPrintFootTape), bPrintLuffTape(p.bPrintLuffTape),
    bLeechPanel(p.bLeechPanel), bLuffPanel(p.bLuffPanel), bFootPanel(p.bFootPanel), bPatch(p.bPatch), patchType(p.patchType),
    panelType(p.panelType)

{
    //for (int i=0; i<p.battens.size(); i++) {
    //    battens.push_back(CBatten(p.battens[i]));
    //}
}
*/

/** This routine returns the smallest 3D box that contains the panel.
 */
CRect3d CPanel::boundingRect() const
{
    CRect3d rect;
    const CSide * sarray[4];
    if (hasHems)
    {
        sarray[0]=  &cutTop;
        sarray[1] = &cutBottom;
        sarray[2] = &cutLeft;
        sarray[3] = &cutRight;
        ;
    }
    else
    {
        sarray[0]=  &top;
        sarray[1] = &bottom;
        sarray[2] = &left;
        sarray[3] = &right;
        ;
    }

    rect.min = rect.max = top[0];

    for (unsigned int s = 0 ; s < 4 ; s++)
    {
        for (unsigned int i = 0 ; i < sarray[s]->size() ; i++)
        {
            CPoint3d curPoint = (*sarray[s])[i];
            for (unsigned int j = 0 ; j < 3 ; j++)
            {
                if ( curPoint[j] < rect.min[j] )
                    rect.min[j] = curPoint[j];
                if ( curPoint[j] > rect.max[j] )
                    rect.max[j] = curPoint[j];
            }
        }
    }

    return rect;
}

/** This routine returns the arithmetic average of all the edge points of a panel.
 */
CPoint3d CPanel::centroid() const
{
    const CSide * sarray[4] =
    {
        &top, &bottom, &left, &right
    };

    CPoint3d p, prev, sum;
    unsigned int  nbDiffPoints = 0;

    for (unsigned int s = 0; s < 4; s++)
    {
        for (unsigned int i = 0 ; i < sarray[s]->size() ; i++)
        {
            p = (*sarray[s])[i];
            if (( nbDiffPoints == 0) || ( p != prev ) )
            {
                // count only distinct points
                prev = p;
                sum = sum + p;
                nbDiffPoints++;
            }
        }
    }

    if ( nbDiffPoints > 0 )
    {
        real coeff = 1.0 / real(nbDiffPoints);
        sum = sum * coeff;
    }

    return sum;
}


/** This routine returns the development of the panel.
 *  The developed panel will be horizontal with its upper or lower edge
 *  aligned to X axis depending on parameter "align"=ALIGN_TOP or ALIGN_BOTTOM
 *
 *  @author Robert Laine alias Sailcuter
 */
CPanel CPanel::develop(enumDevelopAlign align) const
{
    CPanel flatpanel;
    unsigned int npl = left.size();   // number of right/left points
    unsigned int npb = bottom.size(); // number of top/bottom points
    unsigned int i;
    real a = 0, b = 0, c = 0; // sides of triangle
    real CC = 0;  // angle opposite to side c of triangle
    CVector3d v;
    CPoint3d p1, p2, p3, p4;  // points for 2 triangular elements of panel to be developed
    CPoint3d d3(0,0,0);  // point after development
    flatpanel.left.resize(npl);
    flatpanel.cutLeft.resize(npl);
    flatpanel.bottom.resize(npb);
    flatpanel.cutBottom.resize(npb);
    flatpanel.top.resize(npb);
    flatpanel.cutTop.resize(npb);
    flatpanel.right.resize(npl);
    flatpanel.cutRight.resize(npl);

    /** establish origine at bottom point 0 */
    flatpanel.bottom[0] = d3;

    /** establish the baseline as (top point1 - bottom point1) */
    p1= bottom[1];
    p2 = top[1];
    p3 = bottom[0];
    a = CVector3d( p2 - p1 ).norm(); // vertical side at point 1
    b = CVector3d( p3 - p1 ).norm(); // lower side of triangle
    c = CVector3d( p2 - p3 ).norm();
    CC = Atriangle( a , b , c );      // angle of bottom left corner = opposite to side a

    d3.x() =  b;   // set base of first triangle on X axis
    flatpanel.bottom[1] = d3;

    // set point at top of baseline
    d3 = flatpanel.bottom[0] + CMatrix::rot3d( 2 , CC ) * CVector3d( 1 , 0 , 0 ) * c;
    flatpanel.top[1] = d3;

    // set baseline vector
    v = CVector3d( flatpanel.bottom[1] - flatpanel.top[1] );

    /** develop left side of panel by triangulation */
    for (i = 0 ; i < npl ; i++)
    {
        p3 = left[i];
        b = CVector3d( p3 - p1 ).norm(); // lower side of triangle
        c = CVector3d( p3 - p2 ).norm(); // upper side of triangle
        CC = Atriangle( c , a , b );      // angle of bottom corner = opposite to upper side
        // transpose corner of triangle in development plane
        d3 = flatpanel.bottom[1] + CMatrix::rot3d( 2 , -PI+CC ) * v * ( b/v.norm() );
        flatpanel.left[i] = d3;
    }

    /** develop for'd batten points
        currrently only works for full-length battens
    */
    if (foreBattenPoints.size() > 0 ) {
        a = CVector3d( top[1] - bottom[1] ).norm();
        flatpanel.foreBattenPoints = CBattenPoints(foreBattenPoints);
        for (i = 0 ; i < foreBattenPoints.size() ; i++)
        {
            p3 = foreBattenPoints[i].point;
            b = CVector3d( p3 - bottom[1] ).norm(); // lower side of triangle
            c = CVector3d( p3 - p2 ).norm(); // upper side of triangle
            CC = Atriangle( c , a , b );      // angle of bottom corner = opposite to upper side
            // transpose corner of triangle in development plane
            d3 = flatpanel.bottom[1] + CMatrix::rot3d( 2 , -PI+CC ) * v * ( b/v.norm() );
            flatpanel.foreBattenPoints[i].point= d3;
        }
    }

    /** develop luff reef points
    */
    if (luffReefPoints.size() > 0 && panelType != PANEL_VERTICAL_LUFF && panelType != PANEL_VERTICAL_LUFF_GAFF) {
        a = CVector3d( top[1] - bottom[1] ).norm();
        flatpanel.luffReefPoints = luffReefPoints;
        for (i = 0 ; i < luffReefPoints.size() ; i++)
        {
            p3 = luffReefPoints[i];
            b = CVector3d( p3 - bottom[1] ).norm(); // lower side of triangle
            c = CVector3d( p3 - p2 ).norm(); // upper side of triangle
            CC = Atriangle( c , a , b );      // angle of bottom corner = opposite to upper side
            // transpose corner of triangle in development plane
            d3 = flatpanel.bottom[1] + CMatrix::rot3d( 2 , -PI+CC ) * v * ( b/v.norm() );
            flatpanel.luffReefPoints[i]= d3;
        }
    }

    // throat point if gaff sail
    if (panelType == PANEL_GAFF_THROAT) {
        p3 = throatPoint;
        b = CVector3d( p3 - p1 ).norm(); // lower side of triangle
        c = CVector3d( p3 - p2 ).norm(); // upper side of triangle
        CC = Atriangle( c , a , b );      // angle of bottom corner = opposite to upper side
        // transpose corner of triangle in development plane
        d3 = flatpanel.bottom[1] + CMatrix::rot3d( 2 , -PI+CC ) * v * ( b/v.norm() );
        flatpanel.throatPoint = d3;
    }


    // copy lower left point to bottom[0] to close the corner
    flatpanel.bottom[0] = flatpanel.left[0];
    // copy upper left point to top[0]
    flatpanel.top[0] = flatpanel.left[npl-1];

    /** develop body of panel by zig-zag triangulation */
    // reset baseline vector for lower right point
    v = CVector3d( flatpanel.bottom[1] - flatpanel.top[1] );
    c = v.norm();

    for (i = 1 ; i < npb-2 ; i++)
    {
        // define the 4 points corners of 2 adjacent triangles
        p1 = bottom[i];
        p2 = top[i];
        p3 = bottom[i+1];
        p4 = top[i+1];

        // first triangle = lower right p1-p2-p3
        a = c;
        b = CVector3d( p3 - p1 ).norm();
        c = CVector3d( p3 - p2 ).norm();
        CC = Atriangle( c , b , a );
        // transpose corner of triangle in development plane
        d3 = flatpanel.bottom[i] + CMatrix::rot3d( 2 , PI-CC )* v * ( b/v.norm() );
        flatpanel.bottom[i+1] = d3;

        // set baseline vector for upper right point
        v = CVector3d( flatpanel.top[i] - flatpanel.bottom[i+1] );

        // second triangle = upper right
        a = c;
        b = CVector3d( p4 - p2 ).norm();
        c = CVector3d( p4 - p3 ).norm();
        CC = Atriangle( c, b, a );
        // transpose corner of triangle in development plane
        d3 = flatpanel.top[i] + CMatrix::rot3d( 2 , -PI+CC )* v * ( b/v.norm() );
        flatpanel.top[i+1] = d3;

        // set next baseline vector
        v = CVector3d( flatpanel.bottom[i+1] - flatpanel.top[i+1] );
    }

    /** develop right side of panel */
    a= c;  // set baseline on last 2 points
    for (i = 0 ; i < npl ; i++)
    {
        p1 = right[i];
        b = CVector3d(p3-p1).norm(); // lower side of triangle
        c = CVector3d(p4-p1).norm(); // upper side of triangle
        CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
        // transpose corner of triangle in development plane
        d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d(2,PI-CC)* v *(b/v.norm());
        flatpanel.right[i]= d3;
    }

    // develop throat point if sail sail is vertical cut
    // in this case the throat will lie within right[] side
    if (panelType == PANEL_VERTICAL_LUFF_GAFF) {
        p1 = throatPoint;
        b = CVector3d(p3-p1).norm(); // lower side of triangle
        c = CVector3d(p4-p1).norm(); // upper side of triangle
        CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
        // transpose corner of triangle in development plane
        d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d(2,PI-CC)* v *(b/v.norm());
        flatpanel.throatPoint = d3;
    }

    // luff reef points for vertical cut
    if (luffReefPoints.size() > 0)
        cout << "has luff reef point(s)" << endl;
    if (luffReefPoints.size() > 0 && (panelType == PANEL_VERTICAL_LUFF || panelType == PANEL_VERTICAL_LUFF_GAFF)) {
        //a = CVector3d( top[1] - bottom[1] ).norm();
        flatpanel.luffReefPoints = luffReefPoints;
        for (i = 0 ; i < luffReefPoints.size() ; i++)
        {
            p1 = luffReefPoints[i];
            b = CVector3d(p3-p1).norm(); // lower side of triangle
            c = CVector3d(p4-p1).norm(); // upper side of triangle
            CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
            // transpose corner of triangle in development plane
            d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d( 2 , PI+CC ) * v * ( b/v.norm() );
            flatpanel.luffReefPoints[i]= d3;
        }
    }

    // copy lower right point to bottom end to close the corner
    flatpanel.bottom[npb-1]= flatpanel.right[0];
    // copy upper right point to top end
    flatpanel.top[npb-1]= flatpanel.right[npl-1];

    /** develop aft batten points */
    if (aftBattenPoints.size() > 0 ) {
        flatpanel.aftBattenPoints = CBattenPoints(aftBattenPoints);
        for (i = 0 ; i < aftBattenPoints.size() ; i++)
        {
            p1 = aftBattenPoints[i].point;
            b = CVector3d(p3-p1).norm(); // lower side of triangle
            c = CVector3d(p4-p1).norm(); // upper side of triangle
            CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
            // transpose corner of triangle in development plane
            d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d(2,PI-CC)* v *(b/v.norm());
            flatpanel.aftBattenPoints[i].point= d3;
            flatpanel.aftBattenPoints[i].battenId = flatpanel.aftBattenPoints[i].battenId;
        }
    }


    /** develop aft batten hempoints */
    if (aftBattenHemPoints.size() > 0 ) {
        flatpanel.aftBattenHemPoints = CBattenPoints(aftBattenHemPoints);
        for (i = 0 ; i < aftBattenHemPoints.size() ; i++)
        {
            p1 = aftBattenHemPoints[i].point;
            b = CVector3d(p3-p1).norm(); // lower side of triangle
            c = CVector3d(p4-p1).norm(); // upper side of triangle
            CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
            // transpose corner of triangle in development plane
            d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d(2,PI-CC)* v *(b/v.norm());
            flatpanel.aftBattenHemPoints[i].point= d3;
            flatpanel.aftBattenHemPoints[i].battenId = flatpanel.aftBattenHemPoints[i].battenId;
        }
    }

    /** develop leech reef points */
    if (leechReefPoints.size() > 0 ) {
        flatpanel.leechReefPoints = leechReefPoints;
        for (i = 0 ; i < leechReefPoints.size() ; i++)
        {
            p1 = leechReefPoints[i];
            // transpose corner of triangle in development plane
            if (panelType == PANEL_VERTICAL_LEECH) {
                unsigned int idx = bottom.nearestPointIndex(p1);
                CPoint3d pTop= top[idx];
                CPoint3d pBottom = bottom[idx];
                CVector3d vv = pBottom - pTop;
                b = CVector3d(pBottom-p1).norm(); // lower side of triangle
                c = CVector3d(pTop-p1).norm(); // upper side of triangle
                CC = Atriangle(c,vv.norm(),b);      // angle of bottom corner = opposite to upper side

                d3 = flatpanel.bottom[idx] - CMatrix::rot3d(2,CC)* vv *(b/vv.norm());
            } else {
                b = CVector3d(p3-p1).norm(); // lower side of triangle
                c = CVector3d(p4-p1).norm(); // upper side of triangle
                CC = Atriangle(c,a,b);      // angle of bottom corner = opposite to upper side
                d3 = flatpanel.bottom[npb-2] + CMatrix::rot3d(2,PI-CC)* v *(b/v.norm());
            }
            flatpanel.leechReefPoints[i] = d3;
        }
    }


    /** re-align panel with top or bottom edge along X axis */
    if (align != ALIGN_NONE) {
        if (align == ALIGN_TOP)
        { // align on top edge
            p1 = flatpanel.top[0];
            p2 = flatpanel.top[npb-1];
            CC = atan2( (p2.y()-p1.y()) , (p2.x()-p1.x()) );
        }
        else
        { // align on bottom edge
            p1 = flatpanel.bottom[0];
            p2 = flatpanel.bottom[npb-1];
            CC = atan2( (p2.y()-p1.y()) , (p2.x()-p1.x()) );
        }

        // align panel if not align none
        flatpanel = flatpanel.rotate(CPoint3d(0,0,0), CMatrix::rot3d(2,-CC) );
    }

    flatpanel.hasHems = false;
    flatpanel.bPrintBottom = bPrintBottom;
    flatpanel.bPrintLeft = bPrintLeft;
    flatpanel.bPrintTop = bPrintTop;
    flatpanel.bPrintRight = bPrintRight;
    flatpanel.bPrintFootTape = bPrintFootTape;
    flatpanel.bPrintLuffTape = bPrintLuffTape;
    flatpanel.bLeechPanel = bLeechPanel;
    flatpanel.bLuffPanel = bLuffPanel;
    flatpanel.bFootPanel = bFootPanel;
    flatpanel.patchType = patchType;
    flatpanel.panelType = panelType;

    /** frame the developed panel to be X>0 and Y>0 */
    flatpanel = flatpanel.reframe(LOW_LEFT);

    return flatpanel;
}

/**
 * @brief CPanel::splitLeft
 * @param xOffset offset of split from centreline. Negaive values will split to left, positive to right
 * @param seamWidth seam width to be added
 * @return a nee panel representing the left side of this panel
 */
CPanel CPanel::splitLeft(real xOffset, real seamWidth) const {
    CPanel newPanel = *this;
    CPoint3d p, p1;

    CRect3d bounds = boundingRect();
    real x = (bounds.min.x()+bounds.max.x())/ 2 + xOffset;

    newPanel.top.clear();
    newPanel.cutTop.clear();
    newPanel.bottom.clear();
    newPanel.cutBottom.clear();
    newPanel.right.clear();
    newPanel.cutRight.clear();

    for (unsigned int i=0; i<top.size(); i++) {
        if (top[i].x() < x) {
            newPanel.top.push_back(top[i]);
        } else {
            p = top[i];
            break;
        }
    }
    // calculate last point
    real fraction = (x - newPanel.top.back().x()) / (p.x() - newPanel.top.back().x() );
    p1 = newPanel.top.back()+ fraction * (p - newPanel.top.back());
    newPanel.top.push_back(p1);

    for (unsigned int i=0; i<cutTop.size(); i++) {
        if (cutTop[i].x() < x) {
            newPanel.cutTop.push_back(cutTop[i]);
        } else {
            p = cutTop[i];
            break;
        }
    }
    fraction = (x + seamWidth - newPanel.cutTop.back().x()) / (p.x() - newPanel.cutTop.back().x() );
    p1 = newPanel.cutTop.back()+ fraction * (p - newPanel.cutTop.back());
    newPanel.cutTop.push_back(p1);

    for (unsigned int i=0; i<bottom.size(); i++) {
        if (bottom[i].x() < x) {
            newPanel.bottom.push_back(bottom[i]);
        } else {
            p = bottom[i];
            break;
        }
    }

    fraction = (x - newPanel.bottom.back().x()) / (p.x() - newPanel.bottom.back().x() );
    p1 = newPanel.bottom.back() + fraction * (p - newPanel.bottom.back());
    newPanel.bottom.push_back(p1);

    for (unsigned int i=0; i<cutBottom.size(); i++) {
        if (cutBottom[i].x() < x) {
            newPanel.cutBottom.push_back(cutBottom[i]);
        } else {
            p = cutBottom[i];
            break;
        }
    }

    fraction = (x + seamWidth - newPanel.cutBottom.back().x()) / (p.x() - newPanel.cutBottom.back().x() );
    p1 = newPanel.cutBottom.back() + fraction * (p - newPanel.cutBottom.back());
    newPanel.cutBottom.push_back(p1);

    CVector3d v = newPanel.top.back() - newPanel.bottom.back();
    newPanel.right.push_back(newPanel.bottom.back());
    for (unsigned int i = 1; i< NUM_TOP_BOTTOM_POINTS; i++) {
        real f = (real) i / NUM_TOP_BOTTOM_POINTS;
        CPoint3d p = newPanel.bottom.back() + v * f;
        newPanel.right.push_back(p);
    }
    newPanel.right.push_back(newPanel.top.back());

    v = newPanel.cutTop.back() - newPanel.cutBottom.back();
    newPanel.cutRight.push_back(newPanel.cutBottom.back());
    for (unsigned int i = 1; i< NUM_TOP_BOTTOM_POINTS; i++) {
        real f = (real) i / NUM_TOP_BOTTOM_POINTS;
        CPoint3d p = newPanel.cutBottom.back() + v * f;
        newPanel.cutRight.push_back(p);
    }
    newPanel.cutRight.push_back(newPanel.cutTop.back());

    return newPanel;
}

/**
 * @brief CPanel::splitRight
 * @param xOffset offset of split from centreline. Negaive values will split to left, positive to right
 * @param seamWidth seam width to be added
 * @return a nee panel representing the right side of this panel
 */
CPanel CPanel::splitRight(real xOffset, real seamWidth) const {
    CPanel newPanel = *this;
    CPoint3d p, p1;

    CRect3d bounds = boundingRect();
    real x = (bounds.min.x()+bounds.max.x())/ 2 + xOffset;

    newPanel.top.clear();
    newPanel.cutTop.clear();
    newPanel.bottom.clear();
    newPanel.cutBottom.clear();
    newPanel.left.clear();
    newPanel.cutLeft.clear();

    for (unsigned int i=0; i<top.size(); i++) {
        if (top[i].x() > x) {
            newPanel.top.push_back(top[i]);
        } else {
            p = top[i];
        }
    }
    // calculate first point
    real fraction = ((x+seamWidth) - p.x()) / (newPanel.top.front().x() - p.x());
    p1 = p + fraction * (newPanel.top.front() - p);
    newPanel.top.insert(newPanel.top.begin(), p1);


    for (unsigned int i=0; i<bottom.size(); i++) {
        if (bottom[i].x() > x) {
            newPanel.bottom.push_back(bottom[i]);
        } else {
            p = bottom[i];
        }
    }
    fraction = ((x+seamWidth) - p.x()) / (newPanel.bottom.front().x() - p.x());
    p1 = p + fraction * (newPanel.bottom.front() - p);
    newPanel.bottom.insert(newPanel.bottom.begin(), p1);

    for (unsigned int i=0; i<cutTop.size(); i++) {
        if (cutTop[i].x() > x) {
            newPanel.cutTop.push_back(cutTop[i]);
        } else {
            p = cutTop[i];
        }
    }

    fraction = ((x+seamWidth) - p.x()) / (newPanel.cutTop.front().x() - p.x());
    p1 = p + fraction * (newPanel.cutTop.front() - p);
    newPanel.cutTop.insert(newPanel.cutTop.begin(), p1);


    for (unsigned int i=0; i<cutBottom.size(); i++) {
        if (cutBottom[i].x() > x) {
            newPanel.cutBottom.push_back(cutBottom[i]);
        } else {
            p = cutBottom[i];
        }
    }

    fraction = ((x+seamWidth) - p.x()) / (newPanel.cutBottom.front().x() - p.x());
    p1 = p + fraction * (newPanel.cutBottom.front() - p);
    newPanel.cutBottom.insert(newPanel.cutBottom.begin(), p1);


    newPanel.left.push_back(newPanel.bottom.front());
    newPanel.left.push_back(newPanel.top.front());
    newPanel.cutLeft.push_back(newPanel.cutBottom.front());
    newPanel.cutLeft.push_back(newPanel.cutTop.front());

    return newPanel;

}

/** Place the label at the center of the panel */
void CPanel::placeLabel()
{
    label.origin = centroid();
}


/** Reframe a panel such that the most left/right/top/bottom
 *  point is at coordinate X or Y =0
 */
CPanel CPanel::reframe(enumAlign align) const
{
    unsigned int npl = left.size();   // number of right/left points
    unsigned int npb = bottom.size();  // number of top/bottom points
    unsigned int i;
    real xm=11111, ym=11111;

    switch ( align )
    {
    case LEFT:
        if ( hasHems == true )
        {
            for (i = 0 ; i < npl ; i++)
            {
                if ( cutRight[i].x() < xm )
                    xm = cutRight[i].x();
            }
        }
        else
        {
            for (i = 0 ; i < npl ; i++)
            {
                if ( right[i].x() < xm )
                    xm = right[i].x();
            }
        }
        break;
    case BOTTOM:
        if ( hasHems == true )
        {
            for (i = 0 ; i < npb ; i++)
            {
                if ( cutBottom[i].y() < ym )
                    ym = cutBottom[i].y();
            }
        }
        else
        {
            for (i = 0; i < npb; i++)
            {
                if ( bottom[i].y() < ym )
                    ym = bottom[i].y();
            }
        }
        break;
    case LOW_LEFT:
        if ( hasHems ==  true )
        {
            for (i = 0; i < npl; i++)
            {
                if ( cutLeft[i].x() < xm )
                    xm = cutLeft[i].x();
            }

            for (i = 0; i < npb; i++)
            {
                if ( cutBottom[i].y() < ym )
                    ym = cutBottom[i].y();
            }
        }
        else
        {
            for (i = 0; i < npl; i++)
            {
                if ( left[i].x() < xm )
                    xm = left[i].x();
            }

            for (i = 0; i < npb; i++)
            {
                if ( bottom[i].y() < ym )
                    ym = bottom[i].y();
            }
        }
    }

    return (*this + CVector3d( -xm , -ym , 0 ));
}
/** Add the cloth for stitching to the 4 edges of the panel.
 *  This create the panel to be cut (outside the basic panel)
 *   lw = width to be added on left side
 *   tw = width to be added on top side
 *   rw = width to be added on right side
 *   bw = width to be added on bottom side
 *
 * @author Robert Laine alias Sailcuter
 */

void CPanel::addHems( const real &lw, const real &tw, const real &rw, const real &bw )
{
    add6Hems( lw, lw, tw, rw, rw, bw );
}

/** Add the cloth for stitching to the 6 edges of the panel.
 *  This create the panel to be cut (outside the basic panel)
 *   lolW, hilW = width to be added on lo-hi left side
 *   topW = width to be added on top side
 *   lorW, hirW = width to be added on lo-hi right side
 *   botW = width to be added on bottom side
 *
 * @author Robert Laine alias Sailcuter
 */

void CPanel::add6Hems( const real &lolW, const real &hilW, const real &topW, const real &hirW, const real &lorW, const real &botW )
{
    hasHems = true;
    CPoint3d pt(0,0,0);
    CVector3d v(1,0,0);
    CVector3d v0(1,0,0);
    CSubSpace Line1, Line2; // two lines

    real minSize = 0.1;     // used to avoid computation near zero width side
    unsigned int i = 0;
    unsigned int npl = left.size(), npb = bottom.size(), npr = right.size(), npt = top.size();

    ///* compute basic edges vectors */
    CVector3d v1 = CVector3d( left[npl/2] - left[0] );
    //  if ( v1.norm() == 0 ) cout << "CPanel::add6Hems v1=0 " << endl;
    CVector3d v2 = CVector3d( left[npl-1] - left[npl/2] );
    //  if ( v2.norm() == 0 ) cout << "CPanel::add6Hems v2=0 " << endl;
    CVector3d v3 = CVector3d( right[npr/2] - right[0] );
    //  if ( v3.norm() == 0 ) cout << "CPanel::add6Hems v3=0 " << endl;
    CVector3d v4 = CVector3d( right[npr-1] - right[npr/2] );
    //  if ( v4.norm() == 0 ) cout << "CPanel::add6Hems v4=0 " << endl;
    CVector3d v5 = CVector3d( bottom[npb-1] - bottom[0] );
    //  if ( v5.norm() == 0 ) cout << "CPanel::add6Hems v5=0 " << endl;
    CVector3d v6 = CVector3d( bottom[npb-1] - bottom[npb-2] );
    //  if ( v6.norm() == 0 ) cout << "CPanel::add6Hems v6=0 " << endl;
    CVector3d v7 = CVector3d( top[npt-1] - top[0] );
    //  if ( v7.norm() == 0 ) cout << "CPanel::add6Hems v7=0 " << endl;
    CVector3d v8 = CVector3d( top[npt-1] - top[npt-2] );

    ///* copy the basic panel edge points to cut points as default */
    cutLeft = CSide(npl);
    cutRight = CSide(npr);
    cutBottom = CSide(npb);
    cutTop = CSide(npt);

    for (i = 0 ; i < npl ; i++) {
        cutLeft[i] = left[i];
    }

    for (i = 0 ; i < npr ; i++) {
        cutRight[i] = right[i];
    }

    for (i = 0 ; i < npb ; i++) {
        cutBottom[i] = bottom[i];
    }

    for (i = 0 ; i < npt ; i++) {
        cutTop[i] = top[i];
    }

    //cutLeft = left;
    //cutRight = right;
    //cutTop = top;
    //cutBottom = bottom;

    if ( v5.norm() < minSize && v7.norm() < minSize )   // panel is a point
        throw panel_error("CPanel::add6Hems : bottom panel edges v5 and v6 too small");

    if (v5.norm() < minSize ) {   // bottom side too small copy top
        v5 = v7.unit();
        v6 = v5;
    }
    else {   // reset v5 to bottom left point
        v5 = CVector3d( bottom[1] - bottom[0] );
    }

    if (v7.norm() < minSize ) {   // top side too small copy bottom
        v7 = v5.unit();
        v8 = v7;
    }
    else {   // reset v7 to top left point
        v7 = CVector3d( top[1] - top[0] );
    }

    ///* Move the basic bottom edge points to the cut line */
    //cout << "CPanel::add6Hems move basic bottom edge" << endl;

    if ( botW >= EPS ) { // width of material is not too small
        for (i = 0 ; i < npb ; i++) {
            if ( i == 0 )
                v = CVector3d( bottom[1] - bottom[0] );
            else
                v = CVector3d( bottom[i] - bottom[i-1] );

            if ( v.norm() <= EPS )
                v = v5;

            cutBottom[i] = bottom[i] + CMatrix::rot3d(2,-PI/2) * v.unit() *botW;
        }
    }// else  if (topW > EPS ){
     //   bottom[i] =  bottom[i] + CMatrix::rot3d(2,-PI/2) * v.unit() * topW * -1;
    //}

    ///* Move the basic top edge points to the cut line */
    if ( topW >= EPS ) { // width of material is not too small
        for (i = 0 ; i < npt ; i++) {
            if ( i == 0 )
                v = CVector3d( top[1] - top[0] );
            else
                v = CVector3d( top[i] - top[i-1] );

            if ( v.norm() <= minSize )
                v = v7;

            cutTop[i] = top[i] + CMatrix::rot3d(2,PI/2) * v.unit() *topW;
        }
    }

    ///* Move the basic left edge points to the cut line */
    if ( v1.norm() >= minSize ) {  // lower left side is not a point
        for (i = 0 ; i < npl/2 ; i++) {
            if ( i == 0 )
                v = CVector3d( left[1] - left[0] );
            else
                v = CVector3d( left[i] - left[i-1] );

            cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v.unit() * lolW;
        }

        v0 = CVector3d( left[npl/2] - left[npl/2 -1] );
        Line1 = CSubSpace3d::line( cutLeft[npl/2 -1] , v0 );

        if ( v2.norm() >= minSize ) {  // upper left side is not a point
            for (i = npl/2 +1 ; i < npl ; i++) {
                v2 = CVector3d( left[i] - left[i-1] );

                cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v2.unit() * hilW;

                if ( i == npl/2 +1 ) {   // compute mid side break point
                    Line2 = CSubSpace3d::line( cutLeft[i] , v2 );

                    if ( Line1.intersect(Line2).getdim() == 0 )
                        cutLeft[npl/2] = Line1.intersect(Line2).getp();
                    // else cout << "CPanel::add6Hems = no mid left side intersection point" << endl;

                    // check adjacent points relative to mid side point
                    if ( (CVector3d(cutLeft[npl/2] - cutLeft[npl/2 -1]) * v0) <= 0 )
                        cutLeft[npl/2 -1] = cutLeft[npl/2 -2];
                    if ( (CVector3d(cutLeft[npl/2 +1] - cutLeft[npl/2]) * v0) <= 0 )
                        cutLeft[npl/2 +1] = cutLeft[npl/2 +2];
                }
                else {   // compute other uppr lft points
                    cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v2.unit() * hilW;
                    // check position relative to mid side point
                    if ( (CVector3d(cutLeft[i] - cutLeft[npl/2]) * v0) <= 0 )
                        cutLeft[npl/2 +1] = cutLeft[npl/2];
                }
            }
        }
        else {  // upper left side is a point but not lower side
            v2 = CVector3d( left[npl/2] - left[npl/2 -1] );
            for (i = npl/2 +1 ; i < npl ; i++)
                cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v2.unit() * hilW;
        }
    }
    else if ( v2.norm() >= minSize ) {
        // only lower left side is a point
        v1 = CVector3d( left[npl/2 +1] - left[npl/2] );
        for (i = 0 ; i < npl/2  ; i++)
            cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v1.unit() * lolW;

        for (i = npl/2 +1 ; i < npl -1 ; i++)
        {
            v2 = CVector3d( left[i] - left[i-1] );
            cutLeft[i] = left[i] + CMatrix::rot3d( 2 , PI/2) * v2.unit() * hilW;
        }
    }
    else {
        // complete left side is a point
        if ( botW == 0 )
            v = -v5; // extend the bottom edge
        else
            v = -( v5.unit() + v7.unit() ); // extend in bissectrice top-bottom

        for (i = 0 ; i< npl ; i++)
            cutLeft[i] = left[i] + v.unit() * lolW;

        // if (v.norm() == 0) cout << "CPanel::add6Hems 10 v=0 v5="<< v5.norm()<< " v7="<< v7.norm()<< endl;
        v1 = CMatrix::rot3d(2,-PI/2) * v.unit();
        v2 = v1;

    }

    if (lorW > 0 || hirW > 0) {
        ///* Move the basic right edge points to the cut line */
        if ( v3.norm() >= minSize ) {  // lower right side is not a point
            for (i = 0 ; i < npr/2 ; i++) {
                if ( i == 0 ) {
                    if ( right[i+1] != right[i] )
                        v = CVector3d( right[i+1] - right[i] );
                    else if ( right[i+2] != right[i] )
                        v = CVector3d( right[i+2] - right[i] );
                    else if ( right[i+3] != right[i] )
                        v = CVector3d( right[i+3] - right[i] );
                    else if ( right[i+4] != right[i] )
                        v = CVector3d( right[i+4] - right[i] );
                }
                else {
                    if ( right[i] != right[i-1] )
                        v = CVector3d( right[i] - right[i-1] );
                    else if ( right[i+1] != right[i] )
                        v = CVector3d( right[i+1] - right[i] );
                    else if ( right[i+2] != right[i] )
                        v = CVector3d( right[i+2] - right[i] );
                }
                cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v.unit() * lorW;
            }

            v0 = CVector3d( right[npr/2] - right[npr/2 -1] );
            Line1 = CSubSpace3d::line( cutRight[npr/2 -1] , v0 );

            // alternate method of calculating middle point
            // NOTE that currently there aren't any calls where lorW and hirW are different
            if (lorW == hirW) {
                CVector3d vMid = right[npr/2+1] - right[npr/2-1];
                CVector3d vMidP = CMatrix::rot3d(2, -PI/2) * vMid.unit();

                cutRight[npr/2] = right[npr/2] + vMidP.unit() * hirW;
            }

            if ( v4.norm() >= minSize ) {  // upper right side is not a point
                for (i = npr/2 +1 ; i < npr ; i++) {
                    v4 = CVector3d( right[i] - right[i-1] );
                    cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v4.unit() * hirW;
                    if ( i == npr/2 +1 ) {   // compute mid side break point
                        Line2 = CSubSpace3d::line( cutRight[i] , v4 );
                        // if lo and hi are different then fall back to old, buggy method of
                        // calculating middle point
                        if (lorW != hirW) {
                            if (Line1.intersect(Line2).getdim() == 0)
                                cutRight[npr/2] = Line2.intersect(Line1).getp();

                        }
                        // else cout << "CPanel::add6Hems = no mid right side intersection point" << endl;

                        // check adjacent points relative to mid side point
                        if ( (CVector3d(cutRight[npr/2] - cutRight[npr/2 -1]) * v0) <= 0 )
                            cutRight[npr/2 -1] = cutRight[npr/2 -2];
                        if ( (CVector3d(cutRight[npr/2 +1] - cutRight[npr/2]) * v0) <= 0 )
                            cutRight[npr/2 +1] = cutRight[npr/2 +2];
                    }
                    else {   // compute other points
                        cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v4.unit() * hirW;
                    }
                }
            }
            else { // upper right side is a point but not lower side
                v4 = CVector3d( right[npr-1] - right[npr-2] );

                for (i = npr/2 +1 ; i < npr ; i++)
                    cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v4.unit() * hirW;
            }
        }
        else if ( v4.norm() >= minSize ) {   // only lower right side is a point
            v3 = v4;
            //v3 = CVector3d( right[npl-2] - right[npl/2] );
            /*        if (v3.norm() == 0)
                {
                        cout << "AddHems v3=0 : about to crash 13" << endl;
                    for (i = 0 ; i < npl ; i++)
                        cout << "pt " << i << " xyz= " << right[i] << endl;
                }
        */
            for (i = 0 ; i < npr/2  ; i++)
                cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v4.unit() * lorW;

            for (i = npr/2 +1 ; i < npr ; i++) {
                cutRight[i] = right[i] + CMatrix::rot3d( 2 , -PI/2) * v4.unit() * hirW;
            }
            v4 = CVector3d( right[npr-1] - right[npr-2] );
            //    if (v4.norm() == 0) cout << "AddHems v4=0 about to crash 13" << endl;
        }
        else {  // complete right side is a point
            if ( botW == 0 )
                v = v6;
            else
                v = ( v6 + v8 );

            if (v.norm() == 0) cout << "CPanel::add6Hems v=v6=0 or v=v6+v8=0 about to crash 14" << endl;

            for (i = 0 ; i< npr ; i++)
                cutRight[i] = right[i] + v.unit() * lorW;

            v3 = CMatrix::rot3d(2 , PI/2) * v.unit();
            v4 = v3;
        }

    }

    // batten aft hem points
    for (unsigned int i=0; i<aftBattenPoints.size(); i++) {
        battenPoint b = aftBattenPoints.at(i);
        battenPoint * bHem = new battenPoint;
        bHem->battenId = b.battenId;
        bHem->name = b.name;
        bHem->point = b.point  + CMatrix::rot3d( 2 , -PI/2) * v.unit() * lorW;
        aftBattenHemPoints.push_back(*bHem);
    }

    ///* Rejoining the 4 corners of the cut panel */
    // cout << "Rejoining 4 corners" << endl;
    /// lower left
    Line1 = CSubSpace3d::line( cutBottom[0] , v5 );

    if (v6.norm() == 0)
        cout << "CPanel::add6Hems v6=0 about to crash 16" << endl;
    Line2 = CSubSpace3d::line( cutLeft[0] , v1 );

    if (Line1.intersect(Line2).getdim() == 0)
        pt = Line1.intersect(Line2).getp();
    else throw panel_error("CPanel::add6Hems = in rejoining lower corner, no left intersection point");

    /* Adjust the lower left point [0] to be at intersection */
    cutBottom[0] = pt;
    cutLeft[0] = pt;

    /* Scan the first few points of the cut edges to make sure
     * that they are not on the wrong side of the point pt
     */
    for (i = 0 ; i < npl/2 ; i++) {
        if ( (CVector3d( cutLeft[i] - pt) * v1 ) <= 0 )
            cutLeft[i] = pt;
    }

    for (i=0; i<npb/2; i++) {
        if ( (CVector3d( cutBottom[i] - pt) * v5 ) <= 0 )
            cutBottom[i] = pt;

    }

    /// lower right
    Line1 = CSubSpace3d::line( cutBottom[npb-1] , v6 );
    Line2 = CSubSpace3d::line( cutRight[0] , v3 );

    if (Line1.intersect(Line2).getdim() == 0)
        pt = Line1.intersect(Line2).getp();
    else throw panel_error("CPanel::add6Hems = in rejoining lower corner, no right intersection point");

    /* Adjust the lower left point [0] to be at intersection */
    cutBottom[npb-1] = pt;
    cutRight[0] = pt;

    /* Scan the first few points of the cut edges to make sure
     * that they are not on the wrong side of the point pt
     */
    for (i = 1 ; i < min(npr/2, min(npr,npb)) ; i++) {
        if ( (CVector3d( cutRight[i] - pt) * v3 ) <= 0 )
            cutRight[i] = pt;
        if ( (CVector3d( cutBottom[npb-1-i] - pt) * v6 ) >= 0 )
            cutBottom[npb-1-i] = pt;
    }

    /// upper left
    Line1 = CSubSpace3d::line( cutTop[0] , v7 );
    Line2 = CSubSpace3d::line( cutLeft[npl-1] , v2 );

    if (Line1.intersect(Line2).getdim() == 0)
        pt = Line1.intersect(Line2).getp();
    else throw panel_error("Cpanel.add6Hems = in rejoining upper corner, no left intersection point");

    /* Adjust the upper left point to be at intersection */
    cutTop[0] = pt;
    cutLeft[npl-1] = pt;

    /* Scan the first few points of the cut edges to make sure
     * that they are not on the wrong side of the intersect point pt
     */
    for (i = 0 ; i < min(npl/2, min(npl, npt)) ; i++) {
        if ( (CVector3d( cutLeft[npl -1 -i] - pt) * v2 ) >= 0 )
            cutLeft[npl-1-i] = pt;
        if ( (CVector3d( cutTop[i] - pt) * v7 ) <= 0 )
            cutTop[i] = pt;
    }

    /// upper right
    Line1 = CSubSpace3d::line( cutTop[npt-1] , v8 );
    Line2 = CSubSpace3d::line( cutRight[npr-1] , v4 );

    if (Line1.intersect(Line2).getdim() == 0)
        pt = Line1.intersect(Line2).getp();
    else throw panel_error ("Cpanel.add6Hems = in rejoining upper corner, no right intersection point");

    /* Adjust the upper right point to be at intersection */
    cutTop[npt-1] = pt;
    cutRight[npr-1] = pt;

    /* Scan the first few points of the cut edges to make sure
     * that they are not on the wrong side of the intersect point pt
     */
    // cout << "CPanel::add6Hems scan for overlap " << endl;
    for (i = 1 ; i < npr/2 ; i++) {
        if ( (CVector3d( cutRight[npr-1-i] - pt) * v4 ) >= 0 )
            cutRight[npr-1-i] = pt;
    }
    for (i = 1 ; i < npt/2 ; i++) {
        if ( (CVector3d(cutTop[npt-1-i] - pt) * v6) >= 0 )
            cutTop[npt-1-i] = pt;
    }

    // set print flags
    if ((cutLeft.front()-left.front()).norm() > 0.1) {
        switch (panelType) {
        case PANEL_VERTICAL:
        case PANEL_VERTICAL_LEECH:
        case PANEL_VERTICAL_LUFF:
        case PANEL_VERTICAL_LUFF_GAFF:
            bPrintLeft = true;
            break;
        default:
            bPrintLeft = false;
        }
    }

    if (lorW > 0 || hirW > 0) {
        bPrintRight = true;
    } else {
        bPrintRight = false;
    }
    // cout << "End CPanel::add6Hems" << endl << endl;
} /// end add6Hems ////////////////////////////////////////

/**
  * add assembly lines for luff tape, foot tape and bottom seam
  * luffTapeWidth distance in from luff for luff tape assembly line
  * footTapeWidth distance up from foot for foot tape assembly line
  * seamW seam width
  */

void CPanel::addAssemblyLines(const real &luffTapeDistance, const real &footTapeDistance, const real &seamW, const bool &bSplitLuff) {
    //CPoint3d pt(0,0,0);
    CVector3d v(1,0,0);
    //CVector3d v0(1,0,0);
    //CSubSpace Line1, Line2; // two lines

    //cout << "addAssemblyLines: luffTapeDistance=" << luffTapeDistance <<"    footTapeDistance="<<footTapeDistance<<"    seamW="<<seamW<<endl;
    //real minSize = 0.1;     // used to avoid computation near zero width side

    bPrintFootTape = footTapeDistance > EPS;
    bPrintLuffTape = luffTapeDistance > EPS;

    unsigned int i = 0;
    unsigned int npl = left.size(), npb = bottom.size();

    ///* compute basic edges vectors */
    CVector3d v1 = CVector3d( left[npl/2] - left[0] );
    //  if ( v1.norm() == 0 ) cout << "CPanel::add6Hems v1=0 " << endl;
    CVector3d v2 = CVector3d( left[npl-1] - left[npl/2] );
    //  if ( v2.norm() == 0 ) cout << "CPanel::add6Hems v2=0 " << endl;
    CVector3d v3 = CVector3d( right[npl/2] - right[0] );
    //  if ( v3.norm() == 0 ) cout << "CPanel::add6Hems v3=0 " << endl;
    CVector3d v4 = CVector3d( right[npl-1] - right[npl/2] );
    //  if ( v4.norm() == 0 ) cout << "CPanel::add6Hems v4=0 " << endl;
    CVector3d v5 = CVector3d( bottom[npb-1] - bottom[0] );
    //  if ( v5.norm() == 0 ) cout << "CPanel::add6Hems v5=0 " << endl;
    CVector3d v6 = CVector3d( bottom[npb-1] - bottom[npb-2] );
    //  if ( v6.norm() == 0 ) cout << "CPanel::add6Hems v6=0 " << endl;
    CVector3d v7 = CVector3d( top[npb-1] - top[0] );
    //  if ( v7.norm() == 0 ) cout << "CPanel::add6Hems v7=0 " << endl;
    CVector3d v8 = CVector3d( top[npb-1] - top[npb-2] );

    real rotationDir = 1;
    bool bVertical = false;

    CSide sFoot, sLuff;
    switch (panelType) {
    case PANEL_VERTICAL:
    case PANEL_VERTICAL_LEECH:
    case PANEL_VERTICAL_LUFF:
    case PANEL_VERTICAL_LUFF_GAFF:
    case PANEL_MITRE_FOOT_MITRE:
    case PANEL_MITRE_FOOT_LUFF:
        sFoot = cutLeft;
        sLuff = cutRight;
        rotationDir = -1;
        bVertical = true;
        if (luffTapeDistance > 0) {
            //bPrintTop = false;
            bPrintLuffTape = true;
        } else {
            //bPrintTop = true;
            bPrintLuffTape = false;
        }
        if (footTapeDistance > 0) {
            bPrintLeft = false;
            bPrintFootTape = true;
        } else {
            bPrintFootTape = false;
        }
        break;
    case PANEL_MITRE_FOOT_MITRE_LUFF:
        sFoot = cutLeft;
        sLuff.clear();
        for (unsigned int i= cutRight.size()/2; i<cutRight.size(); i++) {
            sLuff.push_back(cutRight[i]);
        }
        rotationDir = -1;
        bVertical = true;
        if (luffTapeDistance > 0) {
            //bPrintTop = false;
            bPrintLuffTape = true;
        } else {
            //bPrintTop = true;
            bPrintLuffTape = false;
        }
        if (footTapeDistance > 0) {
            bPrintLeft = false;
            bPrintFootTape = true;
        } else {
            bPrintFootTape = false;
        }
        break;
    case PANEL_MITRE_LEECH_MITRE_LUFF:
        sFoot = cutBottom;
        sLuff.clear();
        for (unsigned int i= cutLeft.size()/2; i<cutLeft.size(); i++) {
            sLuff.push_back(cutLeft[i]);
        }
        if (luffTapeDistance > 0) {
            bPrintLeft = false;
            bPrintLuffTape = true;
        } else {
            //bPrintLeft = true;
            bPrintLuffTape = false;
        }
        if (footTapeDistance > 0) {
            bPrintBottom = false;
            bPrintFootTape = true;
        } else {
            bPrintFootTape = false;
        }
        break;
    default:
        sFoot = cutBottom;
        sLuff = cutLeft;
        if (luffTapeDistance > 0) {
            bPrintLeft = false;
            bPrintLuffTape = true;
        } else {
            //bPrintLeft = true;
            bPrintLuffTape = false;
        }
        if (footTapeDistance > 0) {
            bPrintBottom = false;
            bPrintFootTape = true;
        } else {
            bPrintFootTape = false;
        }
        break;
    }

    v5 = CVector3d( sFoot[sFoot.size()-1] - sFoot[0] );
    footTape.resize(sFoot.size());
    luffTape.resize(sLuff.size());

    if ( seamW >= EPS ) { // width of material is not too small
        for (i = 0 ; i < cutBottom.size() ; i++) {
            if ( i == 0 )
                v = CVector3d( cutBottom[1] - cutBottom[0] );
            else
                v = CVector3d( cutBottom[i] - cutBottom[i-1] );

            if ( v.norm() <= EPS )
                v = v5;

            bottomSeam[i] = cutBottom[i] + CMatrix::rot3d(2,PI/2) * v.unit() *seamW;
        }
    } else {
        bottomSeam = bottom;
    }

    if (bSplitLuff) {
        // find corner
        unsigned int iCorner = sLuff.size()/2;
        for (unsigned int i=1; i<sLuff.size(); i++) {
            if (sLuff[i].x() > sLuff[i-1].x()) {
                iCorner = i-1;
                break;
            }
        }
        //cout << "iCorner = " << iCorner << endl;
        if (footTapeDistance >= EPS) {
            cout << "split: processing foot tape" << endl;
            footTape.resize(iCorner+1);
            for (i = 0 ; i < iCorner+1 ; i++) {
                if ( i == 0 )
                    v = CVector3d( sLuff[1] - sLuff[0] );
                else
                    v = CVector3d( sLuff[i] - sLuff[i-1] );

                if ( v.norm() <= EPS )
                    v = v5;

                footTape[i] = sLuff[i] - CMatrix::rot3d(2,PI/2*rotationDir) * v.unit() *footTapeDistance*rotationDir;
            }
        } else {
            footTape = bottom;
        }

        if (luffTapeDistance > EPS) {
            //cout << "split: processing luff tape" << endl;
            //cout << "resizing luffTape to " << npl-iCorner << endl;
            luffTape.resize(sLuff.size()-iCorner-1);
            unsigned int j = 0;
            CSide s = sLuff;//panelType == PANEL_GAFF_TOP ? top : left;
            for (i = iCorner+1; i < s.size() ; i++) {
                v = CVector3d( s[i] - s[i-1] );

                if ( v.norm() <= EPS )
                    v = v5;

                luffTape[j++] = s[i] - CMatrix::rot3d(2,PI/2) * v.unit() *luffTapeDistance*rotationDir;
            }
        } else {
            luffTape = sLuff;
        }

    } else {
        if (footTapeDistance >= EPS) {
            //cout << "processing foot tape" << endl;
            for (i = 0 ; i < sFoot.size() ; i++) {
                if ( i == 0 )
                    v = CVector3d( sFoot[1] - sFoot[0] );
                else
                    v = CVector3d( sFoot[i] - sFoot[i-1] );

                if ( v.norm() <= EPS )
                    v = v5;

                footTape[i] = sFoot[i] + CMatrix::rot3d(2,PI/2) * v.unit() *footTapeDistance*rotationDir;
            }
        } else {
            footTape = sFoot;
        }

        if (luffTapeDistance > EPS) {
            luffTape.clear();
            //cout << "processing luff tape" << endl;
            CSide s = sLuff;//panelType == PANEL_GAFF_TOP ? top : left;
            for (i = 0 ; i < s.size() ; i++) {
                if ( i == 0 )
                    v = CVector3d( s[1] - s[0] );
                else
                    v = CVector3d( s[i] - s[i-1] );

                if ( v.norm() <= EPS )
                    v = v5;

                CPoint3d p = s[i] - CMatrix::rot3d(2,PI/2) * v.unit() *luffTapeDistance*rotationDir;
                        luffTape.push_back(p);
            }

        } else {
            luffTape = sLuff;
        }
    }
    if (luffTapeDistance > 0 || footTapeDistance > 0) {
        // trim
        trimLuffAndFootTape(luffTapeDistance, footTapeDistance, bVertical);
    }

}

/**
 * @brief CPanel::trimLuffAndFootTape trim polyline(s) so that it doesn't protrude below bottom of panel
 * @param luffTapeDistance the distance of the line in from the luff
 * @param footTapeDistance the distance of the line in from the foot
 * @param bVertical indicates that panel is vertical
 */
void CPanel::trimLuffAndFootTape(const real &luffTapeDistance, const real &footTapeDistance, bool bVertical) {
    unsigned int luffIdx = 0, footIdx = 0;

    if (bVertical) {
        if (luffTapeDistance > 0) {
            // trim luff tape back to inside the bounding rectangle
            CRect3d rect = boundingRect();

            luffIdx = luffTape.size()+1;
            for (unsigned int i=0 ; i< luffTape.size(); i++) {
                if (luffTape[i].y() > rect.min.y()) {
                    luffIdx = i;
                    break;
                }
            }

            CSide tmp;
            tmp.clear();

            for (auto i= luffIdx; i< luffTape.size(); i++) {
                tmp.push_back(luffTape[i]);
            }

            luffTape = tmp;

            // final trimming of luff tape
            luffIdx = 0;
            footIdx = bottom.size()-1;
            while (luffIdx < (luffTape.size()-1) && (footIdx > 0)) {
                if (bottom[footIdx].x() > luffTape[luffIdx].x()) {
                    footIdx--;
                } else {
                    //CVector3d v = bottom[footIdx] - bottom[footIdx-1];
                    if (Distance3d(luffTape[luffIdx+1], bottom[footIdx-1], bottom[footIdx]) < 0) {
                        luffIdx++;
                        footIdx = bottom.size()-1;
                    }
                    else break;
                }
            }

            if (luffIdx < luffTape.size()-1 && footIdx < bottom.size()-1) {
                // calculate new lowest point of luff tape which intersects bottom
                CPoint3d p = intersectionOfTwoLines(luffTape[luffIdx], luffTape[luffIdx+1], bottom[footIdx], bottom[footIdx+1]);

                CSide tmp;
                tmp.clear();

                tmp.push_back(p);

                for (auto i= luffIdx+1; i< luffTape.size(); i++) {
                    tmp.push_back(luffTape[i]);
                }

                luffTape = tmp;
            }
        }

        // foot tape
        if ((panelType == PANEL_VERTICAL_LEECH || panelType == PANEL_MITRE_FOOT_MITRE) && footTapeDistance > 0) {
            luffIdx = 0;
            footIdx = 0;

            CSide side;
            if ((bottom.front()-bottom.back()).norm() > 2) {
                side = bottom;
            } else {
                side = right;
            }
            while (luffIdx < left.size()-1 && footIdx < side.size()-1) {
                if (side[footIdx].x() < footTape[luffIdx].x()) {
                    footIdx++;
                } else {
                    //CVector3d v = bottom[footIdx+1] - bottom[footIdx];
                    if (Distance3d(footTape[luffIdx+1], side[footIdx-1], side[footIdx]) < 0) {
                        luffIdx++;
                        footIdx = 0;
                    }
                    else break;
                }
            }

            if (luffIdx < footTape.size()-1) {
                // calculate new lowest point of luff tape which intersects bottom
                CPoint3d p = intersectionOfTwoLines(footTape[luffIdx], footTape[luffIdx+1], side[footIdx], side[footIdx+1]);

                CSide tmp;
                tmp.clear();

                tmp.push_back(p);

                for (auto i= luffIdx+1; i< footTape.size(); i++) {
                    tmp.push_back(footTape[i]);
                }

                footTape = tmp;
            }
        }
    } else {
        if (luffTapeDistance > 0) {
            CSide s;
            if (panelType == PANEL_MITRE_LEECH_MITRE_LUFF) {
                s.clear();
                for (unsigned int i=cutLeft.size()/2+1; i>0; i--) {
                    s.push_back(cutLeft[i-1]);
                }
                //cout << "s = " << s << endl;
                //cout << "luffTape = " << luffTape << endl;
                for (unsigned int i=0; i<cutBottom.size(); i++) {
                    s.push_back(cutBottom[i]);
                }
            } else {
                s = bottom;
            }
            // cross-cut panels
            while (luffIdx < left.size()-1 && footIdx < s.size()-1) {
                //if (panelType == PANEL_MITRE_LEECH_MITRE_LUFF) {
                //    cout << "footIdx = " << footIdx << ", luffIdx = " << luffIdx << endl;
                //    cout << "s[footIdx].x() = " << s[footIdx] << ", luffTape[luffIdx].x() = " << luffTape[luffIdx] << endl;
                //}
                if (s[footIdx].x() < luffTape[luffIdx].x()) {
                    footIdx++;
                } else {
                    //if (panelType == PANEL_MITRE_LEECH_MITRE_LUFF) {
                    //   cout << "luffTape[luffIdx+1] = " << luffTape[luffIdx+1] << ", s[footIdx] = " << s[footIdx] << ", s[footIdx+1] = " << s[footIdx+1] << endl;
                    //    cout << "distance = " << (Distance3d(luffTape[luffIdx+1], s[footIdx], s[footIdx+1])) << endl;
                    //}
                    if (panelType == PANEL_MITRE_LEECH_MITRE_LUFF) {
                        if (Distance3d(luffTape[luffIdx+1], s[footIdx], s[footIdx+1]) > 0) {
                            luffIdx++;
                            footIdx = 0;
                        }
                        else break;
                    } else {
                        if (Distance3d(luffTape[luffIdx+1], s[footIdx], s[footIdx+1]) < 0) {
                            luffIdx++;
                            footIdx = 0;
                        }
                        else break;
                    }

                    //CVector3d v = bottom[footIdx+1] - bottom[footIdx];
                }
            }

            if (luffIdx < luffTape.size()-1) {
                // calculate new lowest point of luff tape which intersects bottom
                CPoint3d p = intersectionOfTwoLines(luffTape[luffIdx], luffTape[luffIdx+1], s[footIdx], s[footIdx+1]);

                //if (panelType == PANEL_MITRE_LEECH_MITRE_LUFF) {
                //    cout << "footIdx = " << footIdx << ", luffIdx = " << luffIdx << endl;
                //    cout << "luffTape[luffIdx] = " << luffTape[luffIdx] << ", luffTape[luffIdx+1] = " << luffTape[luffIdx+1] << endl;
                //    cout << "s[footIdx] = " << s[footIdx] << ", s[footIdx+1] = " << s[footIdx+1] << endl;
                //    cout << "p = " << p << endl;
                //}

                CSide tmp;
                tmp.clear();

                tmp.push_back(p);

                for (auto i= luffIdx+1; i< luffTape.size(); i++) {
                    tmp.push_back(luffTape[i]);
                }

                luffTape = tmp;
            }
        }

    }


    // special handling of gaff top panel
/*    if (panelType == PANEL_GAFF_TOP) {
        unsigned int rightIdx = right.size()-1;
        luffIdx = luffTape.size()-1;

        while (luffIdx >= 0 && rightIdx >= 0) {
            if (right[rightIdx].y() > luffTape[luffIdx].y()) {
                        rightIdx--;
            } else {
                CVector3d v = right[rightIdx-1] - right[rightIdx];
                if (Distance3d(luffTape[luffIdx], right[rightIdx-1], right[rightIdx]) < 0) {
                    luffIdx--;
                    footIdx = 0;
                }
                else break;

            }
        }

        if (luffIdx > 0) {
            // calculate new lowest point of luff tape which intersects bottom
            CPoint3d p = intersectionOfTwoLines(luffTape[luffIdx], luffTape[luffIdx+1], right[rightIdx], right[rightIdx+1]);

            CSide tmp;
            tmp.clear();

            for (unsigned int i=0; i< luffIdx; i++) {
                tmp.push_back(luffTape[i]);
            }

            tmp.push_back(p);

            luffTape = tmp;
        }

    }
*/
}

/** Rotates a panel around a point.
 *  p = centre of rotation
 *  m = rotation matrix
 */
CPanel CPanel::rotate( const CPoint3d &p, const CMatrix &m ) const
{
    CPanel panel;
    panel.hasHems = hasHems;
    panel.bPrintBottom = bPrintBottom;
    panel.bPrintLeft = bPrintLeft;
    panel.bPrintTop = bPrintTop;
    panel.bPrintRight = bPrintRight;
    panel.bPrintFootTape = bPrintFootTape;
    panel.bPrintLuffTape = bPrintLuffTape;
    panel.bLeechPanel = bLeechPanel;
    panel.bLuffPanel = bLuffPanel;
    panel.bFootPanel = bFootPanel;
    panel.patchType = patchType;
    panel.panelType = panelType;
    panel.battenpoints.clear();
    for (unsigned int i=0; i<battenpoints.size(); i++) {
        panel.battenpoints.push_back(battenpoints[i].rotate( p , m ));
    }

    panel.extraLines.clear();
    for (unsigned int i=0; i<extraLines.size(); i++) {
        panel.extraLines.push_back(extraLines[i].rotate( p , m ));
    }

    panel.label = label.rotate( p , m );

    panel.left = left.rotate( p , m );
    panel.right = right.rotate( p , m );
    panel.top = top.rotate( p , m );
    panel.bottom = bottom.rotate( p , m );

    panel.cutLeft = cutLeft.rotate( p , m );
    panel.cutRight = cutRight.rotate( p , m );
    panel.cutTop = cutTop.rotate( p , m );
    panel.cutBottom = cutBottom.rotate( p , m );

    panel.luffTape = luffTape.rotate(p, m);
    panel.footTape = footTape.rotate(p, m);
    panel.bottomSeam = bottomSeam.rotate(p, m);

    panel.aftBattenPoints = aftBattenPoints.rotate(p, m);
    panel.foreBattenPoints = foreBattenPoints.rotate(p, m);
    panel.aftBattenHemPoints = aftBattenHemPoints.rotate(p, m);

    // reef points
    panel.luffReefPoints.clear();
    for (unsigned int i=0; i<luffReefPoints.size(); i++) {
        panel.luffReefPoints.push_back(p + m * (luffReefPoints[i] - p));
    }

    panel.leechReefPoints.clear();
    for (unsigned int i=0; i<leechReefPoints.size(); i++) {
        panel.leechReefPoints.push_back(p + m * (leechReefPoints[i] - p));
    }

    panel.throatPoint = p + m * (throatPoint - p);

    return panel;
}

/**
 * @brief CPanel::mergePoints
 * Put batten points into side. Nearest old point above will be
 * discarded so as to preserve the number of elements in the side.
 * @param s the side
 * @param p the batten points
 * @return a merged size
 */
CSide CPanel::mergePoints(const CSide &s,const  CBattenPoints &p) const {
    if (p.size() == 0)
        return s;
    else {
        CSide ret = s;

        // loop though batten points
        for (size_t battenIdx=0; battenIdx<p.size(); battenIdx++) {
            // only process if batten pos is > 1mm from top
            if ((s.back()-p.at(battenIdx).point).norm() > 1) {
                // testbatten point against all side points
                // except front and back
                for (size_t sizeIdx= 1; sizeIdx<s.size()-1; sizeIdx++) {
                    if (p.at(battenIdx).point.y() < s[sizeIdx].y()) {
                        // if battebn point y is < side pint y then
                        // replace the latter
                        ret[sizeIdx] = p.at(battenIdx).point;
                        // and break for next battent point
                        break;
                    }
                }
            }
        }

        return ret;
    }
}

/*
 * straighten bottom, cutBottom and FootTape
 * This is used for either the foot panel of a roped-foot sail or
 * where the broadseaming is positive
 */
void CPanel::straightenBottom() {
    CPoint3d fLeft = bottom.front();
    CPoint3d fRight = bottom.back();
//    CVector3d v = fRight - fLeft;
    unsigned int k;

    bottom.fill(fLeft, fRight);
//    for (k = 1 ; k < bottom.size() -1 ; k++)
//    {
//        //double fraction = double(k) / double(bottom.size());
//        //bottom[k] =  fLeft + fraction*v;
//        bottom[k] = fLeft;
//    }

    fLeft = cutBottom.front();
    fRight = cutBottom.back();
 //   v = fRight - fLeft;
    cutBottom.fill(fLeft, fRight);
    //for (k = 1 ; k < cutBottom.size() -1 ; k++)
    //{
    //    //double fraction = double(k) / double(cutBottom.size());
    //    //cutBottom[k] =  fLeft + fraction*v;
    //    cutBottom[k] = fLeft;
    //}

    fLeft = footTape.front();
    fRight = footTape.back();
  //  v = fRight - fLeft;
    footTape.fill(fLeft, fRight);
//    for (k = 1 ; k < footTape.size() -1 ; k++)
//    {
//        //double fraction = double(k) / double(footTape.size());
 //       //footTape[k] =  fLeft + fraction*v;
 //       footTape[k] = fLeft;
 //   }

}

/**
 * @brief CPanel::scaleX scale a panel in the x direction only. Mainly used
 * for symmetrical spinnaker foot panel. Only scales main edges/cut lines
 * @param x the scale factor
 */
CPanel CPanel::scaleX(real x)  {
    CPanel newPanel = *this;
    newPanel.top.scaleX(x);
    newPanel.cutTop.scaleX(x);
    newPanel.bottom.scaleX(x);
    newPanel.cutBottom.scaleX(x);
    newPanel.left.scaleX(x);
    newPanel.cutLeft.scaleX(x);
    newPanel.right.scaleX(x);
    newPanel.cutRight.scaleX(x);

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();

    return newPanel;
}

/**
 * @brief CPanel::scaleTopInX scale top of panel keeping bottom the same.
 * This is mainly for symmetrical spinnakers as it treats each side
 * equally. Only scales main side/cut side, top. cut top edges. Assumes that
 * sides are of equal length.
 * @param x the scale factor
 */
CPanel CPanel::scaleTopInX(real x)  {
    CRect3d bounds = this->boundingRect();

    real x1 = (bounds.max.x()-bounds.min.x());
    CVector3d v = CVector3d(-x1/2, 0, 0);

    // creat a copy panel with centre a x=0
    CPanel newPanel = *this + v;

    newPanel.top.scaleX(x);
    newPanel.cutTop.scaleX(x);

    real h = newPanel.left.back().y()-newPanel.left.front().y();
    real h0 = newPanel.left.front().y();

    for (unsigned int i=1; i<newPanel.left.size(); i++) {
        real scale = 1 + (x-1) * (newPanel.left[i].y()-h0) / h;
        newPanel.left[i].scaleX(scale);
    }

    h = newPanel.cutLeft.back().y()-newPanel.cutLeft.front().y();
    h0 = newPanel.cutLeft.front().y();

    for (unsigned int i=1; i<newPanel.cutLeft.size(); i++) {
        real scale = 1 + (x-1) * (newPanel.cutLeft[i].y()-h0) / h;
        newPanel.cutLeft[i].scaleX(scale);
    }

    h = newPanel.right.back().y()-newPanel.right.front().y();
    h0 = newPanel.right.front().y();

    for (unsigned int i=1; i<newPanel.right.size(); i++) {
        real scale = 1 + (x-1) * (newPanel.right[i].y()-h0) / h;
        newPanel.right[i].scaleX(scale);
    }

    h = newPanel.cutRight.back().y()-newPanel.cutRight.front().y();
    h0 = newPanel.cutRight.front().y();

    for (unsigned int i=1; i<newPanel.cutRight.size(); i++) {
        real scale = 1 + (x-1) * (newPanel.cutRight[i].y()-h0) / h;
        newPanel.cutRight[i].scaleX(scale);
    }

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();

    newPanel = newPanel.reframe(LOW_LEFT);

    return newPanel;
}


CPanel CPanel::scaleBottomInX(real x) {
    CPanel newPanel = *this;

    return newPanel;
}

CPanel CPanel::scaleBottomRightInX(real x) {
    CPanel newPanel = *this;

    newPanel.bottom.scaleX(x);
    CVector3d v = CVector3d((this->bottom.front().x()-newPanel.bottom.front().x()), 0, 0);
    newPanel.bottom = newPanel.bottom+v;

    newPanel.cutBottom.scaleX(x);
    v = CVector3d((this->cutBottom.front().x()-newPanel.cutBottom.front().x()), 0, 0);
    newPanel.cutBottom = newPanel.cutBottom+v;
    real xdiff = (this->bottom.back().x() - this->bottom.front().x()) - (newPanel.bottom.back().x()-newPanel.bottom.front().x());

    real h = newPanel.right.back().y()-newPanel.right.front().y();
    real h0 = newPanel.right.back().y();

    for (unsigned int i=newPanel.right.size(); i>0; i--) {
        CPoint3d p = newPanel.right[i-1];
        real scale = (h0-p.y()) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.right[i-1] = CPoint3d(newX, p.y(), p.z());
    }

    h = newPanel.cutRight.back().y()-newPanel.cutRight.front().y();
    h0 = newPanel.cutRight.back().y();

    for (unsigned int i=newPanel.cutRight.size(); i>0; i--) {
        CPoint3d p = newPanel.cutRight[i-1];
        real scale = (h0-p.y()) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.cutRight[i-1] = CPoint3d(newX, p.y(), p.z());
    }

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();


    return newPanel;


}

CPanel CPanel::scaleTopLeftInX(real x) {
    CPanel newPanel = *this;

    newPanel.top.scaleX(x);
    CVector3d v = CVector3d((this->top.back().x()-newPanel.top.back().x()), 0, 0);
    newPanel.top = newPanel.top+v;

    newPanel.cutTop.scaleX(x);
    v = CVector3d((this->cutTop.back().x()-newPanel.cutTop.back().x()), 0, 0);
    newPanel.cutTop = newPanel.cutTop+v;

    real h = newPanel.left.back().y()-newPanel.left.front().y();
    real h0 = newPanel.left.front().y();
    real xdiff = (newPanel.top.back().x()-newPanel.top.front().x()) - (this->top.back().x() - this->top.front().x());

    for (unsigned int i=1; i<newPanel.left.size(); i++) {
        CPoint3d p = newPanel.left[i];
        real scale = (p.y()-h0) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.left[i] = CPoint3d(newX, p.y(), p.z());
    }

    h = newPanel.cutLeft.back().y()-newPanel.cutLeft.front().y();
    h0 = newPanel.cutLeft.front().y();

    for (unsigned int i=1; i<newPanel.cutLeft.size(); i++) {
        CPoint3d p = newPanel.cutLeft[i];
        real scale = (p.y()-h0) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.cutLeft[i] = CPoint3d(newX, p.y(), p.z());
    }

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();

    return newPanel;
}


CPanel CPanel::scaleTopRightInX(real x) {
    CPanel newPanel = *this;

    newPanel.top.scaleX(x);
    CVector3d v = CVector3d((this->top.front().x()-newPanel.top.front().x()), 0, 0);
    newPanel.top = newPanel.top+v;

    newPanel.cutTop.scaleX(x);
    v = CVector3d((this->cutTop.front().x()-newPanel.cutTop.front().x()), 0, 0);
    newPanel.cutTop = newPanel.cutTop+v;
    real xdiff = (this->top.back().x() - this->top.front().x()) - (newPanel.top.back().x()-newPanel.top.front().x());

    real h = newPanel.right.back().y()-newPanel.right.front().y();
    real h0 = newPanel.right.front().y();

    for (unsigned int i=1; i<newPanel.right.size(); i++) {
        CPoint3d p = newPanel.right[i];
        real scale = (p.y()-h0) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.right[i] = CPoint3d(newX, p.y(), p.z());
    }

    h = newPanel.cutRight.back().y()-newPanel.cutRight.front().y();
    h0 = newPanel.cutRight.front().y();

    for (unsigned int i=1; i<newPanel.cutRight.size(); i++) {
        CPoint3d p = newPanel.cutRight[i];
        real scale = (p.y()-h0) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.cutRight[i] = CPoint3d(newX, p.y(), p.z());
    }

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();


    return newPanel;
}

/**
 * @brief CPanel::scaleBottomLeftInX
 * @param x
 * @return
 */
CPanel CPanel::scaleBottomLeftInX(real x) {
    CPanel newPanel = *this;

    newPanel.bottom.scaleX(x);
    CVector3d v = CVector3d((this->bottom.front().x()-newPanel.bottom.front().x()), 0, 0);
    newPanel.bottom = newPanel.bottom+v;

    newPanel.cutBottom.scaleX(x);
    v = CVector3d((this->cutBottom.front().x()-newPanel.cutBottom.front().x()), 0, 0);
    newPanel.cutBottom = newPanel.cutBottom+v;
    real xdiff = (newPanel.bottom.back().x() - newPanel.bottom.front().x()) - (this->bottom.back().x()-this->bottom.front().x());

    real h = newPanel.left.back().y()-newPanel.left.front().y();
    real h0 = newPanel.left.back().y();

    for (unsigned int i=newPanel.left.size();i>0; i--) {
        CPoint3d p = newPanel.left[i-1];
        real scale = (h0-p.y()) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.left[i-1] = CPoint3d(newX, p.y(), p.z());
    }

    h = newPanel.cutLeft.back().y()-newPanel.cutLeft.front().y();
    h0 = newPanel.cutLeft.back().y();

    for (unsigned int i=newPanel.cutLeft.size();i>0; i--) {
        CPoint3d p = newPanel.cutLeft[i-1];
        real scale = (h0-p.y()) / h;
        real newX = p.x()-xdiff*scale ;
        newPanel.cutLeft[i-1] = CPoint3d(newX, p.y(), p.z());
    }

    // make sure corner points are exactly equal
    newPanel.bottom.front() = newPanel.left.front();
    newPanel.bottom.back() = newPanel.right.front();
    newPanel.cutBottom.front() = newPanel.cutLeft.front();
    newPanel.cutBottom.back() = newPanel.cutRight.front();
    newPanel.top.front() = newPanel.left.back();
    newPanel.top.back() = newPanel.right.back();
    newPanel.cutTop.front() = newPanel.cutLeft.back();
    newPanel.cutTop.back() = newPanel.cutRight.back();

    return newPanel;
}

/**
 * @brief CPanel::alignTop makes top side at top and horizontal
 * @return
 */
CPanel CPanel::alignTop() {
    real x = top.back().x() - top.front().x();
    real y = top.back().y() - top.front().y();

    real angle = atan2(y, x);

    return rotate(CPoint3d(0,0,0), CMatrix::rot3d(2,-angle));

}

CPanel CPanel::alignBottom() {
    real x = bottom.back().x() - bottom.front().x();
    real y = bottom.back().y() - bottom.front().y();

    real angle = atan2(y, x);

    return rotate(CPoint3d(0,0,0), CMatrix::rot3d(2,-angle));

}

/**
 * @brief CPanel::isRadialSpinnaker return if this a radial panel
 * @return
 */
bool CPanel::isRadialSpinnaker() const {
    return (panelType == PANEL_RADIAL_SPINNAKER ||
            panelType == PANEL_RADIAL_SPINNAKER_FOOT_LEFT ||
            panelType == PANEL_RADIA_SPINNAKERL_FOOT_RIGHT ||
            panelType == PANEL_RADIAL_SPINNAKER_LEECH ||
            panelType == PANEL_RADIAL_SPINNAKER_LUFF ||
            panelType == PANEL_RADIAL_SPINNAKER_MITRE);
}

// operators

/** Performs a 3D translation of the panel by a given vector.
 */
CPanel CPanel::operator+ (const CVector3d &transl) const
{
    CPanel ret;
    ret.hasHems = hasHems;
    ret.bPrintBottom = bPrintBottom;
    ret.bPrintLeft = bPrintLeft;
    ret.bPrintTop = bPrintTop;
    ret.bPrintRight = bPrintRight;
    ret.bPrintFootTape = bPrintFootTape;
    ret.bPrintLuffTape = bPrintLuffTape;
    ret.bLeechPanel = bLeechPanel;
    ret.bLuffPanel = bLuffPanel;
    ret.bFootPanel = bFootPanel;
    ret.patchType = patchType;
    ret.panelType = panelType;

    ret.label = label+transl;

    ret.left = left + transl;
    ret.right = right + transl;
    ret.top = top + transl;
    ret.bottom = bottom + transl;
    ret.bottomSeam = bottomSeam + transl;
    ret.footTape = footTape + transl;
    ret.luffTape = luffTape + transl;

    ret.cutLeft = cutLeft + transl;
    ret.cutRight = cutRight + transl;
    ret.cutTop = cutTop + transl;
    ret.cutBottom = cutBottom + transl;

    ret.aftBattenPoints = aftBattenPoints + transl;
    ret.foreBattenPoints = foreBattenPoints + transl;
    ret.aftBattenHemPoints = aftBattenHemPoints + transl;

    ret.throatPoint = throatPoint + transl;

    ret.battenpoints.clear();

    for (unsigned int i=0; i<battenpoints.size(); i++) {
        ret.battenpoints.push_back(battenpoints[i] + transl);
    }

    ret.extraLines.clear();

    for (unsigned int i=0; i<extraLines.size(); i++) {
        ret.extraLines.push_back(extraLines[i] + transl);
    }

    // reef points
    ret.luffReefPoints.clear();
    for (unsigned int i=0; i<luffReefPoints.size(); i++) {
        ret.luffReefPoints.push_back(luffReefPoints[i] + transl);
    }

    ret.leechReefPoints.clear();
    for (unsigned int i=0; i<leechReefPoints.size(); i++) {
        ret.leechReefPoints.push_back(leechReefPoints[i] + transl);
    }

    return ret;
}


/** Performs an assignment.
 */
/*CPanel& CPanel::operator= (const CPanel &p)
{
    if (&p == this)
        return *this;

    label = p.label;

    left = p.left;
    right = p.right;
    top = p.top;
    bottom = p.bottom;

    cutLeft = p.cutLeft;
    cutRight = p.cutRight;
    cutTop = p.cutTop;
    cutBottom = p.cutBottom;

    bottomSeam = p.bottomSeam;
    luffTape = p. luffTape;
    footTape = p.footTape;

    hasHems = p.hasHems;

    aftBattenPoints = p.aftBattenPoints;
    foreBattenPoints = p.foreBattenPoints;
    aftBattenHemPoints = p.aftBattenHemPoints;
    //battens = p.battens;

    bPrintLeft = p.bPrintLeft;
    bPrintBottom = p.bPrintBottom;
    bPrintTop = p.bPrintTop;
    bPrintFootTape = p.bPrintFootTape;
    bPrintLuffTape = p.bPrintLuffTape;

    bLeechPanel = p.bLeechPanel;
    bLuffPanel = p.bLuffPanel;
    bFootPanel = p.bFootPanel;
    bPatch = p.bPatch;
    patchType = p.patchType;
    panelType = p.panelType;

    return *this;
}

*/
/*****************************************************************************

                              CSide class

*****************************************************************************/

/** Constructs a side with a given number of points.
 */
CSide::CSide( unsigned int nbpoints /* = 1 */)
{
    resize(nbpoints);
}


/** Makes the side a straight line between two points.
 */
void CSide::fill( const CPoint3d &p1 , const CPoint3d &p2 , int startIdx, int numPoints)
{
    switch ( size() )
    {
    case 0:
        return;
    case 1:
        at(0) = p1;
        return;
    }

    unsigned int iStart = startIdx > -1 ? startIdx : 0;
    int nPoints = numPoints > 0 ? numPoints : size();
    for (int i = 0 ; i < nPoints ; i++)
        at(i+iStart) = p1 + ( p2 - p1 ) * ( real(i) / (nPoints -1) );
}


/** Makes the side a two-segment line between three points.
 */
void CSide::fill( const CPoint3d &p1 , const CPoint3d &p2 , const CPoint3d &p3 )
{
    switch ( size() )
    {
    case 0:
        return;
    case 1:
        at(0) = p1;
        return;
    case 2:
        at(0) = p1;
        at(1) = p3;
        return;
    }

    unsigned int n1  = int( size() ) / 2;
    for (unsigned int i = 0 ; i < size() ; i++)
    {
        if ( i <= n1 )
            at(i) = p1 + (p2 - p1) * (real(i) / n1);
        else
            at(i) = p2 + (p3 - p2) * (real(i - n1) / (size() -n1 -1) );
    }
}

/**
 * returns distance around curve/arc of side.,
 * Note that this is an approximation as we sum the straight line distance between each point
 */
real CSide::arcLength() {
    real distance = 0;

    for (unsigned int i=1; i<this->size(); i++) {
        CVector3d v =  (at(i) - at(i-1));
        distance += v.norm();
    }

    return distance;
}

/**
 * @brief CSide::trimAbove
 * @param y
 * @return
 */
CSide CSide::trimAbove(real y) {
    CSide side;
    side.clear();

    for (unsigned int i = 0 ; i < size() ; i++) {
        if (at(i).y() < y) {
            side.push_back(at(i));
        }
    }

    return side;
}

/** Rotates a CSide around a point.
 */
CSide CSide::rotate( const CPoint3d &p, const CMatrix &m ) const
{
    CSide s( size() );

    for (unsigned int i = 0 ; i < size() ; i++)
        s[i] = p + m * (at(i) - p);

    return s;
}

/**
 * @brief CSide::scaleX
 * @param x
 */
void CSide::scaleX(real x) {
    for (unsigned int i = 0 ; i < size() ; i++)
        at(i).scaleX(x);
}

/**
 * @brief CSide::nearestPointIndex find point in CSide which is nearest to point p
 * and return its index
 * @param p the point
 * @return the index of the nearest point CSide
 */
unsigned int CSide::nearestPointIndex(const CPoint3d p) const {
    unsigned int idx = 0;
    real minDist = 99999999;

    for (unsigned int i=0; i< size(); i++) {
        real d = (at(i) - p).norm();
        if (d < minDist) {
            minDist = d;
            idx = i;
        }
    }

    return idx;
}

unsigned int CSide::nearestPointIndex(const double d) {
    real l = (size() -1) * d;
    unsigned ret = int(l+0.5);
    return ret;
}


// operators

/** Performs a 3D translation of the side by a given vector.
 */
CSide CSide::operator+ (const CVector3d &transl) const
{
    CSide ret( size() );
    for (unsigned int i = 0 ; i < size() ; i++)
        ret[i] = transl + at(i);
    return ret;
}

/**
 * @brief CSide::reverse the order of the points in CSide
 * @return
 */
CSide CSide::reverse() {
    CSide::const_reverse_iterator riter;
    CSide ret;
    ret.clear();

    for (riter = rbegin(); riter != rend(); riter++)
        ret.push_back(*riter);

    return ret;

}

/*********************************************

            Global functions

 *********************************************/
/**
 * @brief RunPanelTests run a series of test of various panel functions
 */
void RunPanelTests(void) {
    // create a test panel 1000 wide by 250 high
    CPanel pTest;
    CPoint3d pLowLeft = CPoint3d(200, 50, 0);
    CPoint3d pLowRight = CPoint3d(pLowLeft.x()+1000, pLowLeft.y(),0);
    CPoint3d pHighLeft = CPoint3d(pLowLeft.x(), 250, 0);
    CPoint3d pHighRight = CPoint3d(pLowRight.x(), pHighLeft.y(),0);
    pTest.left.fill(pLowLeft, pHighLeft);
    pTest.right.fill(pLowRight, pHighRight);
    pTest.bottom.fill(pLowLeft, pLowRight);
    pTest.top.fill(pHighLeft, pHighRight);

    // ------ test scaling functions
    double scale = 1.1;
    cout << "pTest" << endl;
    PrintPanelTestResult(pTest, scale);

    cout << "scaleTopInX" << endl;
    PrintPanelTestResult(pTest.scaleTopInX(scale), scale);
    cout << "scaleTopLeftInX" << endl;
    PrintPanelTestResult(pTest.scaleTopLeftInX(scale), scale);
    cout << "scaleTopRightInX" << endl;
    PrintPanelTestResult(pTest.scaleTopRightInX(scale), scale);
    cout << "scaleBottomRightInX" << endl;
    PrintPanelTestResult(pTest.scaleBottomRightInX(scale), scale);

    scale = 0.9;
    cout << "scaleTopInX" << endl;
    PrintPanelTestResult(pTest.scaleTopInX(scale), scale);
    cout << "scaleTopLeftInX" << endl;
    PrintPanelTestResult(pTest.scaleTopLeftInX(scale), scale);
    cout << "scaleTopRightInX" << endl;
    PrintPanelTestResult(pTest.scaleTopRightInX(scale), scale);
    cout << "scaleBottomRightInX" << endl;
    PrintPanelTestResult(pTest.scaleBottomRightInX(scale), scale);

}

/**
 * @brief PrintPanelTestResult print test rssults for a panel
 * @param p the panel
 * @param scale the scaling applied
 */
void PrintPanelTestResult(CPanel p, real scale) {
    cout << "       scale = " << scale << endl;
    cout << "         top = " << p.top.front() << ", " << p.top.back() << endl;
    cout << "      bottom = " << p.bottom.front() << ", " << p.bottom.back() << endl;
    cout << "   top width = " << (p.top.arcLength()) << endl;
    cout << " bottom width = " << (p.bottom.arcLength()) << endl;

}


/** Outputs a CPanel  to a stream.
 *  exemple:  cout << panel[i];
 */
ostream& operator<<(ostream& o , const CPanel &p)
{
    o << p.label;
    o << "== CSide : left ==" << endl << p.left;
    o << "== CSide : top ==" << endl << p.top;
    o << "== CSide : right ==" << endl << p.right;
    o << "== CSide : bottom ==" << endl << p.bottom;

    if ( p.hasHems )
    {
        o << "== CSide : cutLeft ==" << endl << p.cutLeft;
        o << "== CSide : cutTop ==" << endl << p.cutTop;
        o << "== CSide : cutRight ==" << endl << p.cutRight;
        o << "== CSide : cutBottom ==" << endl << p.cutBottom;
    }

    // bottom seam line, foot tape line and luff tape life
    if (p.bottomSeam[0] != p.bottom[0]) {
        o << "== CSide : bottomeSeam ==" << endl << p.bottomSeam;
    }
    if (p.footTape[0] != p.bottom[0]) {
        o << "== CSide : footTape ==" << endl << p.footTape;
    }
    if (p.luffTape[0] != p.left[0]) {
        o << "== CSide : luffTape ==" << endl << p.luffTape;
    }

    if (p.aftBattenPoints.size() > 0) {
        o << "== CBattenPoints : aftBattenPoints =="<< endl<< p.aftBattenPoints;
    }

    return o;
}

/** Outputs a CPanelLabel  to a stream.
 *  exemple:  cout << panel[i].label;
 */
ostream& operator<< (ostream &o , const CPanelLabel &lb)
{
    o << "== CPanelLabel : name ==" << endl << lb.name << endl;
    o << "== CPanelLabel : height ==" << endl << lb.height << endl;
    o << "== CPanelLabel : color ==" << endl << lb.color << endl;
    o << "== CPanelLabel : origin ==" << endl << lb.origin << endl;
    o << "== CPanelLabel : direction ==" << endl << lb.direction << endl;
    return o;
}

/** Outputs a CSide  to a stream.
 *  exemple:  cout << panel[i].left;
 */
ostream& operator<< (ostream &out, const CSide &s)
{
    for (unsigned int i = 0 ; i < s.size() ; i++)
    {
        out << "#" << i << "\t" << s[i] << endl;
    }
    return out;
}


/** Outputs a CBattenBattenPoints  to a stream.
 *  example:  cout << panel[i].aftBattenPoints;
 */
ostream& operator<< (ostream &out, const CBattenPoints &s)
{
    unsigned int x = s.size();
    for (unsigned int i = 0 ; i < x ; i++)
    {
        out << "#" << i << "\tbattenId: " << s[i].battenId << "\tpoint: " << s[i].point << endl;
    }
    return out;
}
