/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef SAILCALC_H
#define SAILCALC_H

#include <geocpp/geocpp.h>

/** @defgroup SailCpp Sail computations library
 *
 * SailCpp is the library that performs all the plotting calculations.
 * It provides classes for generating sails, hulls, rigs and boats from
 * their definitions.
 */

struct ASAresults {
    real sideA;
    real sideB;
    real angleC;
};

/* computation of parabolic edge round */
real RoundP( const real &x, const int &p );
/* computation of angle of triangle defined by 3 sides */
real Atriangle( const real &a, const real &b, const real &c );
/* computation of angle of triangle defined by 3 points */
real Atriangle3d ( const CPoint3d &pta, const CPoint3d &ptb, const CPoint3d &ptc );
/* computation of distance of a point to a line defined by 2 points */
real Distance3d(const CPoint3d &pta, const CPoint3d &ptb, const CPoint3d &ptc);
real CalculateChordHeight(const real radius, const real chordDepth, const real point);
real SolveSSA(const real l, const real m, const real angleM);

/* logical viewport calculation */
CRect3d calcLRect(const CRect3d &viewRect, const CRect3d &objRect, const CPoint3d center, real zoom );

/* computation of straight leech */
real StraightP( const real &x, const int &p );

/* compute intersection of two lines */
CPoint3d intersectionOfTwoLines(CPoint3d line1start, CPoint3d line1end, CPoint3d line2start, CPoint3d line2end);

vector<int> SplitsToInts(string s, bool&, bool allowNegatives=false, bool allowW=true);

struct ASAresults SolveASAtriangle (real angleA, real sideC, real angleB);

#endif
