/*
 * batten.h
 *
 *  Created on: 12 Jun 2011
 *      Author: paul
 */

#ifndef BATTEN_H_
#define BATTEN_H_

#include <string>
#include <geocpp/geometry.h>

#define BATTEN_NUM_POINTS 20

class CBatten
{
public:
    std::string name;
    /* height position of aft edge of batten
        along leech from clew to head */
    real percentHeight;
    /* is batten full length */
    bool fullLength;
    /* length of batten - calculated if batten is full length */
    int battenLength;
    /* angle of batten to leech vector */
    double angle;
    /* offset inwards between end of batten and curve of leech*/
    int inwardOffset;
    /* distance from leech vector to aft end of batten. Initially
        this field is calculated with the point lying on the leech curve*/
    real roundDepth;
    /* position of fore and aft points of batten (calculated) */
    CPoint3d aftPoint;
    CPoint3d frontPoint;
    /* panel numbers onto which fore and aft points of batten
        have been mapped*/
    int aftPointPanelNo;
    int forePointPanelNo;
    /* point where batten intersects straight line of leech */
    CPoint3d leechIntersectPoint;

    real distanceToHead;
    real distanceToClew;
    real distanceToHigherBatten;
    real distanceToLowerBatten;
    /* for full-length battens only
        distance from head to point where batten intersects luff */
    real distanceLuffToHead;
    bool operator < (CBatten b) const {return percentHeight < b.percentHeight;}

    // for position in panel
    real distanceToTopOfPanel;
    real distanceToBottomOfPanel;

    CBatten(void) {

    }

    /* constructor */
    CBatten(std::string nm, int pHeight=1, bool bFullLen=false, int battenLen=1, int ang=90, int offset=0) {
        name = nm;
        percentHeight = pHeight;
        fullLength = bFullLen;
        battenLength = battenLen;
        angle = ang;
        inwardOffset = offset;
    }

    /* copy constructor */
/*    CBatten(const CBatten& b) {
        name = std::string(b.name);
        percentHeight = b.percentHeight;
        fullLength = b.fullLength;
        battenLength = b.battenLength;
        angle = b.angle;
        inwardOffset = b.inwardOffset;
        roundDepth = b.roundDepth;
        aftPoint = CPoint3d(b.aftPoint);
        frontPoint = CPoint3d(b.frontPoint);
        leechIntersectPoint = CPoint3d(b.leechIntersectPoint);
        distanceToHead = b.distanceToHead;
        distanceToClew = b.distanceToClew;
        distanceToHigherBatten = b.distanceToHigherBatten;
        distanceToLowerBatten = b.distanceToLowerBatten;
        distanceLuffToHead = b.distanceLuffToHead;
        forePointPanelNo = b.forePointPanelNo;
        aftPointPanelNo = b.aftPointPanelNo;
        distanceToTopOfPanel = b.distanceToTopOfPanel;
        distanceToBottomOfPanel = b.distanceToBottomOfPanel;
    } */
};
#endif /* BATTEN_H_ */
