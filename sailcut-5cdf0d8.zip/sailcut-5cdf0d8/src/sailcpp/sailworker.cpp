/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <cmath>
#include <stdio.h>
#include <stdlib.h>

#include "sailworker.h"
#include "sailcalc.h"

#define MAX_PANELS 210

/* To enable debugging */
// #define DEBUG 1


/**
 *  The constructor does some preliminary calculations to set
 *  internal variables.
 */
CSailWorker::CSailWorker(const CSailDef &s) : CSailDef(s)
{
    /* First compute the coordinates of the corner of the sail */
    CVector3d v, v1;
    real x = 0, headstay = 0;

    /* Then Compute the coordinates of the 4 corners of the sail */
    switch ( sailType )
    {
    case JIB:
        x = tackY * foreJ / foreI;
        headstay = sqrt(foreI * foreI + foreJ * foreJ);
        rake = foreJ * luffL / headstay;
        tack = CPoint3d( x , tackY , 0 );
        //gaffL = 1;
        gaffR = 0;
        gaffRP = 50;   // imposed value for short gaff
        //gaffDeg = atan2( foreI , foreJ ) * 180/PI - 10;
        break;
    default:
        tack = CPoint3d( tackX, tackY, 0 );
        break;
    }


    v = CVector3d(0, gaffL, 0);  // initial vector gaff set on vertical

    if (sailType == SYMMETRIC) {
        double hf = footL / 2;
        double y = sqrt(luffL*luffL - hf*hf);
        clew = CPoint3d(tack.x()+footL, tack.y(), 0 );
        head = CPoint3d(tack.x()+hf-1, tack.y()+y, 0);
        peak = CPoint3d(tack.x()+hf+1, tack.y()+y, 0);
    } else {
        /** VC++ 6 pre-SP3 bug if we pass the result of a square root directly, see : MS knowledgebase 217164). */
        real stupid_hack = sqrt(luffL*luffL - rake*rake);
        head = tack + CVector3d(rake, stupid_hack, 0);
        peak = head + CMatrix::rot3d( 2 , (-asin(rake / luffL) - gaffDeg * PI / 180) ) * v;

        if ( fabs(peak.y() - head.y()) < 1 )
            peak.y() = head.y() + 1; // to avoid case with gaff horizontal

        /* Compute triangle tack-peak-clew. */
        real aa, b, bb;
        bb = atan2( peak.y() - tack.y() , peak.x() - tack.x() );
        b = CVector3d(peak - tack).norm();
        aa = Atriangle( leechL , b , footL );

        v1 = CVector3d( footL, 0, 0 );  // initial foot vector set on horizontal
        if (sailType == WING)
            clew = tack + v1;
        else
            clew = tack + CMatrix::rot3d( 2 , bb-aa ) * v1;
        /* end of computation of corners of the sail */
    }


    /** Define foot vector of sail edge. */
    footV = CVector3d( clew - tack );
    /** Define gaff vector of sail edge. */
    gaffV = CVector3d( peak - head );
    /** Define fleech vector of sail edge. */
    leechV = CVector3d( peak - clew );
    /** Define luff vector of sail edge. */
    luffV = CVector3d( head - tack );
    /** Define leech vector of sail edge. */
    leechV = CVector3d( peak - clew );

    /** Define mitre vector bisecting foot-leech angle. */
    mitreV = CVector3d( tack - clew ).unit() + leechV.unit();

    /** Define the unitary vectors perpendicular to foot edge, rotated anti-clockwise. */
    footVP = CMatrix::rot3d(2, PI/2) * footV.unit();
    /** Define the unitary vectors perpendicular to gaff edge, rotated anti-clockwise. */
    gaffVP = CMatrix::rot3d(2, PI/2) * gaffV.unit();
    /** Define the unitary vectors perpendicular to leech edge, rotated anti-clockwise. */
    leechVP = CMatrix::rot3d(2, PI/2) * leechV.unit();
    /** Define the unitary vectors perpendicular to luff edge, rotated anti-clockwise. */
    luffVP = CMatrix::rot3d(2, PI/2) * luffV.unit();
    /** vertical vector used in Zpoint for foot calculations */
    vertV = CVector3d(0, -1, 0);

	if (clothAlignsWithLeech) {
	    CPoint3d leechMaxPoint = clew + leechV.unit() * leechL * (leechTurnPos / 100.0);
	    cout << "leechMaxPoint = " << leechMaxPoint << endl;
	    leechTurnPoint = EdgeIntersect(LEECH_EDGE, leechMaxPoint, leechVP);
	    cout << "leechTurnPos = " << leechTurnPos << endl;
	    cout << "leechTurnPoint = " << leechTurnPoint << endl;
//		CPoint3d p = leechTurnPoint - clew;
//		leechV = CVector3d(p.x(), p.y(), p.z());
//	    leechVP = CMatrix::rot3d(2, PI/2) * leechV.unit();
//		cout << "leechV = " << leechV << endl;
	} else {
		leechTurnPoint = peak;
	}

    /** Define useful straight lines of edges and mitre. */
    footLine = CSubSpace3d::line(tack , footV);
    gaffLine = CSubSpace3d::line(head , gaffV);
    leechLine = CSubSpace3d::line(clew , leechV);
    luffLine = CSubSpace3d::line(tack , luffV);
    mitreLine = CSubSpace3d::line(clew , mitreV);

    /** Define point at intersection of mitre and luff. */
    mitreLuffPt = EdgeIntersect( LUFF_EDGE, clew , mitreV );

    bTrace = false;
    bUseBattensForLeech = false;

    if (sailType == MAINSAIL && int(footL/gaffL) < 6) {
        isGaffSail = true;
        throat = head;
        topFront = peak;
        // we may want to calculate new values for
        // topBack, topV and topVP here
        if (minTopWidth == 0) {
            topBack = topFront;
        } else {
            topBack = topFront - gaffVP*(real)minTopWidth;
            // recalculate leech vectors
            leechV = CVector3d( topBack - clew );
            leechVP = CMatrix::rot3d(2, PI/2) * leechV.unit();
            leechLine = CSubSpace3d::line(clew , leechV);
        }
    } else {
        isGaffSail = false;
        topFront = head;
        topBack = peak;
        topV = gaffV;
        topVP = gaffVP;
    }

    topV = topBack - topFront;

    //if (sailCut == CROSS2) {
        // calculate foot chord length
        CPoint3d p = tack.y() > clew.y() ? tack : clew;
        CPoint3d pFwd = FwdIntersect(p);
        CPoint3d pAft = AftIntersect(p);
        real footChord = CVector3d( pAft - pFwd ).norm();

        // calculate profile[1] chord length
        p = tack;
        p.y() = tack.y() + (peak.y() - tack.y()) * mould.vertpos / 100.0;
        pFwd = FwdIntersect(p);
        pAft = AftIntersect(p);
        real chord1 = CVector3d( pAft - pFwd ).norm();

        // calculate profile 2 chord length
        p.y() = tack.y() + (peak.y() - tack.y()) * mould.vertpos2 / 100.0;
        pFwd = FwdIntersect(p);
        pAft = AftIntersect(p);
        real chord2 = CVector3d( pAft - pFwd ).norm();

        // calculate top chord length
        real topChord = max(1.0, CVector3d( topBack - topFront ).norm());
        mould.footDepth = footR;
        //TODO base depth should be a user input
        //mould.baseDepth = 0.7 * mould.profile[0].getDepth();

        mould.setValuesForInterpol2(footChord, chord1, chord2, topChord, peak.y() - tack.y(), interpol2Strength, interpol2RP);

        if (sailType == SYMMETRIC) {
            mould.setProfileType(SYMMETRICAL, profileSubType);

            // calculate radius of luff offset
            if (luffOffset > 0) {
                real l = head.y() - tack.y();
                real h = l * luffOffset / 100;

                luffOffsetRadius = (4*h*h + l*l) / (8*h);
                cout << "luffOffsetRadius = " << luffOffsetRadius << endl;
                real centreX = tack.x()+(clew.x()-tack.x()) /2;
                real centreY = tack.y()+ l /2;
                real centreZ = h - luffOffsetRadius;
                luffOffsetCentrePoint = CPoint3d(centreX, centreY, centreZ);
                cout << "luffOffsetCentrePoint = " << luffOffsetCentrePoint << endl;
            }
        }
    //}
}


/**
 *  Make a Sail from its definition.
 */
CPanelGroup CSailWorker::makeSail() const
{
    CPanelGroup flatsail, dispsail, flattened;
    return makeSail(flatsail,dispsail, flattened);
}


/**
 *  Make a Sail from its definition.
 *  This is the main routine of all the sail layout work
 *  The output is a 3D sail, its display and development versions.
 *
 *  The returned sails are as used as follows:
 *  output - used for shaded view, wireframe view and Print Drawing
 *  flatsail - used as output for all 3d outputs and Print Development
 *  dispsail - used in development tab
 *  flattened - spinnakers only - a "flattened" representation of the sail
 */
CPanelGroup CSailWorker::makeSail( CPanelGroup &flatsail , CPanelGroup &dispsail, CPanelGroup &flattened) const
{
    CPanelGroup output;
    bUseBattensForLeech = false;

    switch ( sailType )
    {
    case WING:
        output = LayoutWing(flatsail , dispsail);
        break;
    default:
        if (sailType != MAINSAIL) {
            bUseBattensForLeech = false;
        }
        switch ( sailCut )
        {
        case CROSS:
            output = Layout0(flatsail , dispsail);
            break;
        case CROSS2:
        	output = LayoutCross2(flatsail, dispsail);
        	break;
        case TWIST:
            output = LayoutTwist(flatsail , dispsail);
            break;
        case HORIZONTAL:
            if (sailType == SYMMETRIC) {
                output = LayoutHorizontalSpinnaker(flatsail , dispsail, flattened);
            } else {
                output = Layout0(flatsail , dispsail);
            }
            break;
        case RADIALBOTTOM:
            output = LayoutRadialBottomSpinnaker(flatsail, dispsail, flattened);
            //output = LayoutHorizontalSpinnaker(flatsail , dispsail, flattened);
            break;
        case VERTICAL:
            output = LayoutVertical(flatsail , dispsail);
            break;
        case RADIAL:
            output = LayoutRadial(flatsail , dispsail);
            break;
        case MITRE:
            output = LayoutMitre(flatsail , dispsail);
            break;
        case MITRE2:
            output = LayoutMitre2(flatsail , dispsail);
            break;
        default:
            throw layout_error("CSailWorker::makeSail : unknown sail cut layout!");
        }
    }
    // place the labels at the centre of each panel
    output.placeLabels();
    dispsail.placeLabels();
    flatsail.plotLabels();

    // assign the sail names
    output.title = sailID + " (3D)";
    dispsail.title = sailID + " (3D)";
    flatsail.title = sailID + " (flat)";

    m_sail = output;
    m_dispsail = dispsail;
    m_flatsail = flatsail;

    return output;
}

CVector3d CSailWorker::LowerLeechVector(void) const {
	if (clothAlignsWithLeech) {
		CPoint3d p = leechTurnPoint - clew;
		return CVector3d(p.x(), p.y(), p.z());
	} else {
		return leechV;
	}
}

/**
 *  Creates a Cross cut or horizontal cut sail.
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 *
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::Layout0( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round)
    *   p1[] are on the luff side and p2[] are on the leech side
    */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS);  // 3D sail
    CPanelGroup dev(MAX_PANELS);  // developed sail

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();   // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0;
    bool flag = false;  // to check if top of sail is reached

    /* create arrays t1 and t2 of type of intersection of upper seam
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    CVector3d seamV; // seam Vector
    CSubSpace seamL; // seam Line

    if ( sailCut == HORIZONTAL )
        seamV = CVector3d(-1, 0, 0);  // horizontal seam orientation for Horizontal cut
    else  // define seamV as the vector perpendicular to the leech vector (peak-clew)
        seamV = leechVP;  // for classical cross cut

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    real CC = 0, x = 0, y = 0;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialise seam forward end at tack point
    p2[0] = clew; // initialise seam aft end at clew point
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

    /** Lay the panels starting from the foot, going upward to the peak */

    for (npanel = 1 ; npanel < MAX_PANELS -1 ; npanel++)
    {
        real exc = 0; // current excess of width
        real exb = 0; // total correction
        cnt = 0; // counter of iterations

        do  /* Loop for optimising the seam position to fit cloth width */
        {
            cnt++;
            p2[npanel] = p2[npanel-1] + (clothW - seamW - exb) * leechV.unit();
            //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line( p2[npanel] , seamV );

            if ( CVector3d( p2[npanel] - peak ) * leechV > 0 )
            {   // we are above peak, stop this is last panel
                flag = true;
                p2[npanel] = peak;
                // check on which side of the sail the previous point p1 is located
                if ( t1[npanel-1] < 2 )
                { // previous seam on foot
                    p1[npanel] = head;
                    t1[npanel] = 2; // set on luff
                    // left points on foot-tack-luff
                    lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                    for (k = 0 ; k < npl / 2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k] , seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
                }
                else if ( t1[npanel-1] == 2 )
                { // left points on luff
                    p1[npanel] = head;
                    t1[npanel] = 2;
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                }
                else
                { // left points on gaff
                    p1[npanel] = p1[npanel-1];
                    t1[npanel] = 3;
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                }

                // fill right points on leech
                lay[npanel-1].right.fill(p2[npanel-1],p2[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k]=EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

                // fill bottom points
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

                // fill top  points
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

                // move all top points of top panel to gaff curve
                for (k = 1 ; k < npb -1 ; k++)
                    lay[npanel -1].top[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].top[k], CVector3d (head.y()-peak.y(),peak.x()-head.x(),0));
                // end peak panel //
            }
            else   // normal panel below peak //////
            {
                /* find position of luff/seam intersection relative to tack and head */
                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::Layout0 -1 : intersection of seam and luff is not a point!");

                if ( CVector3d( ip - tack ) * luffV <= 0 )
                {   // seam intersects foot
                    if ( seamL.intersect(footLine).getdim() == 0 )
                        p1[npanel] = seamL.intersect(footLine).getp();
                    else throw layout_error("CSailWorker::Layout0 -2 : intersection of seam and foot is not a point!");

                    t1[npanel] =1;  // type1=1 = foot type of intersection

                    if ( npanel == 1 )
                    {   // set lower edge to start at same point p1
                        p1[0] = p1[npanel];
                        t1[0] = 1;
                    }
                }
                else if ( CVector3d(ip- head) * luffV > 0 )
                {   // seam intersects gaff
                    if ( seamL.intersect(gaffLine).getdim() == 0 )
                        p1[npanel] = seamL.intersect(gaffLine).getp();
                    else throw layout_error("CSailWorker::Layout0 -3 : intersection of seam and foot is not a point!");

                    t1[npanel] = 3;  // 3 = gaff type of intersection
                }
                else
                {   // seam intersects luff
                    p1[npanel] = ip;
                    t1[npanel] = 2;  // 2 = luff
                    if ( npanel == 1 )
                    {   // force seam 0 to start at the tack
                        p1[0] = tack;
                        t1[0] = 2;
                    }
                }

                /* We now add the intermediate points on all sides of the normal panel */

                /* Below is the code for the left side depending
                *  on t1 for the top side and bottom side
                */
                if ( t1[npanel-1] == 1  &&  t1[npanel] == 1 )
                {   // full foot
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                }
                else if ( t1[npanel-1] == 2  &&  t1[npanel] == 2 )
                {   // full luff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
                }
                else if ( t1[npanel-1] == 3  &&  t1[npanel] == 3 )
                {   // full gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k] , seamV);
                }
                else if ( (t1[npanel-1] == 1) && (t1[npanel] == 2) )
                {   // foot-tack-luff
                    lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                    for (k = 0 ; k < npl / 2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                }
                else if ( (t1[npanel-1] == 2) && (t1[npanel] == 3) )
                {   // luff-head-gaff
                    lay[npanel-1].left.fill(p1[npanel-1], head, p1[npanel]);
                    for (k = 0 ; k < npl/2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                } // end IF ELSE for left side

                /* Below is the code for the intermediate points of the right side
                *  which are all on the leech for a crosscut layout.
                */
                // first check if upper point is not below lower point
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * leechV < 0)
                    p2[npanel] = p2[npanel-1];

                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
                lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

                /* Below is the code for the intermediate points of the bottom side of first panel  */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    for (k = 1 ; k < npb -1 ; k++)
                    {
                        lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
                    }
                }
#ifdef DEBUG
                if ( npanel == 1 )
                {
                    cout << "CSailWorker::Layout0 Crosscut foot after adding curve" << endl;
                    for (k = 0 ; k < npb ; k++)
                        cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;
                }
#endif
            }  /* end else normal panel */

            /** Go over all the points of current panel and calculate their Z */
            lay[npanel-1] = Zpanel(lay[npanel-1]);

#ifdef DEBUG
            if ( npanel == 1 )
            { // move bottom side of first panel to foot curve
                cout << "CSailWorker::Layout0 Crosscut foot after Z " << endl;
                for (k = 0 ; k < npb ; k++)
                    cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;

                cout << "---end Z foot----   DO LOOP=" << cnt << endl;
            }
#endif

            /** Develop the current panel */
            if ( npanel == 1 ) {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            }
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for (k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /*
			cout << "Panel no " << npanel << endl;

			cout << "panel print" << endl;
			for (k = 0 ; k < npb ; k++)
				cout << "bottom point="<< k << " xyz=" << lay[npanel-1].bottom[k] << endl;
			for (k = 0 ; k < npb ; k++)
				cout << "top point="<< k << " xyz=" << lay[npanel-1].top[k] << endl;
			for (k = 0 ; k < npl ; k++)
				cout << "left point="<< k << " xyz=" << lay[npanel-1].left[k] << endl;
			for (k = 0 ; k < npl ; k++)
				cout << "right point="<< k << " xyz=" << lay[npanel-1].right[k] << endl;
			cout << "t1[npanel-1] =" << t1[npanel-1] <<"t1[npanel] = " << t1[npanel] << endl;
*/
            /**  Compute and store the deviation of top edge of
            *   the developed panel and straighten this top edge
            *   except if this is the top panel
            */
            if ( flag == false ) {
                vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb -1 ; k ++)
                {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v= vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /** Add the seam and hems allowance */
            if ( npanel == 1 ) {
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, footHemW );
            }
            else if ( flag == true ) {
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 )
                    dev[npanel-1].add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                else
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
            }
            /* Check the width of developed panel and store the excess */
            exc = dev[npanel-1].boundingRect().height() - clothW;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0  &&  cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        /** Reposition the developed panel such that the
        *  lowest point is Y=0 AND most left point is X=0.
        */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    }  /** Loop FOR next panel */

    if ( npanel == MAX_PANELS-1 )
        throw layout_error("CSailWorker::Layout0 : MAX_PANELS without reaching head, do increase cloth width ");

    /* Copy the sails for 3D display */
    CPanelGroup sail(npanel);

    for (j = 0 ; j < npanel ; j ++)
        sail[j] = lay[j];


    /** Create the displays version of the developed sail  */

    /* Copy the developed sail */
    flatsail = CPanelGroup(npanel);

    for (j = 0 ; j < npanel ; j++)
    {
        flatsail[j] = dev[j];
    }

    /* Re-position the developed panels in a clean stack */
    dispsail = flatsail;
    for (j = 1 ; j < npanel ; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // rotation to align bottom of panel to top of previous panel
        x = dispsail[j-1].top[npb-1].x() - top.x();
        y = dispsail[j-1].top[npb-1].y() - top.y();
        CC = atan2(y , x);
        dispsail[j] = dispsail[j].rotate(bot,CMatrix::rot3d(2,CC));

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = CVector3d ( top - CPoint3d(0,0,0) );
        v.x() = v.x() - bot.x();
        v.y() = v.y() + 2 * seamW +20; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    // cambers
    //if (sailType == SYMETRIC)
    calculateSailCambers();

    return sail;
} /* end layout0 = cross cut or horizontal //////////////// */

/**
 *  Creates a horizontally/sshperically cut symetical spinnaker
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 *
 * @author Paula
 */
CPanelGroup CSailWorker::LayoutHorizontalSpinnaker( CPanelGroup &flatsail, CPanelGroup &dispsail, CPanelGroup &flattened ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round)
    *   p1[] are on the luff side and p2[] are on the leech side
    */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS);  // 3D sail
    CPanelGroup dev(MAX_PANELS);  // developed sail
    bool bTest = true;
    vector<int> widthAdjust = SplitsToInts(panelWidthAdjustments, bTest, true);

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();   // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0;
    bool topOfSailReachedFlag = false;  // to check if top of sail is reached

    /* create arrays t1 and t2 of type of intersection of upper seam
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    CVector3d seamV; // seam Vector
    CSubSpace seamL; // seam Line

    seamV = CVector3d(-1, 0, 0);  // horizontal seam orientation for Horizontal cut

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    real CC = 0, x = 0, y = 0;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialise seam forward end at tack point
    p2[0] = clew; // initialise seam aft end at clew point
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection
    // because we're laying the cloth horizontally rather than
    // perpendicular to the leech the distance we need to add for
    // each panel will be greater than clothW so we'll calculate
    // a ratio by which the cloth width gets multiplied
    double verticalToDiagonalRatio = (real(leechL) / (topBack.y() - clew.y()));

    /** Lay the panels starting from the foot, going upward to the peak */

    for (npanel = 1 ; npanel < MAX_PANELS -1 ; npanel++)
    {
        real exc = 0; // current excess of width
        real exb = 0; // total correction
        cnt = 0; // counter of iterations
        int cw = npanel <= widthAdjust.size() ? clothW + widthAdjust[npanel-1]: clothW;

        do  /* Loop for optimising the seam position to fit cloth width */
        {
            cnt++;
            if (npanel == 1) {
                p2[npanel] = p2[npanel-1] + bottomPanelHeight * verticalToDiagonalRatio * leechV.unit();
            } else {
                p2[npanel] = p2[npanel-1] + ((cw - seamW - exb) * verticalToDiagonalRatio) * leechV.unit();
            }
            //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line( p2[npanel] , seamV );

            if ( CVector3d( p2[npanel] - topBack ) * leechV > 0 )
            {   // we are above peak, stop this is last panel
                topOfSailReachedFlag = true;
                lay[npanel-1].panelType = PANEL_SPINNAKER_TOP;
                p2[npanel] = topBack;
                p1[npanel] = head;
                t1[npanel] = 2;
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                lay[npanel-1].left = FillCurvedEdge( LUFF_EDGE, lay[npanel-1].left, seamV);

                // fill right points on leech
                lay[npanel-1].right.fill(p2[npanel-1],p2[npanel]);
                lay[npanel-1].right=FillCurvedEdge( LEECH_EDGE, lay[npanel-1].right, seamV);

                // fill bottom points
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

                // fill top  points
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

                // move all top points of top panel to gaff curve
                lay[npanel -1].top = FillCurvedEdge( GAFF_EDGE, lay[npanel-1].top, CVector3d (head.y()-peak.y(),peak.x()-head.x(),0));
                // end peak panel //
            }
            else   // normal panel below peak //////
            {
                topOfSailReachedFlag = false;
                lay[npanel-1].panelType = PANEL_CROSS_CUT;
                /* find position of luff/seam intersection relative to tack and head */
                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutHorizontalSpinnaker -1 : intersection of seam and luff is not a point!");

                p1[npanel] = ip;
                t1[npanel] = 2;  // 2 = luff
                if ( npanel == 1 )
                {   // force seam 0 to start at the tack
                    p1[0] = tack;
                    t1[0] = 2;
                }

                /* We now add the intermediate points on all sides of the normal panel */

                /* Below is the code for the left side depending
                *  on t1 for the top side and bottom side
                */
                lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                lay[npanel-1].left = FillCurvedEdge( LUFF_EDGE, lay[npanel-1].left , seamV);
                /* Below is the code for the intermediate points of the right side
                *  which are all on the leech for a crosscut layout.
                */
                // first check if upper point is not below lower point
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * leechV < 0)
                    p2[npanel] = p2[npanel-1];

                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                lay[npanel-1].right = FillCurvedEdge( LEECH_EDGE, lay[npanel-1].right, seamV);

                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
                lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

                /* Below is the code for the intermediate points of the bottom side of first panel  */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    lay[0].bottom = FillCurvedEdge( FOOT_EDGE, lay[0].bottom, CVector3d(0,-1,0));
                }
#ifdef DEBUG
                if ( npanel == 1 )
                {
                    cout << "CSailWorker::Layout0 Crosscut foot after adding curve" << endl;
                    for (k = 0 ; k < npb ; k++)
                        cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;
                }
#endif
            }  /* end else normal panel */

            /** Go over all the points of current panel and calculate their Z */
            lay[npanel-1] = Zpanel(lay[npanel-1], npanel == 1 && footEdgeAtZeroZ == true ? ZPSC_FOOT : ZPSC_NONE);

#ifdef DEBUG
            if ( npanel == 1 )
            { // move bottom side of first panel to foot curve
                cout << "CSailWorker::Layout0 Crosscut foot after Z " << endl;
                for (k = 0 ; k < npb ; k++)
                    cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;

                cout << "---end Z foot----   DO LOOP=" << cnt << endl;
            }
#endif
            //cout << " pre-develop npanel = " << npanel << endl;
            //cout << "     bottom " << lay[npanel-1].bottom.arcLength() << ",  " << distanceBetween(lay[npanel-1].bottom.front(), lay[npanel-1].bottom.back())<< endl;
            //cout << "        top " << lay[npanel-1].top.arcLength() << ",  " << distanceBetween(lay[npanel-1].top.front(), lay[npanel-1].top.back()) << endl;
            //cout << "       left " << lay[npanel-1].left.arcLength() << ",  " << distanceBetween(lay[npanel-1].left.front(), lay[npanel-1].left.back()) << endl;
            //cout << "      right " << lay[npanel-1].right.arcLength() << ",  " << distanceBetween(lay[npanel-1].right.front(), lay[npanel-1].right.back()) << endl;


            /** Develop the current panel */
            if ( npanel == 1 ) {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
                //cout << " post-develop npanel = " << npanel << endl;
                //cout << "     bottom " << dev[npanel-1].bottom.arcLength() << ",  " << distanceBetween(dev[npanel-1].bottom.front(), dev[npanel-1].bottom.back())<< endl;
                //cout << "        top " << dev[npanel-1].top.arcLength() << ",  " << distanceBetween(dev[npanel-1].top.front(), dev[npanel-1].top.back()) << endl;
                //cout << "       left " << dev[npanel-1].left.arcLength() << ",  " << distanceBetween(dev[npanel-1].left.front(), dev[npanel-1].left.back()) << endl;
                //cout << "      right " << dev[npanel-1].right.arcLength() << ",  " << distanceBetween(dev[npanel-1].right.front(), dev[npanel-1].right.back()) << endl;
            }
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                //cout << " post-develop npanel = " << npanel << endl;
                //cout << "     bottom " << dev[npanel-1].bottom.arcLength() << ",  " << distanceBetween(dev[npanel-1].bottom.front(), dev[npanel-1].bottom.back())<< endl;
                //cout << "        top " << dev[npanel-1].top.arcLength() << ",  " << distanceBetween(dev[npanel-1].top.front(), dev[npanel-1].top.back()) << endl;
                //cout << "       left " << dev[npanel-1].left.arcLength() << ",  " << distanceBetween(dev[npanel-1].left.front(), dev[npanel-1].left.back()) << endl;
                //cout << "      right " << dev[npanel-1].right.arcLength() << ",  " << distanceBetween(dev[npanel-1].right.front(), dev[npanel-1].right.back()) << endl;
                // add deviation of previous panel top edge to bottom edge
                for (k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }


            /**  Compute and store the deviation of top edge of
            *   the developed panel and straighten this top edge
            *   except if this is the top panel
            */
            if ( topOfSailReachedFlag == false ) {
                vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb -1 ; k ++)
                {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v= vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /** Add the seam and hems allowance */
            if ( npanel == 1 ) {
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, footHemW );
            }
            else if ( topOfSailReachedFlag == true ) {
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 )
                    dev[npanel-1].add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                else
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
            }
            /* Check the width of developed panel and store the excess */
            CRect3d r = dev[npanel-1].boundingRect();
            exc = dev[npanel-1].boundingRect().height() - cw;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
            cout << "npanel = " << npanel << ", height = " << r.height() << ", exc = " << exc << ", exb = " << exb << ", cnt = " << cnt << endl;
        }
        while ( exc > 0  &&  cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        /** Reposition the developed panel such that the
        *  lowest point is Y=0 AND most left point is X=0.
        */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        // fix foot curve of bottom panel if not foot z at 0
        if (npanel == 1 && !footEdgeAtZeroZ) {
            double h = dev[npanel-1].bottom.front().y();
            double w = dev[npanel-1].bottom.back().x() - dev[npanel-1].bottom.front().x();

            for (unsigned int j=0; j<dev[npanel-1].bottom.size(); j++) {
                real pos = dev[npanel-1].bottom[j].x() / w;
                real y = RoundP(pos, 50);
                dev[npanel-1].bottom[j] = CPoint3d(dev[npanel-1].bottom[j].x(), (h - y * h), 0);
            }
            dev[npanel-1].cutBottom  = dev[npanel-1].bottom;
        }

        /* check if peak has been reached to break off */
        if ( topOfSailReachedFlag == true )
            break;
    }  /** Loop FOR next panel */

    if ( npanel == MAX_PANELS-1 )
        throw layout_error("CSailWorker::LayoutHorizontalSpinnaker : MAX_PANELS without reaching head, do increase cloth width ");

    /* Copy the sails for 3D display */
    CPanelGroup sail(npanel);

    for (j = 0 ; j < npanel ; j ++)
        sail[j] = lay[j];


    /** Create the displays version of the developed sail  */

    /* Copy the developed sail */
    flatsail = CPanelGroup(npanel);

    for (j = 0 ; j < npanel ; j++)
    {
        flatsail[j] = dev[j];
        cout << "lay.left = " << lay[j].left.arcLength() << ", flatsail.left = " << flatsail[j].left.arcLength() << endl;
    }

    /* Re-position the developed panels in a clean stack */
    dispsail = flatsail;
    for (j = 1 ; j < npanel ; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // rotation to align bottom of panel to top of previous panel
        x = dispsail[j-1].top[npb-1].x() - top.x();
        y = dispsail[j-1].top[npb-1].y() - top.y();
        CC = atan2(y , x);
        dispsail[j] = dispsail[j].rotate(bot,CMatrix::rot3d(2,CC));

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = CVector3d ( top - CPoint3d(0,0,0) );
        v.x() = v.x() - bot.x();
        v.y() = v.y() + 2 * seamW +20; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    real centreHeight = 0;

    // fix curves on flatsail and dispsail
    for (j=0; j<npanel-1; j++) {
        //double dBottom = distanceBetween(flatsail[j+1].cutBottom.front(), flatsail[j+1].cutBottom.back());
        //double dTop = distanceBetween(flatsail[j].top.front(), flatsail[j].top.back());

        //double fBottom = dBottom/dTop *.5;
        double fraction = 0.5;//1 - fBottom;
        for (k=1; k<flatsail[j].top.size(); k++) {
            double d = flatsail[j+1].bottom[0].y()-flatsail[j+1].bottom[k].y()
                    +flatsail[j].top[k].y()-flatsail[j].top[0].y();
            flatsail[j].top[k] = CPoint3d(flatsail[j].top[k].x(), flatsail[j].top[0].y()+d*fraction, 0);
            flatsail[j].cutTop[k] = CPoint3d(flatsail[j].cutTop[k].x(), flatsail[j].cutTop[0].y()+d*fraction, 0);

            flatsail[j+1].bottom[k] = CPoint3d(flatsail[j+1].bottom[k].x(), flatsail[j+1].bottom[0].y()-d*fraction, 0);
            flatsail[j+1].cutBottom[k] = CPoint3d(flatsail[j+1].cutBottom[k].x(), flatsail[j+1].cutBottom[0].y()-d*fraction, 0);

        }

        flatsail[j] = flatsail[j].reframe(LOW_LEFT);

        for (k=1; k<dispsail[j].top.size(); k++) {
            double d = dispsail[j+1].bottom[0].y()-dispsail[j+1].bottom[k].y()
                    +dispsail[j].top[k].y()-dispsail[j].top[0].y();
            dispsail[j].top[k] = CPoint3d(dispsail[j].top[k].x(), dispsail[j].top[0].y()+d*fraction, 0);
            dispsail[j].cutTop[k] = CPoint3d(dispsail[j].cutTop[k].x(), dispsail[j].cutTop[0].y()+d*fraction, 0);

            dispsail[j+1].bottom[k] = CPoint3d(dispsail[j+1].bottom[k].x(), dispsail[j+1].bottom[0].y()-d*fraction, 0);
            dispsail[j+1].cutBottom[k] = CPoint3d(dispsail[j+1].cutBottom[k].x(), dispsail[j+1].cutBottom[0].y()-d*fraction, 0);

        }

        real h = flatsail[j].boundingRect().height();
        cout << "flatsail[" <<j <<"]   rect = " << h << endl;
        centreHeight += h - seamW;
    }

    centreHeight += flatsail[npanel-1].boundingRect().height();
    cout << "Centre Height = " << centreHeight << endl;;

    flatsail.back() = flatsail.back().reframe(LOW_LEFT);

    // scale bottom panel to same size as panel 1's bottom
    real d0 = distanceBetween(flatsail[0].top.front(), flatsail[0].top.back());
    real d1 = distanceBetween(flatsail[1].bottom.front(), flatsail[1].bottom.back());

    cout << "Panel 0 width was " << d0 << endl;
    flatsail[0] = flatsail[0].scaleX(d1/d0);

    cout << "Panel 0 width now " << distanceBetween(flatsail[0].top.front(), flatsail[0].top.back()) << ", d1 = " << d1 << endl;
/*
    for (unsigned int i=1; i<flatsail[1].left.size(); i++) {
        cout << "panel 1 " << (flatsail[1].left[i].x() - flatsail[1].left[0].x())
                << "  " << (flatsail[1].right[i].x()-flatsail[1].right[0].x()) << endl;
    }
    */

    // adjust top of each panel to match size of bottom of next panel up
    // we start from panel 1 as panel 0 has already been scaled
    for (unsigned int i=1; i<flatsail.size()-1; i++) {
        d0 = distanceBetween(flatsail[i].top.front(), flatsail[i].top.back());
        d1 = distanceBetween(flatsail[i+1].bottom.front(), flatsail[i+1].bottom.back());
        real xLeft = flatsail[i].top.front().x();
        real xRight = flatsail[i].top.back().x();
        // print out:
        // x difference between left top and left bottom
        // x difference between right top and right bottom
        // duffeerence betweem the two diagonals
        cout << "npanel = " << i << "  " << (flatsail[i].left.back().x()-flatsail[i].left.front().x())
             << " " << (flatsail[i].right.back().x()-flatsail[i].right.front().x())
             << " " << (distanceBetween(flatsail[i].top.front(), flatsail[i].bottom.back()) -
                distanceBetween(flatsail[i].top.back(), flatsail[i].bottom.front()))
             << endl;
        // print out bottom length around arc and straight line  length
        cout << "     bottom " << flatsail[i].cutBottom.arcLength() << ",  " << distanceBetween(flatsail[i].cutBottom.front(), flatsail[i].cutBottom.back())<< endl;
        // print out top length around arc and straight line  length
        cout << "        top " << flatsail[i].top.arcLength()       << ",  " << distanceBetween(flatsail[i].top.front(), flatsail[i].top.back()) << endl;
        flatsail[i] = flatsail[i].scaleTopInX(d1/d0);
        // print x change on left and right side and difference between the two diagonals
        cout << "      change = " << (flatsail[i].top.front().x()-xLeft)
             << " " << (flatsail[i].top.back().x()-xRight)
             << " " << (distanceBetween(flatsail[i].top.front(), flatsail[i].bottom.back()) -
                distanceBetween(flatsail[i].top.back(), flatsail[i].bottom.front()))
             << endl;
        // print out bottom length around arc and straight line  length
        cout << "     bottom " << flatsail[i].cutBottom.arcLength() << ",  " << distanceBetween(flatsail[i].cutBottom.front(), flatsail[i].cutBottom.back())<< endl;
        // print out top length around arc and straight line  length
        cout << "        top " << flatsail[i].top.arcLength()       << ",  " << distanceBetween(flatsail[i].top.front(), flatsail[i].top.back()) << endl;
    }

    // now adjust dispsail even though it's just cosmetic
    for (unsigned int i=1; i<dispsail.size()-1; i++) {
        // save bottom left point of bounding rectangle
        CPoint3d pLowLeft = dispsail[i].boundingRect().min;

        d0 = distanceBetween(dispsail[i].top.front(), dispsail[i].top.back());
        d1 = distanceBetween(dispsail[i+1].bottom.front(), dispsail[i+1].bottom.back());
        // scale ad add back saved point
        dispsail[i] = dispsail[i].scaleTopInX(d1/d0) + (pLowLeft-CPoint3d(0,0,0));
    }
    // align dispsail panels
    for (unsigned int i=1; i<dispsail.size(); i++) {
        real xdiff =  dispsail[i-1].top.front().x() - dispsail[i].bottom.front().x();
        dispsail[i] = dispsail[i]+CVector3d(xdiff, 0, 0);

    }

/*    for (unsigned int i=0; i< flatsail.size(); i++) {
        //int m = int(sail[i].bottom.size() / 2);
        //CPoint3d pLow = sail[i].bottom[m];
        //CPoint3d pHigh = sail[i].top[m];

        //real d = (pHigh-pLow).norm();
        //s+= d;
        //cout << "pLow = " << pLow << ", pHigh = " << pHigh << ", d = " << d << ", s = " << s << endl;
        cout << "npanel = " << i << endl;
        cout << "     bottom " << flatsail[i].cutBottom.arcLength() << ",  " << distanceBetween(flatsail[i].cutBottom.front(), flatsail[i].cutBottom.back())<< endl;
        cout << "        top " << flatsail[i].top.arcLength()       << ",  " << distanceBetween(flatsail[i].top.front(), flatsail[i].top.back()) << endl;
    }
*/

    // generate flattened view

    flattened = flattenSail(flatsail);
    m_flattened = flattened;

    // split bottom panel in two for more efficient nesting
    CPanel leftPanel = flatsail[0].splitLeft(-1*seamW/2,seamW);
    leftPanel.panelType = PANEL_SPINNAKER_FOOT_LEFT;
    CPanel rightPanel = flatsail[0].splitRight(-1*seamW/2,0);
    rightPanel.panelType = PANEL_SPINNAKER_FOOT_RIGHT;
    // reframe panels
    rightPanel = rightPanel.reframe(LOW_LEFT);
    leftPanel = leftPanel.reframe(LOW_LEFT);
    flatsail[0] = rightPanel;
    flatsail.insert(flatsail.begin(), leftPanel);

    unsigned int numFlatPanels = flatsail.size();

    cout << "     bottom " << flatsail[0].cutBottom.arcLength() << ",  " << distanceBetween(flatsail[0].cutBottom.front(), flatsail[0].cutBottom.back())<< endl;
    cout << "        top " << flatsail[0].top.arcLength()       << ",  " << distanceBetween(flatsail[0].top.front(), flatsail[0].top.back()) << endl;

    cout << "     bottom " << flatsail[1].cutBottom.arcLength() << ",  " << distanceBetween(flatsail[1].cutBottom.front(), flatsail[1].cutBottom.back())<< endl;
    cout << "        top " << flatsail[1].top.arcLength()       << ",  " << distanceBetween(flatsail[1].top.front(), flatsail[1].top.back()) << endl;


    leftPanel = dispsail[0].splitLeft(-1*seamW/2,seamW);
    rightPanel = dispsail[0].splitRight(-1*seamW/2,0);
    // don't reframe rightPanel so it shows as part of a split panel
    dispsail[0] = rightPanel;
    dispsail.insert(dispsail.begin(), leftPanel);

    //real s = 0;
    vector<Patch> patches = findPatches(PATCH_SPINNAKER_CLEW);
    if (patches.size()> 0) {
        real patchSize = real(patches[0].dimension1);
        CPanel patch = layoutSymetricalSpinnakerClewPatch(patchSize, PATCH_SPINNAKER_CLEW);
        flatsail.push_back(patch);
        flatsail.push_back(CPanel(patch));

        bool bTest;
        vector<int> vUnderpatches = SplitsToInts(patches[0].underPatches, bTest);
        if (bTest == false) {
            throw layout_error("LayoutHorizontalSpinnaker: Invalid value in splits for clew patch");

        }
        for (unsigned int i=0; i< vUnderpatches.size(); i++) {
            patchSize = real(vUnderpatches[i]);
            patch = layoutSymetricalSpinnakerClewPatch(patchSize, PATCH_SPINNAKER_CLEW_UNDERPATCH);
            // under patches
            // we're only generating these so that printed patterns
            // can be made hence we only output one set for clew
            flatsail.push_back(patch);
        }
    }

    patches = findPatches(PATCH_SPINNAKER_HEAD);
    if (patches.size()> 0) {
        real patchSize = real(patches[0].dimension1);
        CPanel patch = layoutSymetricalSpinnakerHeadPatch(patchSize);
        flatsail.push_back(patch);

        bool bTest;
        vector<int> vUnderpatches = SplitsToInts(patches[0].underPatches, bTest);
        if (bTest == false) {
            throw layout_error("LayoutHorizontalSpinnaker: Invalid value in splits for head patch");
        }
        for (unsigned int i=0; i< vUnderpatches.size(); i++) {
            patchSize = real(vUnderpatches[i]);
            patch = layoutSymetricalSpinnakerHeadPatch(patchSize, PATCH_SPINNAKER_HEAD_UNDERPATCH);
            flatsail.push_back(patch);
        }
    }

    // curve analysis
    unsigned int idxHalfWidth = int(NUM_TOP_BOTTOM_POINTS / 2);
    unsigned int idx25 = int(idxHalfWidth*.75);
    unsigned int idxA = int(idx25 * .75);
    unsigned int idxB = int(idx25 * .5);
    unsigned int idxC = int(idx25 * .25);
    cout << "curve analysis" << endl;

    for (unsigned int i=2; i< numFlatPanels; i++) {
        CPoint3d pHalfWidth = flatsail[i].bottom[idxHalfWidth];
        CPoint3d p25 = flatsail[i].bottom[idx25];
        CPoint3d pA = flatsail[i].bottom[idxA];
        CPoint3d pB = flatsail[i].bottom[idxB];
        CPoint3d pC = flatsail[i].bottom[idxC];

        real y0 = pHalfWidth.y();
        real yHeight = flatsail[i].bottom.front().y() - y0;
        //real x0 = flatsail[i].bottom.front().x();
        //real cosAngle = (pHalfWidth.x()- x0)
        //        / distanceBetween(pHalfWidth, flatsail[i].bottom.front());

        real h25 = (p25.y() - y0) / yHeight * 100;
        real hA = (pA.y() - y0) / yHeight * 100;
        real hB = (pB.y() - y0) / yHeight * 100;
        real hC = (pC.y() - y0) / yHeight * 100;

        cout << "i = " << i << ", h25 = " << h25 << ", hA = " << hA << ", hB = " << hB << ", hC = " << hC << endl;
    }

    // cambers
    calculateSailCambers();

    // broadseam info
    aBroadseamInfo = calculateBroadseams(flatsail);

    return sail;
} /* end layout horizontal spinnaker //////////////// */

/**
 * @brief CSailWorker::LayoutRadialBottomSpinnaker
 * @param flatsail
 * @param dispsail
 * @param flattened
 * @return
 */
CPanelGroup CSailWorker::LayoutRadialBottomSpinnaker( CPanelGroup &flatsail, CPanelGroup &dispsail , CPanelGroup &flattened) const {
    RunPanelTests();
    CPanelGroup sail;
    sail.clear();
    dispsail.clear();
    flatsail.clear();

    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round)
    *   p1[] are on the luff side and p2[] are on the leech side
    */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(1);  // 3D sail
    CPanelGroup dev;  // developed sail
    bool bTest = true;
    vector<int> widthAdjust = SplitsToInts(panelWidthAdjustments, bTest, true);

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();   // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points
    unsigned int centreIdx = int(npb/2);
    unsigned int radialBottomSize = centreIdx +1;

    lay.clear();
    dev.clear();

    unsigned int j = 0, k = 0, cnt = 0;
    bool topOfSailReachedFlag = false;  // to check if top of sail is reached

    /* create arrays t1 and t2 of type of intersection of upper seam
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    CVector3d seamV; // seam Vector
    CSubSpace seamL; // seam Line

    seamV = CVector3d(-1, 0, 0);  // horizontal seam orientation for Horizontal cut

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    real CC = 0, x = 0, y = 0;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialise seam forward end at tack point
    p2[0] = clew; // initialise seam aft end at clew point
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection
    // because we're laying the cloth horizontally rather than
    // perpendicular to the leech the distance we need to add for
    // each panel will be greater than clothW so we'll calculate
    // a ratio by which the cloth width gets multiplied
    double verticalToDiagonalRatio = (real(leechL) / (topBack.y() - clew.y()));

    int cw = npanel <= widthAdjust.size() ? clothW + widthAdjust[npanel-1]: clothW;

    CPoint3d pLeech = clew + + ((cw - seamW) * verticalToDiagonalRatio) * leechV.unit();
    CPoint3d pLuff = tack + + ((cw - seamW) * verticalToDiagonalRatio) * luffV.unit();
    CPoint3d pCentre = pLuff + (pLeech - pLuff) * 0.5;
    CPoint3d pHalfFoot = tack + (clew-tack) *0.5;
    CPoint3d pFootRound = EdgeIntersect(FOOT_EDGE, pHalfFoot, footVP);

    seamL = CSubSpace3d::line( pLeech , seamV );
 /*   CPanel fullBottomPanel;
    fullBottomPanel.left.fill(tack, pLuff);
    fullBottomPanel.left = FillCurvedEdge(LUFF_EDGE, fullBottomPanel.left, seamV);
    fullBottomPanel.right.fill(clew, pLeech);
    fullBottomPanel.right = FillCurvedEdge(LEECH_EDGE, fullBottomPanel.right, seamV);
    fullBottomPanel.top.fill(fullBottomPanel.left.back(), fullBottomPanel.right.back());
    fullBottomPanel.bottom.fill(tack, clew);
    fullBottomPanel.bottom = FillCurvedEdge(FOOT_EDGE, fullBottomPanel.bottom, footVP);

    fullBottomPanel = Zpanel(fullBottomPanel, footEdgeAtZeroZ == true ? ZPSC_FOOT : ZPSC_NONE);
    //sail.push_back(fullBottomPanel);
    fullBottomPanel = fullBottomPanel.develop(ALIGN_NONE);
*/
    CPanel leftBottomPanel = CPanel(radialBottomSize, radialBottomSize);

    leftBottomPanel.left.fill(tack, pLuff);
    leftBottomPanel.left = FillCurvedEdge(LUFF_EDGE, leftBottomPanel.left, seamV);
    leftBottomPanel.top.fill(leftBottomPanel.left.back(), pCentre);
    leftBottomPanel.bottom.fill(tack, pHalfFoot);
    leftBottomPanel.bottom = FillCurvedEdge(FOOT_EDGE, leftBottomPanel.bottom, footVP);
    leftBottomPanel.right.fill(leftBottomPanel.bottom.back(), pCentre);

    // calculate internal angles of 2d shape of left panel
    pLuff = leftBottomPanel.top.front();
    real tackAngle = Atriangle((pLuff-pFootRound).norm(), (tack-pFootRound).norm(), (tack-pLuff).norm());
    real midAngle =  Atriangle((pLuff-pCentre).norm(), (tack-pCentre).norm(), (tack-pLuff).norm());
    real luffAngle = Atriangle( (tack-pCentre).norm(), (pLuff-pCentre).norm(), (tack-pLuff).norm());
    real footAngle = 2*PI - PI/2 - tackAngle - luffAngle;
    real goreAngle = tackAngle/nbGores;
    unsigned int nTopGorePoints = int(midAngle/goreAngle);
    unsigned int nMidGorePoints = int((tackAngle-midAngle)/goreAngle);

    CSide bottomSide = CSide(radialBottomSize);
    bottomSide.fill(pLuff, tack);
    bottomSide = FillCurvedEdge(LUFF_EDGE, bottomSide, seamV);


    CSide tackSide  = CSide(radialBottomSize);
    tackSide.fill(tack, tack);
    CSide clewSide = CSide(radialBottomSize);
    clewSide.fill(clew, clew);

    vector<double> topLeftPoints, topRightPoints, midPoints;
    topLeftPoints.clear();
    topRightPoints.clear();
    midPoints.clear();

    CSide topSide  = CSide(radialBottomSize);
    topSide.fill(pHalfFoot, tack);
    topSide = FillCurvedEdge(FOOT_EDGE, topSide, footVP);

    CPanelGroup midGores;
    midGores.clear();
    // calculate left mid gore points
    for (unsigned int i=0 ; i<nMidGorePoints; i++) {
        real angleA = goreAngle * (i+1);

        struct ASAresults results = SolveASAtriangle(angleA, (pFootRound-tack).norm(), footAngle);
        CPoint3d p = CPoint3d(pFootRound.x(), pFootRound.y()+results.sideA, 0);
        double d = (p-pFootRound).norm() / (pCentre-pFootRound).norm();
        midPoints.push_back(d);
        //cout << "i = " << i << ", pFootRound = " << pFootRound << ", p= " << p << ", pCentre = " << pCentre << endl;
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.top = topSide;
        pnl.bottom.fill(p, tack);
        pnl.right = tackSide;
        pnl.left.fill(p, topSide.front());

        if (i== 0 && footEdgeAtZeroZ) {
            midGores.push_back(Zpanel(pnl, ZPSC_TOP));
        } else {
            midGores.push_back(Zpanel(pnl));
        }

        topSide.fill(p, tack);
    }

    CSide bridgeTopSide = topSide;

    bottomSide.fill(pLuff, tack);
    bottomSide = FillCurvedEdge(LUFF_EDGE, bottomSide, seamV);

    // luf//top gores
    for (unsigned int i=0 ; i<nTopGorePoints; i++) {
        real angleB = goreAngle * (i+1);
        struct ASAresults results = SolveASAtriangle(luffAngle, (tack-pLuff).norm(), angleB);
        CPoint3d p = CPoint3d(pLuff.x()+results.sideB, pLuff.y(), 0);
        double d = (p-pLuff).norm() / (pCentre-pLuff).norm();
        topLeftPoints.push_back(d);
//        cout << "i = " << i << ", sideB = " << results.sideB << endl;
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.bottom = bottomSide;
        pnl.right = tackSide;
        pnl.left.fill(bottomSide.back(), p);
        pnl.top.fill(p, tack);
        sail.push_back(Zpanel(pnl));

        bottomSide.fill(p, tack);
    }

    CSide bridgeBottomSide = bottomSide;
    // bridging gore
    CPanel bridgePnl =  CPanel(radialBottomSize, radialBottomSize);
    bridgePnl.top = bridgeTopSide;
    bridgePnl.bottom = bridgeBottomSide;
    bridgePnl.right = tackSide;
    bridgePnl.left.fill(bridgePnl.bottom.front(), pCentre, bridgePnl.top.front());
    sail.push_back(Zpanel(bridgePnl));

    // append mid gores
    for (unsigned int i = midGores.size(); i > 0; i--) {
        sail.push_back(midGores[i-1]);
    }

    // -------------- right side of radial
    bottomSide.fill(pFootRound, clew);
    bottomSide = FillCurvedEdge(FOOT_EDGE, bottomSide, footVP);

    midGores.clear();
    // calculate right mid gores
    for (unsigned int i=0 ; i<nMidGorePoints; i++) {
        double d = midPoints[i];
        CPoint3d p = pFootRound + (pCentre-pFootRound)*d;
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.top.fill(p, clew);
        pnl.bottom = bottomSide;
        pnl.right = clewSide;
        pnl.left.fill(bottomSide.front(), p);
        if (i== 0 && footEdgeAtZeroZ) {
            sail.push_back(Zpanel(pnl, ZPSC_FOOT));
        } else {
            sail.push_back(Zpanel(pnl));
        }

        bottomSide.fill(p, clew);
    }

    bridgeTopSide = topSide;

    topSide.fill(pLeech, clew);
    topSide = FillCurvedEdge(LEECH_EDGE, topSide, seamV);
    pLeech = topSide.front();
    CPanelGroup topGores;
    topGores.clear();

    // luf//top right gores
    for (unsigned int i=0 ; i<nTopGorePoints; i++) {
        real angleB = goreAngle * (i+1);
        struct ASAresults results = SolveASAtriangle(luffAngle, (tack-pLuff).norm(), angleB);
        //cout << "i = " << i << ", sideB = " << results.sideB << endl;
        CPoint3d p = CPoint3d(pLeech.x()-results.sideB, pLeech.y(), 0);
        //cout << "p to leech = " << (pLeech-p).norm() << endl;
        double d = (p-pLeech).norm() / (pCentre-pLeech).norm();
        topRightPoints.push_back(d);
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.bottom.fill(p, clew);
        pnl.top = topSide;
        pnl.right = clewSide;
        pnl.left.fill(p, topSide.front());
        topGores.push_back(Zpanel(pnl));

        topSide.fill(p, clew);
    }

    bridgeBottomSide = bottomSide;
    bridgeTopSide = topSide;
    // bridging gore
    bridgePnl =  CPanel(radialBottomSize, radialBottomSize);
    bridgePnl.top = bridgeTopSide;
    bridgePnl.bottom = bridgeBottomSide;
    bridgePnl.right = tackSide;
    bridgePnl.left.fill(bridgePnl.bottom.front(), pCentre, bridgePnl.top.front());
    sail.push_back(Zpanel(bridgePnl));

    // append top panels
    for (unsigned int i = topGores.size(); i > 0; i--) {
        sail.push_back(topGores[i-1]);
    }

    CSide fullWidthSide = CSide(NUM_TOP_BOTTOM_POINTS);
    fullWidthSide.fill(pLuff, pLeech);

    // --------------------------------------
    leftBottomPanel = Zpanel(leftBottomPanel, footEdgeAtZeroZ == true ? ZPSC_FOOT : ZPSC_NONE);
    leftBottomPanel = leftBottomPanel.develop(ALIGN_NONE);
    x = leftBottomPanel.right.front().x()-leftBottomPanel.right.back().x();
    y = leftBottomPanel.right.back().y()-leftBottomPanel.right.front().y();
    real angle = atan(x/y);
    leftBottomPanel = leftBottomPanel.rotate(leftBottomPanel.right.front(), CMatrix::rot3d(2,angle*-1));
    leftBottomPanel = leftBottomPanel.reframe(LOW_LEFT);

    // fix foot curve of bottom panel if not foot z at 0
    if (!footEdgeAtZeroZ) {
        double h = leftBottomPanel.bottom.front().y();
        double w = (leftBottomPanel.bottom.back().x() - leftBottomPanel.bottom.front().x()) * 2;

        for (unsigned int j=0; j<leftBottomPanel.bottom.size(); j++) {
            real pos = (leftBottomPanel.bottom[j].x() - leftBottomPanel.bottom[0].x()) / w;
            real y = RoundP(pos, 50);
            leftBottomPanel.bottom[j] = CPoint3d(leftBottomPanel.bottom[j].x(), (h - y * h), 0);
        }
        leftBottomPanel.cutBottom  = leftBottomPanel.bottom;
    }


    dispsail.push_back(CPanel(leftBottomPanel));

    CPanel rightBottomPanel = CPanel(radialBottomSize, radialBottomSize);

    rightBottomPanel.right.fill(clew, pLeech);
    rightBottomPanel.right = FillCurvedEdge(LEECH_EDGE, rightBottomPanel.right, seamV);
    rightBottomPanel.top.fill(pCentre, rightBottomPanel.right.back());
    rightBottomPanel.bottom.fill(pHalfFoot, clew);
    rightBottomPanel.bottom = FillCurvedEdge(FOOT_EDGE, rightBottomPanel.bottom, footVP);
    rightBottomPanel.left.fill(rightBottomPanel.bottom.front(), pCentre);

    rightBottomPanel = Zpanel(rightBottomPanel, footEdgeAtZeroZ == true ? ZPSC_FOOT : ZPSC_NONE);
    rightBottomPanel = rightBottomPanel.develop(ALIGN_NONE);

    x = rightBottomPanel.left.front().x()-rightBottomPanel.left.back().x();
    y = rightBottomPanel.left.back().y()-rightBottomPanel.left.front().y();
    angle = atan(x/y);
    rightBottomPanel = rightBottomPanel.rotate(rightBottomPanel.left.front(), CMatrix::rot3d(2,angle*-1));
    rightBottomPanel = rightBottomPanel.reframe(LOW_LEFT);

    // fix foot curve of bottom panel if not foot z at 0
    if (!footEdgeAtZeroZ) {
        double h = rightBottomPanel.bottom.front().y();
        double w = (rightBottomPanel.bottom.back().x() - rightBottomPanel.bottom.front().x()) * 2;

        for (unsigned int j=0; j<rightBottomPanel.bottom.size(); j++) {
            real pos = 0.5 + (rightBottomPanel.bottom[j].x() - rightBottomPanel.bottom.front().x()) / w;
            real y = RoundP(pos, 50);
            rightBottomPanel.bottom[j] = CPoint3d(rightBottomPanel.bottom[j].x(), (h - y * h), 0);
        }
        rightBottomPanel.cutBottom  = rightBottomPanel.bottom;
    }

    dispsail.push_back(CPanel(rightBottomPanel));

    p1[0] = pLuff; // initialise seam forward end at tack point
    p2[0] = pLeech; // initialise seam aft end at clew point
    t1[0] = 1;

    //--------- generate the remaining horizontal panels
    for (npanel = 1 ; npanel < MAX_PANELS -1 ; npanel++)
    {
        real exc = 0; // current excess of width
        real exb = 0; // total correction
        cnt = 0; // counter of iterations
        int cw = npanel < widthAdjust.size() ? clothW + widthAdjust[npanel]: clothW;

        lay.push_back(CPanel());

        unsigned int idx = lay.size()-1;

        do  /* Loop for optimising the seam position to fit cloth width */
        {
            cnt++;
            p2[npanel] = p2[npanel-1] + ((cw - seamW - exb) * verticalToDiagonalRatio) * leechV.unit();
            //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line( p2[npanel] , seamV );

            if ( p2[npanel].y() >= topBack.y() )
//          if ( CVector3d( p2[npanel] - topBack ) * leechV > 0 )
            {   // we are above peak, stop this is last panel
                topOfSailReachedFlag = true;
                lay[idx].panelType = PANEL_SPINNAKER_TOP;
                p2[npanel] = topBack;
                p1[npanel] = head;
                t1[npanel] = 2;
                lay[idx].left.fill(p1[npanel-1], p1[npanel]);
                lay[idx].left = FillCurvedEdge( LUFF_EDGE, lay[idx].left, seamV);

                // fill right points on leech
                lay[idx].right.fill(p2[npanel-1],p2[npanel]);
                lay[idx].right=FillCurvedEdge( LEECH_EDGE, lay[idx].right, seamV);

                // fill bottom points
                lay[idx].bottom.fill(lay[idx].left[0], lay[idx].right[0]);

                // fill top  points
                lay[idx].top.fill(lay[idx].left[npl-1], lay[idx].right[npl-1]);

                // move all top points of top panel to gaff curve
                lay[idx].top = FillCurvedEdge( GAFF_EDGE, lay[idx].top, CVector3d (head.y()-peak.y(),peak.x()-head.x(),0));
                // end peak panel //
            }
            else   // normal panel below peak //////
            {
                topOfSailReachedFlag = false;
                lay[idx].panelType = PANEL_CROSS_CUT;
                /* find position of luff/seam intersection relative to tack and head */
                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutHorizontalSpinnaker -1 : intersection of seam and luff is not a point!");

                p1[npanel] = ip;
                t1[npanel] = 2;  // 2 = luff

                /* We now add the intermediate points on all sides of the normal panel */

                /* Below is the code for the left side depending
                *  on t1 for the top side and bottom side
                */
                lay[idx].left.fill(p1[npanel-1] , p1[npanel]);
                lay[idx].left = FillCurvedEdge( LUFF_EDGE, lay[idx].left , seamV);
                /* Below is the code for the intermediate points of the right side
                *  which are all on the leech for a crosscut layout.
                */
                // first check if upper point is not below lower point
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * leechV < 0)
                    p2[npanel] = p2[npanel-1];

                lay[idx].right.fill(p2[npanel-1] , p2[npanel]);
                lay[idx].right = FillCurvedEdge( LEECH_EDGE, lay[idx].right, seamV);

                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                lay[idx].top.fill( lay[idx].left[npl-1] , lay[idx].right[npl-1] );
                lay[idx].bottom.fill( lay[idx].left[0] , lay[idx].right[0] );

            }  /* end else normal panel */

            /** Go over all the points of current panel and calculate their Z */
            lay[idx] = Zpanel(lay[idx], ZPSC_NONE);

            //cout << " pre-develop npanel = " << npanel << endl;
            //cout << "     bottom " << lay[npanel-1].bottom.arcLength() << ",  " << distanceBetween(lay[npanel-1].bottom.front(), lay[npanel-1].bottom.back())<< endl;
            //cout << "        top " << lay[npanel-1].top.arcLength() << ",  " << distanceBetween(lay[npanel-1].top.front(), lay[npanel-1].top.back()) << endl;
            //cout << "       left " << lay[npanel-1].left.arcLength() << ",  " << distanceBetween(lay[npanel-1].left.front(), lay[npanel-1].left.back()) << endl;
            //cout << "      right " << lay[npanel-1].right.arcLength() << ",  " << distanceBetween(lay[npanel-1].right.front(), lay[npanel-1].right.back()) << endl;


            /** Develop the current panel */
            if (dev.size() < (idx+1)) {
                dev.push_back(CPanel());
            }
            dev.back() = lay[idx].develop(ALIGN_BOTTOM);
                //cout << " post-develop npanel = " << npanel << endl;
                //cout << "     bottom " << dev[npanel-1].bottom.arcLength() << ",  " << distanceBetween(dev[npanel-1].bottom.front(), dev[npanel-1].bottom.back())<< endl;
                //cout << "        top " << dev[npanel-1].top.arcLength() << ",  " << distanceBetween(dev[npanel-1].top.front(), dev[npanel-1].top.back()) << endl;
                //cout << "       left " << dev[npanel-1].left.arcLength() << ",  " << distanceBetween(dev[npanel-1].left.front(), dev[npanel-1].left.back()) << endl;
                //cout << "      right " << dev[npanel-1].right.arcLength() << ",  " << distanceBetween(dev[npanel-1].right.front(), dev[npanel-1].right.back()) << endl;
                // add deviation of previous panel top edge to bottom edge
                //for (k = 1; k < npb-1; k ++)
                //    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];


            /**  Compute and store the deviation of top edge of
            *   the developed panel and straighten this top edge
            *   except if this is the top panel
            */
/*            if ( topOfSailReachedFlag == false ) {
                vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb -1 ; k ++)
                {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v= vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }
*/

            /** Add the seam and hems allowance */
            if ( topOfSailReachedFlag == true ) {
                dev.back().add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 )
                    dev.back().add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                else
                    dev.back().add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
            }

           /* Check the width of developed panel and store the excess */
            CRect3d r = dev.back().boundingRect();
            exc = dev.back().boundingRect().height() - cw;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
            cout << "npanel = " << npanel << ", height = " << r.height() << ", exc = " << exc << ", exb = " << exb << ", cnt = " << cnt << endl;
        }
        while ( exc > 0  &&  cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        /** Reposition the developed panel such that the
        *  lowest point is Y=0 AND most left point is X=0.
        */
        dev.back() = dev.back().reframe(LOW_LEFT);

        // fix foot curve of bottom panel if not foot z at 0
/*        if (npanel == 1 && !footEdgeAtZeroZ) {
            double h = dev[npanel-1].top.front().y();
            double w = dev[npanel-1].top.back().x() - dev[npanel-1].top.front().x();

            for (unsigned int j=0; j<dev[npanel-1].bottom.size(); j++) {
                real pos = dev[npanel-1].bottom[j].x() / w;
                real y = RoundP(pos, 50);
                dev[npanel-1].bottom[j] = CPoint3d(dev[npanel-1].bottom[j].x(), (h - y * h), 0);
            }
            dev[npanel-1].cutBottom  = dev[npanel-1].bottom;
        }
*/
        /* check if peak has been reached to break off */
        if ( topOfSailReachedFlag == true )
            break;
    }  /** Loop FOR next panel */

    for (unsigned int i=0; i<lay.size(); i++) {
        sail.push_back(lay[i]);
    }

    flatsail.push_back(leftBottomPanel);
    flatsail.push_back(rightBottomPanel.reframe(LOW_LEFT));

    for (unsigned int i=0; i<dev.size(); i++) {
        flatsail.push_back(dev[i]);
    }

    for (unsigned int i=0; i<dev.size(); i++) {
        dispsail.push_back(dev[i]);
    }

    // fix curves on flatsail and dispsail horizontal panels
    for (j=2; j<flatsail.size()-1; j++) {
        double fraction = 0.5;//1 - fBottom;
        for (k=1; k<flatsail[j].top.size(); k++) {
            double d = flatsail[j+1].bottom[0].y()-flatsail[j+1].bottom[k].y()
                    +flatsail[j].top[k].y()-flatsail[j].top[0].y();
            flatsail[j].top[k] = CPoint3d(flatsail[j].top[k].x(), flatsail[j].top[0].y()+d*fraction, 0);
            flatsail[j].cutTop[k] = CPoint3d(flatsail[j].cutTop[k].x(), flatsail[j].cutTop[0].y()+d*fraction, 0);

            flatsail[j+1].bottom[k] = CPoint3d(flatsail[j+1].bottom[k].x(), flatsail[j+1].bottom[0].y()-d*fraction, 0);
            flatsail[j+1].cutBottom[k] = CPoint3d(flatsail[j+1].cutBottom[k].x(), flatsail[j+1].cutBottom[0].y()-d*fraction, 0);

        }

        flatsail[j] = flatsail[j].reframe(LOW_LEFT);

        for (k=1; k<dispsail[j].top.size(); k++) {
            double d = dispsail[j+1].bottom[0].y()-dispsail[j+1].bottom[k].y()
                    +dispsail[j].top[k].y()-dispsail[j].top[0].y();
            dispsail[j].top[k] = CPoint3d(dispsail[j].top[k].x(), dispsail[j].top[0].y()+d*fraction, 0);
            dispsail[j].cutTop[k] = CPoint3d(dispsail[j].cutTop[k].x(), dispsail[j].cutTop[0].y()+d*fraction, 0);

            dispsail[j+1].bottom[k] = CPoint3d(dispsail[j+1].bottom[k].x(), dispsail[j+1].bottom[0].y()-d*fraction, 0);
            dispsail[j+1].cutBottom[k] = CPoint3d(dispsail[j+1].cutBottom[k].x(), dispsail[j+1].cutBottom[0].y()-d*fraction, 0);

        }
    }
    flatsail.back() = flatsail.back().reframe(LOW_LEFT);


    // fix curves on flatsail and dispsail lower panels

    double fraction = 0.5;//1 - fBottom;
    // panel 0
    for (k=1; k<flatsail[0].top.size(); k++) {
        double d = flatsail[2].bottom[0].y()-flatsail[2].bottom[k].y()
                +flatsail[0].top[k].y()-flatsail[0].top[0].y();
        flatsail[0].top[k] = CPoint3d(flatsail[0].top[k].x(), flatsail[0].top[0].y()+d*fraction, 0);
        flatsail[0].cutTop[k] = CPoint3d(flatsail[0].cutTop[k].x(), flatsail[0].cutTop[0].y()+d*fraction, 0);

        flatsail[2].bottom[k] = CPoint3d(flatsail[2].bottom[k].x(), flatsail[2].bottom[0].y()-d*fraction, 0);
        flatsail[2].cutBottom[k] = CPoint3d(flatsail[2].cutBottom[k].x(), flatsail[2].cutBottom[0].y()-d*fraction, 0);

    }

    flatsail[0].right = flatsail[0].right.trimAbove(flatsail[0].top.back().y());
    flatsail[0] = flatsail[0].reframe(LOW_LEFT);

    for (k=1; k<dispsail[0].top.size(); k++) {
        double d = dispsail[2].bottom[0].y()-dispsail[2].bottom[k].y()
                +dispsail[0].top[k].y()-dispsail[0].top[0].y();
        dispsail[0].top[k] = CPoint3d(dispsail[0].top[k].x(), dispsail[0].top[0].y()+d*fraction, 0);
        dispsail[0].cutTop[k] = CPoint3d(dispsail[0].cutTop[k].x(), dispsail[0].cutTop[0].y()+d*fraction, 0);

        dispsail[2].bottom[k] = CPoint3d(dispsail[2].bottom[k].x(), dispsail[2].bottom[0].y()-d*fraction, 0);
        dispsail[2].cutBottom[k] = CPoint3d(dispsail[2].cutBottom[k].x(), dispsail[2].cutBottom[0].y()-d*fraction, 0);

    }

    dispsail[0].right = dispsail[0].right.trimAbove(dispsail[0].top.back().y());
    dispsail[0] = dispsail[0].reframe(LOW_LEFT);
    dispsail[1] = dispsail[1].reframe(LOW_LEFT);
    dispsail[1] = dispsail[1] + (leftBottomPanel.bottom.back()-leftBottomPanel.bottom.front());

    flatsail[1].top.front().y() = flatsail[0].top.back().y();

    dispsail[1].top.front().y() = dispsail[0].top.back().y();

    // panel 1
    for (k=1; k<flatsail[1].top.size()-1; k++) {
        double d = flatsail[2].bottom.back().y()-flatsail[2].bottom[centreIdx+k].y()
                +flatsail[1].top[k].y()-flatsail[1].top.back().y();
        flatsail[1].top[k] = CPoint3d(flatsail[1].top[k].x(), flatsail[1].top.back().y()+d*fraction, 0);
        flatsail[1].cutTop[k] = CPoint3d(flatsail[1].cutTop[k].x(), flatsail[1].cutTop.back().y()+d*fraction, 0);

        flatsail[2].bottom[centreIdx+k] = CPoint3d(flatsail[2].bottom[centreIdx+k].x(), flatsail[2].bottom.back().y()-d*fraction, 0);
        flatsail[2].cutBottom[centreIdx+k] = CPoint3d(flatsail[2].cutBottom[centreIdx+k].x(), flatsail[2].cutBottom[0].y()-d*fraction, 0);

    }

    flatsail[1].left = flatsail[1].left.trimAbove(flatsail[1].top.front().y());
    flatsail[1] = flatsail[1].reframe(LOW_LEFT);

    leftBottomPanel = flatsail[0];
    rightBottomPanel = flatsail[1];

    for (k=1; k<dispsail[1].top.size()-1; k++) {
        double d = dispsail[2].bottom.back().y()-dispsail[2].bottom[centreIdx+k].y()
                +dispsail[1].top[k].y()-dispsail[1].top.back().y();
        dispsail[1].top[k] = CPoint3d(dispsail[1].top[k].x(), dispsail[1].top.back().y()+d*fraction, 0);
        dispsail[1].cutTop[k] = CPoint3d(dispsail[1].cutTop[k].x(), dispsail[1].cutTop.back().y()+d*fraction, 0);

        dispsail[2].bottom[centreIdx+k] = CPoint3d(dispsail[2].bottom[centreIdx+k].x(), dispsail[2].bottom.back().y()-d*fraction, 0);
        dispsail[2].cutBottom[centreIdx+k] = CPoint3d(dispsail[2].cutBottom[centreIdx+k].x(), dispsail[2].cutBottom.back().y()-d*fraction, 0);

    }

    dispsail[1].left = dispsail[1].left.trimAbove(dispsail[1].top.front().y());
    dispsail[1] = dispsail[1].reframe(LOW_LEFT);

    // fix sizes
    double d0 = leftBottomPanel.top.arcLength();
    double d1 = (flatsail[2].bottom.arcLength()) / 2;
    double scale = d1/d0;

    leftBottomPanel = leftBottomPanel.scaleTopLeftInX(scale);
    rightBottomPanel = rightBottomPanel.scaleTopRightInX(scale);
    dispsail[0] = dispsail[0].scaleTopLeftInX(scale);
    dispsail[1] = dispsail[1].scaleTopRightInX(scale);

    // ----------- create radial panels from leftBottomPanel and rightBottomPanel
    CPanelGroup leftRadialGroup, rightRadialGroup, leftRadialDispGroup, rightRadialDispGroup;
    leftRadialGroup.clear();
    rightRadialGroup.clear();
    leftRadialDispGroup.clear();
    rightRadialDispGroup.clear();

    CSide rightSide = leftBottomPanel.left.reverse();

    unsigned int leftIdx=0, rightIdx;

    CPoint3d leftCornerPoint = leftBottomPanel.bottom.front();
    //CPoint3d pBottomEnd = leftBottomPanel.left.back();
    CPoint3d p, pRight;

    for (unsigned int i=0; i < topLeftPoints.size();i++) {
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.panelType = (i == 0) ? PANEL_RADIAL_SPINNAKER_LUFF : PANEL_RADIAL_SPINNAKER;
        pnl.right = rightSide;
        double d = topLeftPoints[i];
        rightIdx = leftBottomPanel.top.nearestPointIndex(d);
        pRight = leftBottomPanel.top[rightIdx];
        pnl.left.clear();
        for (unsigned int j=leftIdx; j<=rightIdx; j++) {
            pnl.left.push_back(leftBottomPanel.top[j]);
        }
        pnl.bottom.resize(3);
        pnl.bottom.fill(pnl.left.front(), pnl.left.front());
        pnl.top.fill(pRight, leftCornerPoint);
        pnl.addHems(seamW, seamW, 0, 0);
        leftRadialGroup.push_back(pnl);
        leftRadialDispGroup.push_back(CPanel(pnl));
        leftIdx = rightIdx;
        rightSide = pnl.top;
    }

    if (leftIdx > leftBottomPanel.top.size()-2) {
        throw layout_error("gore hits too close to centre line.");
    }

    // bridging gore
    bridgePnl = CPanel(radialBottomSize, radialBottomSize);
    bridgePnl.panelType = PANEL_RADIAL_SPINNAKER;
    bridgePnl.right = rightSide;
    p = pRight;
    rightIdx = leftBottomPanel.right.nearestPointIndex(midPoints.back());
    pRight = leftBottomPanel.right[rightIdx];
    bridgePnl.left.clear();
    for (unsigned int j=rightIdx; j<leftBottomPanel.right.size(); j++) {
        bridgePnl.left.insert(bridgePnl.left.begin(), leftBottomPanel.right[j]);
    }
    bridgePnl.bottom.clear();
    for (unsigned int j=leftIdx; j<leftBottomPanel.top.size(); j++) {
        bridgePnl.bottom.insert(bridgePnl.bottom.begin(), leftBottomPanel.top[j]);
    }
    bridgePnl.bPrintBottom = true;
    bridgePnl.bottomSeam = bridgePnl.bottom;
    bridgePnl.top.fill(pRight, leftCornerPoint);
    bridgePnl.addHems(seamW, seamW, 0, seamW);
    leftIdx = rightIdx;
    rightSide = bridgePnl.top;

    leftRadialGroup.push_back(bridgePnl);
    leftRadialDispGroup.push_back(CPanel(bridgePnl));

    // mid gores

    for (unsigned int i=1; i <= midPoints.size();i++) {
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.right = rightSide;
        if ((i == (midPoints.size()))) {
            p = leftBottomPanel.bottom.back();
            rightIdx = 0;
        } else {
            double d = midPoints[midPoints.size()-1-i];
            rightIdx = leftBottomPanel.right.nearestPointIndex(d);
        }
        pRight = leftBottomPanel.right[rightIdx];
        pnl.left.clear();
        for (unsigned int j=rightIdx; j<=leftIdx; j++) {
            pnl.left.insert(pnl.left.begin(), leftBottomPanel.right[j]);
        }
        pnl.bottom.resize(3);
        pnl.bottom.fill(pnl.left.front(), pnl.left.front());
        if ((i == (midPoints.size()))) {
            pnl.panelType = PANEL_RADIAL_SPINNAKER_FOOT_LEFT;
            pnl.top.clear();
            for (unsigned int j=0; j<leftBottomPanel.bottom.size(); j++) {
                pnl.top.insert(pnl.top.begin(), leftBottomPanel.bottom[j]);
            }
            pnl.bPrintTop = false;
            pnl.addHems(seamW, 0, 0, 0);
        } else {
            pnl.panelType = PANEL_RADIAL_SPINNAKER;
            pnl.top.fill(pRight, leftCornerPoint);
            pnl.addHems(seamW, seamW, 0, 0);
        }
//        cout << pnl << endl;
        leftRadialGroup.push_back(pnl);
        leftRadialDispGroup.push_back(CPanel(pnl));
        leftIdx = rightIdx;
        rightSide = pnl.top;
    }

    // ---------------------- right radial gores
    double xDiff = leftBottomPanel.bottom.back().x()-rightBottomPanel.bottom.front().x();
    rightBottomPanel = rightBottomPanel + CVector3d(xDiff, 0, 0);
    dispsail[1] = rightBottomPanel;

    CPoint3d rightCornerPoint = rightBottomPanel.right.front();

    //mid points
    rightSide = rightBottomPanel.bottom;

    for (unsigned int i=0; i < midPoints.size();i++) {
        CPanel pnl =  CPanel(radialBottomSize, radialBottomSize);
        pnl.right = rightSide;

        if (i == 0) {
            p = rightBottomPanel.left.front();
            leftIdx = 0;
        } else {
            double d = midPoints[i-1];
            leftIdx = rightBottomPanel.left.nearestPointIndex(d);
        }
        rightIdx = rightBottomPanel.left.nearestPointIndex(midPoints[i]);
        pnl.left.clear();
        for (unsigned int j=leftIdx; j<=rightIdx; j++) {
            pnl.left.push_back(rightBottomPanel.left[j]);
        }
        pRight = pnl.left.back();
        pnl.bottom.resize(3);
        pnl.bottom.fill(pnl.left.front(), pnl.left.front());
        pnl.top.fill(pRight, rightCornerPoint);
        if (i == 0) {
            pnl.panelType = PANEL_RADIA_SPINNAKERL_FOOT_RIGHT;
        } else {
            pnl.panelType = PANEL_RADIAL_SPINNAKER;
        }
        pnl.addHems(0, seamW, 0, 0);
        //cout << pnl << endl;
        rightRadialGroup.push_back(pnl);
        rightRadialDispGroup.push_back(CPanel(pnl));
        rightSide = pnl.top;

    }

    // right bridging gore
    bridgePnl = CPanel(radialBottomSize, radialBottomSize);
    bridgePnl.panelType = PANEL_RADIAL_SPINNAKER_MITRE;
    bridgePnl.right = rightSide;
    CC = topRightPoints.back();
    rightIdx = rightBottomPanel.top.nearestPointIndex(1-CC);
    p = rightBottomPanel.top[rightIdx];
    CC = midPoints.back();
    leftIdx = rightBottomPanel.left.nearestPointIndex(CC);
    bridgePnl.bottom.clear();
    for (unsigned int i=rightBottomPanel.left.size()-1; i>= leftIdx; i--) {
        bridgePnl.bottom.push_back(rightBottomPanel.left[i]);
    }
    bridgePnl.bPrintBottom = false;
    bridgePnl.left.clear();
    for (unsigned int i=0; i<= rightIdx; i++) {
        bridgePnl.left.push_back(rightBottomPanel.top[i]);
    }
    bridgePnl.top.fill(p, rightCornerPoint);
    bridgePnl.addHems(seamW, seamW, 0, seamW);
    rightRadialGroup.push_back(bridgePnl);
    rightRadialDispGroup.push_back(CPanel(bridgePnl));

    rightSide = bridgePnl.top;
    leftIdx = rightIdx;

    for (unsigned int i=1; i<=topRightPoints.size(); i++) {
        CPanel pnl = CPanel(radialBottomSize, radialBottomSize);
        if (i== topRightPoints.size()) {
            pnl.panelType = PANEL_RADIAL_SPINNAKER_LEECH;
            pnl.bPrintTop = false;
            rightIdx = rightBottomPanel.top.size()-1;
        } else {
            pnl.panelType = PANEL_RADIAL_SPINNAKER;
            double d = topRightPoints[topRightPoints.size()-1-i];
            rightIdx = rightBottomPanel.top.nearestPointIndex(1-d);
        }
        pnl.left.clear();
        for (unsigned int i=leftIdx; i<= rightIdx; i++) {
            pnl.left.push_back(rightBottomPanel.top[i]);
        }
        pnl.right = rightSide;
        pnl.bottom.resize(3);
        pnl.bottom.fill(pnl.right.front(), pnl.right.front());
        if (i== topRightPoints.size()) {
            pnl.top = rightBottomPanel.right.reverse();
            pnl.addHems(seamW, 0, 0, 0);
        } else {
            p = rightBottomPanel.top[rightIdx];
            pnl.top.fill(p, rightCornerPoint);
            pnl.addHems(seamW, seamW, 0, 0);
        }
        //cout << pnl << endl;
        rightRadialGroup.push_back(pnl);
        rightRadialDispGroup.push_back(CPanel(pnl));
        leftIdx = rightIdx;
        rightSide = pnl.top;
    }

    // ------------------------------
    // rotate radial panels and move to desired locations
    real xPoint = dispsail[0].top.front().x();

    for (unsigned int i=0; i<leftRadialGroup.size(); i++) {
        leftRadialGroup[i] = leftRadialGroup[i].alignTop().reframe(LOW_LEFT);
        leftRadialGroup[i].bPrintLeft = true;
    }

    for (unsigned int i=0; i<rightRadialGroup.size(); i++) {
        rightRadialGroup[i] = rightRadialGroup[i].alignTop().reframe(LOW_LEFT);
        rightRadialGroup[i].bPrintLeft = true;
    }

    for (unsigned int i=0; i<leftRadialDispGroup.size(); i++) {
        leftRadialDispGroup[i] = leftRadialDispGroup[i].alignTop().reframe(LOW_LEFT);
    }

    CRect3d rLeftDisp = leftRadialDispGroup.maxBoundingRect();
    double leftXMove = xPoint-2.2*rLeftDisp.width();

    for (unsigned int i=0; i<leftRadialDispGroup.size(); i++) {
        unsigned int i2= leftRadialDispGroup.size()-1-i;
        leftRadialDispGroup[i] = leftRadialDispGroup[i]
                + CVector3d(leftXMove, i2*rLeftDisp.height(), 0);
    }

    for (unsigned int i=0; i<rightRadialDispGroup.size(); i++) {
        rightRadialDispGroup[i] = rightRadialDispGroup[i].alignTop().reframe(LOW_LEFT);
    }

    CRect3d rRightDisp = rightRadialDispGroup.maxBoundingRect();
    double rightXMove = xPoint-1.1*rRightDisp.width();

    for (unsigned int i=0; i<rightRadialDispGroup.size(); i++) {
        unsigned int i2= rightRadialDispGroup.size()-1-i;
        rightRadialDispGroup[i] = rightRadialDispGroup[i]
                + CVector3d(rightXMove, i2*rRightDisp.height(), 0);
    }


    // remove temporary panels
    flatsail.erase(flatsail.begin());
    flatsail.erase(flatsail.begin());
    dispsail.erase(dispsail.begin());
    dispsail.erase(dispsail.begin());

    flatsail.prepend(rightRadialGroup);
    flatsail.prepend(leftRadialGroup);
    dispsail.prepend((rightRadialDispGroup));
    dispsail.prepend((leftRadialDispGroup));

    // ----------- arrange dispsail panels for viewing
    dispsail.push_back(leftBottomPanel);
    dispsail.push_back(rightBottomPanel);

    for (j = leftRadialDispGroup.size() + rightRadialDispGroup.size() ; j < dispsail.size() ; j++)
    {
        CRect3d topBB = dispsail[j-1].boundingRect();
        CRect3d botBB = dispsail[j].boundingRect();
        top = CPoint3d(topBB.min.x(), topBB.max.y(), 0);
        bot = botBB.min;
        real botX = dispsail[j].bottom.front().x();

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = CVector3d ( top - CPoint3d(0,0,0) );
        v.x() = xPoint - botX;
        v.y() = v.y()  + 2 * seamW +20; // adding offset to separate panels vertically

//        cout << "j = " << j << ", xPoint = " << xPoint << ", botX = " << botX << ", v.x() = " << v.x() << endl;
        dispsail[j] = dispsail[j] + v;

        xPoint = dispsail[j].top.front().x();
    }

    // cambers
    calculateSailCambers();

    // broadseam info
    aBroadseamInfo = calculateBroadseams(flatsail);

    return sail;
}


/**
 * @brief CSailWorker::flattenSail
 * @param flatsail
 * @return
 */
CPanelGroup CSailWorker::flattenSail(CPanelGroup &flatsail) const {
    CPanelGroup ret;
    ret.clear();

    ret.push_back(flatsail[0].splitLeft(0,0));

    for (unsigned int i=1; i<flatsail.size(); i++) {
        CPanel panel = flatsail[i].splitLeft(0,0);

        CPoint3d p = ret[i-1].top.front();
        CPoint3d p1 = panel.bottom.front();

        CPanel panel2 = panel+CVector3d(p-p1);

        real a = (ret[i-1].top.back().x() - ret[i-1].top.front().x()) /
                (ret[i-1].top.back().y() - ret[i-1].top.front().y());
        real angle1 = atan(a);

        real b = (panel2.bottom.back().x() - panel2.bottom.front().x()) /
                (panel2.bottom.back().y() - panel2.bottom.front().y());
        real angle2 = atan(b);

        panel2 = panel2.rotate(p,CMatrix::rot3d(2,PI+angle2-angle1) );

        ret.push_back(panel2);
    }

    CPoint3d pBottom = ret.front().bottom.front();
    CPoint3d pTop = ret.back().top.front();

    real t = (pTop.x()-pBottom.x()) / (pTop.y() - pBottom.y());
    real angle = atan(t);

    return ret.rotate(pBottom,CMatrix::rot3d(2,angle) );
}

/**
 * @brief CSailWorker::layoutSymetricalSpinnakerClewPatch
 * @param patchSize
 * @return
 */
CPanel CSailWorker::layoutSymetricalSpinnakerClewPatch(real patchSize, enumPatchType patchType) const {
    CPanel p;
    p.panelType = PANEL_PATCH;
    p.patchType = patchType;
    p.right.clear();
    p.cutRight.clear();

    // calculate foot point
    CPoint3d p1 = tack+footV*((footV.norm()-patchSize) / footV.norm());
    CPoint3d pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);

    real lFoot = (pFoot-clew).norm();
    while (abs((pFoot-clew).norm() - patchSize) > .1) {
        real diff = 0.5*((pFoot-clew).norm()-patchSize);
        lFoot -= diff;
        p1 = tack+footV*((footV.norm()-lFoot) / footV.norm());
        pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);
    }

    // calculate leech point
    CPoint3d p2 = clew + leechV*((patchSize) / leechV.norm());
    CPoint3d pLeechIntersect = EdgeIntersect(LEECH_EDGE, p2, leechVP);
    CPoint3d pLeech = Zpoint(pLeechIntersect);

    real lLeech = (pLeech-clew).norm();
    while (abs((pLeech-clew).norm() - patchSize) > .1) {
        real diff = 0.5*((pLeech-clew).norm()-patchSize);
        lLeech -= diff;
        p2 = clew + leechV*((lLeech) / leechV.norm());
        pLeech = Zpoint(EdgeIntersect(LEECH_EDGE, p2, leechVP));
    }

    CSide footSide;
    footSide.clear();
    CSide leechSide;
    leechSide.clear();

    real d3dDist = calculate3dDistance(pFoot, pLeech, ZPSC_FOOT);

    // calculate clew angle
    real a = (pLeech-pFoot).norm();
    real b = (clew - pFoot).norm();
    real c = (pLeech-clew).norm();

    if ((d3dDist >= (b+c))/* && luffOffset == 0*/) {
        throw layout_error("layoutSymetricalSpinnakerClewPatch: Can't calculate clew angle. Likely cause is foot camber is too deep.");
    }

    real startAngle = Atriangle(a,b,c);
    real clewAngle = Atriangle(d3dDist,b,c);
    real arc = patchSize * clewAngle;

    unsigned int arcPoints = floor(arc / 10);

    unsigned int footLeechPoints = floor(patchSize / 10); // a point about every 10mm

    // foot points
    footSide.clear();
    footSide.push_back(pFoot);
    for (unsigned int i = 1 ; i<footLeechPoints; i++) {
        real fraction = lFoot * real(i) / real(footLeechPoints);
        p1 = tack+footV*((footV.norm()-patchSize+fraction) / footV.norm());
        footSide.push_back(EdgeIntersect(FOOT_EDGE, p1, footVP));
    }
    footSide.push_back(clew);

    // now rotate foot side
    footSide = footSide.rotate(clew, CMatrix::rot3d(2,(clewAngle-startAngle)));
    pFoot = footSide.front();
    CSide curvedSide;
    curvedSide.clear();
    CSide s;
    s.clear();
    s.push_back(pFoot);
    s.push_back(clew);

    curvedSide.push_back(pFoot);

    for (unsigned int i=1; i<= arcPoints; i++) {
        real rotateAngle = clewAngle * (real(i) / real(arcPoints));
        CSide s1 = s.rotate(clew, CMatrix::rot3d(2,-rotateAngle));
        curvedSide.push_back(s1.front());
    }

    // leech points
    leechSide.clear();
    leechSide.push_back(clew);

    for (unsigned int i = 1 ; i<arcPoints; i++) {
        real fraction = lLeech * real(i) / real(arcPoints);
        p2 = clew + leechV*((fraction) / leechV.norm());
        leechSide.push_back(Zpoint(EdgeIntersect(LEECH_EDGE, p2, leechVP)));
    }

    // terminate leech with same point as calculated
    // for curve
    leechSide.push_back(pLeech);

    // rotate leech side to z=0
    a = leechSide.back().y()-clew.y();
    b = leechSide.back().z()-clew.z();

    real leechAngle = atan(b/a);
    CSide leechSide2 = leechSide.rotate(clew, CMatrix::rot3d(0, -leechAngle));

    for (unsigned int i=0; i<leechSide.size(); i++) {
        leechSide2[i] = CPoint3d(leechSide2[i].x(), leechSide2[i].y(), 0);
    }
    leechSide = leechSide2;
    curvedSide.push_back(leechSide.back());

    // print dimensions
    cout << "pFoot to pLeech = " << (pFoot-pLeech).norm() << ", pFoot to clew = " << (pFoot-clew).norm() << ", pLeech to clew = " << (pLeech - clew).norm() << endl;
    p.bottom = footSide;
    p.right = leechSide;
    p.left = curvedSide;
    p.top.fill(p.left.back(), p.right.back());

    CPanel pDev = p.reframe(LOW_LEFT);
    pDev.cutBottom = pDev.bottom;
    pDev.bottomSeam = pDev.bottom;
    pDev.cutLeft = pDev.left;
    pDev.cutRight = pDev.right;
    pDev.cutTop = pDev.top;
    pDev.luffTape = pDev.left;
    pDev.hasHems = true;
    pDev.bPrintFootTape = pDev.bPrintLuffTape = pDev.bPrintTop = pDev.bPrintBottom = false;

    return pDev;
}

/**
 * @brief CSailWorker::layoutSymetricalSpinnakerHeadPatch
 * @param patchSize
 * @return
 */
CPanel CSailWorker::layoutSymetricalSpinnakerHeadPatch(real patchSize, enumPatchType patchType) const {
    CPanel p;
    p.panelType = PANEL_PATCH;
    p.patchType = patchType;

    p.right.clear();
    p.cutRight.clear();

    // calculate luff point
    CPoint3d p1 = topFront-luffV*(patchSize / luffV.norm());
    CPoint3d pLuff = Zpoint(EdgeIntersect(LUFF_EDGE, p1, luffVP));

    real lLuff = (pLuff-topFront).norm();
    while (abs((pLuff-topFront).norm() - patchSize) > .1) {
        real diff = 0.5*((pLuff-topFront).norm()-patchSize);
        lLuff -= diff;
        p1 = topFront-luffV*(lLuff / luffV.norm());
        pLuff = Zpoint(EdgeIntersect(LUFF_EDGE, p1, luffVP));
        //cout << "pLuff-top = " << (pLuff-topFront).norm() << endl;
    }

    // calculate leech point
    CPoint3d p2 = topBack - leechV*((patchSize) / leechV.norm());
    CPoint3d pLeech = Zpoint(EdgeIntersect(LEECH_EDGE, p2, leechVP));

    real lLeech = (pLeech-topBack).norm();
    while (abs((pLeech-topBack).norm() - patchSize) > .1) {
        real diff = 0.5*((pLeech-topBack).norm()-patchSize);
        lLeech -= diff;
        p2 = topBack - leechV*(lLeech / leechV.norm());
        pLeech = Zpoint(EdgeIntersect(LEECH_EDGE, p2, leechVP));
    }

    CSide luffSide;
    luffSide.clear();
    CSide leechSide;
    leechSide.clear();

    CPoint3d pTop = topFront + 0.5 * (topBack - topFront);


    unsigned int luffLeechPoints = floor(patchSize / 10); // a point about every 10mm

    // luff points
    CVector3d vLuff = topFront - pLuff;

    luffSide.push_back(pLuff);
    for (unsigned int i = 1 ; i<luffLeechPoints; i++) {
        real fraction = patchSize * real(i) / real(luffLeechPoints);
        p1 = pLuff+vLuff*((vLuff.norm()-patchSize+fraction) / vLuff.norm());
        luffSide.push_back(Zpoint(EdgeIntersect(LUFF_EDGE, p1, luffVP)));
    }
    luffSide.push_back(topFront);

    // leech points
    CVector3d vLeech = topBack - pLeech;

    leechSide.push_back(pLeech);

    for (unsigned int i = 1 ; i<luffLeechPoints; i++) {
        real fraction = patchSize * real(i) / real(luffLeechPoints);
        p2 = pLeech+vLeech*((vLeech.norm()-patchSize+fraction) / vLeech.norm());
        leechSide.push_back(Zpoint(EdgeIntersect(LEECH_EDGE, p2, leechVP)));
    }
    leechSide.push_back(topBack);

    CPoint3d pMid = pLuff + (pLeech-pLuff) *0.5;
    CPoint3d pMidZ = Zpoint(pMid);
    real scale = (pTop-pMidZ).norm() / (pTop-pMid).norm();
    real l = patchSize*scale;
    real x = (pMid-pLuff).norm();
    real h = sqrt(l*l - x*x);

    pTop = CPoint3d(pTop.x(), pMid.y()+h, 0);

    // calculate head angle
    real a = (pLeech-pLuff).norm();
    real b = (pTop - pLuff).norm();
    real c = (pTop-pLeech).norm();

    real headAngle = Atriangle(a,b,c);
    real arc = patchSize * headAngle;

    unsigned int arcPoints = floor(arc / 10);

    CSide bottomSide;
    bottomSide.clear();
    CSide s;
    s.clear();
    s.push_back(pLuff);
    s.push_back(pTop);

    bottomSide.push_back(pLuff);

    for (unsigned int i=1; i< arcPoints; i++) {
        real rotateAngle = headAngle * (real(i) / real(arcPoints));
        CSide s1 = s.rotate(pTop, CMatrix::rot3d(2,rotateAngle));
        bottomSide.push_back(s1.front());
    }

    bottomSide.push_back(pLeech);

    p.left = luffSide;
    p.right = leechSide;
    p.bottom = bottomSide;
    p.top.resize(bottomSide.size());
    p.top.fill(p.left.back(), p.right.back());

    CPanel pDev = Zpanel(p);
    pDev = pDev.develop(ALIGN_BOTTOM);
    pDev.cutBottom = pDev.bottom;
    pDev.cutLeft = pDev.left;
    pDev.luffTape = pDev.left;
    pDev.hasHems = true;
    pDev.bPrintFootTape = pDev.bPrintLuffTape = pDev.bPrintTop = pDev.bPrintBottom = false;

    pDev.cutRight = pDev.right;
    pDev.cutTop = pDev.top;

    return pDev;

}

CPanelGroup CSailWorker::layoutRadialClewPatches(int numGores, real patchSize, real baseDimension, real seamW) const {
    CPanelGroup pg;
cout << numGores << patchSize << baseDimension << seamW << endl;
    return pg;
}

/**
 *  Creates a Cross-cut sail with an additional bottom panel
 *  allowing more fullness close to the boom
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 *
 * @author Paula Thomas
 */
CPanelGroup CSailWorker::LayoutCross2( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round)
    *   p1[] are on the luff side and p2[] are on the leech side
    */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS);  // 3D sail
    CPanelGroup dev(MAX_PANELS);  // developed sail

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();   // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0;
    bool bTopPanel = false;  // to check if top of sail is reached

    bool bProcessLeechTurn = clothAlignsWithLeech ? true : false;
/*
    CPoint3d pz1 = CPoint3d(1000, 100, 0);
    CPoint3d pz2 = CPoint3d(500, 70, 0);
    CPoint3d pz3 = CPoint3d(1500, 150, 0);
    cout << "distance3d 1 =" << Distance3d(pz1, pz2, pz3) << endl;;
    pz2.y() = 150;
    pz3.y() = 70;
    cout << "distance3d 2 =" << Distance3d(pz1, pz2, pz3) << endl;
    pz2.y() = 70;
    cout << "distance3d 3 =" << Distance3d(pz1, pz2, pz3) << endl;
 */

    /* create arrays t1 and t2 of type of intersection of upper seam
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip, ip2;

	CVector3d lV = LowerLeechVector();
	CVector3d seamV = CMatrix::rot3d(2, PI/2) * lV.unit();;  // for classical cross cut
    CSubSpace seamL; // seam Line
    CVector3d seamV2; // seam Line
    CSubSpace seamL2; // seam Line

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    CVector3d leechVTop = CVector3d(peak - leechTurnPoint);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    //for (int i=30; i<101; i+=5) {
    //    CProfile p = mould.interpol2(real(i)/100, 1000);
    //    cout << "i = " << i << " phsyDepth = " << p.physicalDepth() << endl;
    //}

    real CC = 0, x = 0, y = 0;

    real tackIntersect = SpeedSeamLuffPoint(), clewIntersect = SpeedSeamLeechPoint();
    unsigned int panelWidth[MAX_PANELS];
    unsigned int headPanelStartNo = MAX_PANELS + 1;

    getSplits(panelWidth, generateSpeedSeam, filletPanelWidth, speedPanelWidth);

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialise seam forward end at tack point
    p2[0] = clew; // initialise seam aft end at clew point
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

    /** Lay the panels starting from the foot, going upward to the peak */

    /** calculate batten positions */
    cout << "calculating batten data" << endl;
    CalculateBattenPositions();

    reefPointsList.clear();
    for (unsigned int i = 0 ; i< this->patches.size(); i++) {
        Patch patch = this->patches[i];
        switch (patch.patchType) {
        case PATCH_MAINSAIL_REEF1:
        case PATCH_MAINSAIL_REEF2:
            reefPointsList.push_back(calculateReefPoint(patch));
            break;

        default:
            break;
        }
    }
/*
    CPoint3d pTest = clew+leechV*.15;
    CPoint3d pTestL = CPoint3d(pTest.x()-100, pTest.y(), 0);
    CPoint3d pTestR = CPoint3d(pTest.x()+10, pTest.y(), 0);
    CPoint3d pTest2 = EdgeIntersect(LEECH_EDGE, pTest, leechVP);
    CPoint3d pTest3L = AftIntersect(pTestL);
    CPoint3d pTest3 = AftIntersect(pTest);
    CPoint3d pTest3R = AftIntersect(pTestR);
    cout << "Left = " << pTest3L << ", Centre = " << pTest3 << ", Right = " << pTest3R << endl;
*/
    // maxY is used to detect top of sail
    real maxY = max(topFront.y(), topBack.y());

    unsigned int footPanels = LayoutCross2Foot(p1, p2, lay, dev, deviation, deviaPrev);
    t1[footPanels] = 2;

    for (npanel = footPanels +1 ; npanel < MAX_PANELS -1 ; npanel++)
    {
        real exc = 0; // current excess of width
        real exb = 0; // total correction
        cnt = 0; // counter of iterations

        //enumPanelType panelType = PANEL_CROSS_CUT;

        do  /* Loop for optimising the seam position to fit cloth width */
        {
            //if (p2[3].y() > 1 &&( p2[3].y()-p2[2].y()) <1200) {
            //    cout << "TRACE 0 : P2 changed! npanel = " << npanel << " dist = " << (p2[3].y()-p2[2].y()) << endl;
            //} else {
            //    cout << "TRACE 0 : P2 OK npanel = " << npanel << " dist = " << (p2[3].y()-p2[2].y()) << endl;
            //}
            cnt++;
			int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
            //cout << "npanel = " << npanel << " cw = " << cw << endl;
            if (npanel == 1) {
                p2[npanel] = p2[npanel-1] + lV.unit() * clewIntersect;
			} else if (npanel == 2) {
				real broadseamAllowance = sailType == MAINSAIL ? footL * 30 / 1000 : footL * 15 / 1000;
	            p2[npanel] = p2[npanel-1] + lV.unit() * (cw - seamW * 4 - exb - dev[0].cutTop[npb-1].y() - broadseamAllowance);
	            seamL = CSubSpace3d::line( p2[npanel] , seamV );
	            ip = seamL.intersect(luffLine).getp();
        		if ( ip.y() < (tack.y()+tackIntersect+seamW) ) {
    	            p2[npanel] = p2[npanel-1] + lV.unit() * (cw - seamW - exb - footHemW);
        		}
			} else {
				CVector3d v = lV;
                if (npanel >= headPanelStartNo) {
	            	// recalculate seam vector to align between peak and leech turn point
                    v = CVector3d(peak - leechTurnPoint);
                    if (npanel > headPanelStartNo)
                        seamV = CMatrix::rot3d(2, PI/2) * v.unit();
                    cout << "recalculating seam vector: peak =" << peak << ", leechhTurnPoint =" << leechTurnPoint << ", seamV =" << seamV << endl;
	            }

                cout << "npanel = " << npanel << "  v.unit() = " << v.unit() << "  cw = " << cw << "  seamW = " << seamW << "  exb = " << exb << endl;
	            p2[npanel] = p2[npanel-1] + v.unit() * (cw - seamW - exb);
                cout << "  p2[npanel] = " << p2[npanel] << "     p2[npanel-1] =  " << p2[npanel-1] << endl;
	            // leech turn point
	            if (bProcessLeechTurn && CVector3d( p2[npanel] - leechTurnPoint ) * leechVTop > 0) {
	            	p2[npanel] = leechTurnPoint;

	            	if (radialHead) {
	            		// set width of next panel to very high value
	            		panelWidth[npanel] = luffL;
                    } //else {
	            		// make note of panel which is 1st head panel
	            		// this will be current panel + 1
	            		headPanelStartNo = npanel + 1;
                    //}

	            	bProcessLeechTurn = false; // so we don't execute this block again
	            }
                //cout << "p2[npanel] = " << p2[npanel] <<  "p2[npanel-1] = " << p2[npanel-1] << " cw = " << cw << " seamW = " << seamW << " exb = " << exb<< endl;

			}

            //if (p2[3].y() > 1 &&( p2[3].y()-p2[2].y()) <1200) {
                //cout << "TRACE 1 : P2 changed! npanel = " << npanel << " dist = " << (p2[3].y()-p2[2].y()) << endl;
            //} else {
                //cout << "TRACE 1 : P2 OK npanel = " << npanel << " dist = " << (p2[3].y()-p2[2].y()) << endl;
            //}

            //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line( p2[npanel] , seamV );

            // For a jib, topBack is lower than topFront.
            // In this case we need to test that seam isn't dropping between the two.
            // Might also happen for mainsails especially gaff mainsails with a top width.
            if ((topBack.y() < topFront.y()) && (p2[npanel].y() >= topBack.y()) && (p2[npanel].y() <= topFront.y())) {
                //; throw exception if seam lies between the two
                throw layout_error("Top of panel lies between topFront and topBack");
            }

            //if ( CVector3d( p2[npanel] - peak ) * leechV > 0 )
            if (p2[npanel].y() > maxY)
            {   // we are above peak, stop this is last panel
                //cout << "npanel = " << npanel << "top of sail detected" << endl;
                bTopPanel = true;
                p2[npanel] = peak;
                // check on which side of the sail the previous point p1 is located
                if ( t1[npanel-1] < 2 )
                { // previous seam on foot
                    p1[npanel] = head;
                    t1[npanel] = 2; // set on luff
                    // left points on foot-tack-luff
                    lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                    for (k = 0 ; k < npl / 2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k] , seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
                }
                else if ( t1[npanel-1] == 2 )
                { // left points on luff
                    cout << "top of sail detected_ luff intersect" << endl;
                    p1[npanel] = head;
                    t1[npanel] = 2;
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
//                    cout << "Last panel : bottom left " << lay[npanel-1].left[0] << "   seamV =" << seamV << endl;
//                    cout << "Last panel : p1[npanel] = " << p1[npanel] <<  "p1[npanel-1] = " << p1[npanel-1]<< endl;
                }
                else
                { // left points on gaff
//                	cout << "top of sail detected: gaff intersect" << endl;
                    p1[npanel] = topFront;//p1[npanel-1];
                    t1[npanel] = 3;
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                }

                // fill right points on leech
                lay[npanel-1].right.fill(p2[npanel-1],topBack);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k]=EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);

                // fill bottom points
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);


                // move all top points of top panel to gaff curve
                //for (k = 1 ; k < lay[npanel -1].left.size() -1 ; k++)
                //    lay[npanel -1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], CVector3d (head.y()-peak.y(),peak.x()-head.x(),0));

                // fill top  points
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

                if (isGaffSail) {
                    lay[npanel-1].panelType = PANEL_GAFF_TOP;
                }
                // end peak panel //
            }
            else   // normal panel below peak //////
            {
            	if (npanel == 1) {
            		p1[npanel] = CPoint3d(tack.x(), tack.y() + tackIntersect, tack.z());
        			t1[npanel] = 2;  // 2 = luff

            		p1[0] = tack;
            		t1[0] = 2;
                    seamV2 = CVector3d( p1[npanel] - p2[npanel] ).unit();
                    seamL2 = CSubSpace3d::line( p1[npanel] , seamV );
                    seamL = CSubSpace3d::line(p2[npanel] , seamV2);
                    ip = seamL.intersect(luffLine).getp();
                    ip2 = seamL2.intersect(leechLine).getp();
            	} else {
            		/* find position of luff/seam intersection relative to tack and head */
                    if ( seamL.intersect(luffLine).getdim() == 0 ) {
            			ip = seamL.intersect(luffLine).getp();
                    } else {
                        throw layout_error("CSailWorker::LayoutCross2 -1 : intersection of seam and luff is not a point!");
                    }

                    cout << "npanel = " << npanel << ", ip-tack = " << (CVector3d( ip - tack ) * luffV)
                                       << ", ip - head = " << (CVector3d(ip- head) * luffV) << endl;
            		if ( CVector3d( ip - tack ) * luffV <= 0 )
            		{   // seam intersects foot
                        if ( seamL.intersect(footLine).getdim() == 0 ) {
            				p1[npanel] = seamL.intersect(footLine).getp();
                        } else {
                            throw layout_error("CSailWorker::LayoutCross2 -2 : intersection of seam and foot is not a point!");
                        }
            			t1[npanel] =1;  // type1=1 = foot type of intersection

            			if ( npanel == 1 )
            			{   // set lower edge to start at same point p1
            				p1[0] = p1[npanel];
            				t1[0] = 1;
            			}
            		}
            		else if ( CVector3d(ip- head) * luffV > 0 )
            		{   // seam intersects gaff
                        if ( seamL.intersect(gaffLine).getdim() == 0 ) {
            				p1[npanel] = seamL.intersect(gaffLine).getp();
                        } else {
                            throw layout_error("CSailWorker::LayoutCross2 -3 : intersection of seam and foot is not a point!");
                        }
            			t1[npanel] = 3;  // 3 = gaff type of intersection

                    }
            		else
            		{   // seam intersects luff
            			p1[npanel] = ip;
            			t1[npanel] = 2;  // 2 = luff
            		}
            	}
                cout << "t1[npanel] = " << t1[npanel] << ", t1[npanel-1] = " << t1[npanel-1]
                     << ", p1[npanel] = " << p1[npanel] << ", p1[npanel-1] = " << p1[npanel-1] << endl;
                /* We now add the intermediate points on all sides of the normal panel */

                /* Below is the code for the left side depending
                *  on t1 for the top side and bottom side
                */
                if ( t1[npanel-1] == 1  &&  t1[npanel] == 1 )
                {   // full foot
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                }
                else if ( t1[npanel-1] == 2  &&  t1[npanel] == 2 )
                {   // full luff
                	lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                	for (k = 0 ; k < npl ; k++) {

                		if (npanel == 1) {
                			lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV2);
                		} else {
                			lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
                		}
                	}
                }
                else if ( t1[npanel-1] == 3  &&  t1[npanel] == 3 )
                {   // full gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k] , seamV);
                }
                else if ( (t1[npanel-1] == 1) && (t1[npanel] == 2) )
                {   // foot-tack-luff
                    lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                    for (k = 0 ; k < npl / 2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                }
                else if ( (t1[npanel-1] == 2) && (t1[npanel] == 3) )
                {   // luff-head-gaff
                    if (isGaffSail
                            && (lay[npanel-1].left.front().y() <= throat.y())
                            && (lay[npanel-1].left.back().y() >= throat.y())) {
                         lay[npanel-1].throatPoint = throat;
                        lay[npanel-1].panelType = PANEL_GAFF_THROAT;
                    }
                    lay[npanel-1].left.fill(p1[npanel-1], head, p1[npanel]);
                    for (k = 0 ; k < npl/2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                } // end IF ELSE for left side

                /* Below is the code for the intermediate points of the right side
                *  which are all on the leech for a crosscut layout.
                */
                // first check if upper point is not below lower point
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * lV < 0)
                    p2[npanel] = p2[npanel-1];

                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                //if ((npanel-1) == 3) {
                //    cout << "npanel = " << (npanel-1) << " before EdgeIntersect right = " << lay[npanel-1].right << endl;
                //}
                for (k = 0 ; k < npl ; k++) {
                    //if (k==13 || k==14) bTrace = true;
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);
                    //bTrace=false;
                }
                //if ((npanel-1) == 3) {
                //    cout << "npanel = " << (npanel-1) << " after EdgeIntersect right = " << lay[npanel-1].right << endl;
                //}

                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
                lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

                /* Below is the code for the intermediate points of the bottom side of first panel  */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    for (k = 1 ; k < npb -1 ; k++)
                    {
                        lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
                    }
                }
#ifdef DEBUG
                if ( npanel == 1 )
                {
                    cout << "CSailWorker::Layout0 Crosscut foot after adding curve" << endl;
                    for (k = 0 ; k < npb ; k++)
                        cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;
                }
#endif
            }  /* end else normal panel */

            /** Go over all the points of current panel and calculate their Z */
//            if ((npanel-1) == 3) {
//                cout << "npanel = " << (npanel-1) << " befrore zpanel right = " << lay[npanel-1].right << endl;
//            }
            lay[npanel-1] = Zpanel(lay[npanel-1]);


#ifdef DEBUG
            if ( npanel == 1 )
            { // move bottom side of first panel to foot curve
                cout << "CSailWorker::Layout0 Crosscut foot after Z " << endl;
                for (k = 0 ; k < npb ; k++)
                    cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;

                cout << "---end Z foot----   DO LOOP=" << cnt << endl;
            }
#endif

            /** map batten positions against panels */
            mapBattensToPanel(npanel-1, battenGroup, lay[npanel-1]);

            /** map reef points */
            mapReefPointsToPanel(reefPointsList, lay[npanel-1]);

            /** Develop the current panel */
            if ( npanel == 1 ) {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);

            }
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);

                // add deviation of previous panel top edge to bottom edge
                for (k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /**  Compute and store the deviation of top edge of
            *   the developed panel and straighten this top edge
            *   except if this is the top panel
            */
            if ( bTopPanel == false ) {
                vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb -1 ; k ++)
                {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v= vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            //cout << " hemsW = " << hemsW << endl;
            //cout << " footHemW = " << footHemW << endl;
            //cout << " luffHemW = " << luffHemW << endl;

            // merge any batten points into right and cut right sides
            if (dev[npanel-1].aftBattenPoints.size() > 0) {
//                cout << "merging panel " << (npanel-1) << endl;
//                if ((npanel-1) == 3) {
//                    cout << "right before " << lay[npanel-1].right << endl;
//                }
                dev[npanel-1].right = dev[npanel-1].mergePoints(dev[npanel-1].right, dev[npanel-1].aftBattenPoints);
//                dev[npanel-1].cutRight = dev[npanel-1].mergePoints(dev[npanel-1].cutRight, dev[npanel-1].aftBattenHemPoints);
//                cout << "npanel = " << (npanel-1) << "  right = " << dev[npanel-1].right << endl;
            }

            /** Add the seam and hems allowance */
            if ( npanel == 1 ) {
                //cout << " Adding Seams: npanel = 1" << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, footHemW );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, false);
            }
            else if ( bTopPanel == true ) {
                //cout << " Adding Seams: flag = true" << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 ) {
                    //cout << " Adding Seams: npanel = 1 and t1 = 2" << endl;
                    dev[npanel-1].add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, true);
                } else {
                    //cout << " Adding Seams: default npanel = "<< npanel << endl;
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
                }
            }


            if (npanel < 3) {

                // rotate panel
                bot = dev[npanel-1].bottom[0];

                real a, b, c;
                a = luffV.norm() - tackIntersect - seamW;
                b = lV.norm()  - clewIntersect - seamW;
                c = sqrt( pow((p2[1].x()-p1[1].x()), 2)
                		+ pow((p2[1].y()-p1[1].y()), 2) );

                // calculate angle
                real cosAngle = (b*b+c*c-a*a) / (2*b*c);
                real angle = acos(cosAngle);

                CC = PI / 2 - angle;
                dev[npanel-1] = dev[npanel-1].rotate(bot,CMatrix::rot3d(2,CC*-1));
            }

            /* Check the width of developed panel and store the excess */
            CRect3d rect = dev[npanel-1].boundingRect();
            exc = dev[npanel-1].boundingRect().height() - cw;
            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0  &&  cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;



        /** Reposition the developed panel such that the
        *  lowest point is Y=0 AND most left point is X=0.
        */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        //cout << "End for " << npanel << endl;
        /* check if peak has been reached to break off */
        if ( bTopPanel == true )
            break;
    }  /** Loop FOR next panel */

    if ( npanel == MAX_PANELS-1 )
        throw layout_error("CSailWorker::LayoutCross2 : MAX_PANELS without reaching head, do increase cloth width ");

    // set flag in topmost panel
    dev[npanel-1].bPrintTop = false;


    /* Copy the sails for 3D display */
    CPanelGroup sail(npanel);

    for (j = 0 ; j < npanel ; j ++) {
        sail[j] = lay[j];
    }

    /** Create the displays version of the developed sail  */

    /* Copy the developed sail */
    flatsail = CPanelGroup(npanel);

    for (j = 0 ; j < npanel ; j++)
    {
        flatsail[j] = (j < footPanels) || (j == npanel - 1) ? dev[j]: dev[j].alignTop();
    }

    // adjust panel tops and bottoms
    cout << "Adjusting panel widths" << endl;
    for (j = 0 ; j < npanel - 1 ; j++) {
            double dTop = flatsail[j].top.arcLength();
            double dBottom = flatsail[j+1].bottom.arcLength();
            cout << "j = " << j << ", sail[j] top = " << sail[j].top.arcLength() << endl;
            cout << "      sail[j+1] bottom = " << sail[j+1].bottom.arcLength() << endl;
            cout << "      dTop = " << dTop << ", dBottom =  " << dBottom << endl;
            double targetWidth = sail[j].top.arcLength();

            double topScale = targetWidth / flatsail[j].top.arcLength();
            flatsail[j] = flatsail[j].scaleTopRightInX(topScale);

            while (abs(targetWidth - dBottom) > 0.1) {
                double bottomScale = targetWidth / flatsail[j+1].bottom.arcLength();
                flatsail[j+1] = flatsail[j+1].scaleBottomRightInX(bottomScale);
                dBottom = flatsail[j+1].bottom.arcLength();
            }
            cout << "j = " << j << " top = " << flatsail[j].top.arcLength() << ", bottom = " << flatsail[j+1].bottom.arcLength() << endl;
            //cout << "      dTop = " << dTop << ", dBottom =  " << dBottom << endl;
    }
    cout << "Done" << endl;

    /* Re-position the developed panels in a clean stack */
    dispsail = flatsail;
    for (j = 1 ; j < npanel ; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // rotation to align bottom of panel to top of previous panel
        x = dispsail[j-1].top[npb-1].x() - top.x();
        y = dispsail[j-1].top[npb-1].y() - top.y();
        CC = atan2(y , x);
        if (j > footPanels) {
            dispsail[j] = dispsail[j].rotate(bot,CMatrix::rot3d(2,CC));
        }
        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = CVector3d ( top - CPoint3d(0,0,0) );
        v.x() = v.x() - bot.x();
        v.y() = v.y() + 2 * seamW +20; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;

        //mapBattensToPanel(j, battenGroup, dispsail[j]);
        dispsail[j].aftBattenPoints.clear();
    }

    cout << " sail size pre patches = " << sail.size() << endl;

    // patches
    layoutPatches(sail, flatsail);

    cout << " sail size post patches = " << sail.size() << endl;

    // windows
    if (window1.generate) {
        sail.push_back(layoutSailWindow(sail, &window1));
    }

    if (window2.generate) {
        sail.push_back(layoutSailWindow(sail, &window2));
    }

    // calculate luff and leech points at various heights
    calculateSailCambers();

    /*
    for (size_t i=0; i<npanel; i++) {
        CPanel p = sail[i];
        if (p.aftBattenPoints.size() > 0) {
            for (size_t j=0; j<p.aftBattenPoints.size(); j++) {
                //cout << "Panel " << i << endl;
                //cout << "    batten point " << p.aftBattenPoints.at(j).point << endl;
                int battenId = p.aftBattenPoints.at(j).battenId;
                //cout << "    reference batten  " << battenGroup.getBatten(battenId).aftPoint << endl;
                //cout << "    distance to head = " << calculate3dDistance(head, p.aftBattenPoints.at(j).point) << endl;
            }
        }
    }
*/
    // broadseam info
    aBroadseamInfo = calculateBroadseams(flatsail);

    // lens foot
    if (lensFoot) {
        CPanel pnl = layoutLensFootPanel(flatsail[0]);
        flatsail.push_back(pnl);
    }

    return sail;
} /* end layout cross2 */

/**
 * @brief CSailWorker::layoutPatches
 * @param sail the displayed sail
 * @param flatsail the developed flat sail
 */
void CSailWorker::layoutPatches( CPanelGroup &sail, CPanelGroup &flatsail ) const {
    for (unsigned int i = 0 ; i< patches.size(); i++) {
        Patch patch = patches[i];
        switch (patch.patchType) {
        case PATCH_MAINSAIL_HEAD: {
            CPanel pnl = layoutMainsailHeadPatch(patch.dimension1, patch.dimension1, patch.patchType);
            sail.push_back(pnl);
            flatsail.push_back(developBlockHeadPatch(pnl));

            bool bTest;
            vector<int> vUnderpatches = SplitsToInts(patch.underPatches, bTest);
            if (bTest == false) {
                throw layout_error("LayoutCross2: Invalid value in underpatches list for mainsail head patch");
            }

            for (unsigned int j=0; j< vUnderpatches.size(); j++) {
                int patchSize = real(vUnderpatches[j]);
                pnl = layoutMainsailHeadPatch(patchSize, patchSize, PATCH_MAINSAIL_HEAD_UNDERPATCH);
                sail.push_back(pnl);
                flatsail.push_back(developBlockHeadPatch(pnl));
            }
            break;
        }
        case PATCH_MAINSAIL_CLEW:
        case PATCH_MAINSAIL_REEF1:
        case PATCH_MAINSAIL_REEF2:
        {
            CPanel pnl = layoutMainsailClewFanPatch(patch);
            sail.push_back(pnl);
            flatsail.push_back(developMainsailClewFanPatch(pnl, patch));
            break;
        }
        case PATCH_MAINSAIL_TACK: {
            CPanel pnl = layoutMainsailTackPatch(patch.dimension1, patch.dimension2, patch.patchType);
            sail.push_back(pnl);
            flatsail.push_back(developBlockTackPatch(pnl));
            bool bTest;
            vector<int> vUnderpatches = SplitsToInts(patch.underPatches, bTest);
            if (bTest == false) {
                throw layout_error("LayoutCross2: Invalid value in underpatches list for mainsail head patch");
            }

            for (unsigned int j=0; j< vUnderpatches.size(); j++) {
                int patchSize = real(vUnderpatches[j]);
                pnl = layoutMainsailTackPatch(patchSize, patch.dimension2 - (patch.dimension1-patchSize), PATCH_MAINSAIL_TACK_UNDERPATCH);
                sail.push_back(pnl);
                flatsail.push_back(developBlockTackPatch(pnl));
            }

            // hack for gaff mainsail throat patch
            if (isGaffSail) {
                // generate a throat patch
                // values are calculated rather than input

                // set patch radius to average gaff length and luff length / 10
                real throatPatchLength = (gaffL+luffL)/20;
                CPanel pnl = layoutThroatPatch(throatPatchLength, PATCH_MAINSAIL_THROAT);
                sail.push_back(pnl);
                flatsail.push_back(developThroatPatch(pnl));

                // create same number of underpatches as tack has
                real midPoint = 0.5; // defines innermost patch size relativ to outer patch
                real step = (1-midPoint) / vUnderpatches.size() * throatPatchLength; // the amount to move in for each underpatch
                for (unsigned int j=0; j< vUnderpatches.size(); j++) {
                    int patchSize = throatPatchLength - (j+1) * step;

                    CPanel pnl = layoutThroatPatch(patchSize, PATCH_MAINSAIL_THROAT_UNDERPATCH);
                    sail.push_back(pnl);
                    flatsail.push_back(developThroatPatch(pnl));

                }
            }
            break;
        }

        case PATCH_JIB_HEAD: {
            CPanel pnl = layoutJibHeadPatch(patch.dimension1, patch.patchType);
            sail.push_back(pnl);
            flatsail.push_back(developBlockHeadPatch(pnl));

            bool bTest;
            vector<int> vUnderpatches = SplitsToInts(patch.underPatches, bTest);
            if (bTest == false) {
                throw layout_error("LayoutCross2: Invalid value in underpatches list for jib head patch");
            }

            for (unsigned int j=0; j< vUnderpatches.size(); j++) {
                int patchSize = real(vUnderpatches[j]);
                pnl = layoutJibHeadPatch(patchSize, PATCH_MAINSAIL_HEAD_UNDERPATCH);
                sail.push_back(pnl);
                flatsail.push_back(developBlockHeadPatch(pnl));
            }
            break;
        }
        case PATCH_JIB_CLEW: {
            CPanel pnl = layoutJibClewFanPatch(patch);
            sail.push_back(pnl);
            flatsail.push_back(developMainsailClewFanPatch(pnl, patch));
            break;
        }
        case PATCH_JIB_TACK: {
            CPanel pnl = layoutJibTackPatch(patch.dimension1, patch.patchType);
            sail.push_back(pnl);
            flatsail.push_back(developBlockTackPatch(pnl));

            bool bTest;
            vector<int> vUnderpatches = SplitsToInts(patch.underPatches, bTest);
            if (bTest == false) {
                throw layout_error("LayoutCross2: Invalid value in underpatches list for jib tack patch");
            }

            for (unsigned int j=0; j< vUnderpatches.size(); j++) {
                int patchSize = real(vUnderpatches[j]);
                pnl = layoutJibTackPatch(patchSize, PATCH_JIB_TACK_UNDERPATCH);
                sail.push_back(pnl);
                flatsail.push_back(developBlockTackPatch(pnl));
            }
            break;
        }
        default:
            break;
        }
    }

}

/**
 * @brief CSailWorker::layoutMainsailHeadPatch
 * @param luffDimension length of patch along luff
 * @param leechDimension length of patch along leech
 * @param patchType patch type
 * @return an undeveloped CPanel
 */
CPanel CSailWorker::layoutMainsailHeadPatch(int luffDimension, int leechDimension, enumPatchType patchType) const {
    CPanel panel;
    panel.patchType = patchType;
    panel.panelType = PANEL_PATCH;
    panel.right.clear();
    panel.left.clear();
    panel.top.clear();
    panel.bottom.clear();
    CVector3d leftV = isGaffSail ? gaffV : luffV;

    unsigned int np = floor(leechDimension / 10);

    CPoint3d pLeech = topBack - leechV * (leechDimension / leechV.norm());
    pLeech = EdgeIntersect(LEECH_EDGE, pLeech, leechVP, true);

    CPoint3d pLuff = topFront - leftV * (luffDimension / leftV.norm());
    pLuff = FwdIntersect(pLuff);

    CVector3d bottomV = pLeech-pLuff;
    CVector3d topV = topBack - topFront;
    leftV = topFront - pLuff;
    CVector3d rightV = topBack - pLeech;
    CPoint3d p1;

    // top points
    panel.top.push_back(topFront);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = topFront + fraction * topV;
        panel.top.push_back(p1);
    }
    panel.top.push_back(topBack);

    // bottom points
    panel.bottom.push_back(pLuff);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLuff + fraction * bottomV;
        panel.bottom.push_back(p1);
    }
    panel.bottom.push_back(pLeech);

    // left side
    panel.left.push_back(pLuff);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLuff + fraction * leftV;
        panel.left.push_back(FwdIntersect(p1));
    }
    panel.left.push_back(topFront);

    // right side
    panel.right.push_back(pLeech);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLeech + fraction * rightV;
        panel.right.push_back(EdgeIntersect(LEECH_EDGE , p1, leechVP, true));
    }
    panel.right.push_back(topBack);

    panel = Zpanel(panel);

    //cout << "head patch left " << panel.left << endl;
    //cout << "head patch bottom " << panel.bottom << endl;

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    return panel;
}

/**
 * @brief CSailWorker::layoutJibHeadPatch
 * @param leechDimension
 * @param patchType
 * @return
 */
CPanel CSailWorker::layoutJibHeadPatch(int leechDimension, enumPatchType patchType) const {
    CPanel panel;
    panel.patchType = patchType;
    panel.panelType = PANEL_PATCH;
    panel.right.clear();
    panel.left.clear();
    panel.top.clear();
    panel.bottom.clear();

    unsigned int np = floor(leechDimension / 10);

    CPoint3d pLeech = topBack - leechV * (leechDimension / leechV.norm());

    CPoint3d pLuff = EdgeIntersect(LUFF_EDGE, pLeech, leechVP);
    pLeech = EdgeIntersect(LEECH_EDGE, pLeech, leechVP);

    CVector3d bottomV = pLeech-pLuff;
    CVector3d topV = topBack - topFront;
    CVector3d leftV = topFront - pLuff;
    CVector3d rightV = topBack - pLeech;
    CPoint3d p1;

    // top points
    panel.top.push_back(topFront);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = topFront + fraction * topV;
        panel.top.push_back(p1);
    }
    panel.top.push_back(topBack);

    // bottom points
    panel.bottom.push_back(pLuff);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLuff + fraction * bottomV;
        panel.bottom.push_back(p1);
    }
    panel.bottom.push_back(pLeech);

    // left side
    panel.left.push_back(pLuff);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLuff + fraction * leftV;
        panel.left.push_back(FwdIntersect(p1));
    }
    panel.left.push_back(topFront);

    // right side
    panel.right.push_back(pLeech);
    for (unsigned int i = 1 ; i<np; i++) {
        real fraction = real(i) / real(np);
        p1 = pLeech + fraction * rightV;
        panel.right.push_back(EdgeIntersect(LEECH_EDGE , p1, leechVP));
    }
    panel.right.push_back(topBack);

    panel = Zpanel(panel);

    //cout << "head patch left " << panel.left << endl;
    //cout << "head patch bottom " << panel.bottom << endl;

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    return panel;
}

/**
 * @brief CSailWorker::layoutMainsailClewFanPatch
 * @param patchData
 * @return
 */
CPanel CSailWorker::layoutMainsailClewFanPatch(Patch patchData) const {
    if (patchData.dimension2 <= patchData.baseDimension) {
        return layoutPartialFanPatch(patchData);
    } else {
        CPanel panel;
        panel.panelType = PANEL_PATCH;
        panel.patchType = patchData.patchType;
        panel.right.clear();
        panel.cutRight.clear();
        unsigned int nSidePoints = patchData.numSections*10+1;
        CPoint3d bottomLeft, bottomRight;
        real lFoot;

        //enumZpanelSupressCalc bFoot = (panel.patchType == PATCH_MAINSAIL_CLEW && footEdgeAtZeroZ) ? ZPSC_FOOT : ZPSC_NONE;

        if (panel.patchType == PATCH_MAINSAIL_CLEW || panel.patchType == PATCH_JIB_CLEW) {
            bottomRight = clew;

            // calculate foot point
            CPoint3d p1 = tack+footV*((footV.norm()-patchData.dimension2) / footV.norm());
            CPoint3d pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);

            lFoot = (pFoot-clew).norm();
            while (abs((pFoot-clew).norm() - patchData.dimension2) > .1) {
                real diff = 0.5*((pFoot-clew).norm()-patchData.dimension2);
                lFoot -= diff;
                p1 = tack+footV*((footV.norm()-lFoot) / footV.norm());
                pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);
            }
            bottomLeft = pFoot;
        } else { // should be a reef point
            struct reefPoint rp = calculateReefPoint(patchData);

            bottomRight = rp.leechReefPoint;
            cout << "bottomRight = " << bottomRight << endl;

            // calculate foot point
            bottomLeft = bottomRight-footV*(patchData.dimension2 / footV.norm());

            lFoot = (bottomLeft-bottomRight).norm();
        }

        // calculate leech point
        CPoint3d p2 = bottomRight + leechV*((patchData.dimension1) / leechV.norm());
        CPoint3d pLeech = EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL);

        real lLeech = (pLeech-bottomRight).norm();
        while (abs((pLeech-bottomRight).norm() - patchData.dimension1) > .1) {
            real diff = 0.5*((pLeech-bottomRight).norm()-patchData.dimension1);
            lLeech -= diff;
            p2 = bottomRight + leechV*((lLeech) / leechV.norm());
            pLeech = EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL);
        }

        CSide footSide;
        footSide.clear();
        CSide leechSide;
        leechSide.clear();

        // foot points
        if (panel.patchType == PATCH_MAINSAIL_CLEW) {
            footSide.clear();
            footSide.push_back(bottomLeft);
            for (unsigned int i = 1 ; i<20; i++) {
                real fraction = lFoot * real(i) / real(20);
                CPoint3d p1 = tack+footV*((footV.norm()-patchData.dimension2+fraction) / footV.norm());
                footSide.push_back(EdgeIntersect(FOOT_EDGE, p1, footVP));
            }
            footSide.push_back(clew);
        } else {
            footSide.resize(nSidePoints);

            footSide.fill(bottomLeft, bottomRight);

        }
        // leech points
        leechSide.push_back(bottomRight);
        for (unsigned int i = 1 ; i<nSidePoints; i++) {
            real fraction = lLeech * real(i) / real(nSidePoints);
            p2 = bottomRight + leechV*((fraction) / leechV.norm());
            leechSide.push_back(EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL));
        }

        leechSide.push_back(pLeech);

        // left size
        CVector3d v = bottomLeft - bottomRight;
        CSide s;
        s.resize(2);
        s[0] = bottomRight;

        panel.left.resize(nSidePoints);

        // calculate foot/leect angle
        real a = (pLeech - bottomLeft).norm();
        real b = (pLeech - bottomRight).norm();
        real c = (bottomLeft - bottomRight).norm();
        real angle = Atriangle(a, b, c);

        int startIdx = 0;

        real d = 0.3 * (b-c) *  real(patchData.numSections-1) /  real(patchData.numSections);

        CPoint3d startPoint = bottomLeft;

        for (int i=1 ; i<patchData.numSections; i++) {
            real rotAngle = angle * real(i) / real(patchData.numSections);
            real dist = c + (b-c) * (real(i) / real(patchData.numSections));
            if (i > 1) {
                dist += d * real(i-1) / real(patchData.numSections - 1);
            }
    //        real dist = c + (b-c) * (1-pow(real(patchData.numSections-i) / real(patchData.numSections), 2));
            s[1] = bottomRight + v * (dist / v.norm());
            cout << "i = " << i << ", rotAngle = " << rotAngle << ", dist = " << dist << ", point = " << s[1] << endl;
            CSide s1 = s.rotate(bottomRight, CMatrix::rot3d(2,-rotAngle));
            cout << "rotated angle = " << s1[1] << endl;
            panel.left.fill(startPoint, s1[1], startIdx, 11);
            startIdx += 10;
            startPoint = s1[1];
        }
        panel.left.fill(startPoint, pLeech, startIdx, 11);

        panel.top.resize(footSide.size());
        panel.top.fill(pLeech, pLeech);
        panel.bottom = footSide;
        panel.right = leechSide;

        switch (patchData.patchType) {
        case PATCH_MAINSAIL_REEF1:
        case PATCH_MAINSAIL_REEF2:
            panel = Zpanel(panel, ZPSC_NONE);
            break;
        default:
            panel = Zpanel(panel, footEdgeAtZeroZ ? ZPSC_FOOT : ZPSC_NONE);
        }

        panel.cutBottom = panel.bottom;
        panel.bottomSeam = panel.bottom;
        panel.cutLeft = panel.left;
        panel.cutRight = panel.right;
        panel.cutTop = panel.top;
        panel.luffTape = panel.left;
        panel.hasHems = false;
        panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

        return panel;
    }
}

/**
 * @brief CSailWorker::layoutMainsailTackPatch
 * @param height taken from patch dimension1 or underpatches
 * @param width taken from patch dimension2 or calculated
 * @param patchType
 * @return
 */
CPanel CSailWorker::layoutMainsailTackPatch(int height, int width, enumPatchType patchType) const {
    CPanel panel;
    panel.panelType = PANEL_PATCH;
    panel.patchType = patchType;
    panel.right.clear();
    panel.cutRight.clear();
    unsigned int nSidePoints = 21;

    // calculate foot point
    CPoint3d p1 = tack+footV*(width / footV.norm());
    CPoint3d pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);

    real lFoot = (tack-pFoot).norm();
    while (abs((tack-pFoot).norm() - width) > .1) {
        real diff = 0.5*((tack-pFoot).norm()-width);
        lFoot -= diff;
        p1 = tack+footV*(lFoot / footV.norm());
        pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);
    }

    // calculate luff point
    CPoint3d p2 = tack + luffV*(height / luffV.norm());
    CPoint3d pLuff = EdgeIntersect(LUFF_EDGE, p2, luffVP);

    real lLuff = (pLuff-tack).norm();
    while (abs((pLuff-tack).norm() - height) > .1) {
        real diff = 0.5*((pLuff-tack).norm()-height);
        lLuff -= diff;
        p2 = tack + luffV*((lLuff) / luffV.norm());
        pLuff = EdgeIntersect(LUFF_EDGE, p2, luffVP);
    }


    // foot points
    panel.bottom.clear();
    panel.bottom.push_back(tack);
    for (unsigned int i = 1 ; i<nSidePoints-1; i++) {
        real fraction = real(i) / real(nSidePoints);
        p1 = tack+footV*((width*fraction) / footV.norm());
        panel.bottom.push_back(EdgeIntersect(FOOT_EDGE, p1, footVP));
    }
    panel.bottom.push_back(pFoot);


    // luff points
    panel.left.clear();
    panel.left.push_back(tack);
    for (unsigned int i = 1 ; i<nSidePoints-1; i++) {
        real fraction = lLuff * real(i) / real(nSidePoints);
        p2 = tack + luffV*((fraction) / luffV.norm());
        panel.left.push_back(EdgeIntersect(LUFF_EDGE, p2, luffVP));
    }

    panel.left.push_back(pLuff);

    // top right point
    CPoint3d pTopRight = pLuff+footV*(real(width-30)/footV.norm());

    // top
    panel.top.clear();
    panel.top.resize(panel.bottom.size());
    panel.top.fill(pLuff, pTopRight);

    // right
    panel.right.clear();
    panel.right.resize(panel.left.size());
    panel.right.fill(pFoot, pTopRight);

    panel = Zpanel(panel, footEdgeAtZeroZ ? ZPSC_FOOT : ZPSC_NONE);

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    return panel;
}

/**
 * @brief CSailWorker::layoutJibClewFanPatch
 * @param patchData
 * @return
 */
CPanel CSailWorker::layoutJibClewFanPatch(Patch patchData) const {
    return layoutMainsailClewFanPatch(patchData);

}

/**
 * @brief CSailWorker::layoutJibTackPatch
 * @param dimension
 * @param patchType
 * @return
 */
CPanel CSailWorker::layoutJibTackPatch(int dimension, enumPatchType patchType) const {
    CPanel panel;
    panel.panelType = PANEL_PATCH;
    panel.patchType = patchType;
    panel.right.clear();
    panel.cutRight.clear();
    unsigned int nSidePoints = 21;

    // calculate foot point
    CPoint3d p1 = tack+footV*(dimension / footV.norm());
    CPoint3d pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);

    real lFoot = (tack-pFoot).norm();
    while (abs((tack-pFoot).norm() - dimension) > .1) {
        real diff = 0.5*((tack-pFoot).norm()-dimension);
        lFoot -= diff;
        p1 = tack+footV*(lFoot / footV.norm());
        pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);
    }

    // calculate leech point
    CPoint3d p2 = tack + luffV*(dimension / luffV.norm());
    CPoint3d pLuff = EdgeIntersect(LUFF_EDGE, p2, luffVP);

    real lLuff = (pLuff-tack).norm();
    while (abs((pLuff-tack).norm() - dimension) > .1) {
        real diff = 0.5*((pLuff-tack).norm()-dimension);
        lLuff -= diff;
        p2 = tack + luffV*((lLuff) / luffV.norm());
        pLuff = EdgeIntersect(LUFF_EDGE, p2, luffVP);
    }


    // foot points
    panel.bottom.clear();
    panel.bottom.push_back(tack);
    for (unsigned int i = 1 ; i<nSidePoints-1; i++) {
        real fraction = real(i) / real(nSidePoints);
        p1 = tack+footV*((dimension*fraction) / footV.norm());
        panel.bottom.push_back(EdgeIntersect(FOOT_EDGE, p1, footVP));
    }
    panel.bottom.push_back(pFoot);


    // luff points
    panel.left.clear();
    panel.left.push_back(tack);
    for (unsigned int i = 1 ; i<nSidePoints-1; i++) {
        real fraction = lLuff * real(i) / real(nSidePoints);
        p2 = tack + luffV*((fraction) / luffV.norm());
        panel.left.push_back(EdgeIntersect(LUFF_EDGE, p2, luffVP));
    }

    panel.left.push_back(pLuff);

    // top
    panel.top.clear();
    for (unsigned int i = 0 ; i<nSidePoints; i++) {
        panel.top.push_back(pLuff);
    }

    // right
    panel.right.clear();
    CVector3d v = pLuff - pFoot;

    panel.right.push_back(pFoot);
    for (unsigned int i = 1 ; i<nSidePoints-1; i++) {
        real fraction = real(i) / real(nSidePoints);
        p2 = pFoot + v*(fraction * real(dimension) / v.norm());
        panel.right.push_back(p2);
    }

    panel.right.push_back(pLuff);

    panel = Zpanel(panel, footEdgeAtZeroZ ? ZPSC_FOOT : ZPSC_NONE);

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    return panel;

}

/**
 * @brief CSailWorker::developMainsailClewFanPatch
 * @param p
 * @param patchData
 * @return
 */
CPanel CSailWorker::developMainsailClewFanPatch(CPanel p, Patch patchData) const {
    CPanel panel = p.develop(ALIGN_NONE);
    panel = panel.reframe(LOW_LEFT);
    panel.cutBottom = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;

    return panel;
}

/**
 * @brief CSailWorker::developJibClewFanPatch
 * @param p
 * @param patchData
 * @return
 */
CPanel CSailWorker::developJibClewFanPatch(CPanel p, Patch patchData) const {
    CPanel panel = p.develop(ALIGN_NONE);
    panel = panel.reframe(LOW_LEFT);
    panel.cutBottom = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;

    return panel;
}

/**
 * @brief CSailWorker::developBlockHeadPatch
 * @param p
 * @return
 */
CPanel CSailWorker::developBlockHeadPatch(CPanel p) const {
    CPanel pnl = p.develop(ALIGN_NONE);

    real x = topBack.x() - topFront.x();
    real y = topBack.y() - topFront.y();
    real patchAngle = atan2(y , x);

    x = clew.x() - topBack.x();
    y = topBack.y() - clew.y();
    real leechAngle = atan2(x , y);

    pnl = pnl.reframe(LOW_LEFT);

    x = pnl.top.back().x() - pnl.top.front().x();
    y = pnl.top.back().y() - pnl.top.front().y();
    real CC = patchAngle - atan2(y , x) - leechAngle;
    pnl = pnl.rotate(pnl.left.front(),CMatrix::rot3d(2,CC));

    pnl.cutBottom = pnl.bottom;
    pnl.cutLeft = pnl.left;
    pnl.cutRight = pnl.right;
    pnl.cutTop = pnl.top;

    return pnl;
}

/**
 * @brief CSailWorker::developBlockTackPatch
 * @param p
 * @return
 */
CPanel CSailWorker::developBlockTackPatch(CPanel p) const {
    CPanel pnl = p.develop(ALIGN_NONE);
    pnl = pnl.reframe(LOW_LEFT);

    pnl.cutBottom = pnl.bottom;
    pnl.cutLeft = pnl.left;
    pnl.cutRight = pnl.right;
    pnl.cutTop = pnl.top;

    return pnl;

}

/**
 * @brief CSailWorker::layoutPartialFanPatch
 * @param patchData
 * @return
 */
CPanel CSailWorker::layoutPartialFanPatch(Patch patchData) const {
    CPanel panel;
    panel.panelType = PANEL_PATCH;
    panel.patchType = patchData.patchType;
    CPoint3d bottomLeft, bottomRight;
    unsigned int nSidePoints = patchData.numSections*10+1;
    real lFoot;

    enumZpanelSupressCalc bFoot = (panel.patchType == PATCH_MAINSAIL_CLEW && footEdgeAtZeroZ) ? ZPSC_FOOT : ZPSC_NONE;

    if (panel.patchType == PATCH_MAINSAIL_CLEW) {
        bottomRight = clew;

        // calculate foot point
        CPoint3d p1 = tack+footV*((footV.norm()-patchData.baseDimension) / footV.norm());
        CPoint3d pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);

        lFoot = (pFoot-clew).norm();
        while (abs((pFoot-clew).norm() - patchData.baseDimension) > .1) {
            real diff = 0.5*((pFoot-clew).norm()-patchData.baseDimension);
            lFoot -= diff;
            p1 = tack+footV*((footV.norm()-lFoot) / footV.norm());
            pFoot = EdgeIntersect(FOOT_EDGE, p1, footVP);
        }

        bottomLeft = pFoot;
    } else { // should be a reef point
        struct reefPoint rp = calculateReefPoint(patchData);

        bottomRight = rp.leechReefPoint;

        // calculate foot point
        bottomLeft = bottomRight-footV*(patchData.baseDimension / footV.norm());

        lFoot = (bottomLeft-bottomRight).norm();
    }

    // calculate leech point
    CPoint3d p2 = bottomRight + leechV*((patchData.dimension1) / leechV.norm());
    CPoint3d pLeech = EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL);

    real lLeech = (pLeech-bottomRight).norm();
    while (abs((pLeech-bottomRight).norm() - patchData.dimension1) > .1) {
        real diff = 0.5*((pLeech-bottomRight).norm()-patchData.dimension1);
        lLeech -= diff;
        p2 = bottomRight + leechV*((lLeech) / leechV.norm());
        pLeech = EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL);
    }

    CSide footSide;
    CSide leechSide;
    leechSide.clear();

    // foot points
    if (panel.patchType == PATCH_MAINSAIL_CLEW) {
        footSide.clear();
        footSide.push_back(bottomLeft);
        for (unsigned int i = 1 ; i<nSidePoints; i++) {
            real fraction = lFoot * real(i) / real(nSidePoints);
            CPoint3d p1 = tack+footV*((footV.norm()-patchData.baseDimension+fraction) / footV.norm());
            footSide.push_back(EdgeIntersect(FOOT_EDGE, p1, footVP));
        }
        footSide.push_back(bottomRight);
    } else {
        footSide.resize(nSidePoints);

        footSide.fill(bottomLeft, bottomRight);
    }

    // leech points
    leechSide.push_back(bottomRight);
    for (unsigned int i = 1 ; i<nSidePoints; i++) {
        real fraction = lLeech * real(i) / real(nSidePoints);
        p2 = bottomRight + leechV*((fraction) / leechV.norm());
        leechSide.push_back(EdgeIntersect(LEECH_EDGE, p2, leechVP, sailType == MAINSAIL));
    }

    leechSide.push_back(pLeech);

    // left size
    CSide s;
    s.resize(2);
    s[0] = bottomRight;
    s[1] = bottomLeft;

    panel.top.resize(nSidePoints);

    // calculate foot/leect angle
    real a = (pLeech - bottomLeft).norm();
    real b = (pLeech - bottomRight).norm();
    real c = (bottomLeft - bottomRight).norm();
    real angle = Atriangle(a, b, c);
    // halve the angle
    angle /= 2.0;
    s = s.rotate(bottomRight, CMatrix::rot3d(2,-angle));
    CVector3d v = s[1] - s[0];
    s[1] = bottomRight + v * (patchData.dimension1 / v.norm());

    int startIdx = 0;
    CPoint3d startPoint = s[1];

    panel.left.resize(leechSide.size());
    panel.left.fill(bottomLeft, startPoint);

    for (int i=1 ; i<patchData.numSections; i++) {
        real rotAngle = angle * real(i) / real(patchData.numSections);
        CSide s1 = s.rotate(bottomRight, CMatrix::rot3d(2,-rotAngle));
        panel.top.fill(startPoint, s1[1], startIdx, 11);
        startIdx += 10;
        startPoint = s1[1];
    }
    panel.top.fill(startPoint, pLeech, startIdx, 11);

    panel.bottom = footSide;
    panel.right = leechSide;

    panel = Zpanel(panel, bFoot);

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;


    return panel;
}

/**
 * @brief CSailWorker::layoutThroatPatch
 * @param patchSize the radius of the patch
 * @param patchType the patch type
 * @return the 3d patch
 */
CPanel CSailWorker::layoutThroatPatch(int patchSize, enumPatchType patchType) const {
    CPanel p;
    p.panelType = PANEL_PATCH;
    p.patchType = patchType;
    p.right.clear();
    p.cutRight.clear();

    // calculate luff point
    CPoint3d p1 = tack+luffV*((luffV.norm()-patchSize) / luffV.norm());
    CPoint3d pLuff = EdgeIntersect(LUFF_EDGE, p1, luffVP);

    real lFoot = (pLuff-throat).norm();
    while (abs((pLuff-throat).norm() - patchSize) > .1) {
        real diff = 0.5*((pLuff-throat).norm()-patchSize);
        lFoot -= diff;
        p1 = tack+luffV*((luffV.norm()-lFoot) / luffV.norm());
        pLuff = EdgeIntersect(LUFF_EDGE, p1, luffVP);
    }

    // calculate gaff point
    CPoint3d p2 = throat + gaffV*((patchSize) / gaffV.norm());
    CPoint3d pGaffIntersect = EdgeIntersect(GAFF_EDGE, p2, gaffVP);
    CPoint3d pGaff = Zpoint(pGaffIntersect);

    real lGaff = (pGaff-throat).norm();
    while (abs((pGaff-throat).norm() - patchSize) > .1) {
        real diff = 0.5*((pGaff-throat).norm()-patchSize);
        lGaff -= diff;
        p2 = throat + gaffV*((lGaff) / gaffV.norm());
        pGaff = Zpoint(EdgeIntersect(GAFF_EDGE, p2, gaffVP));
    }

    CSide luffSide;
    luffSide.clear();
    CSide gaffSide;
    gaffSide.clear();

    //real d3dDist = calculate3dDistance(pLuff, pGaff);

    // calculate throat angle
    real a = (pGaff-pLuff).norm();
    real b = (throat - pLuff).norm();
    real c = (pGaff-throat).norm();

    real throatAngle = Atriangle(a,b,c);
    real arc = patchSize * throatAngle;

    unsigned int arcPoints = floor(arc / 10);

    unsigned int luffGaffPoints = floor(patchSize / 10); // a point about every 10mm

    // luff points
    luffSide.clear();
    luffSide.push_back(pLuff);
    for (unsigned int i = 1 ; i<luffGaffPoints; i++) {
        real fraction = lFoot * real(i) / real(luffGaffPoints);
        p1 = tack+luffV*((luffV.norm()-patchSize+fraction) / luffV.norm());
        luffSide.push_back(EdgeIntersect(LUFF_EDGE, p1, luffVP));
    }
    luffSide.push_back(throat);

    pLuff = luffSide.front();
    CSide curvedSide;
    curvedSide.clear();
    CSide s;
    s.clear();
    s.push_back(pLuff);
    s.push_back(throat);

    curvedSide.push_back(pLuff);

    for (unsigned int i=1; i<= arcPoints; i++) {
        real rotateAngle = throatAngle * (real(i) / real(arcPoints));
        CSide s1 = s.rotate(throat, CMatrix::rot3d(2,rotateAngle));
        curvedSide.push_back(s1.front());
    }

    // leech points
    gaffSide.clear();
    gaffSide.push_back(throat);

    for (unsigned int i = 1 ; i<arcPoints; i++) {
        real fraction = lGaff * real(i) / real(arcPoints);
        p2 = throat + gaffV*((fraction) / gaffV.norm());
        gaffSide.push_back(Zpoint(EdgeIntersect(GAFF_EDGE, p2, gaffVP)));
    }

    // terminate leech with same point as calculated
    // for curve
    gaffSide.push_back(pGaff);

    curvedSide.push_back(gaffSide.back());

    // print dimensions
    p.left = luffSide;
    p.right = gaffSide;
    p.bottom = curvedSide;
    p.top.resize(p.bottom.size());
    p.top.fill(throat, throat);

    CPanel panel = Zpanel(p);

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    return panel;
}

/**
 * @brief CSailWorker::developThroatPatch
 * @param p the input panel
 * @return the developed panel
 */
CPanel CSailWorker::developThroatPatch(CPanel p) const {
    CPanel pnl = p.develop(ALIGN_NONE);
    pnl = pnl.reframe(LOW_LEFT);

    pnl.cutBottom = pnl.bottom;
    pnl.cutLeft = pnl.left;
    pnl.cutRight = pnl.right;
    pnl.cutTop = pnl.top;

    return pnl;

}


/**
 * @brief CSailWorker::developPartialFanPatch
 * @param p
 * @param patchData
 * @return
 */
CPanel CSailWorker::developPartialFanPatch(CPanel p, Patch patchData) const {
    CPanel panel;

    return panel;
}

/**
 * @brief CSailWorker::layoutSailWindow
 * @param sail
 * @param sw
 * @return
 */
CPanel CSailWorker::layoutSailWindow(CPanelGroup sail,  SailWindow *sw) const {
    CPanel panel;
    panel.panelType = PANEL_WINDOW;

    CVector3d vPanelBottom = sail[sw->panelNo].bottom.back() - sail[sw->panelNo].bottom.front();

    CVector3d vPanelBottomP = CMatrix::rot3d(2, PI/2) * vPanelBottom.unit();

    CVector3d vWindowBottom;
    CVector3d vWindowBottomP;

    CPoint3d pBottomLeft, pBottomRight, pTopLeft, pTopRight;

    CPoint3d p = sail[sw->panelNo].bottom.front() + vPanelBottom.unit()*sw->xPos;
    pBottomLeft = p + vPanelBottomP.unit()*sw->yPos;

    switch (sw->alignment) {
    case SWA_TOP_SEAM:
    case SWA_LEECH_PERP:
        vWindowBottom = sail[sw->panelNo].top.back() - sail[sw->panelNo].top.front();
        vWindowBottomP = CMatrix::rot3d(2, PI/2) * vWindowBottom.unit();
        break;
    case SWA_FOOT:
        vWindowBottom = footV;
        vWindowBottomP = CMatrix::rot3d(2, PI/2) * vWindowBottom.unit();
        break;
    case SWA_HORIZONTAL: {
        CPoint3d ph1 = CPoint3d(0,0,0);
        CPoint3d ph2 = CPoint3d(100,0,0);
        vWindowBottom = ph2 - ph1;
        vWindowBottomP = CMatrix::rot3d(2, PI/2) * vWindowBottom.unit();
        break;
    }
    default:
        vWindowBottom = vPanelBottom;
        vWindowBottomP = vPanelBottomP;
        break;
    }

    pBottomRight = pBottomLeft + vWindowBottom.unit()*sw->width;
    pTopLeft = pBottomLeft + vWindowBottomP.unit()*sw->height;
    pTopRight = pBottomRight + vWindowBottomP.unit()*sw->height;

    panel.bottom.fill(pBottomLeft, pBottomRight);
    panel.left.fill(pBottomLeft, pTopLeft);
    panel.top.fill(pTopLeft, pTopRight);
    panel.right.fill(pBottomRight, pTopRight);

    panel = Zpanel(panel);

    panel.cutBottom = panel.bottom;
    panel.bottomSeam = panel.bottom;
    panel.cutLeft = panel.left;
    panel.cutRight = panel.right;
    panel.cutTop = panel.top;
    panel.luffTape = panel.left;
    panel.hasHems = false;
    panel.bPrintFootTape = panel.bPrintLuffTape = panel.bPrintTop = panel.bPrintRight = panel.bPrintBottom = false;

    sw->sailXpos = pBottomLeft.x() - tack.x();
    sw->sailYpos = pBottomLeft.y() - tack.y();
    sw->bottomLeftToLuff = int(0.5+abs(Distance3d(pBottomLeft, sail[sw->panelNo].left.front(), sail[sw->panelNo].left.back())));
    sw->topLeftToLuff = int(0.5+abs(Distance3d(pTopLeft, sail[sw->panelNo].left.front(), sail[sw->panelNo].left.back())));

    return panel;
}

/**
 * @brief CSailWorker::calculateReefPoint
 * @param patchData
 * @return
 */
struct reefPoint CSailWorker::calculateReefPoint(Patch patchData) const {
    struct reefPoint rp;

    // calcuate mid-point of foot
    CPoint3d pMidFoot = tack+footV*0.5;

    CPoint3d p = pMidFoot + footVP*real(patchData.leechHeight);
    rp.leechReefPoint = EdgeIntersect(LEECH_EDGE, p, footV, true);

    p = pMidFoot + footVP*real(patchData.luffHeight);
    rp.luffReefPoint = EdgeIntersect(LUFF_EDGE, p, footV);

    return rp;
}

/**
 * @brief CSailWorker::calculateBroadseams
 * @param flatsail
 * @return
 */
vector<broadseamInfo> CSailWorker::calculateBroadseams(CPanelGroup &flatsail) const {
     vector<broadseamInfo> info = vector<broadseamInfo>();

     for (unsigned int i=1; i<flatsail.size(); i++) {
         CPanel *currentPanel = &flatsail[i];
         if ((currentPanel->panelType != PANEL_PATCH) && !currentPanel->isRadialSpinnaker()) {
             int idxMax = int ( (currentPanel->bottom.size() -1) /2 );
             real delta = 0;
             int iStart = int ( (currentPanel->bottom.size() -1) *.3 );
             int iEnd = int ( (currentPanel->bottom.size() -1) /2 );
             double dy;

             for (int j=iStart; j<iEnd; j++) {
                 //dx = CVector3d(  currentPanel.bottom[i] -  currentPanel.bottom.front() ) * CVector3d(  currentPanel.bottom.back() -  currentPanel.bottom.front() ).unit();
                 dy = Distance3d( currentPanel->bottom[j] ,  currentPanel->bottom.front() ,  currentPanel->bottom.back() );

                 //cout << "dy = " << dy << " deltaMin = " << deltaMin << endl;
                 if ((dy < 0 && dy < delta) || (dy >0 && dy > delta)) {
                     delta = dy;
                     idxMax = j;
                 }
             }

             if (delta > 0) {
                 // only straighten if we are not on a curved speed seam panel
                if (!(i==1 && curvedSpeedSeam)) {
                    currentPanel->straightenBottom();
                }
                 delta = 0;
             }

             broadseamInfo *b = new broadseamInfo;
             b->delta = delta;
             b->index = idxMax;
             b->panelNo = i;
             b->percentage = abs(100.0 * delta / (currentPanel->bottom.back().x() - currentPanel->bottom.front().x()));
             info.push_back(*b);
         }
     }


     return info;

}

/**
 * @brief CSailWorker::calculateSailCambers
 * calculate sail camers at various heights
 * also generates camber stripes for wireframe display
 */
void CSailWorker::calculateSailCambers() const {
    double sailHeight = max(topFront.y(), topBack.y()) - tack.y();

    unsigned int j, k;
    real maxY = max(tack.y(), clew.y());
    CVector3d vHoz = CVector3d(-1, 0, 0);
    vector<CSide> vPoints;

    enumZpanelSupressCalc zpsc = (sailType == SYMMETRIC && luffOffset > 0) ? ZPSC_NONE : ZPSC_FOOT;

    camberStripes.clear();
    vPoints.clear();

    aCamberAtHeight[0].height = 0;
    aCamberAtHeight[0].baseCamber = mould.profile[0].getDepth()*100;
    aCamberAtHeight[0].combinedCamber = mould.profile[0].getDepth()*100;
    aCamberAtHeight[0].arcLength = calculate3dDistance(tack, clew);
    aCamberAtHeight[0].chordLength = distanceBetween(tack, clew);
    aCamberAtHeight[0].maxPos = mould.profile[0].getMaxPos()*100.0;
    aCamberAtHeight[0].baseCamberMM = int(0.5+aCamberAtHeight[0].baseCamber/100*aCamberAtHeight[0].chordLength);
    aCamberAtHeight[0].combinedCamberMM = int(0.5+aCamberAtHeight[0].combinedCamber/100*aCamberAtHeight[0].chordLength);
    aCamberAtHeight[0].sailHeight = sailHeight;

    CSide crossSection = CSide();
    crossSection.clear();
    CSide points;
    points.clear();
    crossSection.push_back(Zpoint(tack));

    for (k=1;k<NUM_TOP_BOTTOM_POINTS-1; k++) {
        CPoint3d p = tack + footV * (real(k)/real(NUM_TOP_BOTTOM_POINTS-1));
        crossSection.push_back(Zpoint(p));
        points.push_back(p);
    }

    crossSection.push_back(Zpoint(clew));

    camberStripes.push_back(crossSection);
    vPoints.push_back(points);

    // cross heights
    for (j=1; j<NUM_CAMBER_POINTS; j++) {
        real fraction = j / real(NUM_CAMBER_POINTS);
        // calculate intersect points
        CPoint3d pStart = tack;
        pStart.y() = tack.y() + (topFront.y() - tack.y()) * fraction;
        CPoint3d pFwd;
        CPoint3d pAft;
        CSubSpace subSpace = CSubSpace3d::line(pStart, vHoz);
        pFwd = subSpace.intersect(luffLine).getp();
        if (pFwd.y() > head.y()) {
            pFwd = subSpace.intersect(gaffLine).getp();
        }
        enumEdgeType edgeType;

        if (isGaffSail && pStart.y() > throat.y()) {
            edgeType = GAFF_EDGE;
        } else {
            edgeType = LUFF_EDGE;
        }

        CPoint3d pLuff = EdgeIntersect(edgeType, pFwd, vHoz);
        CPoint3d pLeech = EdgeIntersect(LEECH_EDGE, pStart, vHoz, true);

        CVector3d v = CVector3d( pLeech - pLuff );

        if (!((sailType == SYMMETRIC && luffOffset == 0) || sailCut == CROSS2)) {
            pFwd = Zpoint(pLuff);
            pAft = Zpoint(pLeech);
        } else {
            pFwd = pLuff;
            pAft = pLeech;
        }

        real achord =  v.norm();
        CProfile profile;
        if (interpolMethod == INTERPOL) {
            profile = mould.interpol(fraction);
        } else {
            profile = mould.interpol2(fraction, achord);
        }
        real baseCamber =  profile.getDepth()*100.0;
        aCamberAtHeight[j].height = fraction;
        aCamberAtHeight[j].baseCamber = baseCamber;
        aCamberAtHeight[j].combinedCamber = -1;
        aCamberAtHeight[j].maxPos = profile.getMaxPos()*100.0;
        real baseRatio = ratioFromDepth(baseCamber);

        if (pLuff.y() > maxY && pLeech.y() > maxY) {
            crossSection = CSide();
            crossSection.clear();
            points = CSide();
            points.clear();
            crossSection.push_back(pFwd);
            for (k=1;k<NUM_TOP_BOTTOM_POINTS-1; k++) {
                CPoint3d p = pLuff + v * (real(k)/real(NUM_TOP_BOTTOM_POINTS-1));
                CPoint3d zp = Zpoint(p, zpsc);

                crossSection.push_back(zp);
                points.push_back(p);
            }
            crossSection.push_back(pAft);
            camberStripes.push_back(crossSection);
            vPoints.push_back(points);
        }

        real chord = distanceBetween(pFwd, pAft);
        aCamberAtHeight[j].chordLength = chord;
        aCamberAtHeight[j].arcLength = calculate3dDistance(pFwd, pAft);

        // caclulate combined camber
        if (sailType == MAINSAIL) {
            CPoint3d p;
            if (isGaffSail) {
                if (pLuff.y() == throat.y()) {
                    p = throat;
                } else {
                    real luffFraction = (throat.y()-tack.y()) / (topFront.y()-tack.y());
                    if (pLuff.y() < throat.y()) {
                        p = tack + luffV*fraction * ( 1 / luffFraction);
                    } else {
                        p = throat + gaffV* ((fraction-luffFraction) / (1-luffFraction));
                    }
                }
            } else {
                p = tack + luffV*fraction;
            }
            // compute difference between arc and chord
            real diff = chord * baseRatio / 100.0;
            //
            diff += distanceBetween(pFwd, p);
            real combinedRatio = diff / chord * 100.0;
            aCamberAtHeight[j].combinedCamber = depthFromRatio(combinedRatio);
        } else {
            aCamberAtHeight[j].combinedCamber = baseCamber;
        }

        aCamberAtHeight[j].baseCamberMM = int(0.5+aCamberAtHeight[j].baseCamber/100*aCamberAtHeight[j].chordLength);
        aCamberAtHeight[j].combinedCamberMM = int(0.5+aCamberAtHeight[j].combinedCamber/100*aCamberAtHeight[j].chordLength);
        aCamberAtHeight[j].sailHeight = sailHeight;
    }

    // verticals
    unsigned int lStripes = camberStripes.size();

    for (unsigned int j=1; j<(NUM_CAMBER_POINTS/2); j++) {
        real fraction = j / real(NUM_CAMBER_POINTS/2);
        int idx = int (fraction * (NUM_TOP_BOTTOM_POINTS-1));

        CSide side = CSide();
        side.clear();
        CPoint3d p, p1, p2;
        CVector3d v;

        p = tack+footV*fraction;

        p1 = EdgeIntersect(FOOT_EDGE, p, footVP);
        if (!footEdgeAtZeroZ) {
            p1 = Zpoint(p1);
        }

        p2 = vPoints.at(0).at(idx-1);

        if (sailType == SYMMETRIC || sailCut == CROSS2 || sailCut == VERTICAL || sailCut == MITRE) {
            side.push_back((p1));
        } else {
            side.push_back(Zpoint(p1));
        }

        //v = p2 - p1;
        //for (unsigned int k=1; k<4; k++)  {
        //    CPoint3d p3 = p1 + v * (real(k)/4.0);
        //    side.push_back(Zpoint(p3));
        //}

        for (unsigned int i=0; i<lStripes; i++) {
            p1 = vPoints.at(i).at(idx-1);
            if (i < lStripes - 1) {
                p2 = vPoints.at(i+1).at(idx-1);
            } else {
                if (topV.norm() == 0) {
                    p2 = topFront;
                } else {
                    p2 = topFront + topV * fraction;
                }
            }

            side.push_back(Zpoint(p1));
            v = p2 - p1;
            for (unsigned int k=1; k<4; k++)  {
                CPoint3d p3 = p1 + v * (real(k)/4.0);
                side.push_back(Zpoint(p3));
            }
        }
        side.push_back(Zpoint(p2));

        camberStripes.push_back(side);

    }

    // if a symmetrical spinnaker then plot
    // luff and leech straight lines
    if (sailType == SYMMETRIC) {
        CSide sleft, sright;
        CPoint3d p1, p2;
        sleft.clear();
        sright.clear();
        for (unsigned int i=0; i<NUM_TOP_BOTTOM_POINTS; i++) {
            p1 = tack+luffV*((real)i/(real)NUM_TOP_BOTTOM_POINTS);
            sleft.push_back(Zpoint(p1));
            p2 = clew+leechV*((real)i/(real)NUM_TOP_BOTTOM_POINTS);
            sright.push_back(Zpoint(p2));
        }
        camberStripes.push_back(sleft);
        camberStripes.push_back(sright);
    }

    cout << "calculateSailCambers done" << endl;
}

real CSailWorker::calculateSideLength(CSide side) const {
    real tot = 0;
    int n = side.size();

    for (int i=0; i<n-2; i++) {
        tot += distanceBetween(side[i], side[i+1]);
    }

    return tot;
}

void CSailWorker::mapBattensToPanel(int idx, CBattenGroup& bg, CPanel& panel) const {
    int n = bg.numBattens();
    // clear out any existisng batten points on panel
    panel.aftBattenPoints.clear();
    panel.foreBattenPoints.clear();
    panel.battenpoints.clear();

    //int count = 0;
    for (int i=0; i<n; i++) {
        CBatten * b = &(bg.getBatten(i));
        int s = panel.right.size();
        CPoint3d p1 = panel.right[s-1];
        CPoint3d p2 = panel.right[0];

        if (b->aftPoint.y() < p1.y() && b->aftPoint.y() >= p2.y()) {
            b->aftPointPanelNo = idx;

            b->distanceToTopOfPanel = calculate3dDistance(p1, b->aftPoint);
            b->distanceToBottomOfPanel = calculate3dDistance(b->aftPoint, p2);

            battenPoint * bp = new battenPoint();
            CBatten b1 = (bg.getBatten(i));
            bp->battenId = i;
            bp->point = b1.aftPoint;
            bp->name = b1.name;
            bp->bFullLength = b1.fullLength;
            panel.aftBattenPoints.push_back(*bp);
            bp = new battenPoint();
            bp->battenId = i;
            bp->point = b1.frontPoint;
            bp->name = b1.name;
            bp->bFullLength = b1.fullLength;
            panel.foreBattenPoints.push_back(*bp);
            //count ++;

            //CBatten * nb = new  CBatten(b);
            //panel.battens.push_back(*nb);

            CVector3d v = panel.aftBattenPoints.back().point - b1.frontPoint;

            CSide s;
            s.clear();

            for (unsigned int j=0; j<= BATTEN_NUM_POINTS; j++) {
                real fraction = (real)j / real(BATTEN_NUM_POINTS);
                CPoint3d pb = b1.frontPoint + v * fraction;
                CPoint3d pz = Zpoint(pb);
                s.push_back(pz);
            }
            //bTrace = false;
            panel.battenpoints.push_back(s);
        }
    }
}

/**
 * @brief CSailWorker::mapReefPointsToPanel
 * @param list
 * @param panel
 */
void CSailWorker::mapReefPointsToPanel(vector<struct reefPoint>& list, CPanel&panel) const {
    panel.luffReefPoints.clear();
    panel.leechReefPoints.clear();

    switch (panel.panelType) {
    case PANEL_VERTICAL_LEECH:
        // for verical cut leech panel all reef poi9nts are added
        for (unsigned int i=0; i< list.size(); i++) {
            panel.leechReefPoints.push_back(list[i].leechReefPoint);
        }
        break;
    case PANEL_VERTICAL_LUFF:
    case PANEL_VERTICAL_LUFF_GAFF:
        for (unsigned int i=0; i< list.size(); i++) {
            if (panel.right.front().y() >= list[i].luffReefPoint.y() && panel.right.back().y() < list[i].luffReefPoint.y()) {
                panel.luffReefPoints.push_back(list[i].luffReefPoint);
            }
        }
        break;
    default:
        for (unsigned int i=0; i< list.size(); i++) {
            if (panel.left.back().y() >= list[i].luffReefPoint.y() && panel.left.front().y() < list[i].luffReefPoint.y()) {
                panel.luffReefPoints.push_back(list[i].luffReefPoint);
            }

            if (panel.right.back().y() >= list[i].leechReefPoint.y() && panel.right.front().y() < list[i].leechReefPoint.y()) {
                panel.leechReefPoints.push_back(list[i].leechReefPoint);
            }
        }
    }

}

/*
 * Lay out the base of the sail. Depending on the foot construction will call the appropriate function.
 * (currently on speed seam is supported)
 *
 * parameters:
 * 	p1, p2 are pointers to the points arrays used in LayoutCross2
 *  lay and dev are the panel groups
 *
 *  returns the number of panels laid
 */
int CSailWorker::LayoutCross2Foot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev , vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const {
	return LayoutSpeedSeamFoot(p1, p2, lay, dev, deviation, deviaPrev);
}


/**
 * lay out the base of the sail as a speed seam
 *
 * parameters:
 * 	p1, p2 are pointers to the points arrays used in LayoutCross2
 *  lay and dev are the panel groups
 *  deviation and deviaPrev are used in calculating deviations and straighening the top edge of the panel
 *
 *  returns the number of panels laid including the one above the speed seam
 */
int CSailWorker::LayoutSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const {
    if (sailType == JIB && sailCut == CROSS2 && curvedSpeedSeam) {
        return LayoutCurvedSpeedSeamFoot(p1, p2, lay, dev);
    } else {
        return LayoutStraightSpeedSeamFoot(p1, p2, lay, dev, deviation, deviaPrev);
    }
}

/**
 * lay out the base of the sail as a curved speed seam from tack to clew
 *
 * parameters:
 * 	p1, p2 are pointers to the points arrays used in LayoutCross2
 *  lay and dev are the panel groups
 *
 *  returns the number of panels laid including the one above the speed seam
 */

int CSailWorker::LayoutCurvedSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev) const {

    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();   // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int k = 0, cnt = 0;
    bool flag = false;  // to check if top of sail is reached

    /* create arrays t1 and t2 of type of intersection of upper seam
     *  respectively at points p1 on luff side and p2 on leech side
     *  t=1 seam intersect foot at point p1
     *  t=2 seam intersect luff
     *  t=3 seam intersect gaff
     *  t=4 seam intersect leech
     */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip, ip2;

    CSubSpace seamL; // seam Line

    CVector3d lV = LowerLeechVector();
    CVector3d seamV = CMatrix::rot3d(2, PI/2) * lV.unit();
    CSide curvedSide;
    curvedSide.resize(npb);

    unsigned int panelCount = 1;
    unsigned int speedPanelNo = 0;

    if (generateSpeedSeam) {
        panelCount++;
        speedPanelNo = 1;
    }

    cout << "speedPanelNo = " << speedPanelNo << endl;


    /* Other edge hem width */
    real luffHemW = hemsW;

    real tackIntersect = SpeedSeamLuffPoint();//, clewIntersect = SpeedSeamLeechPoint();
    unsigned int panelWidth[MAX_PANELS];
    getSplits(panelWidth, generateSpeedSeam, filletPanelWidth, speedPanelWidth);

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialise seam forward end at tack point
    p2[0] = clew; // initialise seam aft end at clew point
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

    CPoint3d pSpeedPanelLeech, pSpeedPanelLuffLow, pSpeedPanelLuffHigh;

    /** Lay the panels starting from the foot, going upward to the peak */
    for (npanel = 1 ; npanel < panelCount + 1 ; npanel++)
    {
        real exc = 0; // current excess of width
        real exb = 0; // total correction
        cnt = 0; // counter of iterations

        do  /* Loop for optimising the seam position to fit cloth width */
        {
            cnt++;
            if (npanel == speedPanelNo) {
                CPoint3d p = tack+luffV.unit()*SpeedSeamLuffPoint();
                p1[npanel] = FwdIntersect(p);
                p = clew+leechV.unit()*SpeedSeamLeechPoint();
                p2[npanel] = AftIntersect(p);
                pSpeedPanelLuffLow = p1[npanel];
                pSpeedPanelLeech = p2[npanel];
                //seamL = CSubSpace3d::line( p2[npanel] , seamV );
                //pSpeedPanelLuffHigh = seamL.intersect(luffLine).getp();

                cout << "npanel = " << npanel << endl;
                cout << "npanel == speedPanelNo, p2[npanel] = " <<p2[npanel] << endl;

                // lay out left side
                lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                for (k = 0 ; k < npl ; k++) {
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV, true);
                }

                // lay out right-hand side
                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0 ; k < npl ; k++) {
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);
                }

                // generate curvedSide
                // this will form the op of panel 1 and the bottom of panel 2
                CVector3d vSide = (pSpeedPanelLeech-pSpeedPanelLuffLow);
                CVector3d vSideP = CMatrix::rot3d(2, PI/2) * vSide.unit();
                real sideLength = vSide.norm();
                int camberPos = int(mould.profile[0].getMaxPos()*100+0.5);
                curvedSide.fill( pSpeedPanelLuffLow , pSpeedPanelLeech );
                real speedHt = speedPanelWidth > 0 ? speedPanelWidth : 125;

                for (unsigned int i=1; i<curvedSide.size()-1 ; i++) {
                    real l = (curvedSide[i]-curvedSide.front()).norm() / sideLength;
                    real r = RoundP(l, camberPos);
                    CPoint3d pc = curvedSide[i]+vSideP.unit()*speedHt*r;
                    curvedSide[i] = pc;
                }
                cout << "tack = " << tack << endl;
                cout << "clew = " << clew << endl;
                cout << "curvedSide " << curvedSide << endl;
                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                cout << " target distance = " << calculate3dDistance(lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1]) << endl;
                lay[npanel-1].top = curvedSide;//.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
                lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

                /* Below is the code for the intermediate points of the bottom side of first panel  */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    for (k = 1 ; k < npb -1 ; k++)
                    {
                        lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
                    }
                }

                t1[npanel] = 2;

            } else {
                int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
                //real broadseamAllowance = calculateBroadSeamAllowance(); //footL * 30 / 1000;
                p2[npanel] = p2[npanel-1] + leechV.unit() * (cw - seamW * 4 - exb - dev[npanel-1].cutTop[npb-1].y());
                cout << "npanel = " << npanel << endl;
                cout << "else clause: p2[npanel-1] = " << p2[npanel-1] << endl;
                cout << "else clause: p2[npanel] = " << p2[npanel] << endl;
                cout << "else clause: dev[npanel-1].cutTop[npb-1].y() = " << dev[npanel-1].cutTop[npb-1].y() << endl;
                seamL = CSubSpace3d::line( p2[npanel] , seamV );
                ip = seamL.intersect(luffLine).getp();
                if ( ip.y() < (tack.y()+tackIntersect+seamW) ) {
                    cout << "intersect = " << ip <<  " hits too low for maximum economy of cloth usage"<< endl;
                    p2[npanel] = p2[npanel-1] + lV.unit() * (cw - seamW - exb - footHemW);
                }
                t1[npanel] = 2;  // 2 = luff
                //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels

                seamL = CSubSpace3d::line( p2[npanel] , seamV );

                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutSpeedSeamFoot -1 : intersection of seam and luff is not a point!");

                p1[npanel] = ip;
                t1[npanel] = 2;  // 2 = luff

                // lay out left-hand side
                lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                for (k = 0 ; k < npl ; k++) {
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
                }

                // lay out right-hand side
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * lV < 0)
                    p2[npanel] = p2[npanel-1];

                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);

                // lay out top
                lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );

                // lay out bottom
                lay[npanel-1].bottom = curvedSide; //fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );
            }


            /** Go over all the points of current panel and calculate their Z */
            enum enumZpanelSupressCalc zpsc = ZPSC_NONE;
            if (npanel == speedPanelNo && footEdgeAtZeroZ == true)
                zpsc = ZPSC_FOOT;
            lay[npanel-1] = Zpanel(lay[npanel-1], zpsc);

            cout << "npanel = " << npanel << ", top =" << lay[npanel-1].top.arcLength()
                 << ", bottom = " << lay[npanel-1].bottom.arcLength() << endl;

            /** Develop the current panel */
            if ( npanel == 1 ) {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);

            }
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                //for (k = 1; k < npb-1; k ++)
                //    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /** Add the seam and hems allowance */
            if ( npanel == 1 ) {
                //cout << " Adding Seams: npanel = 1" << ", filletPanelNo = " << filletPanelNo << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, footHemW );
                dev[npanel-1].bPrintBottom = footHemW > 0 || lensFoot;
                int bottomline = 0;
                if (printBottomSeam && lensFoot) {
                    bottomline = seamW;
                } else if (footTapeDistance > 0) {
                    bottomline = footTapeDistance;
                } else {
                    bottomline = 0;
                }
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, bottomline, false);
               // cout << " dev[0]luffTape[0]" << dev[npanel-curvedSpeedSeamCheckBox1].luffTape[0]<<endl;
            }
            else if ( flag == true ) {
                cout << " Adding Seams: flag = true" << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 ) {
                    //cout << " Adding Seams: npanel = 1 and t1 = 2" << endl;
                    //cout << "======================" << endl;
                    for (unsigned int zzz = 0; zzz < npl; zzz++) {
                        cout << zzz << "    " << dev[npanel-1].left[zzz] << endl;
                    }
                    //cout << "======================" << endl;
                    dev[npanel-1].add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, true);
                    //cout << "luffTape:" << endl;
                    for (unsigned int iLuff = 0; iLuff < dev[npanel-1].luffTape.size(); iLuff++) {
                        cout << iLuff << "    " << dev[npanel-1].luffTape[iLuff] << endl;
                    }
                    //cout << "fo0tTape:" << endl;
                    for (unsigned int iFoot = 0; iFoot < dev[npanel-1].footTape.size(); iFoot++) {
                        cout << iFoot << "    " << dev[npanel-1].footTape[iFoot] << endl;
                    }
                } else {
                    //cout << " Adding Seams: default npanel = "<< npanel << endl;
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
                }
            }

            /* Check the width of developed panel and store the excess */
            exc = -1;// dev[npanel-1].boundingRect().height() - clothW;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0  &&  cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        /** Reposition the developed panel such that the
         *  lowest point is Y=0 AND most left point is X=0.
         */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        //cout << " after reframe dev[0]luffTape[0]" << dev[npanel-1].luffTape[0]<<endl;
        //cout << " after reframe dev[0]left[0]" << dev[npanel-1].left[0]<<endl;
        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    }  /** Loop FOR next panel */

    for (unsigned int i = 0; i<panelCount; i++) {
        dev[i] = dev[i].alignTop();

        dev[i] = dev[i].reframe(LOW_LEFT);
    }

    cout << "speedseam difference = " << (dev[speedPanelNo].bottom.arcLength()-dev[speedPanelNo-1].top.arcLength()) << endl;
    cout << "dev[0].top           = " << (dev[0].top.back()-dev[0].top.front()).norm() << endl;
    cout << "dev[1].bottom        = " << (dev[1].bottom.back()-dev[1].bottom.front()).norm() << endl;

    return panelCount;
}

/**
 * lay out the base of the sail as a straight speed seam
 *
 * parameters:
 * 	p1, p2 are pointers to the points arrays used in LayoutCross2
 *  lay and dev are the panel groups
 *  deviation and deviaPrev are used in calculating deviations and straighening the top edge of the panel
 *
 *  returns the number of panels laid including the one above the speed seam
 */
int CSailWorker::LayoutStraightSpeedSeamFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const {

	unsigned int npanel = 1;
	unsigned int npl = lay[0].right.size();   // number of right/left points
	unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int k = 0, cnt = 0;
	bool flag = false;  // to check if top of sail is reached

	/* create arrays t1 and t2 of type of intersection of upper seam
	 *  respectively at points p1 on luff side and p2 on leech side
	 *  t=1 seam intersect foot at point p1
	 *  t=2 seam intersect luff
	 *  t=3 seam intersect gaff
	 *  t=4 seam intersect leech
	 */
    int t1[MAX_PANELS];

	/* define point ip for intersections */
	CPoint3d ip, ip2;

	CSubSpace seamL; // seam Line

	CVector3d lV = LowerLeechVector();
    CVector3d seamV = CMatrix::rot3d(2, PI/2) * lV.unit();


    unsigned int panelCount = 1;
    unsigned int filletPanelNo = 0, speedPanelNo = 0;

	if (filletPanelWidth > 0) {
		panelCount++;
		filletPanelNo = 1;
	}

	if (generateSpeedSeam) {
		panelCount++;
		speedPanelNo = filletPanelNo + 1;
	}

    cout << "filletPanelNo = " << filletPanelNo << endl;
    cout << "speedPanelNo = " << speedPanelNo << endl;

	/* create variables for the development and edge corrections */
	CPoint3d top(0, 0, 0);
	CPoint3d bot(0, 0, 0);
	CVector3d v(0, 0, 0);
	CVector3d vb(0, 0, 0);
	CVector3d vk(0, 0, 0);

	/* Other edge hem width */
	real luffHemW = hemsW;

    real /*CC = 0,*/ x = 0, y = 0;

    real tackIntersect = SpeedSeamLuffPoint();//, clewIntersect = SpeedSeamLeechPoint();
    unsigned int panelWidth[MAX_PANELS];
    getSplits(panelWidth, generateSpeedSeam, filletPanelWidth, speedPanelWidth);

	/* seam 0 is on the foot of the sail ending at the clew */
	p1[0] = tack; // initialise seam forward end at tack point
	p2[0] = clew; // initialise seam aft end at clew point
	t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

    CPoint3d pSpeedPanelLeech, pSpeedPanelLuffLow, pSpeedPanelLuffHigh;

	/** Lay the panels starting from the foot, going upward to the peak */
	for (npanel = 1 ; npanel < panelCount + 1 ; npanel++)
	{
		real exc = 0; // current excess of width
		real exb = 0; // total correction
		cnt = 0; // counter of iterations

		do  /* Loop for optimising the seam position to fit cloth width */
		{
			cnt++;
			if (npanel == filletPanelNo)
			{
	            p2[npanel] = p2[npanel-1] + (filletPanelWidth - exb) * lV.unit();
                cout << "npanel == filletPanelNo, p2[npanel] = " <<p2[npanel] << endl;
                cout << "npanel = " << npanel << endl;
                //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels
	            seamL = CSubSpace3d::line( p2[npanel] , seamV );
                /* find position of luff/seam intersection relative to tack and head */
                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutSpeedSeamFoot -1 : intersection of seam and luff is not a point!");

                if ( seamL.intersect(footLine).getdim() == 0 )
                    p1[npanel] = seamL.intersect(footLine).getp();
                else throw layout_error("CSailWorker::LayoutSpeedSeamFoot -2 : intersection of seam and foot is not a point!");

                t1[npanel] =1;  // type1=1 = foot type of intersection

                p1[0] = p1[npanel];
                t1[0] = 1;

                lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);

				if ( CVector3d( p2[npanel] - p2[npanel-1] ) * lV < 0)
					p2[npanel] = p2[npanel-1];

       				lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
       				for (k = 0 ; k < npl ; k++)
                            lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);

       				/* Below is the code for the intermediate points of the top and bottom sides.
       				 *  The first point is identical to the last point of the left side
       				 *  The last point is identical to the last point of the right side
       				 */
       				lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
       				lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

       				/* Below is the code for the intermediate points of the bottom side of first panel  */
   					for (k = 1 ; k < npb -1 ; k++)
   					{
   						lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
   					}
			} else if (npanel == speedPanelNo) {
                p1[npanel] = CPoint3d(tack.x(), tack.y() + SpeedSeamLuffPoint(), tack.z());
				p2[npanel] = p2[npanel-1]+lV.unit()*SpeedSeamLeechPoint();
                pSpeedPanelLuffLow = p1[npanel];
                pSpeedPanelLeech = p2[npanel];
                seamL = CSubSpace3d::line( p2[npanel] , seamV );
                pSpeedPanelLuffHigh = seamL.intersect(luffLine).getp();

                cout << "npanel = " << npanel << endl;
                cout << "npanel == speedPanelNo, p2[npanel] = " <<p2[npanel] << endl;

				if (filletPanelWidth > 0) {
                    lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                    for (k = 0 ; k < npl / 2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl / 2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
				} else {
					// lay out left-hand side
					lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
					for (k = 0 ; k < npl ; k++) {
						lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
					}
				}
				// lay out right-hand side
				lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
				for (k = 0 ; k < npl ; k++) {
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);
				}

                /* Below is the code for the intermediate points of the top and bottom sides.
                *  The first point is identical to the last point of the left side
                *  The last point is identical to the last point of the right side
                */
                cout << " target distance = " << calculate3dDistance(lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1]) << endl;
                lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );
                lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );

                /* Below is the code for the intermediate points of the bottom side of first panel  */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    for (k = 1 ; k < npb -1 ; k++)
                    {
                        lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
                    }
                }

				t1[npanel] = 2;

			} else {
				int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
				real broadseamAllowance = calculateBroadSeamAllowance(); //footL * 30 / 1000;
                p2[npanel] = p2[npanel-1] + lV.unit() * (cw - seamW * 4 - exb - dev[npanel-2].cutTop[npb-1].y() - broadseamAllowance);
                cout << "npanel = " << npanel << endl;
                cout << "else clause: p2[npanel-1] = " << p2[npanel-1] << endl;
                cout << "else clause: p2[npanel] = " << p2[npanel] << endl;
                cout << "else clause: dev[npanel-2].cutTop[npb-1].y() = " << dev[npanel-2].cutTop[npb-1].y() << endl;
                seamL = CSubSpace3d::line( p2[npanel] , seamV );
				ip = seamL.intersect(luffLine).getp();
				if ( ip.y() < (tack.y()+tackIntersect+seamW) ) {
					cout << "intersect = " << ip <<  " hits too low for maximum economy of cloth usage"<< endl;
					p2[npanel] = p2[npanel-1] + lV.unit() * (cw - seamW - exb - footHemW);
				}
				t1[npanel] = 2;  // 2 = luff
                //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels

				seamL = CSubSpace3d::line( p2[npanel] , seamV );

				if ( seamL.intersect(luffLine).getdim() == 0 )
					ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutSpeedSeamFoot -1 : intersection of seam and luff is not a point!");

				p1[npanel] = ip;
				t1[npanel] = 2;  // 2 = luff

				// lay out left-hand side
				lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
				for (k = 0 ; k < npl ; k++) {
					lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
				}

				// lay out right-hand side
				if ( CVector3d( p2[npanel] - p2[npanel-1] ) * lV < 0)
					p2[npanel] = p2[npanel-1];

				lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
				for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV, true);

				// lay out top
				lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );

				// lay out bottom
				lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );
			}


			/** Go over all the points of current panel and calculate their Z */
            enum enumZpanelSupressCalc zpsc = ZPSC_NONE;
            if (filletPanelWidth == 0 && npanel == speedPanelNo && footEdgeAtZeroZ == true)
                zpsc = ZPSC_FOOT;
            if (filletPanelWidth > 0 && npanel == speedPanelNo && footEdgeAtZeroZ == true)
                zpsc = ZPSC_LUFF_FOOT;
            lay[npanel-1] = Zpanel(lay[npanel-1], zpsc);

            cout << "npanel = " << npanel << ", top =" << lay[npanel-1].top.arcLength()
                 << ", bottom = " << lay[npanel-1].bottom.arcLength() << endl;
            /** map batten positions against panels */
            mapBattensToPanel(npanel-1, battenGroup, lay[npanel-1]);

            /** map reef points */
            mapReefPointsToPanel(reefPointsList, lay[npanel-1]);

#ifdef DEBUG
			if ( npanel == 1 )
			{ // move bottom side of first panel to foot curve
				cout << "CSailWorker::Layout0 Crosscut foot after Z " << endl;
				for (k = 0 ; k < npb ; k++)
					cout << "pt="<< k << " xyz=" << lay[0].bottom[k] << endl;

				cout << "---end Z foot----   DO LOOP=" << cnt << endl;
			}
#endif

			/** Develop the current panel */
			if ( npanel == 1 ) {
				dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);

			}
			else {
				dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
				// add deviation of previous panel top edge to bottom edge
				for (k = 1; k < npb-1; k ++)
					dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
			}

			/**  Compute and store the deviation of top edge of
			 *   the developed panel and straighten this top edge
			 *   except if this is the top panel
			 */
			if ( flag == false ) {
				vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
				for (k = 1 ; k < npb -1 ; k ++)
				{
					vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
					v= vb * -(vk*vb);
					deviation[k] = v;
					dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
				}
			}

            /** Add the seam and hems allowance */
            if ( npanel == 1 ) {
                //cout << " Adding Seams: npanel = 1" << ", filletPanelNo = " << filletPanelNo << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, footHemW );
                dev[npanel-1].bPrintBottom = footHemW > 0 || lensFoot;
                int bottomline = 0;
                if (printBottomSeam && lensFoot) {
                    bottomline = seamW;
                } else if (footTapeDistance > 0) {
                    bottomline = footTapeDistance;
                } else {
                    bottomline = 0;
                }
                dev[npanel-1].addAssemblyLines(npanel == filletPanelNo ? 0 : luffTapeDistance, footTapeDistance, bottomline, false);
               // cout << " dev[0]luffTape[0]" << dev[npanel-curvedSpeedSeamCheckBox1].luffTape[0]<<endl;
            }
            else if ( flag == true ) {
                cout << " Adding Seams: flag = true" << endl;
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
            }
            else {
                if ( t1[npanel-1] == 1 && t1[npanel] == 2 ) {
                    //cout << " Adding Seams: npanel = 1 and t1 = 2" << endl;
                    //cout << "======================" << endl;
                    for (unsigned int zzz = 0; zzz < npl; zzz++) {
                        cout << zzz << "    " << dev[npanel-1].left[zzz] << endl;
                    }
                    //cout << "======================" << endl;
                    dev[npanel-1].add6Hems( footHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, true);
                    //cout << "luffTape:" << endl;
                    for (unsigned int iLuff = 0; iLuff < dev[npanel-1].luffTape.size(); iLuff++) {
                        cout << iLuff << "    " << dev[npanel-1].luffTape[iLuff] << endl;
                    }
                    //cout << "fo0tTape:" << endl;
                    for (unsigned int iFoot = 0; iFoot < dev[npanel-1].footTape.size(); iFoot++) {
                        cout << iFoot << "    " << dev[npanel-1].footTape[iFoot] << endl;
                    }
                } else {
                    //cout << " Adding Seams: default npanel = "<< npanel << endl;
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
                    dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, printBottomSeam ? seamW : 0, false);
                }
            }

            //cout << "Seams added" << endl;
            // dump
            //for (unsigned int kkk = 0; kkk < npb; kkk++) {
            //    cout << kkk << "\t" << dev[npanel-1].bottom[kkk] << "\t" << dev[npanel-1].footTape[kkk] << endl;
            //}
            //cout << " before rotate dev[0]luffTape[0]" << dev[npanel-1].luffTape[0]<<endl;
            //cout << " before rotate dev[0]left[0]" << dev[npanel-1].left[0]<<endl;


            //cout << " after rotate dev[0]luffTape[0]" << dev[npanel-1].luffTape[0]<<endl;
            //cout << " after rotate dev[0]left[0]" << dev[npanel-1].left[0]<<endl;

			/* Check the width of developed panel and store the excess */
			exc = -1;// dev[npanel-1].boundingRect().height() - clothW;

			/* Sum previous correction + 80% of current excess of width + 1mm */
			exb += 0.8 * exc + 1;
		}
		while ( exc > 0  &&  cnt < 9 );
		/* loop as long the excess of width is positive AND counter < 9 */

		deviaPrev = deviation;
        //cout << " before reframe dev[0]luffTape[0]" << dev[npanel-1].luffTape[0]<<endl;
        //cout << " before reframe dev[0]left[0]" << dev[npanel-1].left[0]<<endl;

		/** Reposition the developed panel such that the
		 *  lowest point is Y=0 AND most left point is X=0.
		 */
		dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        //cout << " after reframe dev[0]luffTape[0]" << dev[npanel-1].luffTape[0]<<endl;
        //cout << " after reframe dev[0]left[0]" << dev[npanel-1].left[0]<<endl;
        /* check if peak has been reached to break off */
		if ( flag == true )
			break;
	}  /** Loop FOR next panel */

    x = dev[panelCount-1].top.back().x() - dev[panelCount-1].top.front().x();
    y = dev[panelCount-1].top.back().y() - dev[panelCount-1].top.front().y();

    real rotAngle = atan2( y , x);

    // calculate rotate angle for top panel

    for (npanel=1; npanel<panelCount+1; npanel++) {
        // rotate panel
        bot = dev[npanel-1].bottom[0];

        /*
            FIX ME!!!!
            what this needs to do is if fillet width == 0
            then if this is a jib or this is a main and npanel < panelCount
            do first part rotation
        */
        if (filletPanelWidth == 0 &&
                (sailType == JIB ||
                 (sailType == MAINSAIL && npanel < panelCount)
                )
            ) {

            //if (!clothAlignsWithLeech) {
                // quick and dirt fix for gaff mainsails
                // TODO work out a general solution
                //if (npanel == speedPanelNo && isGaffSail) {
                   //a = (pSpeedPanelLuffHigh-pSpeedPanelLuffLow).norm();
                    //b = (pSpeedPanelLeech-pSpeedPanelLuffHigh).norm();
                    //c = (pSpeedPanelLeech-pSpeedPanelLuffLow).norm();

                    //angle = Atriangle(a,b,c);
                    //CC = rotAngle;
                    //cout << "speed seam angle = " << angle * 180.0 / PI << endl;
                //} else {
                //    CC = rotAngle;
               //}

                dev[npanel-1] = dev[npanel-1].rotate(bot,CMatrix::rot3d(2,rotAngle*-1));
        } else  {
            if (npanel == panelCount || npanel == filletPanelNo) {
                dev[npanel-1] = dev[npanel-1].alignTop();
            } else {
                dev[npanel-1] = dev[npanel-1].alignBottom();//rotate(bot,CMatrix::rot3d(2,rotAngle*-1));
            }
        }

        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);
    }

    cout << "speedseam difference " << (dev[speedPanelNo].bottom.front().y()-dev[speedPanelNo-1].top.front().y())
            << "    " <<  (dev[speedPanelNo].bottom.back().y()-dev[speedPanelNo-1].top.back().y()) << endl;

	return panelCount;
}

/*
 * layoutLensFootPanel
 *
 * create a lens foot panel from the bottom fal developed panel flatpanel
 *
 * */
CPanel CSailWorker::layoutLensFootPanel(CPanel flatpanel) const {
    CPanel *lensPanel = new CPanel();

    CSide top = flatpanel.bottom;

    double CC = 0;
    CPoint3d p1 = top[0];
    CPoint3d p2 = top.back();
    CC = atan2( (p2.y()-p1.y()) , (p2.x()-p1.x()) );

    //cout << "before rotate  top[0] =" << top[0] << "    top.back = " << top.back() << endl;
    top = top.rotate(p1, CMatrix::rot3d(2,-CC) );
    //cout << "after rotate  top[0] =" << top[0] << "    top.back = " << top.back() << endl;

    double y = top[0].y();
    double yBottom = y - 5;

    for (unsigned int i= 1; i< top.size() - 1; i++) {
        top[i] = CPoint3d(top[i].x(), y + (y - top[i].y()), 0);
    }

    lensPanel->top = top;

    CSide left = CSide();
    left.resize(2);
    left[1] = CPoint3d(top[0].x(), y, 0);
    left[0] = CPoint3d(top[0].x(), yBottom, 0);
    lensPanel->left = left;
    lensPanel->cutLeft = left;

    CSide right = CSide();
    right.resize(2);
    right[1] = CPoint3d(top.back().x(), y, 0);
    right[0] = CPoint3d(top.back().x(), yBottom, 0);
    lensPanel->right = right;
    lensPanel->cutRight = right;

    CSide bottom = CSide();
    bottom.resize(top.size());
    for (unsigned int i= 1; i< top.size() - 1; i++) {
        bottom[i] = CPoint3d(top[i].x(), yBottom, 0);
    }
    bottom[0] = left[0];
    bottom.back() = right[0];

    lensPanel->bottom = bottom;
    lensPanel->cutBottom = bottom;

    lensPanel->addHems(0, seamW, 0, 0);
    lensPanel->reframe(LOW_LEFT);

    return *lensPanel;
}

	/*
	 * lay out the base of the sail as a speed seam
	 *
	 * parameters:
	 * 	p1, p2 are pointers to the points arrays used in LayoutCross2
	 *  lay and dev are the panel groups
	 *
	 *  returns the number of panels laid including the one above the speed seam
	 */
int CSailWorker::LayoutSpeedSeamMultiPanelFoot( CPoint3d *p1, CPoint3d *p2, CPanelGroup &lay, CPanelGroup &dev, vector<CVector3d> &deviation, vector<CVector3d> &deviaPrev ) const {

	unsigned int npanel = 1;
	unsigned int npl = lay[0].right.size();   // number of right/left points
	unsigned int npb = lay[0].bottom.size();  // number of bottom/top points

    unsigned int k = 0, cnt = 0;
	bool flag = false;  // to check if top of sail is reached

	/* create arrays t1 and t2 of type of intersection of upper seam
	 *  respectively at points p1 on luff side and p2 on leech side
	 *  t=1 seam intersect foot at point p1
	 *  t=2 seam intersect luff
	 *  t=3 seam intersect gaff
	 *  t=4 seam intersect leech
	 */
    //int t1[MAX_PANELS], t2[MAX_PANELS];

	/* define point ip for intersections */
	CPoint3d ip, ip2;

	CVector3d seamV; // seam Vector
	CSubSpace seamL; // seam Line

	seamV = leechVP;  // for classical cross cut

	/* create variables for the development and edge corrections */
	CPoint3d top(0, 0, 0);
	CPoint3d bot(0, 0, 0);
	CVector3d v(0, 0, 0);
	CVector3d vb(0, 0, 0);
	CVector3d vk(0, 0, 0);


	/* Other edge hem width */
    //real luffHemW = hemsW;

    real CC = 0;//, x = 0, y = 0;

    real tackIntersect = SpeedSeamLuffPoint(), clewIntersect = SpeedSeamLeechPoint();
    unsigned int panelWidth[MAX_PANELS];
    getSplits(panelWidth);

	/* seam 0 is on the foot of the sail ending at the clew */
	p1[0] = tack; // initialise seam forward end at tack point
	p2[0] = clew; // initialise seam aft end at clew point
	p1[footPanelSections] = FootPanelTopLeftPoint(footPanelSections);
	p2[footPanelSections] = FootPanelTopRightPoint(1);
    //t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

	/** Lay the panels starting from the foot, going upward to the peak */
	for (npanel = 1 ; npanel < footPanelSections + 2 ; npanel++)
	{
		real exc = 0; // current excess of width
		real exb = 0; // total correction
		cnt = 0; // counter of iterations

		do  /* Loop for optimising the seam position to fit cloth width */
		{
			cnt++;
			if (npanel <= footPanelSections) {
				// lay out left-hand side
				lay[npanel-1].left.fill(FootPanelBottomLeftPoint(npanel) , FootPanelTopLeftPoint(npanel));
				if (npanel == footPanelSections) {
					for (k = 0 ; k < npl ; k++) {
						lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
					}
				}

				// lay out right-hand side
				lay[npanel-1].right.fill(FootPanelBottomRightPoint(npanel) , FootPanelTopRightPoint(npanel));
				if (npanel == 1) {
					for (k = 0 ; k < npl ; k++)
						lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);
				}

				// lay out top
				lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );

				// lay out bottom
				lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );
				for (k = 1 ; k < npb -1 ; k++)
				{
					lay[npanel-1].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].bottom[k], footVP);
				}

			} else {
				int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
				//real broadseamAllowance = sailType == MAINSAIL ? footL * 30 / 1000 : footL * 15 / 1000;
				real broadseamAllowance = calculateBroadSeamAllowance(); //footL * 30 / 1000;
				p2[npanel] = p2[npanel-1] + leechV.unit() * (cw - seamW * 4 - exb - dev[0].cutTop[npb-1].y() - broadseamAllowance);
				seamL = CSubSpace3d::line( p2[npanel] , seamV );
				ip = seamL.intersect(luffLine).getp();
				if ( ip.y() < (tack.y()+tackIntersect+seamW) ) {
					p2[npanel] = p2[npanel-1] + leechV.unit() * (cw - seamW - exb - footHemW);
				}
                //t1[npanel] = 2;  // 2 = luff
                //t2[npanel] = 4; // type2 = 4 = leech intersection for all horizontally cut panels

				seamL = CSubSpace3d::line( p2[npanel] , seamV );

				if ( seamL.intersect(luffLine).getdim() == 0 )
					ip = seamL.intersect(luffLine).getp();
				else throw layout_error("CSailWorker::LayoutSpeedSeam -1 : intersection of seam and luff is not a point!");

				p1[npanel] = ip;
                //t1[npanel] = 2;  // 2 = luff

				// lay out left-hand side
				lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
				for (k = 0 ; k < npl ; k++) {
					lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , seamV);
				}

				// lay out right-hand side
				if ( CVector3d( p2[npanel] - p2[npanel-1] ) * leechV < 0)
					p2[npanel] = p2[npanel-1];

				lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
				for (k = 0 ; k < npl ; k++)
					lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

				// lay out top
				lay[npanel-1].top.fill( lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1] );

				// lay out bottom
				lay[npanel-1].bottom.fill( lay[npanel-1].left[0] , lay[npanel-1].right[0] );
			}


			/** Go over all the points of current panel and calculate their Z */
			lay[npanel-1] = Zpanel(lay[npanel-1]);

#ifdef DEBUG
			if ( npanel == 1 )
			{ // move bottom side of first panel to foot curve
				for (k = 0 ; k < npb ; k++)
			}
#endif

			/** Develop the current panel */
			if ( npanel <= footPanelSections ) {
				dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);

			}
			else {
				dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
				// add deviation of previous panel top edge to bottom edge
				for (k = 1; k < npb-1; k ++)
					dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
			}

			/**  Compute and store the deviation of top edge of
			 *   the developed panel and straighten this top edge
			 *   except if this is the top panel
			 */
			if ( flag == false ) {
				vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
				for (k = 1 ; k < npb -1 ; k ++)
				{
					vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
					v= vb * -(vk*vb);
					deviation[k] = v;
					dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
				}
			}

			/** Add the seam and hems allowance */
			if ( npanel <= footPanelSections ) {
				real leftSeam = 0, rightSeam = 0;
				if (npanel == 1) {
					rightSeam = leechHemW;
				}
				if (npanel < footPanelSections) {
					leftSeam = seamW;
				}
				dev[npanel-1].addHems( leftSeam, seamW, rightSeam, footHemW );
			}
			else  {
				dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
				// Experimental
				// seam at bottom of panel
				// dev[npanel-1].add6Hems( hemsW, hemsW, 0, leechHemW, leechHemW, seamW );
			}

			// rotate panel
			bot = dev[npanel-1].bottom[0];

			real a, b, c;
			a = luffV.norm() - tackIntersect - seamW;
			b = leechV.norm()  - clewIntersect - seamW;
			c = sqrt( pow((p2[footPanelSections].x()-p1[footPanelSections].x()), 2)
					+ pow((p2[footPanelSections].y()-p1[footPanelSections].y()), 2) );

			// calculate angle
			real cosAngle = (b*b+c*c-a*a) / (2*b*c);
			real angle = acos(cosAngle);

			CC = PI / 2 - angle;
			dev[npanel-1] = dev[npanel-1].rotate(bot,CMatrix::rot3d(2,CC*-1));

			/* Check the width of developed panel and store the excess */
			exc = dev[npanel-1].boundingRect().height() - clothW;

			/* Sum previous correction + 80% of current excess of width + 1mm */
			exb += 0.8 * exc + 1;
		}
		while ( exc > 0  &&  cnt < 9 );
		/* loop as long the excess of width is positive AND counter < 9 */

		deviaPrev = deviation;

		/** Reposition the developed panel such that the
		 *  lowest point is Y=0 AND most left point is X=0.
		 */
		dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

		/* check if peak has been reached to break off */
		if ( flag == true )
			break;
	}  /** Loop FOR next panel */

	return npanel-1;
}

/*
 *  fWidth=fillet panel width
 *  sWidth=speed panel width
 * */
unsigned int CSailWorker::getSplits(unsigned int *panelWidth, bool genSpeedSeam, int fWidth, int sWidth) const {
	cout << "getSplits(): fWidth = " << fWidth << ", sWidth = " << sWidth << endl;

	int count = 1;
	int cw = 0;
	int speedPanelNo = genSpeedSeam ? 1 : -1;

	for (int i=0; i<MAX_PANELS; i++) {
		panelWidth[i] = clothW;
	}

	if (fWidth > 0) {
		panelWidth[0] = fWidth;
		count++;
		speedPanelNo++;
	}

	if (genSpeedSeam && sWidth > 0) {
		panelWidth[speedPanelNo] = sWidth;
	}

	if (splitPanelNos.length() > 0) {
        bool bSplit = true;
        if (splitPanelNos[0] == 'W' || splitPanelNos[0]== 'w') {
            bSplit = false;
        }
        bool bTest;
        // we'll ignore the returned value for bTest as the string should
        // be valid at this point. Pass false as last param as we shouldn't
        // have any negative numbers either
        vector<int> splits = SplitsToInts(splitPanelNos, bTest, false);

        for (unsigned int i=0; i< splits.size(); i++) {
            cw = splits[i];
            if (cw > 0) {
                // if this is the speed panel and sWidth > 0 then use
                // sWidth in the calc else use cloth  width
                // NOTE we have to generate two panelWidth entries here - one for each split panel
                if (bSplit) {
                    panelWidth[count] = ((count == speedPanelNo && sWidth > 0) ? sWidth : clothW) - cw;
                    count++;
                }
                panelWidth[count++] = cw;
            } else {
                // full width panel, move on
                count++;
            }
        }
    }

	return count;
}

unsigned int CSailWorker::calculateBroadSeamAllowance(void) const {
	// compute tack angel
	real tackAngle = Atriangle( leechL , luffL , footL );

	// compute foot median
	real lengthSqrd = luffL*luffL + (footL/2)*(footL/2) - 2*luffL*(footL/2)*cos(tackAngle);
	int footMedian = (int) sqrt(lengthSqrd);

	int height = footMedian * mould.vertpos / 100;

	int dpth = mould.profile[1].getDepth() * footL * (100 -mould.vertpos) / 100;

	real diag = sqrt(height*height + dpth * dpth);

	return 30 + (int) ((diag - height) * 1.3);
}

CPoint3d CSailWorker::FootPanelTopLeftPoint( unsigned int pn ) const {
	CPoint3d ip = CPoint3d(tack.x(), tack.y() + SpeedSeamLuffPoint(), tack.z());;
	if (footPanelSections == pn) {
		return ip;
	} else {
		CPoint3d pTopRight = clew + LowerLeechVector().unit()*SpeedSeamLeechPoint();
		return IntermediatePoint(ip, pTopRight, pn, footPanelSections);
	}
}

CPoint3d CSailWorker::FootPanelTopRightPoint( unsigned int pn ) const {
	CPoint3d point = clew + LowerLeechVector().unit()*SpeedSeamLeechPoint();
	if (pn == 1) {
		return point;
	} else {
		CPoint3d ip = CPoint3d(tack.x(), tack.y() + SpeedSeamLuffPoint(), tack.z());;
		return IntermediatePoint(ip, point, pn-1, footPanelSections);
	}
}

CPoint3d CSailWorker::FootPanelBottomLeftPoint( unsigned int pn ) const {
	if (pn == footPanelSections) {
		return tack;
	} else {
		return FootPoint(IntermediatePoint(tack, clew, pn, footPanelSections));
	}

}

CPoint3d CSailWorker::FootPanelBottomRightPoint( unsigned int pn ) const {
	if (pn == 1) {
		return clew;
	} else {
		return FootPoint(IntermediatePoint(tack, clew, pn-1, footPanelSections));
	}

}

/*
 * return the point on the luff which the speed seam intersects
 */
real CSailWorker::SpeedSeamLuffPoint() const {
	real tackIntersect;
	switch (sailType) {
	case MAINSAIL:
		tackIntersect = seamW;
		break;

	case JIB:
        tackIntersect = curvedSpeedSeam ? seamW : 75;
		break;
    default:
        tackIntersect = 75;
	}

	return tackIntersect;
}


/*
 * return the point on the leech which the speed seam intersects
 */
real CSailWorker::SpeedSeamLeechPoint() const {
	real clewIntersect;

    if (speedSeamLeechHeight > 0 && !curvedSpeedSeam) {
		clewIntersect = speedSeamLeechHeight;
	} else {
		switch (sailType) {
		case MAINSAIL:
			clewIntersect = 400;
			break;

		case JIB:
            clewIntersect = curvedSpeedSeam ? seamW : 250;
			break;
        default:
            clewIntersect = 250;
        }
	}

	return clewIntersect;
}

CPoint3d CSailWorker::IntermediatePoint(CPoint3d leftPoint, CPoint3d rightPoint, unsigned int pn, unsigned int totalPanels) const {
	return rightPoint - ((rightPoint - leftPoint) * ((real) pn / (real) totalPanels));
}

CPoint3d CSailWorker::FootPoint(CPoint3d p1) const {
    CSubSpace seamL = CSubSpace3d::line( p1 , footVP );
    CPoint3d p2 = seamL.intersect(footLine).getp();
    return EdgeIntersect(FOOT_EDGE, p2, footVP);

}

/** Creates a twist foot cut sail.
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutTwist( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
     *   located on the straight edge of the sail (no round)
     */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();  // number of right/left points
    unsigned int npb = lay[0].bottom.size(); // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0;
    bool flag = false;

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    /* define the seamV as the vector perpendicular to the leech vector (peak-clew)*/
    CVector3d seamV = leechVP;
    CSubSpace seamL;  // seam line
    CVector3d seamVT; // seam vector twisted
    CSubSpace seamLT; // seam line twisted

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* create variable to monitor excess over cloth width */
    real CC=0, x=0, y=0;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialised at tack point
    p2[0] = clew;
    t1[0] = 2;
    //t2[0] = 4;    // type=4=leech intersection

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /** Start laying the panels from foot upward to the peak */
    for (npanel = 1; npanel < MAX_PANELS-1; npanel++)
    {
        real exb = 0; // total correction
        real exc = 0; // current excess of width
        cnt = 0;

        /* Loop for optimising the seam position to fit cloth width */
        do
        {
            cnt++;
            p2[npanel] = p2[npanel-1] + leechV.unit() * (clothW - seamW - exb);
            //t2[npanel] = 4; // type2=4=leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line( p2[npanel] , seamV );

            if ( CVector3d(p2[npanel]-peak) * leechV > 0 )
            {  // we are above peak, stop this is last panel
                flag=true;
                p2[npanel] = peak;

                // check where previous point p1 is
                if (t1[npanel-1] <= 2)
                { // left points on luff
                    p1[npanel] = head;
                    t1[npanel] = 2;
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0; k < npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                }
                else
                { // left points on gaff
                    p1[npanel] = p1[npanel-1];
                    t1[npanel] = 3;
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0; k < npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                }

                // fill right points on leech
                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

                // fill bottom points
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

                // fill top  points
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

                // move all top points to gaff curve
                for (k=1; k < npb-1; k++)
                    lay[npanel-1].top[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].top[k], CVector3d (head.y()-peak.y() , peak.x()-head.x() , 0));

                // end peak panel //////
            }
            else // normal panel
            {
                /* find nominal position of luff/seam intersection relative to tack and head */
                if ( seamL.intersect(luffLine).getdim() == 0 )
                    ip = seamL.intersect(luffLine).getp();
                else throw layout_error("CSailWorker::LayoutTwist -1 : twist intersection of seam and luff is not a point!");

                if ( CVector3d( (ip - luffV.unit() * (seamW + clothW/5) ) - p1[npanel-1] ) * luffV < 0 )
                {   // seam intersects luff below previous panel luff point + 1/5 clothW
                    p1[npanel] = p1[npanel-1] + luffV.unit() * (seamW + clothW/5);
                    t1[npanel] = 2;  // 2=luff type of intersection
                    seamVT = CVector3d( p1[npanel] - p2[npanel] ).unit();
                    seamLT = CSubSpace3d::line(p2[npanel] , seamVT);
                    ip = seamLT.intersect(luffLine).getp();
#ifdef DEBUG
                    cout << "CSailWorker::LayoutTwist Seam 1 LUFF CORRECTION DO LOOP = " << cnt << endl;
                    cout << " ip = " << ip << endl;
                    cout << "p1[0] " << p1[0] << "  p2[0] " << p2[0] << " type "<< t1[0] << t2[0] << endl;
                    cout << "p1[1] " << p1[1] << "  p2[1] " << p2[1] << " type "<< t1[1] << t2[1] << endl;
                    cout << "seam VT = " << seamVT << endl;
                    cout << "--- " << endl;
#endif
                }
                else if (CVector3d(ip - head) * luffV > 0)
                {   // seam intersects gaff
                    if ( seamL.intersect(gaffLine).getdim() == 0 )
                        p1[npanel] = seamL.intersect(gaffLine).getp();
                    else throw layout_error("CSailWorker::LayoutTwist -2 : intersection of seam and foot is not a point!");

                    t1[npanel] = 3;  // 3=gaff type of intersection
                    seamVT = seamV;
                }
                else
                { // seam intersects luff normally
                    p1[npanel] = ip;
                    t1[npanel] = 2;  // luff
                    seamVT = seamV;
                }

                /* We now add the intermediate points on all sides of the panel */

                /* Below is the code for the left side depending
                 *  on t1 for the top side and bottom side
                 */
                if (t1[npanel-1] == 2 && t1[npanel] == 2)
                { // full luff
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);

                    for (k = 0; k < npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamVT);
                }
                else if (t1[npanel-1] == 3 && t1[npanel] == 3)
                { // full gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0; k < npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                }
                else if ((t1[npanel-1] ==2 ) && (t1[npanel] == 3))
                { // luff-head-gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , head, p1[npanel]);
                    for (k = 0; k < npl/2; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                    for (k = npl/2 +1; k < npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
                } // end IF ELSE for left side

                /*  Compute the intermediate points of the right side
                 *  which are all on the leech for a twist cut layout.
                 */
                // first check if upper point is not below lower point
                if ( CVector3d( p2[npanel] - p2[npanel-1] ) * leechV < 0 )
                    p2[npanel] = p2[npanel-1];

                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

                /*  Compute the intermediate points of the top and bottom sides.
                 *  The first point is identical to the last point of the left side
                 *  The last point is identical to the last point of the right side
                 */
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);
#ifdef DEBUG
                if ( npanel == 1 )
                {
                    cout << "CSailWorker::LaoutTwist foot straight  - LOOP= "<< cnt << endl;
                    for (k = 0 ; k < npb ; k++)
                        cout << "pt="<< k << " Bottom xyz= " << lay[0].bottom[k] << " Top xyz= " << lay[0].top[k] << endl;
                }
#endif

                /* Move the intermediate points of the bottom side of first panel */
                if ( npanel == 1 )
                { // move bottom side of first panel to foot curve
                    for (k = 1 ; k < npb-1 ; k++)
                        lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE,  lay[0].bottom[k] , footVP );
                }

            } /* end else normal panel //////// */

            /* Now we go over all the points and calculate their Z */
            lay[npanel-1] = Zpanel(lay[npanel-1]);

            /* Develop the current panel */
            if ( npanel == 1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else
            {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to this bottom edge
                for (k = 1 ; k < npb-1 ; k++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /*  Compute and store the deviation of top edge of developed panel
             *  and straighten this top edge Except if this is the top panel. */
            if (flag == false)
            {
                vb= CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] - dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb-1 ; k++)
                {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v= vb * -(vk * vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Add the seam and hems allowance */
            if (npanel == 1)
                dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, leechHemW, leechHemW, footHemW );
            else if (flag == true)
                dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
            else if ((t1[npanel-1] ==2 ) && (t1[npanel] == 2))
                dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );
            else if ((t1[npanel-1] ==2 ) && (t1[npanel] == 3))
                dev[npanel-1].add6Hems( luffHemW, hemsW, seamW, leechHemW, leechHemW, 0 );
            else
                dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );

#ifdef DEBUG
            if ( npanel == 1 )
            { // move bottom side of first panel to foot curve
                cout << "CSailWorker::LayoutTwist foot after adding seams " << endl;
                for (k = 0 ; k < npb ; k++)
                    cout << "pt="<< k << " xyz=" << dev[0].bottom[k] << endl;

                cout << "------END LOOP="<< cnt << endl;
            }
#endif

            /* Check the width of developed panel */
            exc = dev[npanel-1].boundingRect().height() - clothW;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0 && cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        /* Now we reposition the developed panel such that
         *  bottom minimum is Y=0 AND most left point is X=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    }  /* loop FOR next seam */

    if (npanel == MAX_PANELS-1)
        throw layout_error("CSailWorker::LayoutTwist -5 : MAX_PANELS without reaching head, do increase cloth width ");

    /* Copy the sails for display */
    CPanelGroup sail(npanel);
    for (j = 0; j < npanel; j++)
        sail[j] = lay[j];

    /* Copy the developed sail */
    flatsail = CPanelGroup(npanel);

    for (j = 0; j < npanel; j++)
        flatsail[j] = dev[j];

    /* Prepare the displays version of the developed sail */
    dispsail = flatsail;

    for (j = 1; j < npanel; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // rotation to align bottom of panel to top of previous panel
        x = dispsail[j-1].top[npb-1].x() - top.x();
        y = dispsail[j-1].top[npb-1].y() - top.y();
        CC = atan2(y,x);
        dispsail[j] = dispsail[j].rotate(bot,CMatrix::rot3d(2,CC));

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = top;
        v.x() -= bot.x();
        v.y() += 2 * seamW +20; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    return sail;
} /* end layout twist foot //////////// */


/** Creates a VERTICAL cut sail.
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutVertical( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round) */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();  // number of right/left points
    unsigned int npb = lay[0].bottom.size(); // number of bottom/top points

    unsigned int j=0, k=0, cnt=0;
    bool flag=false;

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t2[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    /* define seamV as the vector parrallel to the leech vector (peak-clew)*/
    CVector3d seamV = leechV.unit();
    CSubSpace seamL; // seam Line

    /* create variables for the development and edge corrections */
    CPoint3d pt(0, 0, 0); // test point
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for panel width correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /* seam 0 is on the leech of the sail ending at the peak */
    p1[0] = clew; // initialised at tack point
    p2[0] = peak;
    //t1[0] = 1;
    t2[0] = 3;    // type=4=leech intersection

    reefPointsList.clear();
    for (unsigned int i = 0 ; i< this->patches.size(); i++) {
        Patch patch = this->patches[i];
        switch (patch.patchType) {
        case PATCH_MAINSAIL_REEF1:
        case PATCH_MAINSAIL_REEF2:
            reefPointsList.push_back(calculateReefPoint(patch));
            break;

        default:
            break;
        }
    }

    unsigned int panelWidth[MAX_PANELS];
    //unsigned int headPanelStartNo = MAX_PANELS + 1;

    getSplits(panelWidth, generateSpeedSeam, filletPanelWidth, speedPanelWidth);

    /** Lay the panels parallel to the leech, from the leech toward the tack */

    for (npanel = 1; npanel < MAX_PANELS-1; npanel++)
    {
        enum enumPanelType panelType = PANEL_VERTICAL;

        real exb = 0; // total correction
        real exc = 0; // current excess of width
        cnt = 0;
        //if (npanel==3) flag=true;

        /* Loop for optimising the seam position to fit cloth width */
        do
        {
            cnt++;
            int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;

            pt = p1[npanel-1] + (cw -seamW -exb) * leechVP;
            seamL = CSubSpace3d::line(pt, seamV);
            if ( seamL.intersect(footLine).getdim() == 0 )
                p1[npanel] = seamL.intersect(footLine).getp();
            else throw layout_error("CSailWorker::LayoutVertical -1 : intersection of seam and foot is not a point!");

            //t1[npanel] = 1; // type1=1= foot intersection vertically cut panels

            if ( p1[npanel].x() <= tack.x() )
            {   // last panel
                p1[npanel] = tack;
                //t1[npanel] = 1;
                p2[npanel] = tack;
                t2[npanel] = 2;
                flag = true; // set the FLAG to get out of FOR
            }
            else
            {   // normal panel
                if ( seamL.intersect(gaffLine).getdim() == 0 )
                    p2[npanel] = seamL.intersect(gaffLine).getp();
                else throw layout_error("CSailWorker::LayoutVertical -2 : intersection of seam and gaff is not a point!");

                if ( CVector3d(p2[npanel]-head) * gaffV > 0 )
                    t2[npanel] = 3;
                else
                {
                    if ( seamL.intersect(luffLine).getdim() == 0 )
                        p2[npanel] = seamL.intersect(luffLine).getp();
                    else throw layout_error("LayoutVertical -3 : intersection of seam and luff is not a point!");

                    t2[npanel] = 2;
                }
            }

            // fill right side points
            if ( t2[npanel-1] == 2 && t2[npanel] == 2 )
            {
                // printf ("full luff \n");
                panelType = PANEL_VERTICAL_LUFF;
                lay[npanel-1].right.fill(p2[npanel-1], p2[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].right[k], seamV);
            }
            else if ( t2[npanel-1] == 3 && t2[npanel] == 2 )
            {
                panelType = PANEL_VERTICAL_LUFF_GAFF;
                // save throat point
                lay[npanel-1].throatPoint = throat;
                // printf ("gaff-head-luff \n");
                lay[npanel-1].right.fill(p2[npanel-1], head, p2[npanel]);

                for (k = 0; k < npl/2; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].right[k], seamV);

                for (k = npl/2+1; k < npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].right[k], seamV);
            }
            else
            {
                // printf ("full gaff \n");
                panelType = npanel== 1 ? PANEL_VERTICAL_LEECH : PANEL_VERTICAL;

                lay[npanel-1].right.fill(p2[npanel-1], p2[npanel]);

                for (k = 0; k < npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].right[k], seamV);
            }
            // fill left side points which are all on foot
            lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
            for (k = 0; k < npl; k++)
                lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], leechV);

            // fill bottom points
            lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);
            if ( npanel == 1 )
            {
                // bottom is on the leech
                for (k = 0; k < npb; k++)
                    lay[npanel-1].bottom[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].bottom[k], leechVP);
            }

            /* fill top side points on seam */
            lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

            lay[npanel-1].panelType = panelType;

            // map reef points
            mapReefPointsToPanel(reefPointsList, lay[npanel-1]);

            /* Go over all the points and calculate their z */
            lay[npanel-1] = Zpanel(lay[npanel-1], footEdgeAtZeroZ ? ZPSC_LEFT : ZPSC_NONE);

            /* Develop the current panel */
            if ( npanel == 1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else
            {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for (k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /*  Now we compute the deviation of top edge of developed panel
            *   and straighten this top edge except if this is the top panel */
            if ( flag == false )
            {
                vb = CMatrix::rot3d(2 , PI/2)*CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
                for (k = 1; k < npb-1; k ++)
                {
                    vk = CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v = vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Add the seam and hems allowance */
            if ( npanel == 1 ) { // leech panel
                dev[npanel-1].add6Hems( footHemW, footHemW, seamW, hemsW, hemsW, leechHemW );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, false);
            } else if ( flag == true ) { // last panel
                dev[npanel-1].add6Hems( footHemW, footHemW, luffHemW, luffHemW, luffHemW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, false);
            } else if ( t2[npanel-1] == 3 && t2[npanel] == 3 ) {
                dev[npanel-1].add6Hems( footHemW, footHemW, seamW, hemsW, hemsW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, false);
            } else if ( t2[npanel-1] == 3 && t2[npanel] == 2 ) { // luff-gaff panel
                dev[npanel-1].add6Hems( footHemW, footHemW, seamW, luffHemW, hemsW, 0 );
                dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, printBottomSeam ? seamW : 0, false);
            } else {
                dev[npanel-1].add6Hems( footHemW, footHemW, seamW, luffHemW, luffHemW, 0 );
                dev[npanel-1].addAssemblyLines(0, footTapeDistance, printBottomSeam ? seamW : 0, false);
            }
            /* Check the width of developed panel and store excess */
            exc = dev[npanel-1].boundingRect().height() - cw;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;

        }
        while ( exc > 0 && cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        /* Now we reposition the developed panel such that bottom left is X=0 Y=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;

    }  /* Loop FOR next seam */

    if ( npanel == MAX_PANELS-1 )
        throw layout_error("CSailWorker::LayoutVertical -4 : MAX_PANELS without reaching tack, do increase cloth width ");

    /* Copy the sails for display */
    CPanelGroup sail( npanel );
    for (j = 0; j < npanel; j++)
        sail[j] = lay[j];

    /* Copy the developed sail into flatsail */
    flatsail = CPanelGroup( npanel );

    for (j = 0; j < npanel; j++)
        flatsail[j] = dev[j];

    cout << "Adjusting panel widths" << endl;
    for (j = 0 ; j < npanel - 1 ; j++) {
            double dTop = flatsail[j].top.arcLength();
            double dBottom = flatsail[j+1].bottom.arcLength();
            //cout << "j = " << j << ", sail[j] top = " << sail[j].top.arcLength() << endl;
            //cout << "      sail[j+1] bottom = " << sail[j+1].bottom.arcLength() << endl;
            cout << "j = " << j << " dTop = " << dTop << ", dBottom =  " << dBottom << endl;
            double targetWidth = (dTop+dBottom)/2; //sail[j].top.arcLength();

            double topScale = targetWidth / flatsail[j].top.arcLength();
            flatsail[j] = flatsail[j].scaleTopLeftInX(topScale);

            while (abs(targetWidth - dBottom) > 0.1) {
                double bottomScale = targetWidth / flatsail[j+1].bottom.arcLength();
                flatsail[j+1] = flatsail[j+1].scaleBottomLeftInX(bottomScale);
                dBottom = flatsail[j+1].bottom.arcLength();
            }
            cout << "j = " << j << " top = " << flatsail[j].top.arcLength() << ", bottom = " << flatsail[j+1].bottom.arcLength() << endl;
            //cout << "      dTop = " << dTop << ", dBottom =  " << dBottom << endl;
    }
    cout << "Done" << endl;

    /* Prepare the displays version of the developed sail */
    dispsail = flatsail;

    for (j = 1; j < npanel; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = top;
        v.x() -= bot.x();
        v.y() += 2 * seamW +10; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    // patches
    layoutPatches(sail, flatsail);

    // calculate luff and leech points at various heights
    calculateSailCambers();

    // broadseam info
    aBroadseamInfo = calculateBroadseams(flatsail);

    return sail;
} /* end layout vertical cut //////// */


/** Creates a WING with horizontal cut layout.
 *  The panels are layed parrallel to the central line of the wing (horizontal cut)
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutWing( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
    *   located on the straight edge of the sail (no round) */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* Create number of panels */
    unsigned int npanel=1, np=1;
    unsigned int npl= lay[0].right.size();   // number of right/left points
    unsigned int npb= lay[0].bottom.size(); // number of bottom/top points

    /* Angle of the half wing from X-Y plane */
    real alfa = (180 - dihedralDeg) * PI/360;

    unsigned int j=0, k=0;
    bool flag=false;  // to check if top of sail is reached

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    int t1[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;

    /* define seamV as the horizontal vector*/
    CVector3d seamV(-1,0,0);
    CSubSpace seamL;

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /* create variable to monitor excess over cloth width */
    real CC=0, x=0, y=0;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = tack; // initialised at tack point
    p2[0] = clew;
    t1[0] = 1;
    //t2[0] = 4;    // type=4=leech intersection

    /** Position the seams starting from the centre of the wing (foot) */
    for (npanel = 1; npanel < MAX_PANELS-1; npanel++)
    {
        p2[npanel] = p2[npanel-1] + (clothW-seamW)/(seamV*leechVP) * leechV.unit();
        //t2[npanel] = 4; // type2=4=leech intersection for all horizontally cut panels
        seamL = CSubSpace3d::line(p2[npanel], seamV);

        if (CVector3d(p2[npanel]-peak)*leechV > 0)  // we are above peak, stop last panel
        {
            flag = true;
            p2[npanel] = peak;
            // check on which side of the sail the previous point p1 is located
            if ( t1[npanel-1] < 2 )
            { // previous seam on foot
                p1[npanel] = head;
                t1[npanel] = 2; // set on luff
                // left points on foot-tack-luff
                lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                for (k = 0; k < npl/2; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                for (k = npl/2 +1; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
            }
            else if (t1[npanel-1] == 2)
            { // left points on luff
                p1[npanel] = head;
                t1[npanel] = 2;
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
            }
            else
            { // left points on gaff
                p1[npanel] = p1[npanel-1];
                t1[npanel] = 3;
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
            }

            // fill right points on leech
            lay[npanel-1].right.fill(p2[npanel-1],p2[npanel]);
            for (k = 0; k < npl; k++)
                lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

            // fill bottom points
            lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

            // fill top  points
            lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

            // move all top points of top panel to gaff curve
            for (k = 1; k < npb-1; k++)
                lay[npanel-1].top[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].top[k], CVector3d (head.y()-peak.y(),peak.x()-head.x(),0));
            // end peak panel
        }
        else // normal panel
        {
            /* find position of luff/seam intersection relative to tack and head */
            if ( seamL.intersect(luffLine).getdim() == 0 )
                ip = seamL.intersect(luffLine).getp();
            else throw layout_error("CSailWorker::LayoutWing -1 : intersection of seam and luff is not a point!");

            if ( CVector3d( ip - tack ) * luffV <= 0 )
            {   // seam intersects foot
                if ( seamL.intersect(footLine).getdim() == 0 )
                    p1[npanel] = seamL.intersect(footLine).getp();
                else throw layout_error("CSailWorker::LayoutWing -2 : intersection of seam and foot is not a point!");

                t1[npanel] = 1;  // 1=foot type of intersection

                if ( npanel == 1 )
                {   // set lower edge to start at same point p1
                    p1[0] = p1[npanel];
                    t1[0] = 1;
                }
            }
            else if ( CVector3d(ip - head) * luffV > 0 )
            {   // seam intersects gaff
                if ( seamL.intersect(gaffLine).getdim() == 0 )
                    p1[npanel] = seamL.intersect(gaffLine).getp();
                else throw layout_error("CSailWorker::LayoutWing -3 : intersection of seam and foot is not a point!");

                t1[npanel] = 3;  // 3=gaff type of intersection
            }
            else
            {
                // seam intersects luff
                p1[npanel] = ip;
                t1[npanel] = 2;  // luff
                if ( npanel == 1 )
                {
                    // force seam 0 to start at the tack
                    p1[0] = tack;
                    t1[0] = 2;
                }
            }

            /* We now add the intermediate points on all sides of the normal panel  */

            /* Below is the code for the left side depending
            *  on t1 for the top side and bottom side
            */
            if ( t1[npanel-1] == 1 && t1[npanel] == 1 )
            {
                // full foot
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
            }
            else if ( t1[npanel-1] == 2 && t1[npanel] == 2 )
            {
                // full luff
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
            }
            else if ( t1[npanel-1] == 3 && t1[npanel] == 3 )
            {
                // full gaff
                lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                for (k = 0; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
            }
            else if ( t1[npanel-1] == 1 && t1[npanel] == 2 )
            {
                // foot-tack-luff
                lay[npanel-1].left.fill(p1[npanel-1], tack, p1[npanel]);
                for (k = 0; k < npl/2; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], seamV);
                for (k = npl/2 +1; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
            }
            else if ( t1[npanel-1] == 2 && t1[npanel] == 3 )
            {
                // luff-head-gaff
                lay[npanel-1].left.fill(p1[npanel-1], head, p1[npanel]);
                for (k = 0; k < npl / 2; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], seamV);
                for (k = npl/2 +1; k < npl; k++)
                    lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], seamV);
            } // end IF ELSE for left side

            /* Below is the code for the intermediate points of the right side
            *  which are all on the leech for a crosscut layout.
            */
            lay[npanel-1].right.fill(p2[npanel-1],p2[npanel]);
            for (k = 0; k < npl; k++)
                lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], seamV);

            /* Below is the code for the intermediate points of the top and bottom sides.
            *  The first point is identical to the last point of the left side
            *  The last point is identical to the last point of the right side
            */
            lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);
            lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

            /* Below is the code for the intermediate points of the bottom side of first panel  */
            if ( npanel == 1 )
            { // move bottom side of first panel to foot curve
                for (k = 1; k < npb -1; k++)
                    lay[0].bottom[k] = EdgeIntersect( FOOT_EDGE, lay[0].bottom[k], CVector3d(0,-1,0));
            }
        } // end else normal panel ///////////////// */

        /* Go over all the points and calculate their z */
        lay[npanel-1] = Zpanel(lay[npanel-1]);

        /* Rotate the panel by the dihedral angle */
        lay[npanel-1] = lay[npanel-1].rotate(tack , CMatrix::rot3d(0 , alfa) );

        /* If it is the first panel, then cut the foot to tack level */
        if ( npanel == 1 )
        {
            for (k=0; k < npb-1; k++)
                lay[0].bottom[k].y() = tack.y();

            lay[0].left[0].y() = tack.y();
            lay[0].right[0].y() = tack.y();
        }

        /* Develop the current panel */
        if ( npanel == 1 )
        {
            dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
        }
        else
        {
            dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
            // add deviation of previous panel top edge to bottom edge
            for (k = 1; k < npb-1; k ++)
                dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
        }

        /* Now we compute and store the deviation of top edge of
        *   the developed panel and straighten this top edge
        *   except if this is the top panel
        */
        if ( flag == false )
        {
            vb= CMatrix::rot3d(2,PI/2)*CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
            for (k = 1; k < npb-1; k ++)
            {
                vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                v= vb * -(vk*vb);
                deviation[k] = v;
                dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
            }
        }

        /* Add the seam and hems allowance to wing horizontal layout */
        if ( npanel == 1 )
            dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, leechHemW, leechHemW, footHemW );
        else if ( flag == true )
            dev[npanel-1].add6Hems( hemsW, hemsW, hemsW, leechHemW, leechHemW, 0 );
        else if ( t1[npanel-1] == 3 && t1[npanel] == 3 )
            dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
        else if ( t1[npanel-1] == 2 && t1[npanel] == 3 )
            dev[npanel-1].add6Hems( luffHemW, hemsW, seamW, leechHemW, leechHemW, 0 );
        else
            dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, leechHemW, leechHemW, 0 );

        /* Reset the previous panel deviation to the current panel */
        deviaPrev = deviation;

        /* Reposition the developed panel such that
        *  bottom minimum is Y=0 AND most left is X=0
        */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    } /* loop FOR next seam ///////////// */

    if ( npanel == (MAX_PANELS/2 -1) )
        throw layout_error("CSailWorker::LayoutWing -4 : got to MAX_PANELS without reaching head, do increase cloth width ");

    /** Create the symetrical panels */
    np = npanel;
    for (j = 0; j < np +1; j++)
    {
        npanel++;
        lay[npanel] = lay[j];
        dev[npanel] = dev[j];

        for (k = 0 ; k < npb ; k++)
        {
            lay[npanel].top[k].y() = -lay[npanel].top[k].y();
            lay[npanel].bottom[k].y() = -lay[npanel].bottom[k].y();
        }
        for (k = 0 ; k < npl ; k++)
        {
            lay[npanel].left[k].y() = -lay[npanel].left[k].y();
            lay[npanel].right[k].y() = -lay[npanel].right[k].y();
        }
    }

    /* Copy the sails for display */
    CPanelGroup sail( 2 * npanel +1 );

    for (j = 0; j < npanel; j++)
        sail[j] = lay[j];

    /* Copy the developed sail */
    flatsail = CPanelGroup( 2 * npanel +1);

    for (j = 0; j < npanel; j++)
    {
        flatsail[j] = dev[j];
    }

    /** Prepare the displays version of the developed sail */
    dispsail = flatsail;

    for (j = 1; j < npanel; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // rotation to align bottom of panel to top of previous panel
        x = dispsail[j-1].top[npb-1].x()-top.x();
        y = dispsail[j-1].top[npb-1].y()-top.y();
        CC= atan2(y,x);
        dispsail[j] = dispsail[j].rotate(bot,CMatrix::rot3d(2,CC));

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = CVector3d ( top - CPoint3d(0,0,0) );
        v.x() = v.x() - bot.x();
        v.y() = v.y() + 2*seamW + 25;  // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    return sail;
} /* end layoutWing = cross cut or horizontal //////////////////// */



/** Creates a radial cut sail.
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutRadial( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    unsigned int h = 0, j = 0, k = 0, a = 1, b = 1;
    unsigned int ngLuff = nbLuffGores;  // limit of luff gores
    unsigned int ng1 = 0;   // number of central panels
    //bool flag=false;
    real x = 0, xm = 0, xp = 0, ym = 0;

    CPoint3d pt0, pt1, pt2, pt3, pt4, ptCentre, ptFoot;  // points

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanel = 1;
    unsigned int npl = lay[0].right.size();  // number of right/left points
    unsigned int npb = lay[0].bottom.size();  // number of bottom/top points
    unsigned int nps[10];   // number of panels per sections

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    // int t1[MAX_PANELS], t2[MAX_PANELS];

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    CalculateBattenPositions();

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);

    /* Other edge hem width */
    // real footHemW = hemsW;
    // real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /* Create arrays of points at horizontal seams ends (10 maximum) */
    CPoint3d luffH[10];    // point at the luff end of the horizontal seam
    CPoint3d leechH[10];   // point at the leech end of the horizontal seam
    CSubSpace seamH[10];   // corresponding seam lines
    CSubSpace seamL;  // a seam line

    h = 0;
    luffH[h] = tack;
    leechH[h] = clew;
    seamH[h] = footLine;

    for (h = 1; h < nbSections; h++)
    {
        pt1 = tack + luffV * (real(h) / nbSections );
        pt2 = clew + leechV * (real(h) / nbSections );
        luffH[h] = EdgeIntersect( LUFF_EDGE,  pt1, CVector3d( pt1 - pt2 ) );
        leechH[h] = EdgeIntersect( LEECH_EDGE,  pt2, CVector3d( pt2 - pt1) );
        seamH[h] = CSubSpace3d::line(luffH[h], CVector3d( leechH[h] - luffH[h] ));
    }

    h = nbSections; // one more horizontal line than nbSections
    luffH[h] = head;
    leechH[h] = peak;
    seamH[h] = gaffLine;

    /*  Create arrays of points on luff and leech catenaries
    *   Luff and leech catenaries are the lines going from each side
    *     of the middle panel of the gaff to the tack and clew.
    *   They separate the surface of the sail in 3 zones:
    *     the luff zone, the central zone and the leech zone.
    *   The luff and leech zone have the same number of radial
    *     panels from top to bottom while in the central zone
    *     the number of panels increase by one at each section.
    */
    CPoint3d luffCatenary[11] , leechCatenary[11];

    // top point on luff catenary
    pt0 = head + gaffV * ( real(ngLuff) / real(nbGores) );
    luffCatenary[nbSections] = pt0;

    // top point on leech catenary
    pt0 = head + gaffV * ( real(ngLuff+1) / real(nbGores) );
    leechCatenary[nbSections] = pt0; // top of leech catenary

    // other points on both catenaries
    for (h = nbSections-1 ; h > 0 ; h--)
    {
        pt0 = tack + footV*(real(h) / real(nbSections))*(real(ngLuff) / real(nbGores));
        seamL = CSubSpace3d::line(luffCatenary[h+1], CVector3d(pt0 - luffCatenary[h+1]));
        luffCatenary[h] = seamH[h].intersect(seamL).getp();

        pt0 = clew - footV*(real(h) / real(nbSections))*(real(nbGores-ngLuff) / real(nbGores));
        seamL = CSubSpace3d::line(leechCatenary[h+1], CVector3d(pt0 - leechCatenary[h+1]));
        leechCatenary[h] = seamH[h].intersect(seamL).getp();
    }

    h = 0;
    luffCatenary[h] = tack;
    leechCatenary[h] = clew;

    /* Now we cut the radial panels
    *  Panels are oriented with lower and upper edges on vertical catenary
    *  Bottom side is on luff side and top side is on leech side
    *  Left side is at the top of each section
    *  p1 p2 are the end point of bottom side with
    *  p1 = top of horizontal section, p2 = bottom of horizontal section
    *  The seams between sections are twice the normal seam width
    */
    npanel = 0;
    ng1 = 0;  // initialise number of central panels

    /** Lay the panels from the top section downward to the foot section. */
    for (h = nbSections; h > 0; h--)
    {
        nps[h] = 0;  // counter of panels in current section
        /* Cutting the luff side panels
         *  which are left of the catenary separating the vertical zones
         */
        for (j = 1; j <= ngLuff; j++)
        {
            if ( j == 1 )
            { // place bottom end points on luff catenary
                pt1 = luffH[h];
                pt2 = luffH[h-1];

                lay[npanel].bottom.fill( pt1, pt2 );

                for (k = 1 ; k < npb -1 ; k++)
                    lay[npanel].bottom[k] = EdgeIntersect( LUFF_EDGE, lay[npanel].bottom[k] , CVector3d( luffH[h-1] - leechH[h-1] ) );
            }
            else
            { // copy previous points
                pt1 = pt3;
                pt2= pt4;
                lay[npanel].bottom.fill( pt1, pt2 );
            }

            // we compute the top end points
            pt3 = luffH[h] + CVector3d( luffCatenary[h] - luffH[h] ) * (real(j) / ngLuff);
            if ( h == nbSections )
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );

            pt4 = luffH[h-1] + CVector3d( luffCatenary[h-1] - luffH[h-1] ) * (real(j) / ngLuff);

            // we fill the other edges
            lay[npanel].top.fill( pt3 , pt4 );
            lay[npanel].left.fill( pt1 , pt3 );
            lay[npanel].right.fill( pt2 , pt4 );

            if ( h == nbSections )
            {
                for (k = 1; k < npl -1; k++)
                    lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k] , gaffVP );
            }

            // We compute Z
            lay[npanel] = Zpanel(lay[npanel]);

            // We develop the current panel
            dev[npanel] = lay[npanel].develop(ALIGN_TOP);


            // We add the seams and hems allowance
            if ( h == nbSections )
            {
                if ( j == 1 )
                    dev[npanel].addHems(hemsW, seamW, 0, hemsW);
                else
                    dev[npanel].addHems(hemsW, seamW, 0, 0);
            }
            else if ( j == 1 )
                dev[npanel].addHems(2*seamW, seamW, 0, hemsW);
            else
                dev[npanel].addHems(2*seamW, seamW, 0, 0);

            nps[h]++;
            npanel++;
        }

        /*  Cut the middle panels which are between the
         *  vertical catenaries luff and leech sides. */
        if ( h > 1 )
        {
            ng1++;  // we add one more central panel than section above
            a = int(floor(real(ng1) / 2) );
            b = int(ceil(real(ng1) / 2) );

            // we initialise the bottom end points
            pt3 = luffCatenary[h];
            if ( h == nbSections )
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3 , gaffVP );

            pt4 = luffCatenary[h-1];

            // we now compute the other points
            for (j = 1; j <= ng1; j++)
            {
                pt1 = pt3;
                pt2 = pt4;
                pt4 = luffCatenary[h-1] + CVector3d( leechCatenary[h-1] - luffCatenary[h-1] ) * (real(j) / ng1);

                if ( ng1 < 4 )
                {
                    pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j) / ng1);
                    if ( h == nbSections )
                        pt3 = EdgeIntersect( GAFF_EDGE,  pt3 , gaffVP );
                }
                else
                {
                    if ( j < a )  // before middle point
                    {
                        pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j) / (ng1-1));
                    }
                    else if ( j > b )  // after middle point
                    {
                        pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j-1) / (ng1-1));
                    }
                    else
                    {
                        pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j) / ng1);
                    }
                }

                // we fill the 4 edges
                lay[npanel].left.fill( pt1 , pt3 );
                lay[npanel].right.fill( pt2 , pt4 );
                lay[npanel].bottom.fill( pt1 , pt2 );
                lay[npanel].top.fill( pt3 , pt4 );

                if ( h == nbSections )
                {
                    for (k = 1; k < npl-1; k++)
                        lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k] , gaffVP );
                }

                // Now we go over all the points and calculate their z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if ( h == nbSections )
                    dev[npanel].addHems(hemsW, seamW, 0, 0);
                else
                    dev[npanel].addHems(2*seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }
        }
        else  // h = 1 middle panels of bottom section
        {
            // luff side central
            for (j = 1; j <= (ng1 / 2); j++)
            {
                pt1 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j-1) / ng1);
                pt2 = tack;

                pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j) / ng1);
                pt4 = pt2;

                ptCentre = pt3; // memorise last point on horizontal seam 1

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams allowance
                dev[npanel].addHems(2*seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // luff side lower central
            pt0 = ( luffCatenary[nbSections] + leechCatenary[nbSections] ) * 0.5;
            ptFoot = EdgeIntersect( FOOT_EDGE,  ptCentre , CVector3d(ptCentre - pt0) );
            a = int( (CVector3d (ptFoot - ptCentre).norm()) / (clothW) );
            if (a < 2)
                a = 2;

            for (j = 1 ; j <= a ; j++)
            {   // from center to foot
                pt1 = ptCentre + CVector3d (ptFoot - ptCentre) * (real(j-1) / a);
                pt2 = tack;
                pt3 = ptCentre + CVector3d (ptFoot - ptCentre) * (real(j) / a);
                pt4 = pt2;

                lay[npanel].left.fill( pt1 , pt3 );
                lay[npanel].right.fill( pt2 , pt4 );
                lay[npanel].bottom.fill( pt1 , pt2 );
                lay[npanel].top.fill( pt3 , pt4 );

                if ( j == a )
                {
                    for (k = 0; k < lay[npanel].top.size(); k++)
                        lay[npanel].top[k] = EdgeIntersect(FOOT_EDGE, lay[npanel].top[k], CVector3d(ptFoot - ptCentre));
                }

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if ( j == a )
                    dev[npanel].addHems(seamW, footHemW, 0, 0);
                else
                    dev[npanel].addHems(seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // leech side lower central
            for (j = 1; j <= a; j++)
            {   // from foot to center
                pt1 = ptFoot + CVector3d ( ptCentre - ptFoot ) * (real(j-1) / a );
                pt2 = clew;
                pt3 = ptFoot + CVector3d ( ptCentre - ptFoot ) * (real(j) / a);
                pt4 = pt2;

                lay[npanel].left.fill( pt1, pt3 );
                lay[npanel].right.fill( pt2, pt4 );
                lay[npanel].bottom.fill( pt1, pt2 );
                lay[npanel].top.fill( pt3, pt4 );

                if ( j == 1 )
                {
                    for (k = 0; k < lay[npanel].bottom.size(); k++)
                        lay[npanel].bottom[k] = EdgeIntersect(FOOT_EDGE, lay[npanel].bottom[k], CVector3d(ptFoot - ptCentre));
                }

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if ( j == 1 )
                    dev[npanel].addHems(0, seamW, 0, footHemW);
                else
                    dev[npanel].addHems(0, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // leech side central
            for (j = ng1/2 +1 ; j <= ng1 ; j++)
            {
                pt1 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j-1) / ng1);
                pt2 = clew ;

                pt3 = luffCatenary[h] + CVector3d( leechCatenary[h] - luffCatenary[h] ) * (real(j) / ng1);
                pt4 = pt2;

                lay[npanel].left.fill( pt1, pt3 );
                lay[npanel].right.fill( pt2, pt4 );
                lay[npanel].bottom.fill( pt1, pt2 );
                lay[npanel].top.fill( pt3, pt4 );

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams allowance
                dev[npanel].addHems(2*seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }
        }

        /* Cut the leech side panels */
        for (j = 1; j < (nbGores - ngLuff); j++)
        {
            pt1 = leechCatenary[h] + CVector3d( leechH[h] - leechCatenary[h] ) * (real(j-1) / (nbGores - ngLuff -1) );
            if ( h == nbSections )
                pt1 = EdgeIntersect( GAFF_EDGE,  pt1, gaffVP );

            pt2 = leechCatenary[h-1] + CVector3d( leechH[h-1] - leechCatenary[h-1] ) * (real(j-1) / (nbGores - ngLuff -1) );

            pt3 = leechCatenary[h] + CVector3d( leechH[h] - leechCatenary[h] ) * (real(j) / (nbGores - ngLuff -1) );
            if ( h == nbSections )
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );

            pt4 = leechCatenary[h-1] + CVector3d( leechH[h-1] - leechCatenary[h-1] ) * (real(j) / (nbGores - ngLuff -1) );

            lay[npanel].bottom.fill( pt1, pt2 );
            lay[npanel].top.fill( pt3, pt4 );
            lay[npanel].left.fill( pt1, pt3 );
            lay[npanel].right.fill( pt2, pt4 );

            if ( h == nbSections )
            {
                for (k = 1; k < npl -1; k++)
                    lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k] , gaffVP );
            }

            if ( j == nbGores - ngLuff -1)
            {
                for (k = 1; k < npb -1; k++)
                    lay[npanel].top[k] = EdgeIntersect( LEECH_EDGE, lay[npanel].top[k] , CVector3d(luffH[h-1]-leechH[h-1]) );
            }

            // we compute Z
            lay[npanel] = Zpanel(lay[npanel]);

            // We develop the current panel
            dev[npanel] = lay[npanel].develop(ALIGN_TOP);

            // We add the seams and hems allowance
            if ( h == nbSections )
            {   if ( j == nbGores - ngLuff -1 )
                    dev[npanel].addHems(hemsW, leechHemW, 0, 0);
                else
                    dev[npanel].addHems(hemsW, seamW, 0, 0);
            }
            else if (j == nbGores - ngLuff -1)
                dev[npanel].addHems(2*seamW, leechHemW, 0, 0);
            else
                dev[npanel].addHems(2*seamW, seamW, 0, 0);

            nps[h]++;
            npanel++;
        }
    }

    /* Copy 3d lay into 3d sail */
    CPanelGroup sail(npanel);
    for (j = 0 ; j < npanel ; j ++)
        sail[j] = lay[j];

    /* Copy from temporary developed sail into flatsail */
    flatsail = CPanelGroup(npanel);

    for (j = 0; j < npanel; j++)
        flatsail[j] = dev[j];

    /* Prepare the displays version of the developed sail */
    dispsail = flatsail;
    h = nbSections, k = 0;
    v = CVector3d(0,0,0);
    xm = 0;

    for (j = 0; j < npanel; j++)
    {
        if ( k == nps[h] )
        {
            // decrement section and offset x
            h--;
            k = 0;
            xp = xm + 2*seamW +20; // offset for next section
            v.x() = xp;
            v.y() = 0;
        }

        // translation v to stack panel above previous panel
        dispsail[j] = dispsail[j] + v;

        CRect3d pRect = dispsail[j].boundingRect();
        ym = pRect.height();
        v.y() += ym + 2*seamW +20; // adding offset to separate next panel vertically

        x = pRect.max.x();
        if ( x > xm )
            xm = x;
        k++;
    }

    calculateSailCambers();

    return sail;
} /* end layout radial cut ///////////// */



/** Creates a triradial cut sail.  //// NOT USED ////
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutTriRadial( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    unsigned int h=0, j=0, k=0, a=1, b=1;
    unsigned int ngLuff = nbGores/2;  // limit of luff gores
    unsigned int ng1=0;   // number of central panels
    //bool flag=false;
    real x=0, xm=0, xp=0, ym=0;

    CPoint3d pt0, pt1, pt2, pt3, pt4, ptCentre, ptFoot;  // points

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanel=1;
    unsigned int npl= lay[0].right.size();  // number of right/left points
    unsigned int npb= lay[0].bottom.size();  // number of bottom/top points
    unsigned int nps[10];   // number of panels per sections

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    */
    // int t1[MAX_PANELS], t2[MAX_PANELS];

    /* create variables for the development and edge corrections */
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);

    /* Create arrays of points at horizontal seams ends 10 maximum */
    CPoint3d luffH[10];    // point at the luff end of the horizontal seam
    CPoint3d leechH[10];   // point at the leech end of the horizontal seam
    CSubSpace seamH[10];   // corresponding seam lines
    CSubSpace seamL;  // a seam line

    for (h=0; h<nbSections; h++)  // one more horizontal line than nbSections
    {
        pt1 = tack + luffV * (real(h) / nbSections );
        pt2 = clew + leechV * (real(h) / nbSections );
        luffH[h] = EdgeIntersect( LUFF_EDGE,  pt1, CVector3d(pt1-pt2) );
        leechH[h] = EdgeIntersect( LEECH_EDGE,  pt2, CVector3d(pt2-pt1) );
        seamH[h] = CSubSpace3d::line(luffH[h], CVector3d(leechH[h] - luffH[h]));
    }

    h= nbSections;
    luffH[h] = head;
    leechH[h] = peak;
    seamH[h] = gaffLine;

    /*  Create arrays of points on luff and leech catenaries
    *   Luff and leech catenaries are the lines going from each side
    *     of the middle panel of the gaff to the tack and clew.
    *   They separate the surface of the sail in 3 zones:
    *     the luff zone, the central zone and the leech zone.
    *   The luff and leech zone have the same number of radial
    *     panels from top to bottom while in the central zone
    *     the number of panels increase by one at each section.
    */
    CPoint3d luffCatenary[11], leechCatenary[11];
    pt0 = head + gaffV * ( real(ngLuff) / real(nbGores) );

    luffCatenary[nbSections] = pt0; // top of luff catenary
    pt0 = head + gaffV * ( real(ngLuff+1) / real(nbGores) );
    leechCatenary[nbSections] = pt0; // top of leech catenary

    for (h = nbSections-1; h > 0; h--)
    {
        pt0 = tack + footV*(real(h) / real(2* nbSections));
        seamL = CSubSpace3d::line(luffCatenary[h+1], CVector3d(pt0 - luffCatenary[h+1]));
        luffCatenary[h] = seamH[h].intersect(seamL).getp();

        pt0 = clew - footV*(real(h) / real(2* nbSections));
        seamL = CSubSpace3d::line(leechCatenary[h+1], CVector3d(pt0 - leechCatenary[h+1]));
        leechCatenary[h] = seamH[h].intersect(seamL).getp();
    }

    h = 0;
    luffCatenary[h] = tack;
    leechCatenary[h] = clew;

    /* Now cutting the radial panels.
    *  Panels are oriented with lower edge vertical toward luff
    *  and left side at the top of each section
    */
    npanel = 0;
    ng1 = 0; // initialise number of central panels

    for (h = nbSections; h>0; h--)
    {
        /** Lay the panels from top section downward */
        nps[h]=0; // counter of panels in current section
        /* cutting the luff side panels */
        for (j=1; j<=ngLuff; j++)
        {
            if (j == 1)
            {
                pt1 = luffH[h];
                pt2 = luffH[h-1];
                lay[npanel].bottom.fill(pt1 , pt2);
                for (k=1; k<npb-1; k++)
                    lay[npanel].bottom[k] = EdgeIntersect( LUFF_EDGE, lay[npanel].bottom[k], CVector3d(luffH[h-1]-leechH[h-1]) );
            }
            else
            {
                pt1 = pt3;
                pt2= pt4;
                lay[npanel].bottom.fill(pt1 , pt2);
            }

            pt3 = luffH[h] + CVector3d(luffCatenary[h]-luffH[h]) * (real(j)/ngLuff);
            if (h == nbSections)
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );
            pt4 = luffH[h-1] + CVector3d(luffCatenary[h-1]-luffH[h-1]) * (real(j)/ngLuff);

            lay[npanel].top.fill(pt3, pt4);
            lay[npanel].left.fill(pt1 , pt3);
            lay[npanel].right.fill(pt2 , pt4);

            if (h == nbSections)
            {
                for (k=1; k<npl-1; k++)
                    lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k], gaffVP );
            }

            // compute Z
            lay[npanel] = Zpanel(lay[npanel]);

            // We develop the current panel
            dev[npanel] = lay[npanel].develop(ALIGN_TOP);


            // We add the seams and hems allowance
            if (h == nbSections && j == 1)
                dev[npanel].addHems(hemsW, seamW, 0, hemsW);
            else if (j == 1)
                dev[npanel].addHems(seamW, seamW, 0, hemsW);
            else
                dev[npanel].addHems(seamW, seamW, 0, 0);

            nps[h]++;
            npanel++;
        }

        /* cutting the middle panels */
        if ( h > 1 )
        {
            ng1++; // add one more central panel than section above
            a = int(floor(real(ng1)/2));
            b = int(ceil(real(ng1)/2));
            pt3 = luffCatenary[h];
            if (h == nbSections)
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );
            pt4 = luffCatenary[h-1];
            for (j=1; j<=ng1; j++)
            {
                pt1 = pt3;
                pt2 = pt4;
                pt4 = luffCatenary[h-1] + CVector3d(leechCatenary[h-1]-luffCatenary[h-1])*(real(j)/ng1);
                if (ng1 < 4)
                {
                    pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j)/ng1);
                    if (h == nbSections)
                        pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );
                }
                else
                {
                    if (j < a)
                    {
                        pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j)/(ng1-1));
                    }
                    else if (j > b )
                    {
                        pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j-1)/(ng1-1));
                    }
                    else
                    {
                        pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j)/ng1);
                    }
                }

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                if (h == nbSections)
                {
                    for (k=1; k<npl-1; k++)
                        lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k], gaffVP );
                }

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if (h == nbSections)
                    dev[npanel].addHems(hemsW, seamW, 0, 0);
                else
                    dev[npanel].addHems(seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }
        }
        else
        {
            // bottom section h = 1
            // luff side central
            for (j=1; j<=ng1/2; j++)
            {
                pt1 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j-1)/ng1);
                pt2 = tack;

                pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j)/ng1);
                pt4 = pt2;

                ptCentre = pt3; // memorise last point on horizontal seam 1

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams allowance
                dev[npanel].addHems(seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // luff side lower central
            pt0=(luffCatenary[nbSections]+leechCatenary[nbSections])*0.5;
            ptFoot = EdgeIntersect( FOOT_EDGE,  ptCentre , CVector3d(ptCentre-pt0) );
            a = int( (CVector3d(ptFoot-ptCentre).norm()) / (clothW) );
            if (a < 2)
                a = 2;

            for (j=1; j<=a; j++)
            {
                pt1 = ptCentre + CVector3d (ptFoot - ptCentre)*(real(j-1)/a);
                pt2 = tack;
                pt3 = ptCentre + CVector3d (ptFoot - ptCentre)*(real(j)/a);
                pt4 = pt2;

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                if (j == a)
                {
                    for (k = 0; k < lay[npanel].top.size(); k++)
                        lay[npanel].top[k] = EdgeIntersect(FOOT_EDGE, lay[npanel].top[k], footVP);
                }

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if (j == a)
                    dev[npanel].addHems(seamW, hemsW, 0, 0);
                else
                    dev[npanel].addHems(seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // leech side lower central
            for (j=1; j<=a; j++)
            {
                pt1 = ptFoot + CVector3d (ptCentre - ptFoot)*(real(j-1)/(a));
                pt2 = clew;
                pt3 = ptFoot + CVector3d (ptCentre - ptFoot)*(real(j)/(a));
                pt4 = pt2;

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                if (j == 1)
                {
                    for (k = 0; k < lay[npanel].bottom.size(); k++)
                        lay[npanel].bottom[k] = EdgeIntersect(FOOT_EDGE, lay[npanel].bottom[k], footVP);
                }

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams and hems allowance
                if (j == 1)
                    dev[npanel].addHems(0, seamW, 0, hemsW);
                else
                    dev[npanel].addHems(0, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }

            // leech side central
            for (j=ng1/2+1; j<=ng1; j++)
            {
                pt1 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j-1)/ng1);
                pt2 = clew ;

                pt3 = luffCatenary[h] + CVector3d(leechCatenary[h]-luffCatenary[h])*(real(j)/ng1);
                pt4 = pt2;

                lay[npanel].left.fill(pt1 , pt3);
                lay[npanel].right.fill(pt2 , pt4);
                lay[npanel].bottom.fill(pt1 , pt2);
                lay[npanel].top.fill(pt3 , pt4);

                // compute Z
                lay[npanel] = Zpanel(lay[npanel]);

                // We develop the current panel
                dev[npanel] = lay[npanel].develop(ALIGN_TOP);

                // We add the seams allowance
                dev[npanel].addHems(seamW, seamW, 0, 0);

                nps[h]++;
                npanel++;
            }
        }

        /* Cutting the leech side panels */
        for (j=1; j<nbGores-ngLuff; j++)
        {
            pt1 = leechCatenary[h] + CVector3d(leechH[h]-leechCatenary[h]) * (real(j-1)/(nbGores-ngLuff-1) );
            if (h == nbSections)
                pt1 = EdgeIntersect( GAFF_EDGE,  pt1, gaffVP );
            pt2 = leechCatenary[h-1] + CVector3d(leechH[h-1]-leechCatenary[h-1]) * (real(j-1)/(nbGores-ngLuff-1) );
            pt3 = leechCatenary[h] + CVector3d(leechH[h]-leechCatenary[h]) * (real(j)/(nbGores-ngLuff-1) );
            if (h == nbSections)
                pt3 = EdgeIntersect( GAFF_EDGE,  pt3, gaffVP );
            pt4 = leechCatenary[h-1] + CVector3d(leechH[h-1]-leechCatenary[h-1]) * (real(j)/(nbGores-ngLuff-1) );

            lay[npanel].bottom.fill(pt1 , pt2);
            lay[npanel].top.fill(pt3 , pt4);
            lay[npanel].left.fill(pt1 , pt3);
            lay[npanel].right.fill(pt2 , pt4);

            if (h == nbSections)
            {
                for (k=1; k<npl-1; k++)
                    lay[npanel].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel].left[k], gaffVP );
            }

            if (j == nbGores-ngLuff-1)
            {
                for (k=1; k<npb-1; k++)
                    lay[npanel].top[k] = EdgeIntersect( LEECH_EDGE, lay[npanel].top[k], CVector3d(luffH[h-1]-leechH[h-1]) );
            }

            // compute Z
            lay[npanel] = Zpanel(lay[npanel]);

            // We develop the current panel
            dev[npanel] = lay[npanel].develop(ALIGN_TOP);

            // We add the seams and hems allowance
            if ( h == nbSections && j == nbGores-ngLuff-1)
                dev[npanel].addHems(hemsW, leechHemW, 0, 0);
            else if (j == nbGores-ngLuff-1)
                dev[npanel].addHems(seamW, leechHemW, 0, 0);
            else
                dev[npanel].addHems(seamW, seamW, 0, 0);

            nps[h]++;
            npanel++;
        }
    }

    /* Copy 3d sail lay into sail */
    CPanelGroup sail(npanel);
    for (j = 0; j < npanel; j ++)
        sail[j] = lay[j];

    /* Copy from temporary developed sail into flatsail */
    flatsail = CPanelGroup(npanel);

    for (j=0; j < npanel; j++)
        flatsail[j] = dev[j];

    /* Prepare the displays version of the developed sail */
    dispsail = flatsail;
    h=nbSections, k=0;
    v = CVector3d(0,0,0);
    //xp = 0;
    xm = 0;
    //ym = 0;

    for (j=0; j < npanel; j++)
    {
        if (k == nps[h])
        {
            // decrement section and offset x
            h--;
            k = 0;
            xp = xm + 2*seamW +20; // offset for next section
            v.x() = xp;
            v.y() = 0;
        }

        // translation v to stack panel above previous panel
        dispsail[j] = dispsail[j] + v;

        CRect3d pRect = dispsail[j].boundingRect();
        ym = pRect.height();
        v.y() += ym+ 2*seamW +20; // adding offset to separate next panel vertically

        x = pRect.max.x();
        if (x > xm)
            xm = x;
        k++;
    }

    return sail;
} /* end LayoutTriRadial cut /////////  NOT USED /////////// */


/** Creates a mitre cut sail with panels perpendicular to Leech and Foot.
 *
 * @param flatsail the CPanelGroup object that will hold the developed sail
 * @param dispsail the CPanelGroup object that will hold the display
 *                 version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 */
CPanelGroup CSailWorker::LayoutMitre( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
     *   located on the straight edge of the sail (no round)
     */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanelFoot = 1, npanel = 1;
    unsigned int npl= lay[0].right.size();  // number of right/left points
    unsigned int npb= lay[0].bottom.size(); // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0;
    bool flag = false;

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    *  t=5 seam intersect mitre
    */
    int t1[MAX_PANELS], t2[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;
    /* seam Line */
    CSubSpace seamL;

    /* create variables for the development and edge corrections */
    CPoint3d pt(0, 0, 0); // test point
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /** Mitre Hem Width is set at twice the Seam Width. */
    real mitreHemW = seamW;

    /* Other edge hem width */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /* seam 0 is on the foot of the sail ending at the clew */
    p1[0] = clew; // initialised at clew point
    p2[0] = clew;
    t1[0] = 1;
    t2[0] = 5;    // type=5=mitre intersection

    unsigned int panelWidth[MAX_PANELS];
    getSplits(panelWidth, generateSpeedSeam, 0, 0);

    /** First Cut the foot panels perpendicular to the foot,
     *  starting at the clew and moving toward the tack. */
    enum enumPanelType panelType = PANEL_MITRE_FOOT_LUFF;

    for ( npanel = 1 ; npanel < (MAX_PANELS / 2) -1 ; npanel++ )
    {
        real exb = 0; // total correction
        real exc = 0; // current excess of width
        cnt = 0;

        /* Loop for optimising the seam position to fit cloth width */
        do
        {
            cnt++;
            int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
            // move base point along the foot
            pt = p1[npanel-1] - (cw - seamW - exb) * footV.unit();
            seamL = CSubSpace3d::line( pt , footVP );
            p1[npanel] = seamL.intersect(footLine).getp();
            t1[npanel] = 1; // type 1=foot intersection

            if ( p1[npanel].x() <= tack.x() )
            { // last panel
                p1[npanel] = tack;
                if ( t2[npanel-1] == 5 )
                {
                    p2[npanel] = mitreLuffPt;
                    t2[npanel] = 5;
                    panelType = PANEL_MITRE_FOOT_MITRE_LUFF;
                }
                else
                {
                    p2[npanel] = tack;
                    t2[npanel] = 2;
                    panelType = PANEL_MITRE_FOOT_LUFF;
                    cout<< "npanel = " << npanel  << "panelType = PANEL_MITRE_FOOT_LUFF" << endl;
                }
                flag = true; // set to get out of FOR
            }
            else
            { // normal panel
                p2[npanel] = seamL.intersect(mitreLine).getp();
                //cout << "npanel = " << npanel << "p2.x() = " << p2[npanel].x() << ", mitreLuffPt.x() = " << mitreLuffPt.x() << endl;
                //if (p2[npanel].x() < mitreLuffPt.x())
                if ( CVector3d(p2[npanel] - mitreLuffPt) * mitreV > EPS )
                {
                    t2[npanel] = 2;
                    p2[npanel] = seamL.intersect(luffLine).getp();
                    if (t2[npanel-1] == 5) {
                        cout<< "npanel = " << npanel  << "panelType = PANEL_MITRE_FOOT_MITRE_LUFF" << endl;
                        panelType = PANEL_MITRE_FOOT_MITRE_LUFF;
                    } else {
                        cout<< "npanel = " << npanel  << "panelType = PANEL_MITRE_FOOT_LUFF" << endl;
                        panelType = PANEL_MITRE_FOOT_LUFF;
                    }
                }
                else
                {
                    t2[npanel] = 5;
                    cout<< "npanel = " << npanel  << "panelType = PANEL_MITRE_FOOT_MITRE" << endl;
                    panelType = PANEL_MITRE_FOOT_MITRE;
                }
            }

            // fill right side points
            if ( t2[npanel-1] == 2 && t2[npanel] == 2 )
            {
                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k=0; k<npl; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].right[k], footVP);
            }
            else if ( (t2[npanel-1] == 5) && (t2[npanel] == 2) )
            {
                lay[npanel-1].right.fill(p2[npanel-1] , mitreLuffPt, p2[npanel]);

                for (k = npl/2 +1 ; k<npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].right[k], footVP);
            }
            else
            { // cout <<  "CSailWorker::LayoutMitre full mitre" << endl;
                lay[npanel-1].right.fill(p2[npanel-1], p2[npanel]);
            }

            // fill left side points which are all on foot
            lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
            for (k = 0 ; k < npl ; k++)
                lay[npanel-1].left[k] = EdgeIntersect( FOOT_EDGE, lay[npanel-1].left[k], footVP);

            // fill the intermediate points of bottom side
            lay[npanel-1].bottom.fill(lay[npanel-1].left[0] , lay[npanel-1].right[0]);

            // fill the intermediate points of top side on seam
            lay[npanel-1].top.fill(lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1]);
            if ( flag == true && t2[npanel] == 5 )
            {
                for (k = 0 ; k < npb ; k++)
                    lay[npanel-1].top[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].top[k] , footV);
            }

            lay[npanel-1].panelType = panelType;

            /* Go over all the points of the foot panel and calculate their z */
            lay[npanel-1] = Zpanel(lay[npanel-1], footEdgeAtZeroZ ? ZPSC_LEFT : ZPSC_NONE);

            /* Now we develop the current foot panel */
            if ( npanel == 1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else
            {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for (k = 1 ; k < npb-1 ; k++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /* Compute the deviation of top edge of developed panel
             *   and straighten this top edge except if this is the top panel flag==true */
            if ( flag == false )
            {
                vb= CMatrix::rot3d(2,PI/2)*CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb-1 ; k++)
                {
                    vk = CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v = vb * -(vk * vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Add the seam and hems allowance to the foot panels */
            if ( flag == true )
                dev[npanel-1].add6Hems( footHemW, footHemW, luffHemW, 0, 0, 0 );
            else {
                if ( t2[npanel-1] == 2 && t2[npanel] == 2 )
                    dev[npanel-1].add6Hems( footHemW, footHemW, seamW, luffHemW, luffHemW, 0 );
                else if ( t2[npanel-1] == 5 && t2[npanel] < 5 )
                    dev[npanel-1].add6Hems( footHemW, footHemW, seamW, luffHemW, 0, 0 );
                else
                    dev[npanel-1].add6Hems( footHemW, footHemW, seamW, 0, 0, 0 );

            }
            /* Check the width of developed foot panel */
            exc = dev[npanel-1].boundingRect().height() - cw;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0 && cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        deviaPrev = deviation;

        // add assembly lines
        switch (dev[npanel-1].panelType) {
        case PANEL_MITRE_FOOT_MITRE:
            dev[npanel-1].addAssemblyLines(0, footTapeDistance, 0, false);
            break;
        case PANEL_MITRE_FOOT_LUFF:
            dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, 0, false);
            break;
        case PANEL_MITRE_FOOT_MITRE_LUFF:
            dev[npanel-1].addAssemblyLines(luffTapeDistance, footTapeDistance, 0, false);
            break;
        default: // we shouldn't get anything else really
            break;
        }

        /* Now we reposition the developed panel such that bottom left is X=0 Y=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    } /* Loop FOR next foot panel seam /////////// */

    /* Store the number of panels in foot */
    npanelFoot = npanel;
    if (npanel == MAX_PANELS/2 -1)
        throw layout_error("CSailWorker::LayoutMitre -5 : Foot got to MAX_PANELS/2 without reaching tack, do increase cloth width.");

    p1[npanel] = clew; // re-initialising at clew point
    p2[npanel] = clew;
    t1[npanel] = 5;    // type=5=mitre intersection
    t2[npanel] = 4;    // type=4=leech intersection

    /** Then lay the leech panels perpendicular to the leech,
     *  starting from clew and moving upwards to the peak.  */

    flag = false;
    for ( npanel = npanel +1 ; npanel < MAX_PANELS -1 ; npanel++ )
    {
        real exb = 0; // total correction
        real exc = 0; // current excess of width
        cnt = 0; // reset counter of iterations

        /* Loop for optimising the seam position to fit cloth width */
        do
        {
            cnt++;
            int cw = panelWidth[npanel-1]; // > 1000 ? clothW / 2 : clothW;
            p2[npanel] = p2[npanel-1] + (cw -seamW -exb) * leechV.unit();
            t2[npanel] = 4; // type2=4=leech intersection for all horizontally cut panels
            seamL = CSubSpace3d::line(p2[npanel] , leechVP);

            if (CVector3d(p2[npanel]-peak) * leechV >= 0)
            { // we are above peak, stop last panel
                flag = true;
                p2[npanel] = peak;

                // check on which side of the sail the previous point p1 is located
                if ( t1[npanel-1] == 5 )
                { // previous seam on mitre
                    p1[npanel] = head;
                    t1[npanel] = 2; // set on luff
                    panelType = PANEL_MITRE_LEECH_MITRE_LUFF;

                    // left points on mitrePt-head
                    lay[npanel-1].left.fill(p1[npanel-1] , mitreLuffPt , p1[npanel]);

                    for (k = npl/2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], leechVP);
                }
                else if ( t1[npanel-1] == 2 )
                { // left points on luff
                    p1[npanel] = head;
                    t1[npanel] = 2;
                    panelType = PANEL_MITRE_LEECH_LUFF;
                    lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
                    for (k=0; k<npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], leechVP);
                }
                else
                { // left points on gaff - WE SHOULD NEVER GET HERE!!
                    p1[npanel] = peak;
                    t1[npanel] = 3;
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl-1 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k], leechVP);
                }

                // fill right points on leech
                lay[npanel-1].right.fill(p2[npanel-1],p2[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k], leechVP);

                // fill bottom points
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);

                // fill top  points
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);

                if ( t1[npanel] < 3 ) // move all top points to gaff curve
                {
                    for (k = 1 ; k < npb-1 ; k++)
                        lay[npanel-1].top[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].top[k], CVector3d (head.y()-peak.y() , peak.x()-head.x() , 0));
                }
            }
            else // normal panel //////
            {
                /* find position of luff/seam intersection relative to tack and head
                 * the case when the intersection is not a point needs to be handled */
                if ( seamL.intersect(mitreLine).getdim() == 0 )
                    ip = seamL.intersect(mitreLine).getp();
                else throw layout_error("CSailWorker::LayoutMitre leech-2 : intersection of seam and mitre is not a point!");

                if ( CVector3d(ip - mitreLuffPt) * mitreV <= 0 )
                { // seam intersects mitre
                    p1[npanel] = ip;
                    t1[npanel] = 5;  // mitre intersection
                    panelType = PANEL_MITRE_LEECH_MITRE;

                }
                else
                {
                    ip = seamL.intersect(luffLine).getp();

                    if ( CVector3d( ip - head) * luffV > 0 )
                    { // seam intersects gaff - WE SHOULD NEVER GET HERE !!!
                        p1[npanel] = seamL.intersect(gaffLine).getp();
                        t1[npanel] = 3;  // gaff type of intersection
                    }
                    else
                    { // seam intersects luff
                        p1[npanel] = ip;
                        t1[npanel] = 2;  // luff
                        panelType = t1[npanel-1] == 5 ? PANEL_MITRE_LEECH_MITRE_LUFF : PANEL_MITRE_LEECH_LUFF;

                    }
                }

                /* We now add intermediate points on all sides of the normal panel */

                /* Below is the code for the left side depending
                 *  on t1 for the top side and bottom side
                 */
                if ( t1[npanel-1] == 2 && t1[npanel] == 2 )
                { // full luff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], leechVP);
                }
                else if ( t1[npanel-1] == 3 && t1[npanel] == 3 )
                { // full gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                    for (k = 0 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k] , leechVP);
                }
                else if ( (t1[npanel-1] == 2) && (t1[npanel] == 3) )
                { // luff-head-gaff
                    lay[npanel-1].left.fill(p1[npanel-1] , head , p1[npanel]);
                    for (k = 0 ; k < npl/2 ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , leechVP);
                    for (k = npl/2 +1 ; k < npl ; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( GAFF_EDGE, lay[npanel-1].left[k] , leechVP);
                }
                else if ( (t1[npanel-1] == 5) && (t1[npanel] == 2) )
                { // mitre-luff
                    lay[npanel-1].left.fill(p1[npanel-1] , mitreLuffPt , p1[npanel]);
                    for (k = 0 ; k < npl/2 ; k++)
                        lay[npanel-1].left[k] = MitreIntersect(lay[npanel-1].left[k] , leechVP);
                    for (k=npl/2+1; k<npl; k++)
                        lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k] , leechVP);
                }
                else
                { // full mitre
                    lay[npanel-1].left.fill(p1[npanel-1] , p1[npanel]);
                }

                // Fill the intermediate points of the right side
                lay[npanel-1].right.fill(p2[npanel-1] , p2[npanel]);
                for (k = 0 ; k < npl ; k++)
                    lay[npanel-1].right[k] = EdgeIntersect( LEECH_EDGE, lay[npanel-1].right[k] , leechVP);

                // Fill the intermediate points of the top side of the leech panel
                lay[npanel-1].top.fill(lay[npanel-1].left[npl-1] , lay[npanel-1].right[npl-1]);

                // Fill the intermediate points of the bottom side of leech panel
                lay[npanel-1].bottom.fill(lay[npanel-1].left[0] , lay[npanel-1].right[0]);

            } /* end else normal panel //////////////  */

            lay[npanel-1].panelType = panelType;

            /* Now we go over all the points of the leech panel and calculate their z */
            lay[npanel-1] = Zpanel(lay[npanel-1]);

            /* Now we develop the current leech panel */
            if ( npanel == npanelFoot +1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else
            {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for (k = 1 ; k < npb -1 ; k++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /* Now we compute the deviation of top edge of the developed leech panel
             *   and straighten this top edge except if this is the top panel */
            if ( flag == false )
            {
                vb = CMatrix::rot3d(2,PI/2)*CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
                for (k = 1 ; k < npb -1 ; k++)
                {
                    vk = CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v = vb * -(vk * vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Add the seam and hems allowance to leech panels */
            if ( flag == true )
                dev[npanel-1].add6Hems( luffHemW, luffHemW, luffHemW, leechHemW, leechHemW, 0 );
            else {
                if ( t1[npanel-1] < 5 && t1[npanel] < 5 )
                    dev[npanel-1].add6Hems( hemsW, hemsW, seamW, leechHemW, leechHemW, 0 );
                else if ( t1[npanel-1] == 5 && t1[npanel] < 5 )
                    dev[npanel-1].add6Hems( mitreHemW, hemsW, seamW, leechHemW, leechHemW, 0 );
                else
                     dev[npanel-1].add6Hems( mitreHemW, mitreHemW, seamW, leechHemW, leechHemW, 0 );
           }

            /* Check the width of developed leech panel */
            exc = dev[npanel-1].boundingRect().height() - cw;

            /* Sum previous correction + 80% of current excess of width + 1mm */
            exb += 0.8 * exc + 1;
        }
        while ( exc > 0 && cnt < 9 );
        /* loop as long the excess of width is positive AND counter < 9 */

        for (k = 0 ; k < npb ; k++)
            deviaPrev[k] = deviation[k];
        switch (dev[npanel-1].panelType) {
        case PANEL_MITRE_LEECH_LUFF:
            dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, 0, false);
            break;
        case PANEL_MITRE_LEECH_MITRE_LUFF:
            dev[npanel-1].addAssemblyLines(luffTapeDistance, 0, 0, false);
            break;
        default:
            break;
        }

        /* Now we reposition the developed panel such that bottom left is X=0 Y=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;
    } /* loop FOR next seam of leech panels */

    if ( npanel == MAX_PANELS-1 )
        throw layout_error("CSailWorker::LayoutMitre -3 : Leech got to MAX_PANELS without reaching head, you need to increase cloth width ");

    /* Copy the sails for display */
    CPanelGroup sail(npanel);
    for (j = 0; j < npanel; j++)
        sail[j] = lay[j];

    /* Copy the developed sail into flatsail */
    flatsail = CPanelGroup(npanel);

    for (j = 0 ; j < npanel ; j++)
        flatsail[j] = dev[j];

    /* Prepare the displays version of the developed sail */
    dispsail = flatsail;

    for (j = 1 ; j < npanel ; j++)
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = top;
        v.x() -= bot.x();
        v.y() += 2 * seamW +10; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    // calculate luff and leech points at various heights
    calculateSailCambers();

    // broadseam info
    aBroadseamInfo = calculateBroadseams(flatsail);

    cout << "Mitre Panels" << endl;
    for (j = 0 ; j < flatsail.size() ; j++) {
        cout << "panel no = " << j << ", panel type = " << flatsail[j].panelType << endl;
    }

    return sail;
} /* end layoutMitre cut //////////////////// */


/** Creates a Mitre 2 cut sail with panels Parallel to Leech & Foot.
 *
 * @param flatsail the CPanelGroup object that will hold
 *   the developed sail
 * @param dispsail the CPanelGroup object that will hold
 *   the display version of the developed sail
 * @return CPanelGroup
 * @author Robert Laine alias Sailcuter
 * Adapted by Peter G. Meuse
 */

CPanelGroup CSailWorker::LayoutMitre2( CPanelGroup &flatsail, CPanelGroup &dispsail ) const
{
    /*  First create arrays p1 and p2 of points at the end of each seams
     *   located on the straight edge of the sail (no round)
     */
    CPoint3d p1[MAX_PANELS], p2[MAX_PANELS];

    /* Create two temporary sails lay and the corresponding dev */
    CPanelGroup lay(MAX_PANELS); // 3D sail
    CPanelGroup dev(MAX_PANELS); // developed sail

    /* create number of panels */
    unsigned int npanelFoot = 1, npanel = 1;
    unsigned int npl = lay[0].right.size();  // number of right/left points
    unsigned int npb = lay[0].bottom.size(); // number of bottom/top points

    unsigned int j = 0, k = 0, cnt = 0, cntMax = 9;
    bool flag = false;

    /* create arrays t1 and t2 of type of intersection
    *  respectively at points p1 on luff side and p2 on leech side
    *  t=1 seam intersect foot at point p1
    *  t=2 seam intersect luff
    *  t=3 seam intersect gaff
    *  t=4 seam intersect leech
    *  t=5 seam intersect mitre
    */
    int t2[MAX_PANELS];

    /* define point ip for intersections */
    CPoint3d ip;
    /* define seam line */
    CSubSpace seamL;

    /* create variables for the development and edge corrections */
    CPoint3d pt(0, 0, 0); // test point
    CPoint3d top(0, 0, 0);
    CPoint3d bot(0, 0, 0);
    CVector3d v(0, 0, 0);
    CVector3d vb(0, 0, 0);
    CVector3d vk(0, 0, 0);

    /* create variable for edge correction */
    vector<CVector3d> deviation;
    deviation.resize(npb);
    vector<CVector3d> deviaPrev;
    deviaPrev.resize(npb);

    /* create variable to monitor excess over cloth width */
    real exb = 0, exc = 0;

    /** Mitre Hem Width is set at twice the Seam Width. */
    real mitreHemW = 2 * seamW;

    /* Other edge hem */
    real luffHemW = hemsW;
    // real luffInnerHemW, footInnerHemW;

    /** Start by laying the foot panels parallel to the foot,
     *  from the foot upward toward the mitre */

    p1[0] = tack; // initialised at clew point
    p2[0] = clew; // initialised at tack point
    //t1[0] = 2;    // type 2=luff intersection.
    t2[0] = 5;    // type 5=mitre intersection

    for ( npanel = 1; npanel < MAX_PANELS/2-1; npanel++ )
    {
        // cout << " ----- FOR LOOP foot npanel = " << npanel << endl;
        exb = 0;
        //exc = 0;
        cnt = 0; // reset counter

        /* begin the loop for optimising the seam position to fit cloth width */
        do {
            cnt++;
            // move base point perpendicular to foot
            pt = p1[npanel-1] + (clothW -seamW -exb) * footVP.unit();
            seamL = CSubSpace3d::line( pt, footV );

            // find intersection on luff and mitre
            if ( seamL.intersect(luffLine).getdim() == 0 ) {
                p1[npanel] = seamL.intersect(luffLine).getp();
                //t1[npanel] = 2;
            } else
                throw layout_error("CSailWorker::LayoutMitre2 foot-a : intersection of seam and luff is not a point!"); // the case when the intersection is not a point needs to be handled

            if ( seamL.intersect(mitreLine).getdim() == 0 ) {
                p2[npanel] = seamL.intersect(mitreLine).getp();
                //t1[npanel] = 5;
            } else
                throw layout_error("CSailWorker::LayoutMitre2 foot-b : intersection of seam and mitre is not a point!"); // the case when the intersection is not a point needs to be handled

            // check if top seam is past luff mitre point
            if ( CVector3d(p2[npanel] - mitreLuffPt) * mitreV > EPS ) {
                // last foot panel is meeting Mitre luff point
                p1[npanel] = mitreLuffPt;
                p2[npanel] = p2[npanel-1]; // new top edge on mitre
                // old code p2[npanel] = mitreLuffPt;
                t2[npanel] = 2;
                flag = true; // set to get out of FOR loop
            }

            // fill right side points which are all on mitre
            lay[npanel-1].right.fill( p2[npanel-1], p2[npanel] );
            for ( k = 0; k < npl; k++ )
                lay[npanel-1].right[k] = MitreIntersect( lay[npanel-1].right[k], footV );

            // fill left side points which are all on luff
            lay[npanel-1].left.fill( p1[npanel-1], p1[npanel] );
            for ( k = 0; k < npl; k++ )
                lay[npanel-1].left[k] = EdgeIntersect( LUFF_EDGE, lay[npanel-1].left[k], footV );

            // fill bottom points
            lay[npanel-1].bottom.fill( lay[npanel-1].left[0], lay[npanel-1].right[0] );
            if ( npanel == 1 ) {
                // bottom is on the foot
                for ( k = 0; k < npb; k++ )
                    lay[npanel-1].bottom[k] = EdgeIntersect( FOOT_EDGE,lay[npanel-1].bottom[k], footVP );
            }

            // fill top side points on seam
            lay[npanel-1].top.fill( lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1] );

            /* Now we go over all the points and calculate their Z */
            lay[npanel-1] = Zpanel(lay[npanel-1]);

            /* Now we develop the current panel */
            if ( npanel == 1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for( k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /* Now we compute the deviation of top edge of developed panel
            *   and straighten this top edge except if this is the top panel
            */
            if ( flag == false ) {
                vb = CMatrix::rot3d(2, PI/2) * CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
                for( k = 1; k < npb-1; k ++) {
                    vk= CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v = vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Now we add the seam and hems allowance to the foot panels */
            if ( npanel == 1 )    // Foot panel
                dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, mitreHemW, mitreHemW, footHemW );
            else if ( flag == true )   // last foot section panel
               dev[npanel-1].add6Hems( luffHemW, luffHemW, mitreHemW, mitreHemW, 1.5*mitreHemW, 0 );
            else    // Normal Panel
                dev[npanel-1].add6Hems( luffHemW, luffHemW, seamW, mitreHemW, mitreHemW, 0 );

            /* Now we check the width of developed panel */
            exc = dev[npanel-1].boundingRect().height() - clothW; // current excess of width
            exb = exb + (0.8 * exc) +1; // sum previous correction + 80% of current excess of width +1mm

            if (cnt == cntMax)
                cout << "CSailcorker::LayoutMitre2  Foot panel " << npanel << " may be wider than cloth by " << exc << "mm." << endl;
        }
        while ( exc > 0 && cnt < cntMax );
        /* Loop DO as long as the excess of width is positive  AND counter <9 */

         deviaPrev = deviation;

        /* Reposition the developed panel such that bottom left is X=0 Y=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* Check if peak has been reached to break off */
        if ( flag == true )
            break;
    }  /* Loop FOR next seam */

    /* Store the number of panels in the foot area */
    npanelFoot = npanel;
    if ( npanelFoot == MAX_PANELS/2 -1 )
        throw layout_error("CSailWorker::LayoutMitre2 : Foot got to MAX_PANELS/2 without reaching Mitre intersection at Luff. Please increase cloth width.");

    /** Continue by laying the leech panels parallel to the leech,
     *  from the leech toward the luff intersection with the mitre. */

    p1[npanel] = clew; // re-initialising at clew point.
    p2[npanel] = peak; // initialise at the peak.
    //t1[npanel] = 5;    // type=5=mitre intersection.
    t2[npanel] = 3;    // type=3=gaff intersection.
    flag = false;

    for (npanel = npanelFoot+1; npanel < MAX_PANELS-1; npanel++)
    {
        // printf(" ----- FOR panel = %d \n" , npanel);
        exb = 0;
        //exc = 0;
        cnt = 0; // reset loop counter

        /* begin the loop for optimising the seam position to fit cloth width */
        do {
            cnt++;
            /* Determine width of Panel Perpendicular to Leech side. */
            pt = p1[npanel-1] + (clothW -seamW -exb) * leechVP.unit();
            seamL = CSubSpace3d::line(pt, leechV);

	    // find intersection on mitre
            if ( seamL.intersect(mitreLine).getdim() == 0 ) {
		p1[npanel] = seamL.intersect(mitreLine).getp();
                if ( p1[npanel].x() >= clew.x() ) // point beyong clew
                    p1[npanel] = clew;
                //t1[npanel] = 5; // type1=5= mitre intersection vertically cut panels
            }
            else
               throw layout_error("CSailWorker::LayoutMitre2 leech -c : intersection of seam and mitre is not a point!"); // the case when the intersection is not a point needs to be handled

            // check if top seam is passed luff mitre point
            if ( CVector3d(p1[npanel] - mitreLuffPt) * mitreV > EPS) {
		// last leech panel
                p1[npanel] = p1[npanel-1]; // new top edge on mitre
		// old code  p1[npanel] = mitreLuffPt;
                //t1[npanel] = 5;   // Type=5=Mitre instersection.
                p2[npanel] = mitreLuffPt;
                t2[npanel] = 2;   // Type=2=Luff intersection.
                flag=true; // to get out of FOR
            }
            else {
                // printf ("normal panel \n");
                 if ( seamL.intersect(gaffLine).getdim() == 0 )
                    p2[npanel] = seamL.intersect(gaffLine).getp();
                else
		    throw layout_error("CSailWorker::LayoutMitre2 leech -d : intersection of seam and gaff is not a point!");
                    /* the case when the intersection is not a point needs to be handled */

                if ( CVector3d(p2[npanel]-head)*gaffV > EPS )
                    t2[npanel] = 3;   // Intersect is on the Gaff.
                else {
                    if ( seamL.intersect(luffLine).getdim() == 0 )
                        p2[npanel] = seamL.intersect(luffLine).getp();
                    else
			throw layout_error ("CSailWorker::LayoutMitre2 leech -e : intersection of seam and luff is not a point!");
                    /* the case when the intersection is not a point needs to be handled */
                    t2[npanel] = 2;  // Intersect is on the Luff
                }
            }

            // fill right side points
            if ( t2[npanel-1] == 2 && t2[npanel] == 2 ) {
                 // cout << "CSailWorker::LayoutMitre2 full luff" << endl;
                lay[npanel-1].right.fill(p2[npanel-1], p2[npanel]);
                for ( k = 0; k < npl; k++ )
                    lay[npanel-1].right[k]=EdgeIntersect( LUFF_EDGE, lay[npanel-1].right[k], leechV);
            }
            else if ( t2[npanel-1] == 3 && t2[npanel] == 2 ) {
                // cout << "CSailWorker::LayoutMitre2 gaff-head-luff" << endl;
                lay[npanel-1].right.fill(p2[npanel-1], head, p2[npanel]);

                for ( k = 0; k < npl/2; k++ )
                    lay[npanel-1].right[k] = EdgeIntersect( GAFF_EDGE,lay[npanel-1].right[k], leechV);

                for ( k = npl/2+1; k < npl; k++ )
                    lay[npanel-1].right[k] = EdgeIntersect( LUFF_EDGE,lay[npanel-1].right[k], leechV);
            }
            else {
                // cout << "CSailWorker::LayoutMitre2 full gaff << endl;
                lay[npanel-1].right.fill(p2[npanel-1], p2[npanel]);

                for ( k = 0; k < npl; k++ )
                    lay[npanel-1].right[k] = EdgeIntersect( GAFF_EDGE,lay[npanel-1].right[k], leechV);
            }

            // fill left side points which are all on the mitre
            lay[npanel-1].left.fill(p1[npanel-1], p1[npanel]);
            if (p1[npanel-1] == p1[npanel]) { // clew limit
                for ( k = 0; k < npl; k++ )
                    lay[npanel-1].left[k] = lay[npanel-1].left[k];
            }
            else
                for ( k = 0; k < npl; k++ )
                    lay[npanel-1].left[k] = MitreIntersect(lay[npanel-1].left[k], leechV);

            // fill bottom points
            lay[npanel-1].bottom.fill(lay[npanel-1].left[0], lay[npanel-1].right[0]);
            if ( npanel == npanelFoot +1 ) {  // bottom is on the leech
                for ( k = 0; k < npb; k++ )
                    lay[npanel-1].bottom[k] = EdgeIntersect( LEECH_EDGE,lay[npanel-1].bottom[k], leechVP);
            }

            // fill top side points on seam
            lay[npanel-1].top.fill(lay[npanel-1].left[npl-1], lay[npanel-1].right[npl-1]);
            /* Now we go over all the points and calculate their z */
            lay[npanel-1] = Zpanel(lay[npanel-1]);

            /* Now we develop the current panel */
            if ( npanel == npanelFoot +1 )
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_TOP);
            else {
                dev[npanel-1] = lay[npanel-1].develop(ALIGN_BOTTOM);
                // add deviation of previous panel top edge to bottom edge
                for( k = 1; k < npb-1; k ++)
                    dev[npanel-1].bottom[k] = dev[npanel-1].bottom[k] + deviaPrev[k];
            }

            /* Now we compute the deviation of top edge of developed panel
            *  and straighten this top edge except if this is the top panel */
            if ( flag == false ) {
                vb = CMatrix::rot3d(2,PI/2) * CVector3d(dev[npanel-1].top[npb-1] -dev[npanel-1].top[0]).unit();
                for( k = 1; k < npb-1; k++ )
                {
                    vk = CVector3d (dev[npanel-1].top[k] - dev[npanel-1].top[0]);
                    v = vb * -(vk*vb);
                    deviation[k] = v;
                    dev[npanel-1].top[k] = dev[npanel-1].top[k] + deviation[k];
                }
            }

            /* Now we add the seam and hems allowance to the leech panels*/
            if ( npanel == npanelFoot +1 )
                dev[npanel-1].add6Hems( 0, 0, seamW, hemsW, hemsW, leechHemW );
            else if( flag == true )
                dev[npanel-1].add6Hems( 0, 0, 0, luffHemW, luffHemW, 0 );
                // old code dev[npanel-1].add6Hems( 0, 0, luffHemW, hemsW, hemsW, 0 );
            else
                dev[npanel-1].add6Hems( 0, 0, seamW, hemsW, hemsW, 0 );

            /* Now we check the width of developed panel and correct for the next loop */
            exc = dev[npanel-1].boundingRect().height() - clothW;

            exb = exb + (0.8 * exc) + 1; // sum previous correction + 80% of current excess of width +1mm

            if (cnt == cntMax)
                cout << "CSailWorker::LayoutMitre2  Leech panel " << npanel << " may be wider than cloth by " << exc << "mm." << endl;
        }
        while ( exc > 0 && cnt < cntMax );
        /* loop DO as long as the excess of width is positive  AND counter <9 */

        deviaPrev = deviation;

        /* Now we reposition the developed panel such that bottom left is X=0 Y=0 */
        dev[npanel-1] = dev[npanel-1].reframe(LOW_LEFT);

        /* check if peak has been reached to break off */
        if ( flag == true )
            break;

    }  /* Loop FOR next seam */

    if ( npanel == MAX_PANELS -1 )
        throw layout_error("CSailWorker::LayoutMitre2 -f : MAX_PANELS without reaching Miter Intersect Point at Luff. Please increase cloth width.");

    /* Copy the sails for display */
    CPanelGroup sail(npanel);
    for( j = 0; j < npanel; j++ )
        sail[j] = lay[j];

    /* Copy the developed sail into flatsail */
    flatsail = CPanelGroup(npanel);

    for ( j = 0; j < npanel; j++ )
        flatsail[j] = dev[j];

    /*  Prepare the displays version of the developed sail */
    dispsail = flatsail;

    for ( j = 1; j < npanel; j++ )
    {
        top = dispsail[j-1].top[0];
        bot = dispsail[j].bottom[0];

        // translation v to align panel bottom edge origin to previous panel upper edge origin
        v = top;
        v.x() -= bot.x();
        v.y() += 2*seamW +10; // adding offset to separate panels vertically

        dispsail[j] = dispsail[j] + v;
    }

    return sail;
} /* end LayoutMitre2 ////////////////// */


/** Routine used for computing the cord of the profiles.
 *  Return a 3d point which is the aft intersection of
 *  the horizontal line passing by p1 with the leech.
 *  If the point p1 is above or below the leech segment then
 *  the aft intersection is forced to be on the vertical of the
 *  corresponding peak or clew.
 *
 * @author Robert Laine alias Sailcuter
 */
CPoint3d CSailWorker::AftIntersect( const CPoint3d& pt1 ) const
{
    // real x=0, y=0, z=0; // for debugging only

    CPoint3d pAft = pt1; // aft intersection point is initialised at p1
    CVector3d vH = CVector3d( 1, 0, 0 );

    if ( pt1.y() >= peak.y() )
    {   // rear point above the peak, set output on vertical above peak
        pAft.x() = peak.x();
    }
    else if ( pt1.y() <= clew.y() )
    {   // rear point on or below the clew, set output on vertical below clew
        pAft.x() = clew.x();
    }
    else
    {   // move point on leech which is not straight
        pAft = EdgeIntersect( LEECH_EDGE, pt1, vH );
    }
    // ensure that Z=0
    pAft.z() = 0;
    //
    return pAft;
}


/**
 *  Routine for computing the area of the sail taking
 *  into account the luff and leech round.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::Area()
{
    real surface = luffV.cross(footV).norm() / 2;
    surface = surface + leechV.cross(gaffV).norm() / 2;
    surface = surface + .75*(luffL*luffR + footL*footR + leechL*leechR + gaffL*gaffR);

    return ( .01 * floor(surface /10000) );
}


/**
 *  Routine for computing the diagonal length from head to clew.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::Diagonal()
{
    //return floor( CVector3d(head-clew).norm() );
    return floor(calculate3dDistance(throat, clew));
}


/**
 *  Routine for computing the width of the sail at a given
 *  relative height on the leech in accordance with IRC rule.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::IRCwidth( const real &HL )
{
    unsigned int i, imax=10;
    real h1=0, h2=0, LL=0, l1=0, w=0;
    CPoint3d p, p1, p2, p3;
    //printf ("IRC height = %f \n", HL);

    /// compute the leech edge length LL
    h1 = 1;
    LL = LeechLength( h1 );
    //printf ("IRC leech length = %f \n", LL);

    /* compute the point on leech for relative length HL */
    h2 = HL;
    //do
    {
        h1 = h2;
        l1 = LeechLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
        h1 = h2;
        l1 = LeechLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
    }
    //while ( fabs(h1-h2)>.001 );

    /* compute the shortest distance to the real luff */
    p1 = clew + leechV*h2;
    p2 = Zpoint(EdgeIntersect( LEECH_EDGE, p1, leechVP));

    p1 = Zpoint(EdgeIntersect( LUFF_EDGE, p2, luffVP));

    w = 0;
    p3 = p1;

    for (i = 1; i <= imax; i++)
    {
        h1 = real(i) / imax;
        p = Zpoint(p1 +CVector3d(p2 - p1) * h1);
        w = w + CVector3d(p - p3).norm();
        p3 = p;
    }

    return ( w );
}


/**
 *  Routine for computing the width of the sail at a given
 *  relative height on the luff and the leech.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::SailWidth( const  real  &HL )
{
    unsigned int i, imax=10;
    real h=0, h1=0, h2=0, LeL=0, LuL=0, l1=0, w=0;
    CPoint3d p, p1, p2, p3;
    //printf ("IRC height = %f \n", HL);

    // compute the leech edge length LeL
    h = 1;
    LeL = LeechLength( h );
    //printf ("IOR leech length = %f \n", LeL);

 //   cout << "SailWidth: LeL =" << LeL << endl;
    /* compute the height of point on leech for relative length HL */
    h2 = HL;
    //do
    {
        h = h2;
        l1 = LeechLength( h );
        h2 = h * (1-(l1 - LeL*HL) / (LeL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h, h2);
        h = h2;
        l1 = LeechLength(h);
        h2 = h * (1-(l1 - LeL*HL) / (LeL*HL));
        //printf (" HL=%f  l1=%f  h=%f - h1=%f \n", HL, l1, h, h2);
    }
    //while ( fabs(h1-h2)>.001 );

    /* compute the luff edge length LuL */
    h = 1;
    LuL = LuffLength( h );
    //printf ("IOR luff length = %f \n", LuL);

    /* compute the height of point on luff for relative length HL */
    h1 = HL;
    //do
    {
        h = h1;
        l1 = LuffLength( h );
        h1 = h * (1 - (l1 - LuL*HL) / (LuL*HL) );
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h, h1);
        h = h1;
        l1 = LuffLength( h );
        h1 = h * (1 - (l1 - LuL*HL) / (LuL*HL) );
        //printf (" HL=%f  l1=%f  h=%f - h1=%f \n", HL, l1, h, h1);
    }
    //while ( fabs(h1-h2)>.001 );
   // cout << "SailWidth: h1 =" << h1 << endl;


    /* compute the shortest distance real leech to the real luff */
    p = clew + leechV * h2;
    p2 = Zpoint(EdgeIntersect( LEECH_EDGE, p , leechVP, sailType == MAINSAIL) );

    p = tack + luffV * h1;
    p1 = Zpoint(EdgeIntersect( LUFF_EDGE, p , luffVP) );

//    cout << "SailWidth: p1 =" << p1 << endl;
//    cout << "SailWidth: p2 =" << p2 << endl;
    w = 0;
    p3 = p1;

    for (i = 1; i <= imax; i++)
    {
        h1 = real(i) / imax;
        p = Zpoint( p1 + CVector3d(p2 - p1) * h1 );
        w = w + CVector3d(p - p3).norm();
        p3 = p;
    }
    return ( w );
}


/**
 *  Routine for computing the perpendicular width of the sail
 *  from clew to luff, measured perpendicular to the luff.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::SailLP( )
{
    unsigned int i, imax=10;
    real h1=0, w=0;
    CPoint3d p, p1, p2, p3;
    CVector3d v;

    p1 = Zpoint( EdgeIntersect( LUFF_EDGE, clew , luffVP) );
    v = CVector3d(clew - p1);
    p2 = p1;

    // compute the distance from the real luff to clew
    for (i = 1 ; i <= imax ; i++)
    {
        h1 = real(i) / imax;
        p =  p1 + v * h1 ;
        p.z() = 0;
        p3 = Zpoint( p );
        w = w + CVector3d(p3 - p2).norm();
        p2 = p3;
    }
    //
    return ( w );
}

/**
 *  Routine for computing the perpendicular width of the sail
 *  from clew to luff, measured perpendicular to the luff.
 *
 * @author Robert Laine alias Sailcuter
 */
//real CSailWorker::LeechP( )
//{
//    unsigned int i, imax=10;
//    real h1=0, w=0;
//    CPoint3d p, p1, p2, p3;
//    CVector3d v;
//
//    p1 = Zpoint( EdgeIntersect( LEECH_EDGE, tack , LeechVP) );
//    v = CVector3d(tack - p1);
//    p2 = p1;
//
//    // compute the distance from the real luff to clew
//    for (i = 1 ; i <= imax ; i++)
//    {
//        h1 = real(i) / imax;
//        p =  p1 + v * h1 ;
//        p.z() = 0;
//        p3 = Zpoint( p );
//        w = w + CVector3d(p3 - p2).norm();
//        p2 = p3;
//    }
//    //
//    cout << "Leech LP is " << w << endl;
//
//    return ( w );
//}

/**
 *  Routine for computing the actual length of the leech edge
 *  up to a given relative heigth on straight leech line.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::LeechLength( const real &h )
{
    unsigned int i=0, imax=40;
    CPoint3d p1, p2, p3;
    real l=0, h1=0;

    p1 = clew;

    for (i = 1; i <= imax; i++)
    {
        h1= real(i) / imax;
        p2 = clew + leechV * (h * h1);
        p3 = Zpoint( EdgeIntersect( LEECH_EDGE, p2 , leechVP) );
        l = l + CVector3d(p3 - p1).norm();
        // printf ("step = %f - p2.y = %f - leech length = %f \n", h1, p2.y(), l);
        p1 = p3;
    }
    return ( l );
}


/**
 *  Routine for computing the actual length of the luff edge
 *  up to a given relative heigth on straight luff line.
 *
 * @author Robert Laine alias Sailcuter
 */
real CSailWorker::LuffLength( const real &h )
{
    unsigned int i=0, imax=40;
    CPoint3d p1=tack, p2, p3;
    real l=0, h1=0;

    for (i = 1 ; i < imax ; i++)
    {
        h1= real(i) / imax;
        p2 = tack + luffV * (h * h1);
        p3 = Zpoint( EdgeIntersect( LUFF_EDGE, p2 , luffVP ) );
        l = l + CVector3d(p3 - p1).norm();
        p1 = p3;
    }
    return ( l );
}


real CSailWorker::calculateDistanceAroundLuffCurve(CPoint3d pStart, CPoint3d pEnd) {
    unsigned int i=0, imax=20;
    CPoint3d p1=pStart, p2, p3;
    real l=0, h1=0;
    CVector3d v = pEnd - pStart;

    for (i = 1 ; i < imax ; i++)
    {
        h1= real(i) / (real)imax;
        p2 = pStart + v * h1;
        p3 = Zpoint( EdgeIntersect( LUFF_EDGE, p2 , luffVP ) );
        l = l + CVector3d(p3 - p1).norm();
        p1 = p3;
    }

    l += CVector3d(pEnd - p1).norm();

    return ( l );

}

/**
 *  Routine used for computing the forward end of the cord of the profile.
 *  Return a 3d point which is the forward intersection of
 *  the horizontal line passing by p1 with either foot, luff or gaff.
 *
 * @author Robert Laine alias Sailcuter
 */
CPoint3d CSailWorker::FwdIntersect( const CPoint3d &pt1 ) const
{
    CPoint3d pFwd = pt1; // forward intersection point initialised at p1
    CVector3d vH = CVector3d( 1, 0, 0 );

    if ( pt1.y() <= tack.y() )  // point is at or below tack
    {
        pFwd.x() = tack.x();  // set forward point on vertical below tack
        // pFwd.z() = tack.z();
    }
    else if ( pt1.y() < head.y() ) // forward point is on luff curve
    {
        pFwd = EdgeIntersect( LUFF_EDGE, pt1, vH );
    }
    else if ( pt1.y() == head.y() )  // point exactly at head height
    {
        pFwd.x() = head.x();
        // pFwd.z() = head.z();
    }
    else if ( pt1.y() < peak.y() )
    {   // forward point is on gaff
        pFwd = EdgeIntersect( GAFF_EDGE, pt1, vH );
    }
    else
    { // point is above peak
        pFwd.x() = peak.x(); // set forward point on vertical above peak
        //pFwd.z() = peak.z(); //
    }
    // Ensure Z = 0
    pFwd.z() = 0;
    //
    return pFwd;
} /*  end FwdIntersect //////////////// */


/**
 *  Routine used for computing the point position on a sail curved edge.
 *  Return a 3D point which is the intersection of the vector v1
 *  passing by pt1 point inside sail area with the Edge curve.
 *
 * @author Robert Laine alias Sailcuter
 */
CPoint3d CSailWorker::EdgeIntersect( const enumEdgeType &Edge, const CPoint3d &pt1, const CVector3d &v1, bool bBattenHollow ) const
{
    if ( v1.norm() <= EPS )
        throw layout_error("CSailWorker::EdgeIntersect : input vector is nul");

    // Input line
    CSubSpace InputLine = CSubSpace3d::line( pt1 , v1 );
    // Edge end points
    CPoint3d pEnd1, pEnd2;
    // Edge Vector
    CVector3d vEdge;
    // Edge perpendicular vector toward outside of sail
    CVector3d vpEdge;
    // Edge round
    real EdgeR = 0;
    // Edge round position from end1 toward end2
    int EdgeRP;

    switch ( Edge )
    {
    case LUFF_EDGE:
        pEnd1 = tack;
        pEnd2 = head;
        EdgeR = luffR;
        EdgeRP = luffRP;
        vEdge = CVector3d( pEnd2 - pEnd1 );
        vpEdge = CMatrix::rot3d(2 , PI/2) * vEdge.unit();
        break;

    case GAFF_EDGE:
        pEnd1 = head;
        pEnd2 = peak;
        EdgeR = gaffR;
        EdgeRP = gaffRP;
        vEdge = CVector3d( pEnd2 - pEnd1 );
        vpEdge = CMatrix::rot3d(2 , PI/2) * vEdge.unit();
        break;

    case FOOT_EDGE:
        pEnd1 = tack;
        pEnd2 = clew;
        EdgeR = footR;
        EdgeRP = footRP;
        vEdge = CVector3d( pEnd2 - pEnd1 );
        vpEdge = CMatrix::rot3d(2 , -PI/2) * vEdge.unit();
        break;

    case LEECH_EDGE:
        pEnd1 = clew;
        pEnd2 = topBack;
        EdgeR = leechR;
        EdgeRP = leechRP;
        vEdge = CVector3d( pEnd2 - pEnd1 );
        vpEdge = CMatrix::rot3d(2 , -PI/2) * vEdge.unit();
        //if (bTrace) {
        //    cout << "LEECH_EDGE  point = " << pt1 << ", vector = " << v1 << endl;
        //}
        break;

    case BATTEN_HOLLOW: {
        //real h = (pt1.y()-clew.y()) / (topBack.y()-clew.y());
        unsigned int idx = findBattenIndexAtHeight(pt1);
        if (idx == 0) {
            pEnd1 = clew;
            pEnd2 = (const_cast<CBattenGroup&>(battenGroup)).getBatten(0).aftPoint;
        } else if (idx == battenGroup.numBattens()) {
            pEnd1 = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).aftPoint;
            pEnd2 = topBack;
        } else {
            pEnd1 = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).aftPoint;
            pEnd2 = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx).aftPoint;
        }

        EdgeRP = 50;
        vEdge = CVector3d( pEnd2 - pEnd1 );
        EdgeR = real(battenHollowPC)/100.0*vEdge.norm();
        vpEdge = /*leechVP;*/CMatrix::rot3d(2 , -PI*3/2) * vEdge.unit();
        //if (bTrace) {
        //    cout << "BATTEN_HOLLOW  point = " << pt1 << ", vector = " << v1 << ", pEnd1 = " << pEnd1 << ", pEnd2 = " << pEnd2 << endl;
        //}

        break;
    }
    }

    // Edge line
    CSubSpace Line2 = CSubSpace3d::line( pEnd1, vEdge );

    real h1=0, h2=0, d1=0, d2=0;
    CPoint3d p0 , p1 , p2 , p3;
    CVector3d v;

    // find point p0 at intersection of straight edge with input line
    if ( InputLine.intersect( Line2 ).getdim() == 0 ) {
        p0 = InputLine.intersect( Line2 ).getp();
        p2 = p0;    // default output
        //if (bTrace) cout << "p0 = " << p0 << endl;
    }
    else {
    	cout << "CSailWorker::EdgeIntersect -1 : intersection with edge is not a point!" << endl;
    	cout << "edge = " << Edge << endl;
    	cout << "pt1 = " << pt1 << endl;
    	cout << "v1 = " << v1 << endl;
    	throw layout_error("CSailWorker::EdgeIntersect -1 : intersection with edge is not a point!");
    }

    if ( CVector3d(p0 - pEnd1) * vEdge <= 0 )
        p2 = pEnd1;  // intersection left of edge
    else if ( CVector3d(p0 - pEnd2) * vEdge >= 0 )
        p2 = pEnd2;  // intersection right of edge
    else if ( fabs(EdgeR) > 1 ) {   // intersection is on curved edge
        h1 = CVector3d(p0 - pEnd1).norm() / (vEdge.norm() + EPS); // relative height
        switch (Edge) {
        case LEECH_EDGE:
        	d1 = calculateLeechPoint(EdgeR, h1, EdgeRP);
        	break;
        default:
            d1 = EdgeR * RoundP(h1 , EdgeRP); // local depth of edge curve
        }
        p1 = p0 + vpEdge * d1;
        //if (bTrace) cout << "h1 = " << h1 << ", p0 = " << p0 << ", p1 = " << p1 << ", d1 = " << d1 <<endl;

        // define a line parrallel to edge at distance d1
        Line2 = CSubSpace3d::line( p1 , vEdge );

        // point2 at intersection of input line with parrallel to edge is always valid
        p2 = InputLine.intersect( Line2 ).getp();

        v = CVector3d( p2 - p1);

        if ( v.norm() >= /*EPS*/0.001 ) {
            // translate point0 on straight edge
            p3 = p0 + v;

            // check if p3 is inside edge
            if ( CVector3d(p3 - pEnd1) * vEdge <= 0 ) // p3 outside left of edge end
                p2 = pEnd1;
            else if ( CVector3d(p3 - pEnd2) * vEdge >= 0 ) // p3 outside right of edge end
                p2 = pEnd2;
            else {   // point is on edge curve
                h2 = CVector3d(p3 - pEnd1).norm() / (vEdge.norm() + EPS);
//                d2 = EdgeR * RoundP( h2 , EdgeRP ); // local depth of edge curve
                //if (bTrace) cout << "h2 = " << h2 <<endl;

                switch (Edge) {
                case LEECH_EDGE:
                	d2 = calculateLeechPoint(EdgeR, h2, EdgeRP);
                	break;
                default:
                    d2 = EdgeR * RoundP(h2 , EdgeRP); // local depth of edge curve
                }

                p2 = p3 + vpEdge * d2;
            }

            v = CVector3d ( p2 - p1 );

            if ( v.norm() <= /*EPS*/0.001 )
                // keep p1 which is strictly on input line
                p2 = p1;
            else {   // displaced point 2 and p1 are used for Line2
                Line2 = CSubSpace3d::line( p1 , v );
                // compute final intersection point p2
                p2 = InputLine.intersect( Line2 ).getp();
            }
        }
    }

    if (Edge == LEECH_EDGE && bBattenHollow && bUseBattensForLeech && battenGroup.numBattens() > 0 && battenHollowPC > 0) {
        v = CVector3d(p0-p2);
        if (v.norm() > EPS) {
            //if (bTrace) cout << "p2 pre = " << p2 << endl;
            p2 = EdgeIntersect(BATTEN_HOLLOW, p2, v1);
            //if (bTrace) cout << "p2 post = " << p2 << endl;
        }
    }

    //
    return p2;
} /* end  EdgeIntersect //////////////////// */

/**
 * @brief CSailWorker::FillCurvedEdge fill the edge point of a side
 * @param Edge edge type
 * @param side the side
 * @param v the vector
 * @return a filled side
 */
CSide CSailWorker::FillCurvedEdge( const enumEdgeType &Edge, const CSide &side, const CVector3d &v ) const {
    CSide ret;
    ret.clear();

    for (unsigned int i=0; i<side.size(); i++) {
        ret.push_back(EdgeIntersect(Edge, side[i], v));
    }

    return ret;
}

real CSailWorker::calculateLeechPoint(real e, real h, int ep) const {
	real d1 = 0;
//    if (bTrace) {
//        cout << "calculateLeechPoint: bUseBattensForLeech=" <<bUseBattensForLeech << endl;
//        cout << "calculateLeechPoint: battenGroup.numBattens()=" <<battenGroup.numBattens() << endl;
//    }

    // NEED TO MOD HERE FOR STRAIGHT LINE LEECH BETWEEN BATTEN ENDS
    if (bUseBattensForLeech && battenGroup.numBattens() > 0 ) {
 //       if (bTrace) {
 //           cout << "calculateLeechPoint: using battens" << endl;
 //       }
        real hHigh, hLow, dHigh, dLow;

        unsigned int idx = findBattenIndexAtHeight(h);

        if (idx == 0) {
            hHigh = (const_cast<CBattenGroup&>(battenGroup)).getBatten(0).percentHeight / 100.0;
            dHigh = (const_cast<CBattenGroup&>(battenGroup)).getBatten(0).roundDepth;
            hLow = 0;
            dLow = 0;
        } else if (idx == battenGroup.numBattens()) {
            hLow = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).percentHeight / 100.0;
            dLow = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).roundDepth;
            dHigh = 0;
            hHigh = 1;
        } else {
            hLow = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).percentHeight / 100.0;
            dLow = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx-1).roundDepth;
            hHigh = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx).percentHeight / 100.0;
            dHigh = (const_cast<CBattenGroup&>(battenGroup)).getBatten(idx).roundDepth;
        }

        //d1 = e * RoundP(h , ep); // local depth of edge curve
        d1 = dLow + (dHigh - dLow) * (h - hLow) / (hHigh - hLow);
    } else if (straightLineLeech) {
 //       if (bTrace) {
 //           cout << "calculateLeechPoint: straight line leech" << endl;
 //       }
	    d1 = e * StraightP(h , ep); // local depth of edge with straight line leech
	} else {
//        if (bTrace) {
//            cout << "calculateLeechPoint: round leech" << endl;
//        }
	    d1 = e * RoundP(h , ep); // local depth of edge curve
	}

	return d1;
}

/*
find batten whose height is greater than the input height (0-1)

return the index of that batten. If height is > than all battens
the return number of battens
*/
int CSailWorker::findBattenIndexAtHeight(real h) const {
    for (unsigned int i=0; i< battenGroup.numBattens(); i++) {
        CBatten& b = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i);
        if (b.percentHeight/100.0 > h) {
            return i;
        }
    }
    return battenGroup.numBattens();
}

/**
 * @brief CSailWorker::findBattenIndexAtHeight
 * find the batten who's aft point y value is above the supplied point
 * @param p the CPoint3d object who's y value will be used
 * @return the index of the batten above the point or
 * the number of battens if point is higher than all the battens
 */
int CSailWorker::findBattenIndexAtHeight(CPoint3d p) const {
    for (unsigned int i=0; i< battenGroup.numBattens(); i++) {
        CBatten& b = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i);
        if (b.aftPoint.y() > p.y()) {
            return i;
        }
    }
    return battenGroup.numBattens();
}

/** 
 *  Routine used for computing the intersection with mitre line.
 *  Return a 3d point which is the intersection of the vector v1
 *  passing by pt1 point with the mitre line.
 *
 * @author: Robert Laine alias Sailcuter
 */
CPoint3d CSailWorker::MitreIntersect( const CPoint3d &pt1, const CVector3d &v1 ) const
{
    if ( v1.norm() <= EPS )
        throw layout_error("CSailWorker::MitreIntersect : input vector is nul");
    // real x=0, y=0, z=0; // for debugging only

    /* straight line passing through input point */
    CSubSpace ptv1 = CSubSpace3d::line(pt1 , v1);

    CPoint3d p2 = pt1;

    if ( CVector3d(p2 - clew).norm() <= EPS )
        p2 = clew;
    else {
        /* point at intersection of input vector and mitre
           ckecking if it is inside segment or not is in LayoutMitre */
        if ( ptv1.intersect(mitreLine).getdim() == 0 )
            p2 = ptv1.intersect(mitreLine).getp();
        else
            throw layout_error("CSailWorker::MitreIntersect -1 : intersection with mitre is not a point!");
    }
    return p2;
}


/**
 *  Routine used for computing the Z of a point of the sail.
 *  Return a 3D point which is the input point p1 with its Z modified.
 *
 * @author Robert Laine alias Sailcuter
*/
CPoint3d CSailWorker::Zpoint( const CPoint3d &pIn, enum enumZpanelSupressCalc zpsc ) const
{
    CPoint3d p1 = CPoint3d(pIn.x(), pIn.y(),0);
    CPoint3d p2 = p1;      // p2 will be the returned point with Z added to p1
    //real y = tack.y() > clew.y() ? clew.y() : tack.y();
    real baseY;
    if (p1.x() <= tack.x()) {
        baseY = tack.y();
    } else if (p1.x() >= clew.x()) {
        baseY = clew.y();
    } else {
        baseY = tack.y() + (clew.y()-tack.y()) * (p1.x()-tack.x()) / (clew.x() - tack.x());
    }
    /* computing the relative height on the sail */
    real h1 = (p1.y() - baseY) / (peak.y() - baseY);  // for mould

    real x=0,  z=0, twist=0, pivotX=0, pos=0, cord=1;
    CPoint3d pFwd = FwdIntersect( p1 );   // forward end of the cord
    CPoint3d pAft = AftIntersect( p1 );    // rear end of the cord

    /* computing local cord of the profile */
    if (p1.y() < baseY) {
        cord = footV.norm();
    } else {
        cord = CVector3d( pAft - pFwd ).norm();
    }

    //if (p1.y() <= max(tack.y(), clew.y())) {
    //    cout << "p1 = " << p1 << ", tack = " << tack << ", clew = " << clew << ", cord = " << cord << ", y = " << y << ", h1 = " << h1 << endl;
    //}

    /* computing Z from normalised position on profile */
    if ( cord < 1 )   // to avoid division by cord = zero
    {
        //pos = 0 ;
        z = 0;
    }
    else   // position on profile
    {
        pos = ( CVector3d( p1 - pFwd ).norm() ) / cord;

        bool flag = false;
        double dFootToPoint = 0;
        if (zpsc == ZPSC_FOOT || zpsc == ZPSC_LEFT) {
            if (p1.y() < tack.y() || p1.y() < clew.y()) {
                dFootToPoint = Distance3d(p1, tack, clew);
                if (dFootToPoint < 0) {
                    flag = true;
                }
            }
        }

        if (flag) {
            // interpolate z as being on a straight line
            // betweem the z along foot straight line (tack to clew, h= 0)
            // and 0 at the foot edge
            //
            // first find the foot edge point
            CPoint3d pFootEdge = EdgeIntersect(FOOT_EDGE, p1, vertV);
            cord = footV.norm();

            if (interpolMethod == INTERPOL2) {
                z = cord * mould.interpol2( 0 , cord).z(pos);
            } else {
                z = cord * mould.interpol( 0 ).z(pos);
            }

            double yMax = clew.y()-tack.y();
            double xMax = clew.x()-tack.x();
            double pX = p1.x()-tack.x();
            double pY = tack.y() - pFootEdge.y() + pX * yMax/xMax;

            z = z * (p1.y()-pFootEdge.y()) / pY;
        } else {

            /* Now computing actual Z  including twist and sheeting angle
            *  kluff, kleech, depth coefficient used in z1=f(pos, h1) of the
            *  sailmould are interpolated between the respective profile[0..2].
            *  The position of profile[1] is driven by vertpos which is
            *  the vertical position of the middle profile entered in the
            *  left vertical pane of formmouldbase.
            */
            CProfile profile;
            if (interpolMethod == INTERPOL2) {
                //if (isGaffSail) {
                //    real height2;
                //    if (p1.x() < throat.x()) {
                //        height2 = throat.y();
                //    } else if (p1.x() > peak.x()) {
                //        height2 = peak.y();
                //    } else {
                //        height2 = throat.y() + (peak.y()-throat.y()) * (p1.x()-throat.x()) / (peak.x()-throat.x());
                //    }

                    // convert to relative height
                //    real h2 = (height2-baseY) / (peak.y() - baseY);
                //    profile = mould.interpol2Gaff( h1 , h2, cord);
                //} else {
                    profile = mould.interpol2( h1 , cord);
                //}
            } else {
                profile = mould.interpol( h1 );
            }

            z = cord * profile.z(pos);

            if (sailType == SYMMETRIC) {
                if (h1 >= 0) {
                    if (luffOffset > 0) {
                        real zOff = RoundP(h1, luffOffsetRP);
                        real l = peak.y() - tack.y();
                        zOff = zOff * l * (luffOffset / 100);

                        z+= zOff;
                    }
                } else {
                    if (interpolMethod == INTERPOL2) {
                        profile = mould.interpol2( h1 , cord);
                    } else {
                        profile = mould.interpol( h1 );
                    }
                    real d = profile.z(pos);
                    z = cord * d;
                    //real footTightening = 0.4; // 5%
                    //ddfdfreal footDepth = profile.getDepth();
                    //real h = (tack.y() - p1.y()) / footR;
                    //real edgePos = pos <= 0.5 ? pos : 1 - pos;
                    //real f = footTightening * h ;
                    //z = z *  (1-f) ;
                }
            }
        }
    }

    /* computing the twist from the relative height on straight leech */
    real h2 = ( p1.y() - clew.y() ) / leechV.y();

    if ( h2 >= 1 )    // above peak
        h2 = 1;
    else if ( h2 <= 0 )   // below clew
        h2 = 0;

    // for CROSS2 cuts or symmetrical spinnakers we always ignore sheeting angle and twist
    if (sailCut == CROSS2 || sailType == SYMMETRIC) {
            twist = 0;
    } else {
            twist = ( h2 * twistDeg  + sheetDeg ) * PI / 180;
    }

    if ( p1.y() >= head.y() )   // on gaff
        pivotX = head.x();
    else if ( p1.y() <= tack.y() )   // below tack
        pivotX = tack.x();
    else   // on luff
        pivotX = pFwd.x();

    x = p1.x() - pivotX;

    /* applying the twist by rotating the profile around pivotX */
    p2.x() = pivotX + x * cos(twist) - z * sin(twist);
    p2.z() = x * sin(twist) + z * cos(twist);

    return p2;
} /*  end  Zpoint ///////////////// */


/**
 * Routine used for computing the Z of all the points of a panel.
 * Returns a CPanel with all its points Z's modified.
 *
 * @author Robert Laine alias Sailcuter
 */
CPanel CSailWorker::Zpanel( const CPanel &p1, enum enumZpanelSupressCalc zpsc ) const
{
    CPanel ret = p1;
    unsigned int k;
    //bool b = bTrace;
    //bTrace = false;

    if (zpsc != ZPSC_LEFT) {
        for (k = 0; k < ret.left.size(); k++)
            ret.left[k] = Zpoint(ret.left[k], zpsc);
    }

    ret.throatPoint = Zpoint(ret.throatPoint);

    if (zpsc != ZPSC_RIGHT) {
        for (k = 0; k < ret.right.size(); k++) {
            ret.right[k] = Zpoint(ret.right[k], zpsc);
        }
    }
   // bTrace = false;

    if (zpsc != ZPSC_TOP) {
        for (k = 0; k < ret.top.size(); k++)
            ret.top[k] = Zpoint(ret.top[k], zpsc);
    }

    if (zpsc != ZPSC_FOOT) {
        for (k = 0; k < ret.bottom.size(); k++)
            ret.bottom[k] = Zpoint(ret.bottom[k], zpsc);
    }

    if (zpsc == ZPSC_LUFF_FOOT) {
//        for (k = ret.right.size() / 2 +1  ; k < ret.right.size() ; k++) {
            for (k = 0  ; k < ret.right.size() / 2 ; k++) {
            ret.right[k] = Zpoint(ret.right[k], zpsc);
        }

    }

    //bTrace = b;

    return ret;
}

CPoint3d CSailWorker::LeechPoint(real &HL ) {
    //unsigned int i, imax=10;
    real h1=0, h2=0, LL=0, l1=0;
    CPoint3d p, p1, p2;
    //printf ("IRC height = %f \n", HL);

    /// compute the leech edge length LL
    h1 = 1;
    LL = LeechLength( h1 );
    //printf ("IRC leech length = %f \n", LL);

    /* compute the point on leech for relative length HL */
    h2 = HL;
    //do
    {
        h1 = h2;
        l1 = LeechLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
        h1 = h2;
        l1 = LeechLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
    }
    //while ( fabs(h1-h2)>.001 );

    /* compute the shortest distance to the real luff */
    p1 = clew + leechV*h2;
    p2 = Zpoint(EdgeIntersect( LEECH_EDGE, p1, leechVP, sailType == MAINSAIL));

    return p2;

}

CPoint3d CSailWorker::LuffPoint(real &HL ) {
    //unsigned int i, imax=10;
    real h1=0, h2=0, LL=0, l1=0;
    CPoint3d p, p1, p2;
    //printf ("IRC height = %f \n", HL);

    /// compute the leech edge length LL
    h1 = 1;
    LL = LuffLength( h1 );
    //printf ("IRC leech length = %f \n", LL);

    /* compute the point on leech for relative length HL */
    h2 = HL;
    //do
    {
        h1 = h2;
        l1 = LuffLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
        h1 = h2;
        l1 = LuffLength(h1);
        h2 = h1 * (1-(l1 - LL*HL)/(LL*HL));
        //printf (" HL=%f  l1=%f  h1=%f - h2=%f \n", HL, l1, h1, h2);
    }
    //while ( fabs(h1-h2)>.001 );

    /* compute the shortest distance to the real luff */
    p1 = tack + luffV*h2;
    p2 = Zpoint(EdgeIntersect( LUFF_EDGE, p1, luffVP));

    return p2;

}

real CSailWorker::CrossMeasurementAtDistanceFromHead(const real &distanceFromHead) {
    real lLeech = leechV.norm();
	real dist = distanceFromHead;
	real distToLeech = 0;
	real inc = 0;
	real percentHeight = 0;
    CPoint3d p, p1, p2, p3;
    real w, h1;
    unsigned int i, imax=20;

	do {
		// subtract inc for next iteration
		dist -= inc;
		// calculate cross measurement height
        percentHeight = (lLeech-dist)/lLeech;
		// find leech point
        p = LeechPoint(percentHeight);
		// calc head to leech point distance
        distToLeech = calculate3dDistance(Zpoint(p), head);
		// calc inc
		inc = .5*(distToLeech - distanceFromHead);

	} while (fabs(distToLeech - distanceFromHead) > .5);

    p2 = Zpoint(p);
    p1 = Zpoint(calculateNearestLuffPoint(p));
    cout << "CrossMeasurementAtDistanceFromHead\n\tp1 " << p1 << endl << "\tp2 " << p2 << endl;
    cout << "\tstraight line distance "<< distanceBetween(p1, p2) << endl;

    w = 0;
    p3 = p1;

    for (i = 1; i <= imax; i++)
    {
        h1 = real(i) / imax;
        p = Zpoint(p1 +CVector3d(p2 - p1) * h1);
        w = w + CVector3d(p - p3).norm();
        p3 = p;
    }

    cout << "\tarc distance "<< w << endl;
    return w;
}

int CSailWorker::HeadToLeechTurnPointDistance(void) const {
	CVector3d v = CVector3d(head - leechTurnPoint);

    int ret = int(calculate3dDistance(head, leechTurnPoint)+.5);

    return ret;
}

void CSailWorker::dumpRight(CPanel p) const {
	unsigned int sz = p.right.size();

    cout << "dumpRight" << endl;
	CPoint3d p0 = p.right[0];

    for (unsigned int i=0; i< sz; i++) {
		CPoint3d p1 = p.right[i];
		cout << p1;
        //if (i > 0) {
        //    cout << "      " << (p1.x()-p0.x()) / (p1.y()-p0.y());
        //}

        cout << endl;
	}

    cout << "end dump" << endl;
}

real CSailWorker::ratioFromDepth(real depth) const {
    for (int i=1; i<= DEPTH_RATIO_TABLE_SIZE; i++) {
        if (depth <= camberRatios[i].percentDepth) {
            // found
            real scale = (depth - camberRatios[i-1].percentDepth)
                            / (camberRatios[i].percentDepth - camberRatios[i-1].percentDepth);

            return camberRatios[i-1].ratio + scale * (camberRatios[i].ratio - camberRatios[i-1].ratio);
        }
    }
    return -1;
}

real CSailWorker::depthFromRatio(real ratio) const {
    for (int i=1; i<= DEPTH_RATIO_TABLE_SIZE; i++) {
        if (ratio <= camberRatios[i].ratio) {
            // found
            real scale = (ratio - camberRatios[i-1].ratio)
                            / (camberRatios[i].ratio - camberRatios[i-1].ratio);

            return camberRatios[i-1].percentDepth + scale * (camberRatios[i].percentDepth - camberRatios[i-1].percentDepth);
        }
    }
    return -1;
}

/*
  calculate the distance between two points
  */
real CSailWorker::distanceBetween(CPoint3d p1, CPoint3d p2) const {
    /*real xdiff = p1.x() - p2.x();
    real ydiff = p1.y() - p2.y();
    real zdiff = p1.z() - p2.z();

    return sqrt(xdiff*xdiff + ydiff*ydiff +zdiff*zdiff);*/

    real d = (p1 - p2).norm();
    return abs(d);
}

real CSailWorker::TackToSailLPIntersect() {
	CPoint3d p1 = Zpoint( EdgeIntersect( LUFF_EDGE, clew , luffVP) );
	real dist = distanceBetween(tack, p1);

	return dist;
}

/*
 * calculate cross measurements using ERS method
 * For mains toNearestPoint should be set to true.
 * For symetrical spinnakers toNearestPoint should be set to false
 *
 * crossHeight is updated with reesults
 */
void CSailWorker::IsafCrossMeasurement(crossHeights &crossHeight, bool toNearestPoint) {
    CPoint3d pHalfHeight = calculateLeechPoint(sailType == SYMMETRIC ? peak : head, clew, .5);
    CPoint3d pQuarterHeight = calculateLeechPoint(pHalfHeight, clew, .25);
    CPoint3d pThreeQuarterHeight = calculateLeechPoint(head, pHalfHeight, .75);

    cout << "clew to 1/4 " << (pQuarterHeight-clew).norm() << endl;
    cout << "1/4 to 1/2  " << (pQuarterHeight-pHalfHeight).norm() << endl;
    cout << "1/2 to 3.4  " << (pThreeQuarterHeight-pHalfHeight).norm() << endl;
    cout << "clew to 1/4 " << (pQuarterHeight-clew).norm() << endl;
    cout << "clew to 1/2 " << (pHalfHeight-clew).norm() << endl;
    cout << "1/2 to head " << (head - pHalfHeight).norm() << endl;

    crossHeight.quarterLeechPoint = pQuarterHeight;
    crossHeight.halfLeechPoint = pHalfHeight;
    crossHeight.threeQuarterLeechfPoint = pThreeQuarterHeight;

    if (toNearestPoint) {
        CPoint3d pLuff = calculateNearestLuffPoint(pThreeQuarterHeight);
        crossHeight.threeQuarterHeight = floor(calculate3dDistance(pLuff, pThreeQuarterHeight)+.5);
        crossHeight.threeQuarterLuffPoint = pLuff;

        pLuff = calculateNearestLuffPoint(pHalfHeight);
        crossHeight.halfHeight = floor(calculate3dDistance(pLuff, pHalfHeight)+.5);
        crossHeight.halfLuffPoint = pLuff;

        pLuff = calculateNearestLuffPoint(pQuarterHeight);
        crossHeight.quarterHeight = floor(calculate3dDistance(pLuff, pQuarterHeight)+.5);
        crossHeight.quarterLuffPoint = pLuff;
    } else {
        CPoint3d pLuffHalfHeight = calculateLuffPoint(head, tack, .5);
        CPoint3d pLuffQuarterHeight = calculateLuffPoint(pLuffHalfHeight, tack, .25);
        CPoint3d pLuffThreeQuarterHeight = calculateLuffPoint(head, pLuffHalfHeight, .75);

        crossHeight.quarterLuffPoint = pLuffQuarterHeight;
        crossHeight.halfLuffPoint = pLuffHalfHeight;
        crossHeight.threeQuarterLuffPoint = pLuffThreeQuarterHeight;

        if (sailType == SYMMETRIC && sailCut == HORIZONTAL) {
            crossHeight.threeQuarterHeight = floor(calculateSymetricalSpinnakerCrossMeasurement(pLuffThreeQuarterHeight,pThreeQuarterHeight)+.5);
            crossHeight.halfHeight = floor(calculateSymetricalSpinnakerCrossMeasurement(pLuffHalfHeight, pHalfHeight)+.5);
            crossHeight.quarterHeight = floor(calculateSymetricalSpinnakerCrossMeasurement(pLuffQuarterHeight, pQuarterHeight)+.5);
            crossHeight.panelQuarterCrossHeight = floor(calculatePanelCrossMeasurement(pLuffQuarterHeight));
            crossHeight.panelHalfCrossHeight = floor(calculatePanelCrossMeasurement(pLuffHalfHeight));
            crossHeight.panelThreeQuarterCrossHeight = floor(calculatePanelCrossMeasurement(pLuffThreeQuarterHeight));
        } else {
            crossHeight.threeQuarterHeight = crossHeight.panelThreeQuarterCrossHeight = floor(calculate3dDistance(pThreeQuarterHeight, pLuffThreeQuarterHeight)+.5);
            crossHeight.halfHeight = crossHeight.panelHalfCrossHeight = floor(calculate3dDistance(pHalfHeight, pLuffHalfHeight)+.5);
            crossHeight.quarterHeight = crossHeight.panelQuarterCrossHeight = floor(calculate3dDistance(pQuarterHeight, pLuffQuarterHeight)+.5);
        }
    }

    return;
}

/**
 * @brief CSailWorker::maxPanelHeight
 * @return  return maximum height of any panel
 */
int CSailWorker::maxPanelHeight() {
    real maxHeight = 0;

    for (unsigned int i=0; i<m_flatsail.size(); i++) {
        maxHeight = max(maxHeight, m_flatsail[i].boundingRect().height());
    }

    return int(maxHeight+0.5);
}

/**
 * @brief CSailWorker::maxPanelWidth
 * @return return maximum width of any panel
 */
int CSailWorker::maxPanelWidth() {
    real maxWidth = 0;

    for (unsigned int i=0; i<m_flatsail.size(); i++) {
        maxWidth = max(maxWidth, m_flatsail[i].boundingRect().width());
    }

    return int(maxWidth+0.5);

}
/**
 * @brief CSailWorker::LuffFoldCrossMeasurements
 * calculate cross measurements using the "luff fold" method where the sail is folded so that
 * two points on the luff (e.g. head and tack) coincide then the measurement is taken
 * along the fold to the leech
 * @param crossHeight
 */
void CSailWorker::LuffFoldCrossMeasurements(crossHeights &crossHeight) {
    CPoint3d pLuffHalfHeight = calculateLuffPoint(topFront, tack, .5);
    CPoint3d pLuffQuarterHeight = calculateLuffPoint(pLuffHalfHeight, tack, .25);
    CPoint3d pLuffThreeQuarterHeight = calculateLuffPoint(topFront, pLuffHalfHeight, .75);

    crossHeight.quarterLuffPoint = pLuffQuarterHeight;
    crossHeight.halfLuffPoint = pLuffHalfHeight;
    crossHeight.threeQuarterLuffPoint = pLuffThreeQuarterHeight;

    CPoint3d pLeechHalfHeight = calculateLeechPoint(topFront, tack, .5);
    CPoint3d pLeechQuarterHeight = calculateLeechPoint(pLuffHalfHeight, tack, .25);
    CPoint3d pLeechThreeQuarterHeight = calculateLeechPoint(topFront, pLuffHalfHeight, .75);

    crossHeight.quarterLeechPoint = pLeechQuarterHeight;
    crossHeight.halfLeechPoint = pLeechHalfHeight;
    crossHeight.threeQuarterLeechfPoint = pLeechThreeQuarterHeight;

    crossHeight.threeQuarterHeight = floor(calculate3dDistance(pLeechThreeQuarterHeight, pLuffThreeQuarterHeight)+.5);
    crossHeight.halfHeight = floor(calculate3dDistance(pLeechHalfHeight, pLuffHalfHeight)+.5);
    crossHeight.quarterHeight = floor(calculate3dDistance(pLeechQuarterHeight, pLuffQuarterHeight)+.5);
}

/**
 * @brief CSailWorker::calculatePanelCrossMeasurement a sanity check method for
 * symmetrical spinnaker cross measurements. Maps height to actual panel then takes
 * measurement across corresponding flat panel.
 * @param p the cross height point
 * @return the cross measurement taken from the flat panel
 */
real CSailWorker::calculatePanelCrossMeasurement(CPoint3d p) {
    for (unsigned int npanel=0; npanel<m_sail.size(); npanel++) {
        if (p.y() >= m_sail[npanel].left[0].y() && p.y() <= m_sail[npanel].left.back().y()) {
            for (unsigned int i=0; i<m_sail[npanel].left.size()-1; i++) {
                if (p.y() > m_sail[npanel].left[i].y() && p.y() < m_sail[npanel].left[i+1].y()) {
                    real y = p.y() - m_sail[npanel].left[i].y();

                    // now look at flatsail
                    // because the foot panel of flatsail has been split our correstonding panel
                    // is one number higher
                    real ydist = m_flatsail[npanel+1].left[i+1].y() - m_flatsail[npanel+1].left[i].y();
                    CPoint3d pLeft = m_flatsail[npanel+1].left[i] + (m_flatsail[npanel+1].left[i+1] - m_flatsail[npanel+1].left[i]) * (y/ydist);
                    CPoint3d pRight = m_flatsail[npanel+1].right[i] + (m_flatsail[npanel+1].right[i+1] - m_flatsail[npanel+1].right[i]) * (y/ydist);
                    cout << "calculatePanelCrossHeight:" << endl;
                    cout << "panel no = " << npanel << endl;
                    cout << "distance to bottom of panel = " << (pLeft-m_flatsail[npanel+1].left.front()).norm() << endl;
                    cout << "distance to top of panel = " << (m_flatsail[npanel+1].left.back() - pLeft).norm() << endl;
                    return (pRight-pLeft).norm();
                }
            }
        }
    }

    return -1;
}

/*
 * calculate a cross measurement for a symetrical spinnaker given the two end points of chord
 *
 * returns measurement
 */
real CSailWorker::calculateSymetricalSpinnakerCrossMeasurement(CPoint3d pStart, CPoint3d pEnd) const {
    real sailHeight = max(head.y(), peak.y()) - min(tack.y(), clew.y());
    //real baseY = min(tack.y(), clew.y());
    real pHeight = pStart.y() - min(tack.y(), clew.y());
    CPoint3d pCentre = (pStart + pEnd) * 0.5;
    real chord = (pEnd - pStart).norm();

    real h1 = pHeight /sailHeight;

    int sz = m_sail.size();
    for (auto i=sz-1; i>-1; i--) {
        if (pCentre.y() < m_sail[i].left.back().y() && pCentre.y() > m_sail[i].left.front().y()) {
            int idx1 = (int) m_sail[i].top.size() / 2;
            int idx2 = (int) m_sail[i].bottom.size() / 2;
            CPoint3d p1 = m_sail[i].top[idx1];
            CPoint3d p2 = m_sail[i].bottom[idx2];
            real a = (p1-pCentre).norm();
            real b = (p1-p2).norm();
            real c = (p2 - pCentre).norm();

            real angle = Atriangle(a, b, c);

            // get distancefrom pCentre to point perpendicular to to line p1..p2
            // this will represent the height of the curve we calculate
            real d = c * sin(angle);

            CProfile profile;

            // get the profile for our height
            if (interpolMethod == INTERPOL2) {
                profile = mould.interpol2( h1 , chord);
            } else {
                profile = mould.interpol( h1 );
            }

            real dpth = d / chord;

            profile = CProfile( dpth, profile.getLeech() , profile.getLuff(),
                    chord, profile.getProfileType());

            CSide side = CSide();
            side.clear();

            side.push_back(pStart);

            for (unsigned int i=1; i<NUM_TOP_BOTTOM_POINTS-1; i++) {
                real fraction = real(i)/ real(NUM_TOP_BOTTOM_POINTS);

                real z = pStart.z()+chord * profile.z(fraction);
                real x = pStart.x()+fraction*chord;
                CPoint3d p = CPoint3d(x, pCentre.y(), z);

                side.push_back(p);
            }

            side.push_back(pEnd);

            return side.arcLength();
        }
    }

    return -1;
}

/**
 * @brief CSailWorker::validateSymmetricalSpinnakerLuff
 * @return
 */
bool CSailWorker::validateSymmetricalSpinnakerLuff()  {
    real lastDist = 0;
    real minDiff = 1.0;
    real luffDist = 0;
    real LuffPanelDist = 0;
    int nPanels = m_sail.size()-2;
    if (nPanels < 1) nPanels = 1;
    real luffY = topFront.y()-tack.y();
    real luffX = topFront.x()-tack.x();
    CPoint3d panelPoints[2][nPanels];

    if (m_sail.size() > 0) {
        for (unsigned int i=0; i<m_flattened.size(); i++) {
            LuffPanelDist += distanceBetween(m_flattened[i].left.back(), m_flattened[i].left.front());
        }

        cout << "LuffPanelDist distance = " << LuffPanelDist << endl;

        for (int i=0; i<nPanels; i++) {
            panelPoints[0][i] = CPoint3d(m_sail[i+2].bottom.front().x(), m_sail[i+2].bottom.front().y(), 0);
            real xIntersect = tack.x()+luffX*(panelPoints[0][i].y()-tack.y()) / luffY;
            panelPoints[1][i] = CPoint3d(xIntersect, panelPoints[0][i].y(), 0);
        }
    }

    for (unsigned int i=0; i<= 20; i++) {
        real fraction = double(20-i)/20.0;
        real luffHeight = fraction * luffR;
        CPoint3d p1 = tack, p2;
        real dist = 0;
        real panelDist = 0;

        for (unsigned int j=1; j<NUM_TOP_BOTTOM_POINTS; j++) {
            real dRound = RoundP(double(j)/double(NUM_TOP_BOTTOM_POINTS), luffRP);
            CPoint3d p = tack + luffV*(double(j)/double(NUM_TOP_BOTTOM_POINTS));
            p2 = (dRound == 0) ? p : p + luffVP * luffHeight * dRound;
            p2 = Zpoint(p2);
            dist += (p2-p1).norm();
            p1 = p2;
        }

        dist += (topFront-p1).norm();

        if (m_sail.size() > 0) {
            p1 = tack;
            for (int j=0; j<nPanels; j++) {
                p2 = panelPoints[1][j]- fraction*(panelPoints[1][j]-panelPoints[0][j]);

                //cout << "p0 = " << panelPoints[0][j] << ", p2 = " <<p2 << ", p1 =" << panelPoints[1][j] << endl;

                p2 = Zpoint(p2);
                panelDist += (p2-p1).norm();
                p1 = p2;
            }

            panelDist += (topFront-p1).norm();
        }


        if (i==0) {
            luffDist = dist;
//            LuffPanelDist = panelDist;
            cout << "luff distance = " << luffDist << endl;
        }

        cout <<  "i = " << i << ", instep = " << (luffR-luffHeight)
              << ", dist = " << dist << ", difference = " << (dist-luffDist)
              << ", panelDist = " << panelDist << ", diff 2 = " << (panelDist-LuffPanelDist)
              << endl;

        if ((dist-lastDist) < minDiff) {
            throw layout_error("Luff validation failed");
        }

        lastDist = dist;
    }

    //cout << "lastDist = " << lastDist << endl;

    return true;
}
/*
 * calculate the nearest point in Z to a chord defined by pStart and pEnd
 * This functionj is primarily for calculating the cross measurements of
 * symetrical spinnakers
 * Returns a point midway between tack and clew in x anc calculated y and z
 */
CPoint3d CSailWorker::calculateNearestPointInZ(CPoint3d pStart, CPoint3d pEnd) const {
    real sailHeight = max(head.y(), peak.y()) - min(tack.y(), clew.y());
    real baseY = min(tack.y(), clew.y());
    real pHeight = pStart.y() - min(tack.y(), clew.y());
    CPoint3d pCentre = (pStart + pEnd) * 0.5;
    real chord = (pEnd - pStart).norm();

    real h1 = pHeight /sailHeight;
    real inc = 0.01;

    real z, z1, z2;

    if (interpolMethod == INTERPOL2) {
        z = chord * mould.interpol2( h1 , chord).z(0.5);
        z1 = chord * mould.interpol2( h1-inc , chord).z(0.5);
        z2 = chord * mould.interpol2( h1+inc , chord).z(0.5);
    } else {
        z = chord * mould.interpol( h1 ).z(0.5);
        z1 = chord * mould.interpol( h1 -inc).z(0.5);
        z2 = chord * mould.interpol( h1+inc ).z(0.5);
    }

    CPoint3d p, p1, p2;

    p = CPoint3d(pCentre.x(), pCentre.y(), z);
    p1 = CPoint3d(pCentre.x(), baseY+sailHeight*(h1-inc), z1);
    p2 = CPoint3d(pCentre.x(), baseY+sailHeight*(h1+inc), z2);

//cout << "z = " << z << ",    z1 = " << z1 << ",   z2 = " << z2 << endl;

    real dist1 = distanceBetween(p1, pCentre);
    real dist2 = distanceBetween(p2, pCentre);

    //cout << "d = " << (p-pCentre).norm() << ",    dist1 = " << dist1 << ",    dist2 = " << dist2 << endl;

    real gap = dist1>dist2 ? 0.05 : -0.05;
    if (dist1>dist2) {
        dist1 = dist2;
    }// else {
    //    dist2 = dist1;
    //}

    real h = h1 + gap;

    // recalculate
    if (interpolMethod == INTERPOL2) {
        z = chord * mould.interpol2( h , chord).z(0.5);
    } else {
        z = chord * mould.interpol( h ).z(0.5);
    }

    p2 = CPoint3d(pCentre.x(), baseY+sailHeight*(h), z);

    dist2 = distanceBetween(pCentre, p2);

    int nTrys = 0;
    while (fabs(dist1 - dist2) > .2 && nTrys < 50) {
        nTrys++;
        if (dist2 > dist1) {
            gap /= 2.0;
            h -= gap;
        } else {
            p1 = p2;
            dist1 = dist2;
            h += gap;
        }

        // recalculate
        if (interpolMethod == INTERPOL2) {
            z = chord * mould.interpol2( h , chord).z(0.5);
        } else {
            z = chord * mould.interpol( h ).z(0.5);
        }

        p2 = CPoint3d(pCentre.x(), baseY+sailHeight*(h), z);

        dist2 = distanceBetween(pCentre, p2);
    } // end while

    return p2;
}

real CSailWorker::calculate3dDistance(CPoint3d pStart, CPoint3d pEnd, enum enumZpanelSupressCalc zpsc) const
{
    unsigned int i, imax=100;
    real h1=0, w=0;
    CPoint3d p, p1;
    CVector3d v;

    v = CVector3d(pEnd - pStart);
    p1 = pStart;

    for (i = 1; i <= imax; i++)
    {
        h1 = real(i) / real(imax);
        if (i== imax) {
            p = pEnd;
        } else {
            p = Zpoint(pStart +v * h1, zpsc);
        }
//        cout << "calculate3dDistance  = p " << p << ",  p1 = " << p1 << ", distance = " << CVector3d(p - p1).norm() << endl;
        w += distanceBetween(p, p1);
        p1 = p;
    }


//    cout << "calculate3dDistance pStart = "  << pStart << ", pEnd = " << pEnd << ", w = " << w << endl;
    //
    return ( w );
}

CPoint3d CSailWorker::calculateLeechPoint(CPoint3d pHigh, CPoint3d pLow, real startPercent) {

    real lLeech = leechV.norm();
    real dist, dist1, dist2;
    real inc = 0;
    real percentHeight = 0;
    CPoint3d p, p1, p2;

    if (battenGroup.numBattens() + 0) {
        bUseBattensForLeech = true;
    }

    p1 = pHigh;
    p2 = pLow;
    dist = startPercent;

    do {
        // subtract inc for next iteration
        dist -= inc;
        // calculate cross measurement height
        percentHeight = (lLeech-dist)/lLeech;
        // find leech point
        p = Zpoint(LeechPoint(percentHeight));
        // calc distances between centre point and our outer points
        dist1 = distanceBetween(p, p1);
        dist2 = distanceBetween(p, p2);
        // calc inc
        inc = .5*(dist1 - dist2);

    } while (fabs(dist1 - dist2) > .5);

    return p;
}

CPoint3d CSailWorker::calculateLuffPoint(CPoint3d pHigh, CPoint3d pLow, real startPercent) {

    real lLuff = luffV.norm();
    real dist, dist1, dist2;
    real inc = 0;
    real percentHeight = 0;
    CPoint3d p, p1, p2;

    p1 = pHigh;
    p2 = pLow;
    dist = startPercent;

    do {
        // subtract inc for next iteration
        dist -= inc;
        // calculate cross measurement height
        percentHeight = (lLuff-dist)/lLuff;
        // find luff point
        p = LuffPoint(percentHeight);
        // calc distances between centre point and our outer points
        //dist1 = distanceBetween(p, p1);
        //dist2 = distanceBetween(p, p2);
        dist1 = calculateDistanceAroundLuffCurve(p, p1);
        dist2 = calculateDistanceAroundLuffCurve(p, p2);
        // calc inc
        inc = .5*(dist1 - dist2);

    } while (fabs(dist1 - dist2) > .5);

    return p;
}

CPoint3d CSailWorker::calculateNearestLuffPoint(CPoint3d leechPoint) const {
    CPoint3d p1 = Zpoint(EdgeIntersect( LUFF_EDGE, leechPoint, luffVP));
    p1.z() = 0;
    real tackToIntersectDist = CVector3d(p1 - tack).norm();

    int i = floor(100*tackToIntersectDist/luffL);

    real gap =  i > luffRP ? 25 : - 25;
    real h = tackToIntersectDist + gap;
    CPoint3d p = tack + luffV * (h / real(luffL));
    CPoint3d p2 = Zpoint(EdgeIntersect( LUFF_EDGE, p , luffVP) );
    real h1 = tackToIntersectDist - gap;
    p = tack + luffV * (h1 / real(luffL));
    CPoint3d p3 = Zpoint(EdgeIntersect( LUFF_EDGE, p , luffVP) );

    real dist1 = distanceBetween(p1, leechPoint);
    real dist2 = distanceBetween(p2, leechPoint);

    int nTrys = 0;
    while (fabs(dist1 - dist2) > .2 && nTrys < 50) {
        nTrys++;
        if (dist2 > dist1) {
            gap /= 2.0;
            h -= gap;
        } else {
            p1 = p2;
            dist1 = dist2;
            h += gap;
        }

        // re-calculate p2
        p = tack + luffV * (h / real(luffL));
        p2 = Zpoint(EdgeIntersect( LUFF_EDGE, p , luffVP) );

        dist2 = distanceBetween(p2, leechPoint);
    }

    return p1;
}


unsigned int CSailWorker::CalculateFootMedian() {
    // calculate mid point of foot
    CPoint3d pMidFoot = Zpoint(tack +(clew-tack)*.5);
    CPoint3d pMedian = EdgeIntersect(FOOT_EDGE, tack +(clew-tack) *.5, footVP);
    if (!footEdgeAtZeroZ) {
        pMedian = Zpoint(pMedian);
    }
    //CPoint3d pMedian = Zpoint(EdgeIntersect(FOOT_EDGE, tack +(clew-tack) *.5, footVP));

    //cout << "CalculateFootMedian straight line = " << (head-pMidFoot).norm() << endl;

    real ret = calculate3dDistance(head, pMidFoot);
    ret += distanceBetween(pMidFoot, pMedian);

    return int(ret+0.5);
}

unsigned int CSailWorker::CalculateLeechLength (bool isTriangular) {
    return  int(calculate3dDistance(isTriangular ? head : peak, clew)+.5);
}

unsigned int CSailWorker::CalculateLeechRoundDistance() {
    double d = 0;
    for (unsigned int i=0; i<m_sail.size(); i++) {
        d += m_sail[i].left.arcLength();
    }

    return (int) (d+0.5);
}

unsigned int CSailWorker::CalculateFootLength () {
    return  int(calculate3dDistance(tack, clew)+.5);
}

unsigned int CSailWorker::CalculateLuffLength () {
    real tot = 0;
    int np = 100;
    CPoint3d lastPoint = tack;

    for (int j=1; j<np; j++) {
        real fraction = j / real(np);
        CPoint3d pLuff = tack + luffV.unit() * luffL * fraction;
        CPoint3d pLuffIntersect = EdgeIntersect( LUFF_EDGE, pLuff, luffVP);
        tot += distanceBetween(lastPoint, pLuffIntersect);
        lastPoint = pLuffIntersect;
    }

    tot += distanceBetween(lastPoint, head);

    return  int(tot+.5);
}

void CSailWorker::CalculateBattenPositions() const {
    bUseBattensForLeech = false;
    battenGroup.sort();

    int n = battenGroup.numBattens();

    for (int i=0; i<n; i++) {
        CBatten& b = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i);
        // calculate aft point
        CPoint3d leechMaxPoint = clew + leechV.unit() * leechL * (b.percentHeight / 100.0);
        //b.aftPoint = Zpoint(EdgeIntersect(LEECH_EDGE, leechMaxPoint, leechVP)
        //                    -leechVP.unit()*b.inwardOffset);
        // get basic intersect point on leech
        CPoint3d l = EdgeIntersect(LEECH_EDGE, leechMaxPoint, leechVP);
        // calculate poit on straight line leech
        CVector3d v1 = leechV * (b.percentHeight / 100.0);
        CVector3d v2 = v1 + clew;

        real rd = calculateLeechPoint(leechR, b.percentHeight / 100.0, leechRP);

        CVector3d v3 = l - v2;
        b.aftPoint = v2 + v3 * ((rd - b.inwardOffset) / rd);

        //b.roundDepth = calculateLeechPoint(leechR, (b.percentHeight / 100.0), leechRP)-b.inwardOffset;
        b.roundDepth = distanceBetween(v2, b.aftPoint);

        cout << "Leech point " << Zpoint(b.aftPoint) << "    Aft batten point " << b.aftPoint << endl;

        if (b.fullLength) {
            // create a vector at the batten angl wrt strainht line of leech
            CVector3d v = CMatrix::rot3d(2, b.angle*PI/180) * leechV.unit();  // for classical cross cut
            // create a subspace object and use it to get the insection of the batten with the straight libne of luff
            CSubSpace ssBatten = CSubSpace3d::line( b.aftPoint , v );
            CVector3d ip = ssBatten.intersect(luffLine).getp();
            // get actual intersection point with curve of luff
            b.frontPoint  = EdgeIntersect(LUFF_EDGE, ip, v);

            b.battenLength = calculate3dDistance(b.frontPoint, b.aftPoint);
            b.distanceLuffToHead = calculate3dDistance(b.frontPoint, head);
            cout << "3d batten length = " << b.battenLength << ",  straight line length" << distanceBetween(b.frontPoint, b.aftPoint) << endl;
        } else {
            b.frontPoint = Zpoint(EdgeIntersect(LEECH_EDGE, leechMaxPoint, leechVP)
                                  +leechVP.unit()*(b.inwardOffset+b.battenLength));
        }
    }

    if (n > 0) {
        bUseBattensForLeech = true;

        //for (int i=0; i<n; i++) {
        //    CBatten& b = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i);
            // calculate aft point
        //    CPoint3d leechMaxPoint = clew + leechV.unit() * leechL * (b.percentHeight / 100.0);
        //    b.aftPoint = Zpoint(EdgeIntersect(LEECH_EDGE, leechMaxPoint, leechVP));
        //}
    }

    // now calculate various distances
    for (int i=0; i<n; i++) {
        CBatten& b = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i);
        b.distanceToClew = calculate3dDistance(clew, b.aftPoint);
        b.distanceToHead = calculate3dDistance(head, b.aftPoint);

        if (i<n-1) {
            CBatten& b1 = (const_cast<CBattenGroup&>(battenGroup)).getBatten(i+1);
            b.distanceToHigherBatten = b1.distanceToLowerBatten
                    = calculate3dDistance(b1.aftPoint, b.aftPoint);
            if (i == 0) {
                b.distanceToLowerBatten = b.distanceToClew;
            }
        } else {
            b.distanceToHigherBatten = calculate3dDistance(peak, b.aftPoint);
        }

    }

}

/**
 * @brief CSailWorker::isGaffMainsail
 * @return if this is a gaff mainsail
 */
bool CSailWorker::isGaffMainsail() {
    return isGaffSail;
}
