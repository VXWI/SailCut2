/*
 * battengroup.h
 *
 *  Created on: 12 Jun 2011
 *      Author: paul
 */

#ifndef BATTENGROUP_H_
#define BATTENGROUP_H_

#include "batten.h"

class CBattenGroup
{
public:
    CBattenGroup(void);
    CBattenGroup(const unsigned int);
    //CBattenGroup(const  CBattenGroup& );
    CBattenGroup(const  CBatten& );
    void addBatten(const CBatten& );
    vector<CBatten>& listBattens(void);
    unsigned int numBattens(void) const;
    CBatten& getBatten(const int);
    void clear(void);
    void updateAll(CBattenGroup&);
    void update(int, CBatten);
    void sort(void);
    void removeBatten(const int);

private:
    vector<CBatten> battens;
};
#endif /* BATTENGROUP_H_ */
