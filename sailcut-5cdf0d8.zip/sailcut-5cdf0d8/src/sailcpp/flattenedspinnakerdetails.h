#ifndef FLATTENEDSPINNAKERDETAILS_H
#define FLATTENEDSPINNAKERDETAILS_H

#include "sailcpp/panelgroup.h"
#include "sailcalc.h"

struct flattenedSpinnakerValues
{
    double leechLength;
    double leechLengthStraightLine;
    double fullnessFactor;
    double leechRound;
    double halfMidGirth;
    double footMedian;
    double centreRound;
    double partHeadAngle;
};

class FlattenedSpinnakerDetails
{
public:
    FlattenedSpinnakerDetails();

    struct flattenedSpinnakerValues getValues(CPanelGroup &pg);

private:
    CPoint3d getLeftPointBelow(CPoint3d p, CPanelGroup &pg);
    CPoint3d getRightPointBelow(CPoint3d p, CPanelGroup &pg);
    CPoint3d getLeftPointAbove(CPoint3d p, CPanelGroup &pg);
    CPoint3d getRightPointAbove(CPoint3d p, CPanelGroup &pg);
    CPoint3d findCentrePoint(double y, CPoint3d p1, CPoint3d p2);

};

#endif // FLATTENEDSPINNAKERDETAILS_H
