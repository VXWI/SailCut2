#ifndef PATCHDEFS_H
#define PATCHDEFS_H

#include <string>

enum enumPatchStyles {PATCH_STYLE_BLOCK, PATCH_STYLE_FAN, PATCH_STYLE_RADIAL};
enum enumPatchType {PATCH_TYPE_NONE, PATCH_SPINNAKER_TACK, PATCH_SPINNAKER_CLEW, PATCH_SPINNAKER_CLEW_PORT,
                     PATCH_SPINNAKER_CLEW_STARBOARD, PATCH_SPINNAKER_HEAD, PATCH_SPINNAKER_DOWNHAUL,
                     PATCH_SPINNAKER_FOOT, PATCH_SPINNAKER_FOOT_PORT, PATCH_SPINNAKER_FOOT_STARBOARD,
                     PATCH_SPINNAKER_CLEW_UNDERPATCH, PATCH_SPINNAKER_HEAD_UNDERPATCH,
                     PATCH_RADIAL_CLEW, PATCH_RADIAL_CLEW_FOOT, PATCH_RADIAL_CLEW_LEECH,
                     PATCH_JIB_HEAD, PATCH_JIB_HEAD_UNDERPATCH, PATCH_JIB_TACK, PATCH_JIB_TACK_UNDERPATCH,
                     PATCH_JIB_CLEW, PATCH_JIB_CLEW_UNDERPATCH,
                     PATCH_MAINSAIL_HEAD, PATCH_MAINSAIL_HEAD_UNDERPATCH, PATCH_MAINSAIL_TACK, PATCH_MAINSAIL_TACK_UNDERPATCH,
                     PATCH_MAINSAIL_CLEW, PATCH_MAINSAIL_CLEW_UNDERPATCH,
                     PATCH_MAINSAIL_REEF1, PATCH_MAINSAIL_REEF1_UNDERPATCH,
                     PATCH_MAINSAIL_REEF2, PATCH_MAINSAIL_REEF2_UNDERPATCH,
                     PATCH_MAINSAIL_THROAT, PATCH_MAINSAIL_THROAT_UNDERPATCH,
                     };

struct Patch {
    enumPatchType patchType;
    enumPatchStyles patchStyle;
    int dimension1;
    int dimension2;
    // fields for plain style
    std::string underPatches;
    // fields for fan style
    int numSections;
    int overlap;
    int baseDimension;
    // reef info
    int luffHeight;
    int leechHeight;
};

#endif // PATCHDEFS_H
