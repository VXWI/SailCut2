#ifndef CAMBERSTRUCT_H
#define CAMBERSTRUCT_H

// structure for calculated camber at various heights
struct camberAtHeight {
    double      height;
    double      baseCamber;
    int         baseCamberMM;
    double      combinedCamber;
    int         combinedCamberMM;
    double      arcLength;
    double      chordLength;
    double      maxPos;
    double      sailHeight;
};

#define NUM_CAMBER_POINTS 20

#endif // CAMBERSTRUCT_H
