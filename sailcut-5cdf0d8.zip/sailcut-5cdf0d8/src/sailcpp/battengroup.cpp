/*
 * battengroup.cpp
 *
 *  Created on: 12 Jun 2011
 *      Author: paul
 */

#include "battengroup.h"
#include <algorithm>

CBattenGroup::CBattenGroup(void) {

}

CBattenGroup::CBattenGroup(const unsigned int nbpanels)
{
    battens.resize(nbpanels);
}


/** Copy constructor.
 */

/*CBattenGroup::CBattenGroup(const CBattenGroup& g )
{
    battens.clear();
    int l = g.numBattens();

    for (int i=0; i<l; i++) {
        CBatten& b = (const_cast<CBattenGroup&>(g)).getBatten(i);
        addBatten(CBatten(b));
    }
}
*/

/** Construct a panel group from a single panel.
 */
CBattenGroup::CBattenGroup(const CBatten& p )
{
    battens.resize(1);
    battens.at(0) = p;
}

void CBattenGroup::addBatten(const CBatten& b) {
    battens.push_back(b);
}

vector<CBatten>& CBattenGroup::listBattens() {
    return battens;
}

unsigned int CBattenGroup::numBattens() const {
    return battens.size();
}

CBatten& CBattenGroup::getBatten(const int i) {
    return battens.at(i);
}

void CBattenGroup::clear() {
    battens.clear();
    battens.resize(1);
}

void CBattenGroup::updateAll(CBattenGroup& g) {
    battens.clear();
    int l = g.numBattens();

    for (int i=0; i<l; i++) {
        CBatten& b = g.getBatten(i);
        addBatten(CBatten(b));
    }
}

void CBattenGroup::update(int index, CBatten b) {
    CBatten& batt = battens.at(index);
    batt.name = b.name;
    batt.battenLength = b.battenLength;
    batt.percentHeight = b.percentHeight;
    batt.angle = b.angle;
}

void CBattenGroup::sort() {
    std::sort(battens.begin(), battens.end());
}

void CBattenGroup::removeBatten(const int idx) {
    battens.erase(battens.begin()+idx);
}
