#ifndef SAILWINDOW_H
#define SAILWINDOW_H

enum enumSailWindowAlign {SWA_BOTTOM_SEAM, SWA_TOP_SEAM, SWA_FOOT, SWA_LEECH_PERP, SWA_HORIZONTAL};

struct SailWindow {
    bool    generate = false;
    int     panelNo = 0;
    int     width = 0;
    int     height = 0;
    int     xPos = 0;
    int     yPos = 0;
    int     sailXpos = 0; // calculated
    int     sailYpos = 0; // calculated
    int     bottomLeftToLuff = 0; //calculated
    int     topLeftToLuff = 0; // calculated
    enumSailWindowAlign alignment = SWA_BOTTOM_SEAM;
};

#endif // SAILWINDOW_H
