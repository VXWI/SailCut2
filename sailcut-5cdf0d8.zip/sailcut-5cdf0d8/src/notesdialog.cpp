#include "notesdialog.h"
#include "ui_notesdialog.h"

NotesDialog::NotesDialog(QWidget *parent, CSailDef * def)
    : QDialog(parent), sailDef(def)
    , ui(new Ui::NotesDialog)
{
    ui->setupUi(this);
    ui->textEdit->setText(QString::fromStdString(sailDef->notes));
}

void NotesDialog::accept() {
    QString s = ui->textEdit->toPlainText();
    sailDef->notes = s.toStdString();
    QDialog::accept();
}

NotesDialog::~NotesDialog()
{
    delete ui;
}
