#include "windowwidget.h"
#include "ui_windowwidget.h"

WindowWidget::WindowWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::WindowWidget)
{
    ui->setupUi(this);
    ui->panelNoLineEdit->setText(QString::number(0));
    ui->widthLineEdit->setText(QString::number(0));
    ui->heightLineEdit->setText(QString::number(0));
    ui->xPosLineEdit->setText(QString::number(0));
    ui->yPosLineEdit->setText(QString::number(0));
    ui->alignComboBox->clear();

    ui->alignComboBox->addItem("Bottom Seam", QString::number(0));
    ui->alignComboBox->addItem("Top Seam", QString::number(1));
    ui->alignComboBox->addItem("Foot", QString::number(2));
    ui->alignComboBox->addItem("Leech Perpendicular", QString::number(3));
    ui->alignComboBox->addItem("Horizontal", QString::number(3));
}

WindowWidget::~WindowWidget()
{
    delete ui;
}

void WindowWidget::setValues(std::string title, SailWindow sailWindow) {
    ui->windowNoLable->setText(QString::fromStdString(title));
    ui->generateCheckBox->setChecked(sailWindow.generate);
    ui->panelNoLineEdit->setText(QString::number(sailWindow.panelNo));
    ui->widthLineEdit->setText(QString::number(sailWindow.width));
    ui->heightLineEdit->setText(QString::number(sailWindow.height));
    ui->xPosLineEdit->setText(QString::number(sailWindow.xPos));
    ui->yPosLineEdit->setText(QString::number(sailWindow.yPos));
    ui->alignComboBox->setCurrentIndex(sailWindow.alignment);
    _sailWindow = sailWindow;
}

SailWindow WindowWidget::getValues() {
    struct SailWindow sw;
    QString txt;
    bool bValid = true;

    sw.generate = ui->generateCheckBox->isChecked();
    txt = ui->panelNoLineEdit->text();
    sw.panelNo = txt.toInt(&bValid);
    txt = ui->widthLineEdit->text();
    sw.width = txt.toInt(&bValid);
    txt = ui->heightLineEdit->text();
    sw.height = txt.toInt(&bValid);
    txt = ui->xPosLineEdit->text();
    sw.xPos = txt.toInt(&bValid);
    txt = ui->yPosLineEdit->text();
    sw.yPos = txt.toInt(&bValid);

    int idx = ui->alignComboBox->currentIndex();

    sw.alignment = static_cast<enumSailWindowAlign>(idx);

    return sw;
}

bool WindowWidget::check() {
    bool flag = true;
    bool bTest = true;
    QString txt;
    int tmpInt;

    /** Create four palettes for levels of warning. */
    QPalette palStd, palHi, palLo, palRel;
    palStd = ui->panelNoLineEdit->palette();
    palLo = palHi = palRel = palStd;
    palLo.setColor( QPalette::Text, Qt::magenta); // too low value
    palHi.setColor( QPalette::Text, Qt::red );    // too high value
    palRel.setColor( QPalette::Text, Qt::blue );  // related value to be checked

    txt = ui->panelNoLineEdit->text();
    if (txt.length() > 0) {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->panelNoLineEdit->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            ui->panelNoLineEdit->setPalette(palLo);
        }
    } else {
        flag = false;
        ui->panelNoLineEdit->setText("0");
        ui->panelNoLineEdit->setPalette(palHi);
    }

    txt = ui->widthLineEdit->text();
    if (txt.length() > 0) {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->widthLineEdit->setPalette(palHi);
        } else if (tmpInt < 1){
            flag = false;
            ui->widthLineEdit->setPalette(palLo);
        }
    } else {
        flag = false;
        ui->widthLineEdit->setText("0");
        ui->widthLineEdit->setPalette(palHi);
    }

    txt = ui->heightLineEdit->text();
    if (txt.length() > 0) {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->heightLineEdit->setPalette(palHi);
        } else if (tmpInt < 1){
            flag = false;
            ui->heightLineEdit->setPalette(palLo);
        }
    } else {
        flag = false;
        ui->heightLineEdit->setText("0");
        ui->heightLineEdit->setPalette(palHi);
    }

    txt = ui->xPosLineEdit->text();
    if (txt.length() > 0) {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->xPosLineEdit->setPalette(palHi);
        } else if (tmpInt < 1){
            flag = false;
            ui->xPosLineEdit->setPalette(palLo);
        }
    } else {
        flag = false;
        ui->xPosLineEdit->setText("0");
        ui->xPosLineEdit->setPalette(palHi);
    }

    txt = ui->yPosLineEdit->text();
    if (txt.length() > 0) {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            ui->yPosLineEdit->setPalette(palHi);
        } else if (tmpInt < 1){
            flag = false;
            ui->yPosLineEdit->setPalette(palLo);
        }
    } else {
        flag = false;
        ui->yPosLineEdit->setText("0");
        ui->yPosLineEdit->setPalette(palHi);
    }


    return flag;
}

bool WindowWidget::generate() {
    return ui->generateCheckBox->isChecked();
}
