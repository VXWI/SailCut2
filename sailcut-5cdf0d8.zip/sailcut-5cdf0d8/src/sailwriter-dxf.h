/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef SAILWRITER_DXF_H
#define SAILWRITER_DXF_H

#include "filewriter.h"
#include "sailcpp/panelgroup.h"
#include <iostream>
#include <fstream>
#include "ui_formdxfparams.h"

#define DXF_ENTITY  0
#define DXF_TEXTSTRING 1
#define DXF_NAME    2
#define DXF_LINE    6
#define DXF_LAYER   8
#define DXF_X       10
#define DXF_Y       20
#define DXF_Z       30
#define DXF_TEXTHEIGHT 40
#define DXF_TEXT_ROTATION 50
#define DXF_COLOR   62
#define DXF_FLAG    70
#define DXF_COMMENT 999

#define DXF_BLACK   "0"
#define DXF_RED     "1"
#define DXF_YELLOW  "2"
#define DXF_GREEN   "3"
#define DXF_CYAN    "4"
#define DXF_BLUE    "5"
#define DXF_MAGENTA "6"
#define DXF_WHITE   "7"

#define DXF_DRAW_LAYER 2
#define DXF_CUT_LAYER 1

struct DxfParams {
    bool isGaffSail;
    int DxfDrawLayer;
    int DxfCutLayer;
    QString DxfDrawColour;
    QString DxfCutColour;
    QString DxfTextColour;
    int DxfFontSize;
    QString DxfPanelPrefix;
    bool DxfPrintAllLeech;
    bool DxfExportTopPatches;
    bool DxfExportUnderPatches;
    bool DxFPrintThoatPoint;
};

/** An abstract class containing the methods needed for DXF writing.
 */
class CSailDxfWriter : public CFileWriter<CPanelGroup>
{
public:
    /** The constructor.
     */
    CSailDxfWriter() : CFileWriter<CPanelGroup>(".dxf", "DXF files")
    {}
    ;

    void writeBegin(ofstream &out, const QString &filename) const;
    void writeEnd(ofstream &out) const;

    void writeAtom(ofstream &out, int code, const QString& content) const;
    void writeFace(ofstream &out, CPoint3d p0, CPoint3d p1, CPoint3d p2, unsigned int layer) const;
    void writeLayer(ofstream &out, unsigned int layer, const QString &color) const;
    void writePolyline(ofstream &out, unsigned int layer, const QString &color) const;
    void writeVertex(ofstream &out, CPoint3d p0, unsigned int layer) const;
    void writeText(ofstream &out, CPoint3d p, const QString& text, int textSize, unsigned int layer, real rotation = 0) const;

    mutable int DxfDrawLayer;
    mutable int DxfCutLayer;
    mutable QString DxfDrawColour;
    mutable QString DxfCutColour;
    mutable QString DxfTextColour;
    mutable QString DxFPanelPrefix;
    mutable int DxfFontSize;
    mutable bool DxfPrintAllLeech;
    mutable bool DxfExportTopPatches;
    mutable bool DxfExportUnderPatches;
    mutable bool DxFPrintThoatPoint;

};

class CFormDxfParams : public QDialog, private Ui::CFormDxfParams
{
    Q_OBJECT

public:
    CFormDxfParams( QWidget *, struct DxfParams*);

    bool check();
    struct DxfParams getParams();

    virtual void accept();

    QString colours[8] = {"Black", "Red", "Yellow","Green","Cyan","Blue","Magenta", "White"};

    mutable struct DxfParams * params;
};

/** A class used to write a CPanelGroup to a 2D DXF file.
 *
 * @ingroup FileIo
 */
class CSailDxfWriter2d : public CSailDxfWriter
{
public:
    enum Dxf2dType {
        NORMAL,
        BLOCKS,
        SPLIT,
    };

    CSailDxfWriter2d(enum Dxf2dType format) : type(format) {};
    CSailDxfWriter2d(enum Dxf2dType format, struct DxfParams *p);
    void write(const CPanelGroup &sail, const QString &filename) const;
    void writeDxf(const CPanelGroup &sail, const QString &filename, const struct DxfParams *params) const;

protected:
    void writePanel(ofstream &out, const CPanel &panel, unsigned int drawLayer, unsigned int cutLayer, unsigned int panelNo) const;

    void writeNormal(const CPanelGroup &sail, const QString &filename) const;
    void writeBlocks(const CPanelGroup &sail, const QString &filename) const;
    void writeSplit(const CPanelGroup &sail, const QString &filename) const;

    Dxf2dType type;
    //struct DxfParams *params;
};


/** A class used to write a CPanelGroup to a 3D DXF file.
 *
 * @ingroup FileIo
 */
class CSailDxfWriter3d : public CSailDxfWriter
{
public:
    enum Dxf3dType {
        NORMAL,
        SPLIT,
    };

    CSailDxfWriter3d(enum Dxf3dType format) : type(format) {};
    void write(const CPanelGroup &sail, const QString &filename) const;

protected:
    void writePanel(ofstream &out, const CPanel &panel, unsigned int layer) const;

    void writeNormal(const CPanelGroup &sail, const QString &filename) const;
    void writeSplit(const CPanelGroup &sail, const QString &filename) const;

    Dxf3dType type;
};


#endif
