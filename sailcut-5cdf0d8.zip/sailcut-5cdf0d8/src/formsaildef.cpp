/*
 * Copyright (C) 1993-2015 Robert & Jeremy Laine
 * See AUTHORS file for a full list of contributors.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <cmath>

#include <QLabel>
#include <QMessageBox>
#include <QRadioButton>
#include <QLineEdit>

#include "formsaildef.h"
#include "qbuttongroup.h"
#include "sailcpp/sailworker.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/** The constructor.
 *
 * @param parent the parent window
 * @param sailptr pointer to the CSailDef
 */
CFormSailDef::CFormSailDef( QWidget* parent, CSailDef * sailptr )
        : QDialog(parent)
{
    setupUi(this);
    setModal(true);

    QList<QPushButton *> buttonsList = this->findChildren<QPushButton *>();
    for (int i = 0; i < buttonsList.count(); i++){
        buttonsList.at(i)->setStyleSheet(QString::fromUtf8("QPushButton:disabled { color: lightGray }"));
    }

    QList<QLineEdit *> lineEditList = this->findChildren<QLineEdit *>();
    for (int i = 0; i < lineEditList.count(); i++){
        lineEditList.at(i)->setStyleSheet(QString::fromUtf8("QLineEdit:disabled { color: lightGray }"));
    }

    QList<QRadioButton *> radioList = this->findChildren<QRadioButton *>();
    for (int i = 0; i < radioList.count(); i++){
        radioList.at(i)->setStyleSheet(QString::fromUtf8("QRadioButton:disabled { color: lightGray }"));
    }


    /* we store the pointer to the CSailDef so we can update it when
       the user clicks OK */
    saildef = sailptr;

    /** Write all the sail data to the screen dimensions of sail. */
    setSailCut( saildef->sailCut );
    setSailType( saildef->sailType );

    txtSailID->setText(QString::fromStdString(saildef->sailID));

    txtLOA->setText( QString::number(saildef->LOA ) );
    txtTriangBase->setText( QString::number(saildef->foreJ ) );
    txtTriangHoist->setText( QString::number(saildef->foreI ) );

    txtClothWidth->setText( QString::number( saildef->clothW ) );
    txtSeamWidth->setText( QString::number( saildef->seamW ) );
    txtLeechHemWidth->setText( QString::number( saildef->leechHemW ) );
    txtFootHemWidth->setText( QString::number( saildef->footHemW ) );
    txtHemsWidth->setText( QString::number( saildef->hemsW ) );

    txtTackDist->setText( QString::number( saildef->tackX ) );
    txtTackHeight->setText( QString::number( saildef->tackY ) );
    txtRake->setText( QString::number( saildef->rake ) );

    txtLuffLen->setText( QString::number( saildef->luffL ) );
    txtLuffRound->setText( QString::number( saildef->luffR ) );
    txtLuffRoundPos->setText( QString::number( saildef->luffRP ) );

    txtGaffAngle->setText( QString::number( saildef->gaffDeg ) );
    txtGaffLen->setText( QString::number( saildef->gaffL ) );
    txtGaffRound->setText( QString::number( saildef->gaffR ) );

    txtLeechLen->setText( QString::number( saildef->leechL ) );
    txtLeechRound->setText( QString::number( saildef->leechR ) );
    txtLeechRoundPos->setText( QString::number( saildef->leechRP ) );

    txtFootLen->setText( QString::number( saildef->footL ) );
    txtFootRound->setText( QString::number( saildef->footR ) );

    txtTopDepth->setText ( QString::number( saildef->mould.profile[2].getDepth()*100 ) );
    txtMidDepth->setText ( QString::number( saildef->mould.profile[1].getDepth()*100 ) );
    txtFootDepth->setText ( QString::number( saildef->mould.profile[0].getDepth()*100 ) );

    txtTwistAngle->setText ( QString::number( saildef->twistDeg ) );
    txtSheetAngle->setText ( QString::number( saildef->sheetDeg ) );

    txtSections->setText ( QString::number( saildef->nbSections ) );
    txtGores->setText ( QString::number( saildef->nbGores ) );
    txtLuffGores->setText (QString::number( saildef->nbLuffGores ) );

    txtDihedral->setText ( QString::number( saildef->dihedralDeg ) );

    setAdvancedButton();

    /** Create button group for sail type. */
    QButtonGroup *bgrpSailType = new QButtonGroup( this );
    bgrpSailType->addButton( radioMainSail );
    bgrpSailType->addButton( radioJib );
    bgrpSailType->addButton( radioWing );
    bgrpSailType->addButton( radioSymetric );

    /** Create button group for sail cut. */
    QButtonGroup *bgrpSailCut = new QButtonGroup( this );
    bgrpSailCut->addButton( radioCross );
    bgrpSailCut->addButton( radioCross2 );
    bgrpSailCut->addButton( radioTwist );
    bgrpSailCut->addButton( radioHorizontal );
    bgrpSailCut->addButton( radioVertical );
    bgrpSailCut->addButton( radioMitre );
    bgrpSailCut->addButton( radioMitre2 );
    bgrpSailCut->addButton( radioRadial );
    bgrpSailCut->addButton( radioRadialBottom );

    /** Set signals and slots connections */
    connect( btnOK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( btnCompute, SIGNAL( pressed() ), this, SLOT( slotCompute() ) );
    connect( btnAdvanced, SIGNAL( clicked() ), this, SLOT( slotAdvanced() ) );
    connect( bgrpSailType, SIGNAL( buttonClicked(QAbstractButton *) ), this, SLOT( slotSailType() ) );
    connect( bgrpSailCut, SIGNAL( buttonClicked(QAbstractButton *) ), this, SLOT( slotSailCut() ) );

    /** Activate "compute" to calculate sail area and diagonal and display them. */
    compute();
}


// member functions

/**
 *  Compute and Display ancillary data of the sail computation
 */
void CFormSailDef::compute()
{
    CSailWorker worker(*saildef);
    lblSailArea->setText ( QString::number( worker.Area() ) );
    lblDiagonal->setText ( QString::number( worker.Diagonal() ) );
    worker.TackToSailLPIntersect();
}


/**
 *  Returns the sail cut layout from the form.
 */
enumSailCut CFormSailDef::getSailCut()
{
    if ( radioHorizontal->isChecked() )
        return HORIZONTAL;
    else if ( radioMitre->isChecked() )
        return MITRE;
    else if ( radioMitre2->isChecked() )
        return MITRE2;
    else if ( radioRadial->isChecked() )
        return RADIAL;
    else if ( radioRadialBottom->isChecked() )
        return RADIALBOTTOM;
    else if ( radioTwist->isChecked() )
        return TWIST;
    else if ( radioVertical->isChecked() )
        return VERTICAL;
    else if ( radioCross2->isChecked() )
        return CROSS2;
    else
        /* default */
        return CROSS;
}


/**
 *  Returns the sail type from the form.
 */
enumSailType CFormSailDef::getSailType()
{
    if ( radioJib->isChecked() )
        return JIB;
    else if ( radioWing->isChecked() )
        return WING;
    else if (radioSymetric->isChecked())
        return SYMMETRIC;
    else
        /* default */
        return MAINSAIL;
}


/**
 *  Enables or disables appropriate controls depending
 *  on the sail cut.
 */
void CFormSailDef::setSailCut( enumSailCut cut )
{
    saildef->sailCut = cut;

    switch ( cut )
    {
    case CROSS:
        radioCross->setChecked( true );
        break;
    case CROSS2:
        radioCross2->setChecked( true );
        break;
    case HORIZONTAL:
        radioHorizontal->setChecked( true );
        break;
    case RADIAL:
        radioRadial->setChecked( true );
        break;
    case TWIST:
        radioTwist->setChecked( true );
        break;
    case VERTICAL:
        radioVertical->setChecked( true );
        break;
    case MITRE:
        radioMitre->setChecked( true );
        break;
    case MITRE2:
        radioMitre2->setChecked( true );
        break;
    case RADIALBOTTOM:
        radioRadialBottom->setChecked(true);
    }

    setAdvancedButton();
}


/**
 *  Enables or disables appropriate controls depending
 *  on the sail type.
 */
void CFormSailDef::setSailType( enumSailType type )
{
    saildef->sailType = type;
    radioRadialBottom->setEnabled( type == SYMMETRIC);

    switch ( type )
    {
    case MAINSAIL:
#ifdef DEBUG
        cout << "setSailType( MAINSAIL )" << endl;
#endif
        radioMainSail->setChecked( true );
        txtTackDist->setEnabled( true );
        txtTackHeight->setEnabled( true );
        txtRake->setEnabled( true );

        txtTriangBase->setEnabled( true );
        txtTriangHoist->setEnabled( true );

        txtGaffLen->setEnabled( true );
        txtGaffRound->setEnabled( true );
        txtGaffAngle->setEnabled( true );
        txtLeechLen->setEnabled(true);
        txtLeechRound->setEnabled(true);
        txtLeechRoundPos->setEnabled(true);

        txtDihedral->setEnabled( false );
        radioCross->setEnabled( true );
        radioCross2->setEnabled( true );
        radioHorizontal->setEnabled( true );
        radioRadial->setEnabled( true );
        radioTwist->setEnabled( true );
        radioVertical->setEnabled( true );
        if(radioMitre->isChecked() || radioMitre2->isChecked()) {
            radioCross->setChecked(true);
        }
        radioMitre->setEnabled( false );
        radioMitre2->setEnabled( false );
        break;

    case JIB:
    case ASYMMETRIC:
#ifdef DEBUG
        cout << "setSailType( JIB )" << endl;
#endif
        radioJib->setChecked( true );
        txtTackDist->setEnabled( true );
        txtTackHeight->setEnabled( true );
        txtRake->setEnabled( true );

        txtTriangBase->setEnabled( true );
        txtTriangHoist->setEnabled( true );
        txtLeechLen->setEnabled(true);
        txtLeechRound->setEnabled(true);
        txtLeechRoundPos->setEnabled(true);

        txtGaffLen->setEnabled( true );
        txtGaffRound->setEnabled( true );
        txtGaffAngle->setEnabled( true );

        txtDihedral->setEnabled( false );
        radioCross->setEnabled( true );
        radioCross2->setEnabled( true );
        radioHorizontal->setEnabled( true );
        radioRadial->setEnabled( true );
        radioTwist->setEnabled( true );
        radioVertical->setEnabled( true );
        radioMitre->setEnabled( true );
        radioMitre2->setEnabled( true );
        break;

    case SYMMETRIC:
        radioSymetric->setChecked( true );
        txtSections->setEnabled(false);
        txtLuffGores->setEnabled(false);
        /* FALLTHRU */
    case WING:
#ifdef DEBUG
        cout << "setSailType( WING )" << endl;
#endif
        radioWing->setChecked( type == WING );
        txtLeechLen->setEnabled( type == WING );
        txtLeechRound->setEnabled( type == WING );
        txtLeechRoundPos->setEnabled( type == WING );
        txtTackDist->setEnabled( true );
        txtTackHeight->setEnabled( true );
        txtRake->setEnabled( true );

        txtTriangBase->setEnabled( true );
        txtTriangHoist->setEnabled( true );

        txtGaffLen->setEnabled( false );
        txtGaffRound->setEnabled( false );
        txtGaffAngle->setEnabled( false );

        txtDihedral->setEnabled( type == WING );
        radioHorizontal->setEnabled( true );
        radioHorizontal->setChecked( type == WING );
        radioCross->setEnabled( false );
        radioCross2->setEnabled( false );
        //radioHorizontal->setEnabled( true );
        radioRadial->setEnabled(false);
        radioTwist->setEnabled( false );
        radioVertical->setEnabled( false );
        radioMitre->setEnabled( false );
        radioMitre2->setEnabled( false );
        break;

    }

    setAdvancedButton();
}

void CFormSailDef::setAdvancedButton() {
    switch (getSailType()) {
    case MAINSAIL:
    case JIB:
    case ASYMMETRIC:
        switch (getSailCut()) {
        case CROSS2:
        case RADIAL:
        case MITRE:
            btnAdvanced->setEnabled(true);
            break;
        case VERTICAL:
            if (getSailType() == MAINSAIL) {
                btnAdvanced->setEnabled(true);
            } else {
                btnAdvanced->setEnabled(false);
            }
            break;
        default:
            btnAdvanced->setEnabled(false);
        }
        break;

    case SYMMETRIC:
        btnAdvanced->setEnabled(true);
        break;

    case WING:
        btnAdvanced->setEnabled(false);

    }

}

// Qt overrides

/**
 *  Saves the parameters entered by the user in the CSailDef.
 *  Slot connected to OK button
 */
void CFormSailDef::accept()
{
    /** Return data if everything is OK. */
    if (check() == true)
        QDialog::accept();
}


/**
 *  Check all dimensions entered in order to make
 *  sure that the sail is possible and reasonable
 */
bool CFormSailDef::check(bool bValidateSail)
{
    long L1=1, L2=1;
    real A1=0, A2=0;
    bool flag = true;
    QString txt;

    /** Create four palettes for levels of warning. */
    QPalette palStd, palHi, palLo, palRel;
    palStd = txtLuffLen->palette();
    palLo = palHi = palRel = palStd;
    palLo.setColor( QPalette::Text, Qt::magenta); // too low value
    palHi.setColor( QPalette::Text, Qt::red );    // too high value
    palRel.setColor( QPalette::Text, Qt::blue );  // related value to be checked

    /** Get sail type and cut. */
    saildef->sailCut = getSailCut();
    saildef->sailType = getSailType();

    /** Get and the sail ID text length. */
    txt = txtSailID->text();
    txt = txt.simplified();

    if (txt.length() > 100)
    {
        txt.truncate(100);
        flag = false;
        txtSailID->setPalette(palHi);
        txtSailID->setText(QString(txt));
    }
    else
    {
        txtSailID->setPalette(palStd);
        txtSailID->setText(QString(txt));
    }
    saildef->sailID = txt.toStdString();

    /** Get and check length of boat. */
    saildef->LOA = txtLOA->text().toDouble();

    if (saildef->LOA < 100)
    {
        flag = false;
        txtLOA->setPalette(palLo);
        saildef->LOA = 100;
    }
    else if (saildef->LOA > 100000)
    {
        flag = false;
        txtLOA->setPalette(palHi);
        saildef->LOA = 100000;
    }
    else
    {
        txtLOA->setPalette(palStd);
    }
    txtLOA->setText(QString::number(saildef->LOA));
    L1 = (long)(saildef->LOA);

    /** Get and check foretriangle base against boat length. */
    saildef->foreJ = txtTriangBase->text().toDouble();

    if (saildef->foreJ > 0.9* L1)
    {
        flag = false;
        txtTriangBase->setPalette(palHi);
        txtLOA->setPalette(palRel);
        saildef->foreJ = floor(0.9*L1);
    }
    else   if (saildef->foreJ < 0.05* L1)
    {
        flag = false;
        txtTriangBase->setPalette(palLo);
        txtLOA->setPalette(palRel);
        saildef->foreJ = ceil(0.05*L1);
    }
    else
    {
        txtTriangBase->setPalette(palStd);
        txtLOA->setPalette(palStd);
    }
    txtTriangBase->setText(QString::number(saildef->foreJ));

    /** Get and check foretriangle hoist against boat length */
    saildef->foreI = txtTriangHoist->text().toDouble();

    if (saildef->foreI > 4*L1)
    {
        flag = false;
        txtTriangHoist->setPalette(palHi);
        txtLOA->setPalette(palRel);
        saildef->foreI = 4*L1;
    }
    else if (saildef->foreI < 0.1*L1)
    {
        flag = false;
        txtTriangHoist->setPalette(palLo);
        txtLOA->setPalette(palRel);
        saildef->foreI = ceil( 0.1*L1);
    }
    else
    {
        txtTriangBase->setPalette(palStd);
        txtLOA->setPalette(palStd);
    }
    txtTriangHoist->setText(QString::number(saildef->foreI));

    /** Check tack position function of boat length. */
    L1 = (long)(saildef->LOA);

    saildef->tackX  = txtTackDist->text().toDouble();
    if (saildef->tackX > 0.9*L1)
    {
        flag = false;
        txtTackDist->setPalette(palHi);
        txtLOA->setPalette(palRel);
        saildef->tackX = floor(0.9*L1);
    }
    else
    {
        txtTackDist->setPalette(palStd);
        txtLOA->setPalette(palStd);
    }
    txtTackDist->setText(QString::number(saildef->tackX));

    saildef->tackY  = txtTackHeight->text().toDouble();
    L1 = (long)(saildef->foreI);

    saildef->tackY  = txtTackHeight->text().toDouble();
    if (saildef->tackY > 0.5*L1)
    {
        flag = false;
        txtTackHeight->setPalette(palHi);
        txtTriangHoist->setPalette(palRel);
        saildef->tackY = floor(0.5*L1);
    }
    else
    {
        txtTackHeight->setPalette(palStd);
        txtTriangHoist->setPalette(palStd);
    }
    txtTackHeight->setText(QString::number(saildef->tackY));

    /** Get length and round data of the 4 sides of sail. */
    saildef->luffL  = txtLuffLen->text().toDouble();
    saildef->luffR  = txtLuffRound->text().toDouble();
    saildef->luffRP = txtLuffRoundPos->text().toInt();

    saildef->gaffDeg = txtGaffAngle->text().toDouble();
    saildef->gaffL  = txtGaffLen->text().toDouble();
    saildef->gaffR  = txtGaffRound->text().toDouble();

    if (saildef->sailType == SYMMETRIC) {
        saildef->leechL = saildef->luffL;
        saildef->leechR = saildef->luffR;
        saildef->leechRP = saildef->luffRP;
    } else {
        saildef->leechL = txtLeechLen->text().toDouble();
        saildef->leechR = txtLeechRound->text().toDouble();
        saildef->leechRP = txtLeechRoundPos->text().toInt();
    }

    saildef->footL  = txtFootLen->text().toDouble();
    saildef->footR  = txtFootRound->text().toDouble();
    saildef->footRP = 50; // imposed value

    /** Check  rake. */
    saildef->rake   = txtRake->text().toDouble();

    switch (saildef->sailType )
    {
    case WING:
        L1 = (long)(saildef->luffL);
        if (saildef->rake > L1)
        {
            flag = false;
            txtRake->setPalette(palHi);
            saildef->rake =L1 - 1;
        }
        else if (saildef->rake < 0)
        {
            flag = false;
            txtRake->setPalette(palHi);
            saildef->rake =0;
        }
        else
        {
            txtRake->setPalette(palStd);
        }
        txtRake->setText(QString::number(saildef->rake));
        break;

    default:
        L1 = (long)(saildef->foreI);
        if (saildef->rake > 0.3*L1)
        {
            flag = false;
            txtRake->setPalette(palHi);
            txtTriangHoist->setPalette(palRel);
            saildef->rake = floor(0.3*L1 - 1);
        }
        else if (saildef->rake < -0.3*L1)
        {
            flag = false;
            txtRake->setPalette(palHi);
            txtTriangHoist->setPalette(palRel);
            saildef->rake =-floor(0.3*L1);
        }
        else
        {
            txtRake->setPalette(palStd);
            txtTriangHoist->setPalette(palStd);
        }
        txtRake->setText(QString::number(saildef->rake));
        break;
    }

    /** Check luff length and round, gaff length. */
    //L1 = (long)(saildef->LOA);

    switch (saildef->sailType )
    {
    case MAINSAIL:
        L1 = (long) (saildef->foreI);
        if (saildef->luffL > 3*L1)
        {
            flag=false;
            txtTriangHoist->setPalette(palRel);
            txtLuffLen->setPalette(palHi);
            saildef->luffL = 3*L1;
        }
        else if (saildef->luffL < 0.1*L1)
        {
            flag=false;
            txtTriangHoist->setPalette(palRel);
            txtLuffLen->setPalette(palLo);
            saildef->luffL = 1 + 0.1*L1;
        }
        else
        {
            txtTriangHoist->setPalette(palStd);
            txtLuffLen->setPalette(palStd);
        }
        txtLuffLen->setText(QString::number(saildef->luffL));

        L2 =(long) ((saildef->luffL ) / 10); // luff round limit

        if (saildef->luffR > L2)
        {
            flag=false;
            txtLuffRound->setPalette(palHi);
            saildef->luffR = L2;
        }
        else if (saildef->luffR <- L2  )
        {
            flag=false;
            txtLuffRound->setPalette(palLo);
            saildef->luffR = - L2 ;
        }
        else
        {
            txtLuffRound->setPalette(palStd);
        }
        txtLuffRound->setText(QString::number(saildef->luffR) );

        /** Check main sail gaff length. */
        L1 =(long) (5);
        //L2 =(long) (6 * saildef->luffL);

        if (saildef->gaffL < L1)
        {
            txtGaffLen->setPalette(palLo);
            saildef->gaffL= L1;
            flag = false;
        }
        //else if (saildef->gaffL > L2)
        //{
        //    txtGaffLen->setPalette(palHi);
        //    saildef->gaffL= L2;
        //    flag = false;
        //}
        else
        {
            txtGaffLen->setPalette(palStd);
        }
        txtGaffLen->setText(QString::number(saildef->gaffL) );

        /** Check main sail gaff round. */
        L1 = (long) ((saildef->gaffL )/ 8);

        if (saildef->gaffR > L1)
        {
            flag=false;
            txtGaffRound->setPalette(palHi);
            saildef->gaffR = L1;
        }
        else if (saildef->gaffR <0)
        {
            flag=false;
            txtGaffRound->setPalette(palLo);
            saildef->gaffR = 0;
        }
        else
        {
            txtGaffRound->setPalette(palStd);
        }
        txtGaffRound->setText(QString::number(saildef->gaffR) );

        break;

    case JIB:
    case ASYMMETRIC:
        L1 =( long) (sqrt(((saildef->foreI - saildef->tackY) * (saildef->foreI - saildef->tackY)) + (saildef->foreJ * saildef->foreJ ))-1);
        if (saildef->luffL > L1)
        {
            flag=false;
            txtTriangHoist->setPalette(palRel);
            txtTackHeight->setPalette(palRel);
            txtLuffLen->setPalette(palHi);
            saildef->luffL = int (L1);
        }
        else if (saildef->luffL < (L1 / 10) )
        {
            flag=false;
            txtLuffLen->setPalette(palLo);
            saildef->luffL = int(1 + real(L1) / 10);
        }
        else
        {
            txtTriangHoist->setPalette(palStd);
            txtTackHeight->setPalette(palStd);
            txtLuffLen->setPalette(palStd);
        }
        txtLuffLen->setText(QString::number(saildef->luffL) );

        L2 = (long) ((saildef->luffL )/ 10); // round limit
        /** To acommodate code zero jib
            the positive luff round limit is twice negative round limit
        */
        if (saildef->luffR > 2*L2)
        {
            flag=false;
            txtLuffRound->setPalette(palHi);
            saildef->luffR = 2*L2;
        }
        else if (saildef->luffR <-L2)
        {
            flag=false;
            txtLuffRound->setPalette(palLo);
            saildef->luffR = -L2;
        }
        else
        {
            txtLuffRound->setPalette(palStd);
        }
        txtLuffRound->setText(QString::number(saildef->luffR) );

        /** Check jib gaff length. */
        L1 =(long) (1);
        L2 =(long) (100);

        if (saildef->gaffL < L1)
        {
            txtGaffLen->setPalette(palLo);
            saildef->gaffL = L1;
            flag = false;
        }
        else if (saildef->gaffL > L2)
        {
            txtGaffLen->setPalette(palHi);
            saildef->gaffL = L2;
            flag = false;
        }
        else
        {
            txtGaffLen->setPalette(palStd);
        }
        txtGaffLen->setText(QString::number(saildef->gaffL) );

        // reset gaff round
        txtGaffRound->setPalette(palStd);
        txtGaffRound->setText(QString::number(0) );

        break;

    case WING:
        /** For a wing set gaff length to minimum. */
        saildef->gaffL = 2;
        txtGaffLen->setText(QString::number(saildef->gaffL) );
        saildef->gaffR = 0;
        txtGaffRound->setText(QString::number(saildef->gaffR) );

        // check gaff angle and set it to be horizontal
        A1 = saildef->rake / saildef->luffL;
        saildef->gaffDeg = acos (A1) * 180/PI;
        txtGaffAngle->setText(QString::number(floor(saildef->gaffDeg)) );

        // adjust leech length such that foot is horizontal
        A1 = saildef->rake + saildef->gaffL - saildef->footL;
        A2 = saildef->luffL * sin(saildef->gaffDeg * PI/180);

        saildef->leechL = floor(sqrt( A1*A1 + A2*A2 ) );
        txtLeechLen->setText(QString::number(saildef->leechL) );

        L2 =(long) ((saildef->luffL )/ 4); // wing luff round limit

        if (saildef->luffR > L2)
        {
            flag=false;
            txtLuffRound->setPalette(palHi);
            saildef->luffR = L2;
        }
        else if (saildef->luffR <0)
        {
            flag=false;
            txtLuffRound->setPalette(palLo);
            saildef->luffR = 0;
        }
        else
        {
            txtLuffRound->setPalette(palStd);
        }
        txtLuffRound->setText(QString::number(saildef->luffR) );

        break;

    case SYMMETRIC:
        saildef->gaffL = 2;
        txtGaffLen->setText(QString::number(saildef->gaffL) );
        saildef->gaffR = 0;
        txtGaffRound->setText(QString::number(saildef->gaffR) );

        // check gaff angle and set it to be horizontal
        A1 = saildef->rake / saildef->luffL;
        saildef->gaffDeg = acos (A1) * 180/PI;
        txtGaffAngle->setText(QString::number(floor(saildef->gaffDeg)) );


        L2 =(long) ((saildef->luffL )/ 4); // wing luff round limit

        if (saildef->luffR > L2)
        {
            flag=false;
            txtLuffRound->setPalette(palHi);
            saildef->luffR = L2;
        }
        else if (saildef->luffR <0)
        {
            flag=false;
            txtLuffRound->setPalette(palLo);
            saildef->luffR = 0;
        }
        else
        {
            txtLuffRound->setPalette(palStd);
        }
        txtLuffRound->setText(QString::number(saildef->luffR) );

        break;

    }

    if (saildef->sailType != SYMMETRIC) {
        /** Check leech length. */
        L1 = (long) saildef->luffL;
        L1 = L1 + (long) saildef->gaffL;

        if (saildef->leechL > 1.5*L1)
        {
            flag = false;
            txtLuffLen->setPalette(palRel);
            txtLeechLen->setPalette(palHi);
            saildef->leechL = 1.5*L1 -1;
        }
        else if (saildef->leechL < 0.5*L1)
        {
            flag = false;
            txtLuffLen->setPalette(palRel);
            txtLeechLen->setPalette(palLo);
            saildef->leechL = 0.5*L1 +1;
        }
        else
        {
            txtLuffLen->setPalette(palStd);
            txtLeechLen->setPalette(palStd);
        }
        txtLeechLen->setText(QString::number(saildef->leechL));

        /** Check leech round. */
        L1 = (long) (saildef->leechL / 10);
        if (saildef->leechR > 3*L1)
        {
            flag = false;
            txtLeechRound->setPalette(palHi);
            txtLeechRound->setText(QString::number(3*L1) );
        }
        else if (saildef->leechR <-L1)
        {
            flag = false;
            txtLeechRound->setPalette(palLo);
            txtLeechRound->setText(QString::number(-L1) );
        }
        else
            txtLeechRound->setPalette(palStd);
    }

    /** Check foot length. */
    switch (saildef->sailType )
    {
    case MAINSAIL:
        L2 = (long)(saildef->luffL + saildef->gaffL - saildef->leechL);
        if (L2 < (long)(0.1*(saildef->luffL)))
            L2=(long)(0.1*(saildef->luffL));
        break;
    case JIB:
    case ASYMMETRIC:
        L2 = (long)(saildef->luffL  - saildef->leechL);
        if (L2 < (long)(0.1*(saildef->luffL)))
            L2=(long)(0.1*(saildef->luffL));
        break;
    case SYMMETRIC:
    case WING:
        L2 = (long)(saildef->luffL  - saildef->leechL);
        if (L2 < (long)(0.1*(saildef->luffL)))
            L2=(long)(0.1*(saildef->luffL));
        break;
    }

    if (saildef->footL > 1.5*(saildef->leechL) )
    {
        flag=false;
        txtLeechLen->setPalette( palRel );
        txtFootLen->setPalette( palHi );
        saildef->footL = 1.5*(saildef->leechL) -1;
    }
    else if (saildef->footL < L2)
    {
        flag=false;
        txtLeechLen->setPalette( palRel );
        txtFootLen->setPalette( palLo );
        saildef->footL = L2 +1;
    }
    else
    {
        txtLeechLen->setPalette( palStd );
        txtFootLen->setPalette( palStd );
    }
    txtFootLen->setText( QString::number( saildef->footL ) );

    /** Check foot round value. */
    L1 = (long)(saildef->footL / 5);

    switch (saildef->sailType)
    {
    case WING:
        saildef->footR = 0;
        txtFootRound->setText(QString::number(saildef->footR));
        break;

    default:

        if (saildef->footR > L1)
        {
            flag=false;
            txtFootLen->setPalette( palRel );
            txtFootRound->setPalette(palHi);
            saildef->footR = L1;
        }
        else if (saildef->footR <-L1)
        {
            flag=false;
            txtFootLen->setPalette( palRel );
            txtFootRound->setPalette(palLo);
            saildef->footR = 1-L1;
        }
        else
        {
            txtFootLen->setPalette( palStd );
            txtFootRound->setPalette(palStd );
        }
        txtFootRound->setText(QString::number(saildef->footR));
        break;
    }

    /** Get cloth, seams and hems width. */
    saildef->clothW = txtClothWidth->text().toDouble();
    saildef->seamW  = txtSeamWidth->text().toDouble();
    saildef->leechHemW = txtLeechHemWidth->text().toDouble();
    saildef->footHemW = txtFootHemWidth->text().toDouble();
    saildef->hemsW = txtHemsWidth->text().toDouble();

    if (saildef->sailCut != RADIAL && saildef->sailCut != VERTICAL) {
        unsigned int minPanels = saildef->sailCut == CROSS2 ? 1 : 3;
        /** Check cloth width. */
        if (saildef->clothW < saildef->leechL /100)
        {
            saildef->clothW = saildef->leechL /100 +1;
            flag = false;
            txtClothWidth->setPalette(palLo);
        }
        else if (saildef->clothW > saildef->leechL / minPanels)
        {
            saildef->clothW = saildef->leechL / minPanels;
            flag = false;
            txtClothWidth->setPalette(palHi);
        }
    }

    txtClothWidth->setText( QString::number(saildef->clothW));

    L1 = (long)(5+ saildef->clothW / 10);

    /** Check seams width function of cloth width. */
    if (saildef->seamW > L1)
    {
        flag=false;
        txtSeamWidth->setPalette( palHi);
        saildef->seamW = L1;
    }
    else if (saildef->seamW < 0)
    {
        flag=false;
        txtSeamWidth->setPalette( palLo);
        saildef->seamW = 0;
    }
    else
    {
        txtSeamWidth->setPalette( palStd);
    }
    txtSeamWidth->setText( QString::number(saildef->seamW));

    /** Check leech hem width function of cloth width. */
    if (saildef->leechHemW > L1*2)
    {
        flag=false;
        txtLeechHemWidth->setPalette( palHi);
        saildef->leechHemW = L1*2;
    }
    else if (saildef->leechHemW  < 0)
    {
        flag=false;
        txtLeechHemWidth->setPalette( palLo);
        saildef->leechHemW = 0;
    }
    else
    {
        txtLeechHemWidth->setPalette( palStd);
    }
    txtLeechHemWidth->setText( QString::number(saildef->leechHemW));

    /** Check foot hem width function of cloth width. */
    if ((saildef->footHemW > L1*2) || (saildef->footHemW > 0 && saildef->footTapeDistance > 0))
    {
        flag=false;
        txtFootHemWidth->setPalette( palHi);
        saildef->footHemW = saildef->footTapeDistance > 0 ? 0 : L1*2;
    }
    else if (saildef->footHemW  < 0)
    {
        flag=false;
        txtFootHemWidth->setPalette( palLo);
        saildef->footHemW = 0;
    }
    else
    {
        txtFootHemWidth->setPalette( palStd);
    }
    txtFootHemWidth->setText( QString::number(saildef->footHemW));

    /** Check other luff and gaff hem width function of cloth width. */
    if ((saildef->hemsW > L1) || (saildef->hemsW > 0 && saildef->luffTapeDistance > 0))
    {
        flag=false;
        txtHemsWidth->setPalette( palHi);
        saildef->hemsW = saildef->luffTapeDistance > 0 ? 0 :L1;
    }
    else if (saildef->hemsW < 0)
    {
        flag=false;
        txtHemsWidth->setPalette( palLo);
        saildef->hemsW = 0;
    }
    else
    {
        txtHemsWidth->setPalette( palStd);
    }
    txtHemsWidth->setText( QString::number(saildef->hemsW));


    /** Get the mould data. */
    saildef->mould.profile[2].setDepth( real(txtTopDepth->text().toInt())/100 );
    saildef->mould.profile[1].setDepth( real(txtMidDepth->text().toInt())/100 );
    saildef->mould.profile[0].setDepth( real(txtFootDepth->text().toInt())/100 );


    /** Get and check dihedral angle for a wing. */
    saildef->dihedralDeg = txtDihedral->text().toInt();
    if (saildef->dihedralDeg<90)
    {
        flag = false;
        txtDihedral->setPalette( palLo );
        saildef->dihedralDeg = 90;
    }
    else if (saildef->dihedralDeg > 180)
    {
        flag = false;
        txtDihedral->setPalette( palHi );
        saildef->dihedralDeg = 180;
    }
    else
    {
        txtDihedral->setPalette( palStd );
    }
    txtDihedral->setText(QString::number(saildef->dihedralDeg));


    /** Get and check twist of the sail. */
    saildef->twistDeg = txtTwistAngle->text().toInt();
    if (saildef->twistDeg > 45)
    {
        flag = false;
        txtTwistAngle->setPalette( palHi );
        saildef->twistDeg = 45;
    }
    else if (saildef->twistDeg < 0)
    {
        flag = false;
        txtTwistAngle->setPalette( palLo );
        saildef->twistDeg = 0;
    }
    else
    {
        txtTwistAngle->setPalette( palStd );
    }
    txtTwistAngle->setText(QString::number(saildef->twistDeg));


    /** Get and check sheeting angle of the sail. */
    saildef->sheetDeg = txtSheetAngle->text().toInt();

    if (saildef->sheetDeg > 45)
    {
        flag=false;
        txtSheetAngle->setPalette( palHi);
        saildef->sheetDeg = 45;
    }
    else
    {
        txtSheetAngle->setPalette( palStd);
    }

    L2 = 0; // set lower limit for sheeting main or jib
/*    switch (saildef->sailType ) // set lower limit for sheeting main or jib
    {
    case MAINSAIL:
        L2 = 0;
        break;
    case JIB:
    case ASYMMETRIC:
        L2 = 0;
        break;
    case WING:
        L2 = 0;
        break;
    case SYMMETRIC:
        L2 = 0;
        break;
    } */

    if (saildef->sheetDeg < L2)
    {
        flag=false;
        txtSheetAngle->setPalette( palLo);
        saildef->sheetDeg = L2;
    }
    else
    {
        txtSheetAngle->setPalette( palStd);
    }
    txtSheetAngle->setText(QString::number(saildef->sheetDeg));


    /** Get and check radial sections and gores number. */
    if (saildef->sailCut == RADIAL || saildef->sailCut == RADIALBOTTOM)
    {
        saildef->nbGores = txtGores->text().toInt();

        if (saildef->nbGores < 3)
        {
            flag=false;
            txtGores->setPalette( palLo);
            txtGores->setText(QString::number(3));
        }
        else  if (saildef->nbGores > 12)
        {
            flag=false;
            txtGores->setPalette( palHi);
            txtGores->setText(QString::number(12));
        }
        else
        {
            txtGores->setPalette( palStd);
        }
        saildef->nbGores = txtGores->text().toInt();

        saildef->nbSections = txtSections->text().toInt();

        if (saildef->nbSections < 3)
        {
            flag=false;
            txtSections->setPalette( palLo);
            txtSections->setText(QString::number(3));
        }
        else if (saildef->nbSections > 8)
        {
            flag=false;
            txtSections->setPalette( palHi);
            txtSections->setText(QString::number(8));
        }
        else
        {
            txtSections->setPalette( palStd);
        }
        saildef->nbSections = txtSections->text().toInt();

        saildef->nbLuffGores = txtLuffGores->text().toInt();

        if (saildef->nbLuffGores < 1)
        {
            flag=false;
            txtLuffGores->setPalette( palLo);
            txtLuffGores->setText(QString::number(1));
        }
        else  if (saildef->nbLuffGores > saildef->nbGores -2)
        {
            flag=false;
            txtLuffGores->setPalette( palHi);
            txtLuffGores->setText(QString::number(saildef->nbGores -2));
        }
        else
        {
            txtLuffGores->setPalette( palStd);
        }
        saildef->nbLuffGores = txtLuffGores->text().toInt();
    }

    // if this is a spinnaker then validate that luff is OK
    if (bValidateSail && saildef->sailType == SYMMETRIC && saildef->sailCut == HORIZONTAL) {
        CSailWorker worker = CSailWorker(*saildef);
        try {
            worker.validateSymmetricalSpinnakerLuff();
        } catch (layout_error &le) {
            QMessageBox box;
            QString title = "Error";
            QString content = le.what();
            box.warning(QApplication::activeWindow(), title, content);
            flag = false;
        } catch (invalid_argument &ia) {
            QMessageBox box;
            QString title = "Error";
            QString content = ia.what();
            box.warning(QApplication::activeWindow(), title, content);
            flag = false;
        } catch (range_error &re) {
            QMessageBox box;
            QString title = "Error";
            QString content = re.what();
            box.warning(QApplication::activeWindow(), title, content);
            flag = false;
        }
    }

    //  return true IF everything is OK
    return flag;
}


/**
 *  Enable/disable appropriate controls when the user
 *  changes the sail cut.
 **/
void CFormSailDef::slotSailCut()
{
    setSailCut( getSailCut() );
}



/**
 *  Saves the parameters entered by the user in the CSailDef.
 *  compute and display ancillary sail data
 *
 *  slot connected to Compute button
 */
void CFormSailDef::slotCompute()
{
    // ckeck data
    if (!check(false)) {
        return;
    }

    // calculate sail area and diagonal
    compute();

    // display ancillary data
    real w=0;
    bool bPrintCrossMeasurements = false;
    bool bTriangularSail = true;
    QString txta, txtb, txtc, txtd, txte;
    struct crossHeights cheights;
    CSailDef & sd = *saildef;
    sd.rake = 0;
    //sd.twistDeg = 0;
    sd.sheetDeg = 0;

    //CSailWorker worker(*saildef);
    CSailWorker worker(sd);
    try {
        worker.makeSail();

        if (worker.sailType == MAINSAIL || worker.sailType == SYMMETRIC) {
            if (worker.gaffL / worker.luffL < 0.05) {
                bPrintCrossMeasurements = true;
            } else {
                bTriangularSail = false;
            }
        }

        // if this is a spinnaker then validate that luff is OK
        if (saildef->sailType == SYMMETRIC && saildef->sailCut == HORIZONTAL) {
            worker.validateSymmetricalSpinnakerLuff();
        }


        txta = tr("Sail corners coordinates");
        txta = txta+"\n  "+tr("tack")+" \t x = "+QString::number(int(worker.tack.x())) +"\n\t y = "+QString::number(int(worker.tack.y())) +" mm" ;
        txta = txta+"\n  "+tr("clew")+" \t x = "+QString::number(int(worker.clew.x())) +"\n\t y = "+QString::number(int(worker.clew.y())) +" mm";
        txta = txta+"\n  "+tr("head")+" \t x = "+QString::number(int(worker.head.x())) +"\n\t y = "+QString::number(int(worker.head.y())) +" mm";
        txta = txta+"\n  "+tr("peak")+" \t x = "+QString::number(int(worker.peak.x())) +"\n\t y = "+QString::number(int(worker.peak.y())) +" mm ";

        real luffLength, leechLength, footLength;

        if (worker.sailType == SYMMETRIC) {
            luffLength = leechLength = worker.CalculateLeechLength(bTriangularSail);
            txtb = "\n"+tr("Leech Length")+" = "+QString::number(int(leechLength))+" mm ";
            txtb = txtb+"  ("+QString::number(worker.CalculateLeechRoundDistance())+" mm around curve)";
            txtb = txtb+"\n"+tr("Luff Length")+"  = "+QString::number(int(luffLength))+" mm ";
            txtb = txtb+"  ("+QString::number(worker.CalculateLeechRoundDistance())+" mm around curve)";

            if (worker.sailCut == HORIZONTAL) {
                struct flattenedSpinnakerValues values = FlattenedSpinnakerDetails().getValues(worker.m_flattened);

                txtb = txtb+"\n"+tr("Leech Length Around Curve (flattened)")+"  = "+QString::number(int(values.leechLength))+" mm";
                txtb = txtb+"\n"+tr("Leech Length Straight (flattened)")+"  = "+QString::number(int(values.leechLengthStraightLine))+" mm ";
                txtb = txtb+"\n"+tr("Leech Round (flattened)")+"  = "+QString::number(int(values.leechRound))+" mm";
                txtb = txtb+"\n"+tr("Centre Round (flattened)")+"  = "+QString::number(int(values.centreRound))+" mm";
                txtb = txtb+"\n"+tr("Half Mid-girth (flattened)")+"  = "+QString::number(int(values.halfMidGirth))+" mm";
                txtb = txtb+"\n"+tr("Foot Median (flattened)")+"  = "+QString::number(int(values.footMedian))+" mm";
                txtb = txtb+"\n"+tr("Fullness Factor (flattened)")+"  = "+QString::number(int(values.fullnessFactor))+"%";
                txtb = txtb+"\n"+tr("Part Head Angle (flattened)")+"  = "+QString::number(int(values.partHeadAngle))+" degrees";
            }
        } else {
            leechLength = worker.CalculateLeechLength(bTriangularSail);
            txtb = "\n"+tr("Leech Length")+" = "+QString::number(int(leechLength))+" mm ";
            luffLength = worker.CalculateLuffLength();
            txtb = txtb+"\n"+tr("Luff Length")+"  = "+QString::number(int(luffLength))+" mm ";
        }

        footLength = worker.CalculateFootLength();
        txtb = txtb+"\n"+tr("Foot Length")+"  = "+QString::number(int(footLength))+" mm ";
        txtb = txtb+"("+QString::number(int(worker.distanceBetween(worker.clew, worker.tack)))+" mm)";
        txtb = txtb+"\n"+tr("Foot Median")+"  = "+QString::number(int(worker.CalculateFootMedian()))+" mm ";
        txtb = txtb+"\n"+tr("Top Width")+"  = "+QString::number(  int((worker.peak-worker.head).norm())  )+" mm ";

        if (!bTriangularSail) {
            txtb = txtb+"\n"+tr("Diagonal")+"  = "+QString::number(int(worker.Diagonal()+.5))+" mm ";
        }

        QString strCrossMeasurementType;

        real w875 = -1, w75 = 0, w50 = 0, w25 = 0;

        switch (saildef->crossMeasurementType) {
        case ERS:
            strCrossMeasurementType = "ERS";
            worker.IsafCrossMeasurement(cheights, worker.sailType != SYMMETRIC);
            w75 = cheights.threeQuarterHeight;
            w50 = cheights.halfHeight;
            w25 = cheights.quarterHeight;
            break;
        case LUFF_LEECH_POINTS:
            strCrossMeasurementType = "LLP";
            worker.IsafCrossMeasurement(cheights, false);
            w75 = cheights.threeQuarterHeight;
            w50 = cheights.halfHeight;
            w25 = cheights.quarterHeight;
            break;
        case IRC:
            strCrossMeasurementType = "IRC";
            w875 = worker.IRCwidth(0.875);
            w75 = worker.IRCwidth(0.75);
            w50 = worker.IRCwidth(0.5);
            w25 = worker.IRCwidth(0.25);
            break;
        case IOR:
            strCrossMeasurementType = "IOR";
            w875 = worker.SailWidth(0.875);
            w75 = worker.SailWidth(0.75);
            w50 = worker.SailWidth(0.5);
            w25 = worker.SailWidth(0.25);
            break;
        case LUFF_FOLD:
            strCrossMeasurementType = "LF";
            worker.LuffFoldCrossMeasurements(cheights);
            w75 = cheights.threeQuarterHeight;
            w50 = cheights.halfHeight;
            w25 = cheights.quarterHeight;
            break;
        }

        if (worker.sailType != SYMMETRIC) {
            w = worker.SailLP();
            txtb = txtb+"\nLP = " +QString::number(int(w)) +" mm ";
        } else {
            real sailArea = 0.25 * luffLength/1000 * (0.5 * footLength + w75 + w50 + w25)/1000;
            // round sail area to 2 decimal places
            sailArea = int((sailArea * 100 + 0.5)) / 100.0;
            txtb = txtb+"\nERS Sail Area = " +QString::number(sailArea) +" Sq M ";
            // maximum panel dimensions
            txtb = txtb+"\nMaximum panel height = " +QString::number(worker.maxPanelHeight()) +" mm";
            txtb = txtb+"\nMaximum panel width = " +QString::number(worker.maxPanelWidth()) +" mm";
        }

        if (bPrintCrossMeasurements) {
            txtc = "\n" + tr("Sail width measurements ");

            if (w875 > -1) {
                txtc = txtc+ "\n  h= 0.875";
                txtc = txtc+"\t "+strCrossMeasurementType+" w= "+QString::number(int(w875)) +" mm";
            }
            txtc = txtc+ "\n  h= 0.75";
            txtc = txtc+"\t "+strCrossMeasurementType+" w= "+QString::number(int(w75)) +" mm";
            if (saildef->sailType == SYMMETRIC) {
                txtc += "  ("+QString::number(cheights.panelThreeQuarterCrossHeight) +" mm)";
            }
            txtc = txtc+ "\n  h= 0.50";
            txtc = txtc+"\t "+strCrossMeasurementType+" w= "+QString::number(int(w50)) +" mm";
            if (saildef->sailType == SYMMETRIC) {
                txtc += "  ("+QString::number(cheights.panelHalfCrossHeight) +" mm)";
            }
            txtc = txtc+ "\n  h= 0.25";
            txtc = txtc+"\t "+strCrossMeasurementType+" w= "+QString::number(int(w25)) +" mm";
            if (saildef->sailType == SYMMETRIC) {
                txtc += "  ("+QString::number(cheights.panelQuarterCrossHeight) +" mm)";
            }
        }


        if (worker.clothAlignsWithLeech) {
            txtc = txtc + "\n\nDistance Head to Leech Turn Point = "+QString::number(worker.HeadToLeechTurnPointDistance()) + " mm\n";
        }

        // windows
        if (saildef->window1.generate) {
            txtc = txtc + "\nWindow 1:\n";
            txtc = txtc + "  Distance to tack (x,y) = "+QString::number(worker.window1.sailXpos)+"mm, "+QString::number(worker.window1.sailYpos)+"mm\n";
            txtc = txtc + "  Bottom Left to Luff = "+QString::number(worker.window1.bottomLeftToLuff)+"mm\n";
            txtc = txtc + "  Top Left to Luff = "+QString::number(worker.window1.topLeftToLuff)+"mm\n";
        }

        if (saildef->window2.generate) {
            txtc = txtc + "\nWindow 2:\n";
            txtc = txtc + "  Distance to tack (x,y) = "+QString::number(worker.window2.sailXpos)+"mm, "+QString::number(worker.window1.sailYpos)+"mm\n";
            txtc = txtc + "  Bottom Left to Luff = "+QString::number(worker.window2.bottomLeftToLuff)+"mm\n";
            txtc = txtc + "  Top Left to Luff = "+QString::number(worker.window2.topLeftToLuff)+"mm\n";
        }

        displayData(  txta, txtb, txtc, txtd, txte );
    } catch (layout_error &le) {
        cout << "slotCompute error" << endl;
        QMessageBox box;
        QString title = "Error";
        QString content = le.what();
        box.warning(QApplication::activeWindow(), title, content);
        return;
    } catch (invalid_argument &ia) {
        QMessageBox box;
        QString title = "Error";
        QString content = ia.what();
        box.warning(QApplication::activeWindow(), title, content);
        return;
    } catch (range_error &re) {
        QMessageBox box;
        QString title = "Error";
        QString content = re.what();
        box.warning(QApplication::activeWindow(), title, content);
        return;
    }


}


/**
 *  Display ancillary data in a message box
 */
void CFormSailDef::displayData(QString &txt0, QString &txt1, QString &txt2, QString &txt3, QString &txt4 )
{
    QMessageBox* mb = new QMessageBox();
    mb->setIcon(QMessageBox::NoIcon);
    mb->setWindowTitle("Sailcut");
    mb->setText (QString(txt0+"\n" +txt1+"\n" +txt2+"\n" +txt3+"\n" +txt4));
    mb->setButtonText (0, "OK");
    mb->exec();
    delete mb;
}


/**
 *  Enable/disable appropriate controls when the user
 *  changes the sail type.
 **/
void CFormSailDef::slotSailType()
{
    setSailType( getSailType() );
}

void CFormSailDef::slotAdvanced()
{
    //cout << "CFormSailDef::slotAdvanced()" << endl;
    if (check(false)) {
        compute();
        CFormSailAdvanced(this, saildef).exec();
    }
}


CFormSailAdvanced::CFormSailAdvanced( QWidget* parent, CSailDef * sailptr )
        : QDialog(parent)
{
    setupUi(this);
    setModal(true);
    this->setAttribute(Qt::WA_AlwaysShowToolTips, true);

    QList<QPushButton *> buttonsList = this->findChildren<QPushButton *>();
    for (int i = 0; i < buttonsList.count(); i++){
        buttonsList.at(i)->setStyleSheet(QString::fromUtf8("QPushButton:disabled { color: lightGray }"));
    }

    QList<QLineEdit *> lineEditList = this->findChildren<QLineEdit *>();
    for (int i = 0; i < lineEditList.count(); i++){
        lineEditList.at(i)->setStyleSheet(QString::fromUtf8("QLineEdit:disabled { color: lightGray }"));
    }

    QList<QRadioButton *> radioList = this->findChildren<QRadioButton *>();
    for (int i = 0; i < radioList.count(); i++){
        radioList.at(i)->setStyleSheet(QString::fromUtf8("QRadioButton:disabled { color: lightGray }"));
    }

    QList<QComboBox *> comboList = this->findChildren<QComboBox *>();
    for (int i = 0; i < comboList.count(); i++){
        comboList.at(i)->setStyleSheet(QString::fromUtf8("QComboBox:disabled { color: lightGray }"));
    }

    /* we store the pointer to the CSailDef so we can update it when
       the user clicks OK */
    saildef = sailptr;

    cout << "copy from saildef batten group"  << endl;
    battenGroup.updateAll(saildef->battenGroup);

    //genSpeedSeamCheckBox->setChecked(saildef->generateSpeedSeam);
    interpolCheckBox->setChecked(saildef->interpolMethod == INTERPOL2);
    interpolationStrengthLineEdit->setText(QString::number(saildef->interpol2Strength));
    interpolationStrengthLineEdit->setEnabled(interpolCheckBox->isChecked());
    interpol2RPLineEdit->setText(QString::number(saildef->interpol2RP));

    splitsTextField->setText(QString::fromStdString(saildef->splitPanelNos));

    filletPanelWidthTextField->setText(QString::number(saildef->filletPanelWidth, 10));

    speedPanelWidthTextField->setText(QString::number(saildef->speedPanelWidth, 10));

    //footPanelsSpinBox->setValue(saildef->footPanelSections);

    speedSeamHeightSpinBox->setValue(saildef->speedSeamLeechHeight);

    // remove the tab for now as functions don't work properly
    tabWidget->removeTab(leechTabIdx);
    patchesTabIdx--;
    reefPatchesTabIdx--;
    windowsIdx--;

    // show 1st tab
    tabWidget->setCurrentIndex(0);
    footEdgeCheckBox->setChecked(saildef->footEdgeAtZeroZ);
    bottomCamberLineEdit->setText(QString::number(saildef->mould.bottomDepth * 100));
    bottomCamberLineEdit->setEnabled(/*saildef->sailType == SYMMETRIC && */!footEdgeCheckBox->isChecked());

    if (saildef->sailType == MAINSAIL) {
        checkBoxStraightLineLeech->setChecked(saildef->straightLineLeech);
        checkBoxClothAlignLeech->setChecked(saildef->clothAlignsWithLeech);
        leechTurnPointPos->setText(QString::number(saildef->leechTurnPos, 10));
        checkBoxRadialHead->setChecked(saildef->radialHead);
        lensFootCheckBox->setEnabled(saildef->footR > 0
                                     && saildef->sailCut == CROSS2
                                     && saildef->footHemW == 0);
        if (lensFootCheckBox->isEnabled()) {
            lensFootCheckBox->setChecked(saildef->lensFoot);
        }
        if (saildef->sailCut == VERTICAL) {
            tabWidget->removeTab(battensTabIdx);
            patchesTabIdx--;
            reefPatchesTabIdx--;
            windowsIdx--;
        }
    } else {
        checkBoxStraightLineLeech->setChecked(false);
        checkBoxClothAlignLeech->setChecked(false);
        leechTurnPointPos->setText(QString::number(0));
        checkBoxRadialHead->setChecked(false);

        checkBoxStraightLineLeech->setEnabled(false);
        checkBoxClothAlignLeech->setEnabled(false);
        leechTurnPointPos->setEnabled(false);
        checkBoxRadialHead->setEnabled(false);
        lensFootCheckBox->setChecked(false);
        lensFootCheckBox->setEnabled(false);

        addBattenButton->setEnabled(false);
        battenIdLineEdit->setEnabled(false);
        battenLeechAngleLineEdit->setEnabled(false);
        battenLeechPositionLineEdit->setEnabled(false);
        battenLengthLineEdit->setEnabled(false);
        inwardOffsetLineEdit->setEnabled(false);
        tabWidget->removeTab(battensTabIdx);
        patchesTabIdx--;
        reefPatchesTabIdx--;
        windowsIdx--;
        tabWidget->removeTab(reefPatchesTabIdx);
        windowsIdx--;
    }

    if (saildef->sailCut == CROSS2 && (saildef->sailType == MAINSAIL || saildef->sailType == JIB)) {
        // set up window widgets
        WindowWidget * w1 = new WindowWidget();
        w1->setValues("Window 1", saildef->window1);
        WindowWidget * w2 = new WindowWidget();
        w2->setValues("Window 2", saildef->window2);
        gridLayout->addWidget(w1, 0, 0);
        gridLayout->addWidget(w2, 1, 0);
        windowWidgets.push_back(w1);
        windowWidgets.push_back(w2);
    } else {
        tabWidget->removeTab(windowsIdx);
    }

    crossMeasurementComboBox->addItem("ERS", QString::number(0));
    crossMeasurementComboBox->addItem("Luff and Leech Points", QString::number(1));
    crossMeasurementComboBox->addItem("IRC", QString::number(2));
    crossMeasurementComboBox->addItem("IOR", QString::number(3));
    crossMeasurementComboBox->addItem("Luff Fold", QString::number(3));

    int idx = 0;
    switch(saildef->crossMeasurementType) {
    case ERS:
        idx = 0;
        break;
    case LUFF_LEECH_POINTS:
        idx = 1;
        break;
    case IRC:
        idx = 2;
        break;
    case IOR:
        idx = 3;
        break;
    case LUFF_FOLD:
        idx = 4;
    }

    crossMeasurementComboBox->setCurrentIndex(idx);

    profileSubTypeComboBox->addItem("Default", QString::number(0));
    profileSubTypeComboBox->addItem("Ellipse", QString::number(1));
    profileSubTypeComboBox->addItem("Ellipse/Flat", QString::number(1));
    profileSubTypeComboBox->addItem("Circle", QString::number(2));

    switch (saildef->profileSubType) {
    case PROFILE_DEFAULT:
        idx = 0;
        break;
    case PROFILE_ELLIPSE:
        idx = 1;
        break;
    case PROFILE_ELLIPSE_FLAT:
        idx = 2;
        break;
    case PROFILE_CIRCLE:
        idx = 3;
        break;

    }

    profileSubTypeComboBox->setCurrentIndex(idx);
    profileSubTypeComboBox->setEnabled(saildef->sailType == SYMMETRIC);

    bottomPanelHeightLineEdit->setText(QString::number(saildef->bottomPanelHeight));
    luffOffsetLineEdit->setText(QString::number(saildef->luffOffset));
    luffOffsetLineEdit->setEnabled(saildef->sailType == SYMMETRIC);
    luffOffsetRoundPLineEdit->setText(QString::number(saildef->luffOffsetRP));
    panelWidthAdjustmentsLineEdit->setText(QString::fromStdString(saildef->panelWidthAdjustments));

    printBottomSeamCheckBox->setEnabled(true);
    printBottomSeamCheckBox->setChecked(saildef->printBottomSeam);

    gaffRPlineEdit->setText(QString::number(saildef->gaffRP));
    minTopWidthlineEdit->setText(QString::number(saildef->minTopWidth));

    luffTapeDistanceTextField->setText(QString::number(saildef->luffTapeDistance));
    footTapeDistanceTextField->setText(QString::number(saildef->footTapeDistance));

    // flag to indicate if we hide any fields and
    // therefore can resize the dialog
    bool fieldsHidden = false;

    // hide various fields on main tab depending on sail type
    if (saildef->sailCut == CROSS2 && saildef->sailType == JIB) {
        curvedSpeedSeamCheckBox->setChecked(saildef->curvedSpeedSeam);
    } else {
        curvedSpeedSeamCheckBox->hide();
    }

    if (saildef->sailType == SYMMETRIC) {
        splitsTextField->hide();
        splitsTextFieldLabel->hide();
        filletPanelWidthTextField->hide();
        filletPanelWidthTextFieldLabel->hide();
        speedPanelWidthTextField->hide();
        speedPanelWidthTextFieldLabel->hide();
        speedSeamHeightSpinBox->hide();
        speedSeamHeightSpinBoxLabel->hide();
        printBottomSeamCheckBox->hide();
        lensFootCheckBox->hide();
        gaffRPlineEdit->hide();
        gaffRPlineEditLabel->hide();
        minTopWidthlineEdit->hide();
        minTopWidthlineEditLabel->hide();
        luffTapeDistanceTextField->hide();
        luffTapeDistanceTextFieldLabel->hide();
        footTapeDistanceTextField->hide();
        footTapeDistanceTextFieldLabel->hide();
        fieldsHidden = true;
    } else {
        profileSubTypeComboBox->hide();
        profileSubTypeComboBoxLabel->hide();
        luffOffsetLineEdit->hide();
        luffOffsetLineEditLabel->hide();
        luffOffsetRoundPLineEdit->hide();
        luffOffsetRoundPLineEditLabel->hide();
        bottomPanelHeightLineEdit->hide();
        bottomPanelHeightLineEditLabel->hide();
        bottomCamberLineEdit->hide();
        bottomCamberLineEditLabel->hide();
        panelWidthAdjustmentsLabel->hide();
        panelWidthAdjustmentsLineEdit->hide();
        fieldsHidden = true;
        if (saildef->sailType == JIB) {
            gaffRPlineEdit->hide();
            gaffRPlineEditLabel->hide();
            minTopWidthlineEdit->hide();
            minTopWidthlineEditLabel->hide();
            lensFootCheckBox->hide();
        }
        if (saildef->sailCut == VERTICAL || saildef->sailCut == MITRE) {
            // hide speed seams
            filletPanelWidthTextField->hide();
            filletPanelWidthTextFieldLabel->hide();
            speedPanelWidthTextField->hide();
            speedPanelWidthTextFieldLabel->hide();
            speedSeamHeightSpinBox->hide();
            speedSeamHeightSpinBoxLabel->hide();
            printBottomSeamCheckBox->hide();
            lensFootCheckBox->hide();
        }
    }

    // resize dialog
/*
   if (fieldsHidden) {
        //QSize tabSize = tabWidget->minimumSizeHint();
        int tabHeight = tabWidget->height() + 100;
        QRect tabGeom = this->geometry();
        int parentHeight = parent->height();
        tabHeight = min(tabHeight, parentHeight);
        tabWidget->resize(tabWidget->width(), tabHeight);
        this->resize(this->width(), tabHeight+ 55);
        QRect buttonBoxGeom = buttonBox->geometry();
        int buttonHeight = buttonBoxGeom.bottom() -buttonBoxGeom.top();
        int buttonY = tabGeom.y()+ tabHeight + 15;
        buttonBoxGeom.setTop(buttonY);
        buttonBoxGeom.setBottom(buttonY+buttonHeight);
        buttonBox->setGeometry(buttonBoxGeom);
    }
*/
    patchWidgets.clear();

    Patch patch;
    // patches tab
    switch (saildef->sailType) {
    case SYMMETRIC: {
        PatchWidget *spinnakerHeadPatch = new PatchWidget();
        spinnakerHeadPatch->setTitle("Spinnaker Head Patch");
        spinnakerHeadPatch->setDimension1Title("Luff/Leech length");
        spinnakerHeadPatch->hideDimension2();
        spinnakerHeadPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
        vector<Patch> patches = saildef->findPatches(PATCH_SPINNAKER_HEAD);
        if (patches.size()> 0) {
            patch = patches[0];
        } else {
            patch = initialisePatch(PATCH_SPINNAKER_HEAD, PATCH_STYLE_BLOCK);
        }
        spinnakerHeadPatch->setValues(patch);
        spinnakerHeadPatch->setGenerate(patches.size() > 0);
        vertLayout->addWidget(spinnakerHeadPatch);
        patchWidgets.push_back(spinnakerHeadPatch);

        PatchWidget *spinnakerClewPatch = new PatchWidget();
        spinnakerClewPatch->setTitle("Spinnaker Clew Patches");
        spinnakerClewPatch->setDimension1Title("Luff/Leech length");
        spinnakerClewPatch->hideDimension2();
        spinnakerClewPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
        patches = saildef->findPatches(PATCH_SPINNAKER_CLEW);
        if (patches.size()> 0) {
            patch = patches[0];
        } else {
            patch = initialisePatch(PATCH_SPINNAKER_CLEW, PATCH_STYLE_BLOCK);
        }
        spinnakerClewPatch->setGenerate(patches.size() > 0);
        spinnakerClewPatch->setValues(patch);
        vertLayout->addWidget(spinnakerClewPatch);
        patchWidgets.push_back(spinnakerClewPatch);
        break;
        }
    case MAINSAIL: {
            PatchWidget *clewPatch = new PatchWidget();
            clewPatch->setTitle("Mainsail Clew Patch");
            clewPatch->setDimension1Title("Leech length");
            clewPatch->setDimension2Title("Foot length");
            clewPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_FAN);
            vector<Patch> patches = saildef->findPatches(PATCH_MAINSAIL_CLEW);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_MAINSAIL_CLEW, PATCH_STYLE_FAN);
            }
            clewPatch->setGenerate(patches.size() > 0);
            clewPatch->setValues(patch);
            vertLayout->addWidget(clewPatch);
            patchWidgets.push_back(clewPatch);

            PatchWidget *mainHeadPatch = new PatchWidget();
            mainHeadPatch->setTitle("Mainsail Head Patch");
            mainHeadPatch->setDimension1Title("Leech length");
            mainHeadPatch->hideDimension2();
            mainHeadPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
            patches = saildef->findPatches(PATCH_MAINSAIL_HEAD);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_MAINSAIL_HEAD, PATCH_STYLE_BLOCK);
            }
            mainHeadPatch->setValues(patch);
            mainHeadPatch->setGenerate(patches.size() > 0);
            vertLayout->addWidget(mainHeadPatch);
            patchWidgets.push_back(mainHeadPatch);

            PatchWidget *mainsailTackPatch = new PatchWidget();
            mainsailTackPatch->setTitle("Mainsail Tack Patch");
            mainsailTackPatch->setDimension1Title("Height");
            mainsailTackPatch->setDimension2Title("Width");
            mainsailTackPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
            patches = saildef->findPatches(PATCH_MAINSAIL_TACK);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_MAINSAIL_TACK, PATCH_STYLE_BLOCK);
            }
            mainsailTackPatch->setValues(patch);
            mainsailTackPatch->setGenerate(patches.size() > 0);
            //vertLayout->insertWidget(2, mainsailTackPatch,2);
            vertLayout->addWidget(mainsailTackPatch);
            patchWidgets.push_back(mainsailTackPatch);

            // reef patches
            PatchWidget *reef1Patch = new PatchWidget();
            reef1Patch->setTitle("Reef 1 Patch");
            reef1Patch->setDimension1Title("Leech length");
            reef1Patch->setDimension2Title("Foot length");
            reef1Patch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_REEF_FAN);
            patches = saildef->findPatches(PATCH_MAINSAIL_REEF1);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_MAINSAIL_REEF1, PATCH_STYLE_FAN);
            }
            reef1Patch->setGenerate(patches.size() > 0);
            reef1Patch->setValues(patch);
            reefVertlLayout->addWidget(reef1Patch);
            patchWidgets.push_back(reef1Patch);

            PatchWidget *reef2Patch = new PatchWidget();
            reef2Patch->setTitle("Reef 2 Patch");
            reef2Patch->setDimension1Title("Leech length");
            reef2Patch->setDimension2Title("Foot length");
            reef2Patch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_REEF_FAN);
            patches = saildef->findPatches(PATCH_MAINSAIL_REEF2);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_MAINSAIL_REEF2, PATCH_STYLE_FAN);
            }
            reef2Patch->setGenerate(patches.size() > 0);
            reef2Patch->setValues(patch);
            reefVertlLayout->addWidget(reef2Patch);
            patchWidgets.push_back(reef2Patch);

            break;
        }
    case JIB: {
            PatchWidget *jibClewPatch = new PatchWidget();
            jibClewPatch->setTitle("Jib Clew Patch");
            jibClewPatch->setDimension1Title("Leech length");
            jibClewPatch->setDimension2Title("Foot length");
            jibClewPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_FAN);
            vector<Patch> patches = saildef->findPatches(PATCH_JIB_CLEW);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_JIB_CLEW, PATCH_STYLE_FAN);
            }
            jibClewPatch->setGenerate(patches.size() > 0);
            jibClewPatch->setValues(patch);
            vertLayout->addWidget(jibClewPatch);
            patchWidgets.push_back(jibClewPatch);

            PatchWidget *jibHeadPatch = new PatchWidget();
            jibHeadPatch->setTitle("Jib Head Patch");
            jibHeadPatch->setDimension1Title("Leech length");
            jibHeadPatch->hideDimension2();
            jibHeadPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
            patches = saildef->findPatches(PATCH_JIB_HEAD);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_JIB_HEAD, PATCH_STYLE_BLOCK);
            }
            jibHeadPatch->setValues(patch);
            jibHeadPatch->setGenerate(patches.size() > 0);
            vertLayout->addWidget(jibHeadPatch);
            patchWidgets.push_back(jibHeadPatch);

            PatchWidget *jibTackPatch = new PatchWidget();
            jibTackPatch->setTitle("Jib Tack Patch");
            jibTackPatch->setDimension1Title("Luff/Foot length");
            jibTackPatch->hideDimension2();
            jibTackPatch->setDisplayStyle(PATCH_WIDGET_DISPLAY_STYLE_PLAIN);
            patches = saildef->findPatches(PATCH_JIB_TACK);
            if (patches.size()> 0) {
                patch = patches[0];
            } else {
                patch = initialisePatch(PATCH_JIB_TACK, PATCH_STYLE_BLOCK);
            }
            jibTackPatch->setValues(patch);
            jibTackPatch->setGenerate(patches.size() > 0);
            vertLayout->addWidget(jibTackPatch);
            patchWidgets.push_back(jibTackPatch);

            break;
        }

    default:
            break;
    }

    connect( addBattenButton, SIGNAL( clicked() ), this, SLOT( slotAddBatten()) );
    connect( updateBattenButton, SIGNAL( clicked() ), this, SLOT( slotUpdateBatten()) );
    connect( deleteBattenButton, SIGNAL( clicked() ), this, SLOT( slotDeleteBatten()) );
    connect ( lensFootCheckBox, SIGNAL(clicked(bool)), this, SLOT(slotLensFootChecked()));
    connect ( interpolCheckBox, SIGNAL(clicked(bool)), this, SLOT(slotInterpol()));
    connect ( footEdgeCheckBox, SIGNAL(clicked(bool)), this, SLOT(slotFootAtZ()));
    connect(battenListWidget,
                SIGNAL(currentItemChanged(QListWidgetItem *, QListWidgetItem *)),
                this, SLOT(slotItemSelected(QListWidgetItem *)));

    initialiseBattenFields();
    initialiseBattenList();
}

Patch CFormSailAdvanced::initialisePatch(enumPatchType type, enumPatchStyles style) {
    Patch patch;

    patch.patchStyle = style;
    patch.patchType = type;
    patch.dimension1 = patch.dimension2 = patch.overlap = patch.baseDimension = 0;
    patch.underPatches = "";
    patch.dimension2 = 0;
    patch.numSections = 4;
    patch.overlap = 0;
    patch.baseDimension = 0;
    patch.luffHeight = 0;
    patch.leechHeight = 0;

    return patch;
}

bool CFormSailAdvanced::check() {
    bool flag = true;
    QString txt;
    int tmpInt;
    double tmpDbl;
    bool bTest;
    int tabIdx = -1;

    /** Create four palettes for levels of warning. */
    QPalette palStd, palHi, palLo, palRel;
    palStd = splitsTextField->palette();
    palLo = palHi = palRel = palStd;
    palLo.setColor( QPalette::Text, Qt::magenta); // too low value
    palHi.setColor( QPalette::Text, Qt::red );    // too high value
    palRel.setColor( QPalette::Text, Qt::blue );  // related value to be checked

    /*
        main panel validation
     */
    string s = splitsTextField->text().toStdString();
    SplitsToInts(s, bTest);
    if (!bTest) {
        flag = false;
        splitsTextField->setPalette(palHi);
    } else {
        saildef->splitPanelNos = s;
    }

    // fott panels sections always 1 for now..
    saildef->footPanelSections = 1; //footPanelsSpinBox->value();

    txt = filletPanelWidthTextField->text();
    if (txt.length() == 0) {
        saildef->filletPanelWidth = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            filletPanelWidthTextField->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            filletPanelWidthTextField->setPalette(palLo);
        } else if (tmpInt > (saildef->clothW+2*saildef->seamW)) {
            flag = false;
            filletPanelWidthTextField->setPalette(palHi);
        } else {
            saildef->filletPanelWidth = tmpInt;
        }
    }

    txt = interpolationStrengthLineEdit->text().trimmed();
    double maxInterpol = saildef->sailType == SYMMETRIC ? 2 : 1;

    if (txt.length() == 0) {
        saildef->interpol2Strength = DEFAULT_INTERPOL_STRENGTH;
    } else {
        tmpDbl = txt.toDouble(&bTest);
        if (!bTest) {
            flag = false;
            interpolationStrengthLineEdit->setPalette(palHi);
        } else if ((tmpDbl < 0) || (tmpDbl > maxInterpol)) {
            flag = false;
            interpolationStrengthLineEdit->setPalette(palLo);
        } else {
            saildef->interpol2Strength = tmpDbl;
        }
    }

    txt = interpol2RPLineEdit->text();
    if (txt.length() == 0) {
        saildef->interpol2RP = 50;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            interpol2RPLineEdit->setPalette(palHi);
        } else if (tmpInt < 30){
            flag = false;
            interpol2RPLineEdit->setPalette(palLo);
        } else if (tmpInt > 70) {
            flag = false;
            interpol2RPLineEdit->setPalette(palHi);
        } else {
            saildef->interpol2RP = tmpInt;
        }
    }

    txt = speedPanelWidthTextField->text();
    if (txt.length() == 0) {
        saildef->speedPanelWidth = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            speedPanelWidthTextField->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            speedPanelWidthTextField->setPalette(palLo);
        } else if (tmpInt > (saildef->clothW*2)) {
            flag = false;
            speedPanelWidthTextField->setPalette(palHi);
        } else {
            saildef->speedPanelWidth = tmpInt;
        }
    }

    // always generate speed seam for now...
    saildef->generateSpeedSeam = true; //genSpeedSeamCheckBox->isChecked();
    saildef->curvedSpeedSeam = curvedSpeedSeamCheckBox->isChecked();

    txt = bottomCamberLineEdit->text().trimmed();
    if (txt.length() == 0) {
        saildef->mould.bottomDepth = 0;
    } else {
        tmpDbl = txt.toDouble(&bTest);
        if (!bTest) {
            flag = false;
            bottomCamberLineEdit->setPalette(palHi);
        } else if ((tmpDbl < 0) || (tmpDbl > 50)) {
            flag = false;
            bottomCamberLineEdit->setPalette(palLo);
        } else {
            saildef->mould.bottomDepth = tmpDbl / 100;
        }
    }


    int idx = crossMeasurementComboBox->currentIndex();
    switch (idx) {
    case 0:
        saildef->crossMeasurementType = ERS;
        break;
    case 1:
        saildef->crossMeasurementType = LUFF_LEECH_POINTS;
        break;
    case 2:
        saildef->crossMeasurementType = IRC;
        break;
    case 3:
        saildef->crossMeasurementType = IOR;
        break;
    case 4:
        saildef->crossMeasurementType = LUFF_FOLD;
        break;
    }

    idx = profileSubTypeComboBox->currentIndex();
    switch (idx) {
    case 0:
        saildef->profileSubType = PROFILE_DEFAULT;
        break;
    case 1:
        saildef->profileSubType = PROFILE_ELLIPSE;
        break;
    case 2:
        saildef->profileSubType = PROFILE_ELLIPSE_FLAT;
        break;
    case 3:
        saildef->profileSubType = PROFILE_CIRCLE;
        break;
    }

    txt = bottomPanelHeightLineEdit->text();
    if (txt.length() == 0) {
        saildef->bottomPanelHeight = 1;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            bottomPanelHeightLineEdit->setPalette(palHi);
        } else if (tmpInt < 1){
            flag = false;
            bottomPanelHeightLineEdit->setPalette(palLo);
        } else if (tmpInt > 200) {
            flag = false;
            bottomPanelHeightLineEdit->setPalette(palHi);
        } else {
            saildef->bottomPanelHeight = tmpInt;
        }
    }

    txt = luffOffsetLineEdit->text();
    if (txt.length() == 0) {
        saildef->luffOffset = 0;
    } else {
        tmpDbl = txt.toDouble(&bTest);
        if (!bTest) {
            flag = false;
            luffOffsetLineEdit->setPalette(palHi);
        } else if (tmpDbl < 0){
            flag = false;
            luffOffsetLineEdit->setPalette(palLo);
        } else if (tmpDbl > 25) {
            flag = false;
            luffOffsetLineEdit->setPalette(palHi);
        } else {
            saildef->luffOffset = tmpDbl;
        }
    }

    txt = luffOffsetRoundPLineEdit->text();
    if (txt.length() == 0) {
        saildef->luffOffsetRP = 50;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            luffOffsetRoundPLineEdit->setPalette(palHi);
        } else if (tmpInt < 50){
            flag = false;
            luffOffsetRoundPLineEdit->setPalette(palLo);
        } else if (tmpInt > 60) {
            flag = false;
            luffOffsetRoundPLineEdit->setPalette(palHi);
        } else {
            saildef->luffOffsetRP = tmpInt;
        }
    }


    s = panelWidthAdjustmentsLineEdit->text().toStdString();
    SplitsToInts(s, bTest, true,false);
    if (!bTest) {
        flag = false;
        panelWidthAdjustmentsLineEdit->setPalette(palHi);
    } else {
        saildef->panelWidthAdjustments = s;
    }

    // interpolation method
    saildef->interpolMethod = interpolCheckBox->isChecked() ? INTERPOL2 : INTERPOL;

    saildef->speedSeamLeechHeight = speedSeamHeightSpinBox->value();
    saildef->footEdgeAtZeroZ = footEdgeCheckBox->isChecked();


    saildef->printBottomSeam = printBottomSeamCheckBox->isChecked();
    saildef->lensFoot = lensFootCheckBox->isChecked();
//

    txt = minTopWidthlineEdit->text();
    if (txt.length() == 0) {
        saildef->minTopWidth = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            minTopWidthlineEdit->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            minTopWidthlineEdit->setPalette(palLo);
        } else if (tmpInt > 1000) {
            flag = false;
            minTopWidthlineEdit->setPalette(palHi);
        } else {
            saildef->minTopWidth = tmpInt;
        }
    }

    txt = gaffRPlineEdit->text();
    if (txt.length() == 0) {
        saildef->gaffRP = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            gaffRPlineEdit->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            gaffRPlineEdit->setPalette(palLo);
        } else if (tmpInt > 1000) {
            flag = false;
            gaffRPlineEdit->setPalette(palHi);
        } else {
            saildef->gaffRP = tmpInt;
        }
    }

    //
    txt = luffTapeDistanceTextField->text();
    if (txt.length() == 0) {
        saildef->luffTapeDistance = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            luffTapeDistanceTextField->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            luffTapeDistanceTextField->setPalette(palLo);
        } else if (tmpInt > 100) {
            flag = false;
            luffTapeDistanceTextField->setPalette(palHi);
        } else {
            saildef->luffTapeDistance = tmpInt;
        }
    }

    txt = footTapeDistanceTextField->text();
    if (txt.length() == 0) {
        saildef->footTapeDistance = 0;
    } else {
        tmpInt = txt.toInt(&bTest);
        if (!bTest) {
            flag = false;
            footTapeDistanceTextField->setPalette(palHi);
        } else if (tmpInt < 0){
            flag = false;
            footTapeDistanceTextField->setPalette(palLo);
        } else if (tmpInt > 100) {
            flag = false;
            footTapeDistanceTextField->setPalette(palHi);
        } else {
            saildef->footTapeDistance = tmpInt;
        }
    }


    if (!flag && tabIdx == -1) {
        tabIdx = mainTabIdx;
    }

    // batten hollow
    saildef->battenHollowPC = battenHollowSpinBox->value();

    // leech profile
    //
    // comment out code to get get leech params fro ui as we're not
    // using that ATM
    //if (saildef->sailType == MAINSAIL) {
    /*
            Leech Panel validation
         */

    //saildef->straightLineLeech = checkBoxStraightLineLeech->isChecked();

    //saildef->clothAlignsWithLeech = checkBoxClothAlignLeech->isChecked();

    //txt = leechTurnPointPos->text();
    //if (txt.length() == 0) {
    //    saildef->leechTurnPos = 0;
    //} else {
    //tmpInt = txt.toInt(&bTest);
    //tmpInt = 0;
    //if (!bTest) {
    //    flag = false;
    //    leechTurnPointPos->setPalette(palHi);
    //} else if (tmpInt < 50){
    //    flag = false;
    //    leechTurnPointPos->setPalette(palLo);
    //} else if (tmpInt > 95) {
    //    flag = false;
    //    leechTurnPointPos->setPalette(palHi);
    //} else {
    //    saildef->leechTurnPos = tmpInt;
    //}
    //}

    //saildef->radialHead = checkBoxRadialHead->isChecked();
    //} else {
    // defaults for a jib
    saildef->leechTurnPos = 0;
    saildef->straightLineLeech = false;
    saildef->clothAlignsWithLeech = false;
    saildef->radialHead = false;
    //}



    // patches
    bool cornerPatchError = false;

    if (patchWidgets.size() > 0) {
        saildef->patches.clear();
        for (unsigned int i=0; i<patchWidgets.size() ; i++) {
            PatchWidget *p = patchWidgets[i];
            if (p->generate()) {
                if (!p->check()) {
                    flag = false;
                    switch (p->getValues().patchType) {
                    case PATCH_MAINSAIL_REEF1:
                    case PATCH_MAINSAIL_REEF2:
                        break;
                    default:
                        cornerPatchError = true;
                    }
                }
                Patch patch = p->getValues();
                saildef->patches.push_back(patch);
            }
        }
    }

    if (!flag && tabIdx == -1) {
        // if corner patch is not valid then always show that
        // regardless of reef patch validity
        tabIdx = cornerPatchError ? patchesTabIdx : reefPatchesTabIdx;
    }

    // windows
    if (saildef->sailCut == CROSS2 && (saildef->sailType == MAINSAIL || saildef->sailType == JIB)) {
        if (windowWidgets[0]->generate()) {
            if (!windowWidgets[0]->check()) {
                flag = false;
                if (tabIdx == -1) {
                    tabIdx = windowsIdx;
                }
            } else {
                saildef->window1 = windowWidgets[0]->getValues();
            }
        } else {
            saildef->window1 = createBlankSailWindow();
        }

        if (windowWidgets[1]->generate()) {
            if (!windowWidgets[1]->check()) {
                flag = false;
                if (tabIdx == -1) {
                    tabIdx = windowsIdx;
                }
            } else {
                saildef->window2 = windowWidgets[1]->getValues();
            }
        } else {
            saildef->window2 = createBlankSailWindow();
        }
    }

    if (!flag) {
        tabWidget->setCurrentIndex(tabIdx);
    }

    cout << "splitPanels = " << saildef->splitPanelNos << "flag = " << flag << endl;
    return flag;
}

void CFormSailAdvanced::accept()
{
    /** Return data if everything is OK. */
    if (check() == true) {
        cout << "updating saildef batten group" << endl;
        battenGroup.sort();
        saildef->battenGroup.updateAll(battenGroup);
        QDialog::accept();
    }
}

bool CFormSailAdvanced::checkBatten() {
    bool bValid = true;
    bool bTest = false;
    int iLen = 0, iOffset=0;
    real dPos = 0, dAngle =0;

    QPalette palStd, palHi, palLo, palRel;
    palStd = battenIdLabel->palette();
    palLo = palHi = palRel = palStd;
    palLo.setColor( QPalette::Text, Qt::magenta); // too low value
    palHi.setColor( QPalette::Text, Qt::red );    // too high value
    palRel.setColor( QPalette::Text, Qt::blue );  // related value to be checked

    QString id = battenIdLineEdit->text();
    QString lenStr = battenLengthLineEdit->text();
    QString posStr = battenLeechPositionLineEdit->text();
    QString angleStr = battenLeechAngleLineEdit->text();
    QString offsetStr = inwardOffsetLineEdit->text();

    if (id.trimmed().length() == 0) {
        bValid = false;
        battenIdLineEdit->setPalette(palHi);
    } else {
        battenIdLineEdit->setPalette(palStd);
    }


    iLen = lenStr.toInt(&bTest);
    if (!bTest) {
        bValid = false;
        battenLengthLineEdit->setPalette(palHi);
    } else if (iLen <0) {
        bValid = false;
        battenLengthLineEdit->setPalette(palLo);
    } else {
        battenLengthLineEdit->setPalette(palStd);
    }

    dPos = posStr.toDouble(&bTest);
    if (!bTest) {
        bValid = false;
        battenLeechPositionLineEdit->setPalette(palHi);
    } else if (dPos < 5) {
        bValid = false;
        battenLeechPositionLineEdit->setPalette(palLo);
    } else if (dPos > 95) {
        bValid = false;
        battenLeechPositionLineEdit->setPalette(palHi);
    } else {
        battenLeechPositionLineEdit->setPalette(palStd);
    }

    dAngle = angleStr.toDouble(&bTest);
    if (!bTest) {
        bValid = false;
        battenLeechAngleLineEdit->setPalette(palHi);
    } else if ((dAngle < 30) || (dAngle > 150)) {
        bValid = false;
        battenLeechAngleLineEdit->setPalette(palHi);
    } else {
        battenLeechAngleLineEdit->setPalette(palStd);
    }

    iOffset = offsetStr.toInt(&bTest);
    if (!bTest) {
        bValid = false;
        inwardOffsetLineEdit->setPalette(palHi);
//    } else if (iOffset < 0) {
//        bValid = false;
//        inwardOffsetLineEdit->setPalette(palHi);
    } else {
        inwardOffsetLineEdit->setPalette(palStd);
    }

    if (bValid) {
        // update batten fields
        currentBatten.name = id.toStdString();
        currentBatten.battenLength = iLen;
        currentBatten.percentHeight = dPos;
        currentBatten.angle = dAngle;
        currentBatten.inwardOffset = iOffset;
        currentBatten.fullLength = currentBatten.battenLength == 0;
    }

    return bValid;
}

void CFormSailAdvanced::slotAddBatten() {
    if (checkBatten()) {
        battenGroup.addBatten(currentBatten);
        // update list box
        battenListWidget->addItem(new QListWidgetItem(QString::fromStdString(currentBatten.name)));
        initialiseBattenFields();
    }
}

void CFormSailAdvanced::slotDeleteBatten() {
    int row =battenListWidget->row(battenListWidget->currentItem());
    QListWidgetItem* it =  battenListWidget->takeItem(row);
    delete it;
    battenGroup.removeBatten(row);

    battenListWidget->clearSelection();
    initialiseBattenFields();
}

void CFormSailAdvanced::slotUpdateBatten() {
    cout << "CFormSailAdvanced::slotUpdateBatten()" << endl;

    if (checkBatten()) {
        //int idx = currentBattenIndex-1;
        battenGroup.update( currentBattenIndex,currentBatten);
        // update list box
        slotDeleteBatten();
        battenGroup.addBatten(currentBatten);
        // update list box
        battenListWidget->addItem(new QListWidgetItem(QString::fromStdString(currentBatten.name)));
    }
}

void CFormSailAdvanced::slotItemSelected(QListWidgetItem *current) {
    if (current == 0) return;

    int row = battenListWidget->row(current);
    QString s = QString::fromStdString(battenGroup.getBatten(row).name);
    battenIdLineEdit->setText(s);
    battenLeechPositionLineEdit->setText(QString::number(battenGroup.getBatten(row).percentHeight));
    battenLengthLineEdit->setText(battenGroup.getBatten(row).fullLength ? "0"
                : QString::number(battenGroup.getBatten(row).battenLength, 10));
    battenLeechAngleLineEdit->setText(QString::number(battenGroup.getBatten(row).angle));
    inwardOffsetLineEdit->setText(QString::number(battenGroup.getBatten(row).inwardOffset, 10));
    currentBattenIndex = row;
    deleteBattenButton->setEnabled(true);
    updateBattenButton->setEnabled(true);
}

void CFormSailAdvanced::slotLensFootChecked() {
    if (lensFootCheckBox->isChecked()) {
        int w = saildef->clothW -saildef->footR - 2*saildef->seamW - 50;
        speedPanelWidthTextField->setText(QString:: number(w));
    } else {
        speedPanelWidthTextField->setText("0");
    }
}

void CFormSailAdvanced::slotInterpol() {
    cout << "interpol clicked" << endl;
    interpolationStrengthLineEdit->setEnabled(interpolCheckBox->isChecked());
}

void CFormSailAdvanced::slotFootAtZ() {
//    cout << "footatz clicked" << endl;
    if (bottomCamberLineEdit->isVisible()) {
        bottomCamberLineEdit->setEnabled(!footEdgeCheckBox->isChecked());
    }
}

void CFormSailAdvanced::initialiseBattenFields() {
    battenIdLineEdit->setText("");
    battenLengthLineEdit->setText("0");
    battenLeechPositionLineEdit->setText("");
    battenLeechAngleLineEdit->setText("90");
    inwardOffsetLineEdit->setText("0");
    currentBattenIndex = -1;
    deleteBattenButton->setEnabled(false);
    updateBattenButton->setEnabled(false);

    battenHollowSpinBox->setValue(saildef->battenHollowPC);
}

void CFormSailAdvanced::initialiseBattenList() {
    int numBattens = battenGroup.numBattens();

    if (numBattens > 0) {
        for (int i=0; i<numBattens; i++) {
            CBatten b = battenGroup.getBatten(i);

            battenListWidget->addItem(new QListWidgetItem(QString::fromStdString(b.name)));
        }
    }
}

SailWindow CFormSailAdvanced::createBlankSailWindow() {
    SailWindow sw;
    sw.generate = false;
    sw.height = sw.panelNo = sw.width = sw.xPos = sw.yPos = 0;
    sw.alignment = SWA_BOTTOM_SEAM;

    return sw;
}
