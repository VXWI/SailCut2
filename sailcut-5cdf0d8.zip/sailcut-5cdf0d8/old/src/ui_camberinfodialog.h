/********************************************************************************
** Form generated from reading UI file 'camberinfodialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CAMBERINFODIALOG_H
#define UI_CAMBERINFODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_CamberInfoDialog
{
public:
    QDialogButtonBox *buttonBox;
    QTextEdit *textEdit;

    void setupUi(QDialog *CamberInfoDialog)
    {
        if (CamberInfoDialog->objectName().isEmpty())
            CamberInfoDialog->setObjectName(QString::fromUtf8("CamberInfoDialog"));
        CamberInfoDialog->setWindowModality(Qt::ApplicationModal);
        CamberInfoDialog->resize(483, 296);
        buttonBox = new QDialogButtonBox(CamberInfoDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(150, 250, 301, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);
        textEdit = new QTextEdit(CamberInfoDialog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(13, 15, 461, 221));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier"));
        textEdit->setFont(font);
        textEdit->setLineWrapMode(QTextEdit::FixedColumnWidth);
        textEdit->setLineWrapColumnOrWidth(80);

        retranslateUi(CamberInfoDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), CamberInfoDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), CamberInfoDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(CamberInfoDialog);
    } // setupUi

    void retranslateUi(QDialog *CamberInfoDialog)
    {
        CamberInfoDialog->setWindowTitle(QApplication::translate("CamberInfoDialog", "Camber Details"));
    } // retranslateUi

};

namespace Ui {
    class CamberInfoDialog: public Ui_CamberInfoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CAMBERINFODIALOG_H
