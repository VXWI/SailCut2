/********************************************************************************
** Form generated from reading UI file 'formrigdefbase.ui'
**
** Created by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMRIGDEFBASE_H
#define UI_FORMRIGDEFBASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_CFormRigDefBase
{
public:
    QGridLayout *gridLayout;
    QPushButton *btnCheck;
    QPushButton *btnOK;
    QPushButton *btnCancel;
    QSpacerItem *spacerItem;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout1;
    QLabel *lbl_CapShroudBase;
    QLabel *lbl_CSH;
    QLabel *lbl_LowerShroudBase;
    QLineEdit *txt_LSB;
    QLineEdit *txt_CSH;
    QLabel *lbl_CSB;
    QLabel *lbl_CapShroudHeight;
    QLineEdit *txt_CSB;
    QLabel *lbl_LSB;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout2;
    QSpacerItem *spacerItem1;
    QSpinBox *spinBox_SPNB;
    QLabel *lbl_SPNB;
    QLabel *label_SpreaderNumber;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout3;
    QLineEdit *txt_SPH2;
    QLineEdit *txt_SPH1;
    QLineEdit *txt_SPH3;
    QLabel *lbl_SPH2;
    QLabel *lbl_SPH3;
    QLabel *lbl_SPH1;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout4;
    QLabel *lbl_SPW3;
    QLineEdit *txt_SPW3;
    QLabel *lbl_SPW1;
    QLineEdit *txt_SPW1;
    QLabel *lbl_SPW2;
    QLineEdit *txt_SPW2;
    QGroupBox *groupBox_5;
    QGridLayout *gridLayout5;
    QLabel *lbl_MS_LuffRP;
    QLabel *label;
    QLabel *lbl_MS_LuffR;
    QLabel *lbl_MS_TackY;
    QLabel *lbl_Y;
    QLabel *lbl_MS_TackX;
    QLabel *lbl_X;
    QLabel *lbl_Main_Tack;
    QSpacerItem *spacerItem2;
    QLabel *lbl_MS_LuffL;
    QLabel *lblMSLL;
    QLabel *lbl_Main_LuffL;
    QLabel *lbl_Main_Luff_Round;
    QLabel *lbl_MS_Rake;
    QLabel *lblMSR;
    QLabel *lbl_Main_Rake;
    QSpacerItem *spacerItem3;
    QLabel *lbl_BAD;
    QLineEdit *txt_BAD;
    QLabel *lblBAD;
    QFrame *line_2;
    QLabel *lbl_HAD;
    QLabel *lblHAD;
    QLineEdit *txt_HAD;
    QSpacerItem *spacerItem4;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout6;
    QLabel *lbl_MastWidth;
    QLabel *lbl_MW;
    QLineEdit *txt_MW;
    QLineEdit *txt_MC;
    QLabel *lbl_MC;
    QLabel *lbl_MastCord;
    QLabel *lbl_MRkD;
    QLabel *lbl_MRkDeg;
    QLabel *lbl_MastRakeAngle;
    QLineEdit *txt_MH;
    QLineEdit *txt_MRnd;
    QSpacerItem *spacerItem5;
    QLabel *lbl_MastRake;
    QLabel *lbl_MRkM;
    QLineEdit *txt_MRkM;
    QLabel *lbl_MastHeight;
    QLabel *lbl_MH;
    QLabel *lbl_MRnd;
    QLabel *lbl_MastRound;
    QLabel *lbl_MRndPos;
    QLabel *lbl_MastRoundPos;
    QFrame *line;
    QSpinBox *spinBox_MRndPos;
    QGroupBox *groupBox;
    QGridLayout *gridLayout7;
    QSpacerItem *spacerItem6;
    QLineEdit *txt_foreI;
    QLabel *lbl_I;
    QLineEdit *txt_foreJ;
    QLabel *lbl_J;
    QLabel *lbl_foreJ;
    QLabel *lbl_foreI;
    QLineEdit *txt_RigID;
    QLabel *lbl_RigID;
    QLabel *lbl_TopFrame;
    QSpacerItem *spacerItem7;

    void setupUi(QDialog *CFormRigDefBase)
    {
        if (CFormRigDefBase->objectName().isEmpty())
            CFormRigDefBase->setObjectName(QString::fromUtf8("CFormRigDefBase"));
        CFormRigDefBase->resize(700, 550);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CFormRigDefBase->sizePolicy().hasHeightForWidth());
        CFormRigDefBase->setSizePolicy(sizePolicy);
        CFormRigDefBase->setMinimumSize(QSize(700, 550));
        gridLayout = new QGridLayout(CFormRigDefBase);
        gridLayout->setSpacing(4);
        gridLayout->setContentsMargins(4, 4, 4, 4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        btnCheck = new QPushButton(CFormRigDefBase);
        btnCheck->setObjectName(QString::fromUtf8("btnCheck"));

        gridLayout->addWidget(btnCheck, 6, 4, 1, 1);

        btnOK = new QPushButton(CFormRigDefBase);
        btnOK->setObjectName(QString::fromUtf8("btnOK"));
        sizePolicy.setHeightForWidth(btnOK->sizePolicy().hasHeightForWidth());
        btnOK->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnOK, 6, 5, 1, 2);

        btnCancel = new QPushButton(CFormRigDefBase);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));
        sizePolicy.setHeightForWidth(btnCancel->sizePolicy().hasHeightForWidth());
        btnCancel->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnCancel, 6, 7, 1, 1);

        spacerItem = new QSpacerItem(321, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem, 6, 0, 1, 4);

        groupBox_3 = new QGroupBox(CFormRigDefBase);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox_3->sizePolicy().hasHeightForWidth());
        groupBox_3->setSizePolicy(sizePolicy1);
        gridLayout1 = new QGridLayout(groupBox_3);
        gridLayout1->setSpacing(4);
        gridLayout1->setContentsMargins(4, 4, 4, 4);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        lbl_CapShroudBase = new QLabel(groupBox_3);
        lbl_CapShroudBase->setObjectName(QString::fromUtf8("lbl_CapShroudBase"));
        sizePolicy.setHeightForWidth(lbl_CapShroudBase->sizePolicy().hasHeightForWidth());
        lbl_CapShroudBase->setSizePolicy(sizePolicy);
        lbl_CapShroudBase->setMinimumSize(QSize(155, 22));

        gridLayout1->addWidget(lbl_CapShroudBase, 1, 0, 1, 1);

        lbl_CSH = new QLabel(groupBox_3);
        lbl_CSH->setObjectName(QString::fromUtf8("lbl_CSH"));
        sizePolicy.setHeightForWidth(lbl_CSH->sizePolicy().hasHeightForWidth());
        lbl_CSH->setSizePolicy(sizePolicy);
        lbl_CSH->setMinimumSize(QSize(40, 22));

        gridLayout1->addWidget(lbl_CSH, 0, 1, 1, 1);

        lbl_LowerShroudBase = new QLabel(groupBox_3);
        lbl_LowerShroudBase->setObjectName(QString::fromUtf8("lbl_LowerShroudBase"));
        sizePolicy.setHeightForWidth(lbl_LowerShroudBase->sizePolicy().hasHeightForWidth());
        lbl_LowerShroudBase->setSizePolicy(sizePolicy);
        lbl_LowerShroudBase->setMinimumSize(QSize(155, 22));

        gridLayout1->addWidget(lbl_LowerShroudBase, 2, 0, 1, 1);

        txt_LSB = new QLineEdit(groupBox_3);
        txt_LSB->setObjectName(QString::fromUtf8("txt_LSB"));
        sizePolicy.setHeightForWidth(txt_LSB->sizePolicy().hasHeightForWidth());
        txt_LSB->setSizePolicy(sizePolicy);
        txt_LSB->setMinimumSize(QSize(60, 22));
        txt_LSB->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txt_LSB, 2, 2, 1, 1);

        txt_CSH = new QLineEdit(groupBox_3);
        txt_CSH->setObjectName(QString::fromUtf8("txt_CSH"));
        sizePolicy.setHeightForWidth(txt_CSH->sizePolicy().hasHeightForWidth());
        txt_CSH->setSizePolicy(sizePolicy);
        txt_CSH->setMinimumSize(QSize(60, 22));
        txt_CSH->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txt_CSH, 0, 2, 1, 1);

        lbl_CSB = new QLabel(groupBox_3);
        lbl_CSB->setObjectName(QString::fromUtf8("lbl_CSB"));
        sizePolicy.setHeightForWidth(lbl_CSB->sizePolicy().hasHeightForWidth());
        lbl_CSB->setSizePolicy(sizePolicy);
        lbl_CSB->setMinimumSize(QSize(40, 22));

        gridLayout1->addWidget(lbl_CSB, 1, 1, 1, 1);

        lbl_CapShroudHeight = new QLabel(groupBox_3);
        lbl_CapShroudHeight->setObjectName(QString::fromUtf8("lbl_CapShroudHeight"));
        sizePolicy.setHeightForWidth(lbl_CapShroudHeight->sizePolicy().hasHeightForWidth());
        lbl_CapShroudHeight->setSizePolicy(sizePolicy);
        lbl_CapShroudHeight->setMinimumSize(QSize(155, 22));

        gridLayout1->addWidget(lbl_CapShroudHeight, 0, 0, 1, 1);

        txt_CSB = new QLineEdit(groupBox_3);
        txt_CSB->setObjectName(QString::fromUtf8("txt_CSB"));
        sizePolicy.setHeightForWidth(txt_CSB->sizePolicy().hasHeightForWidth());
        txt_CSB->setSizePolicy(sizePolicy);
        txt_CSB->setMinimumSize(QSize(60, 22));
        txt_CSB->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txt_CSB, 1, 2, 1, 1);

        lbl_LSB = new QLabel(groupBox_3);
        lbl_LSB->setObjectName(QString::fromUtf8("lbl_LSB"));
        sizePolicy.setHeightForWidth(lbl_LSB->sizePolicy().hasHeightForWidth());
        lbl_LSB->setSizePolicy(sizePolicy);
        lbl_LSB->setMinimumSize(QSize(40, 22));

        gridLayout1->addWidget(lbl_LSB, 2, 1, 1, 1);


        gridLayout->addWidget(groupBox_3, 5, 0, 1, 2);

        groupBox_4 = new QGroupBox(CFormRigDefBase);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(groupBox_4->sizePolicy().hasHeightForWidth());
        groupBox_4->setSizePolicy(sizePolicy2);
        gridLayout2 = new QGridLayout(groupBox_4);
        gridLayout2->setSpacing(4);
        gridLayout2->setContentsMargins(4, 4, 4, 4);
        gridLayout2->setObjectName(QString::fromUtf8("gridLayout2"));
        spacerItem1 = new QSpacerItem(21, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout2->addItem(spacerItem1, 0, 3, 1, 1);

        spinBox_SPNB = new QSpinBox(groupBox_4);
        spinBox_SPNB->setObjectName(QString::fromUtf8("spinBox_SPNB"));
        spinBox_SPNB->setMinimumSize(QSize(50, 21));
        spinBox_SPNB->setAlignment(Qt::AlignHCenter);
        spinBox_SPNB->setMaximum(3);
        spinBox_SPNB->setValue(3);

        gridLayout2->addWidget(spinBox_SPNB, 0, 2, 1, 1);

        lbl_SPNB = new QLabel(groupBox_4);
        lbl_SPNB->setObjectName(QString::fromUtf8("lbl_SPNB"));

        gridLayout2->addWidget(lbl_SPNB, 0, 1, 1, 1);

        label_SpreaderNumber = new QLabel(groupBox_4);
        label_SpreaderNumber->setObjectName(QString::fromUtf8("label_SpreaderNumber"));
        label_SpreaderNumber->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout2->addWidget(label_SpreaderNumber, 0, 0, 1, 1);

        groupBox_7 = new QGroupBox(groupBox_4);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        sizePolicy.setHeightForWidth(groupBox_7->sizePolicy().hasHeightForWidth());
        groupBox_7->setSizePolicy(sizePolicy);
        gridLayout3 = new QGridLayout(groupBox_7);
        gridLayout3->setSpacing(6);
        gridLayout3->setContentsMargins(6, 6, 6, 6);
        gridLayout3->setObjectName(QString::fromUtf8("gridLayout3"));
        txt_SPH2 = new QLineEdit(groupBox_7);
        txt_SPH2->setObjectName(QString::fromUtf8("txt_SPH2"));
        sizePolicy.setHeightForWidth(txt_SPH2->sizePolicy().hasHeightForWidth());
        txt_SPH2->setSizePolicy(sizePolicy);
        txt_SPH2->setMinimumSize(QSize(0, 22));
        txt_SPH2->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txt_SPH2, 1, 1, 1, 1);

        txt_SPH1 = new QLineEdit(groupBox_7);
        txt_SPH1->setObjectName(QString::fromUtf8("txt_SPH1"));
        sizePolicy.setHeightForWidth(txt_SPH1->sizePolicy().hasHeightForWidth());
        txt_SPH1->setSizePolicy(sizePolicy);
        txt_SPH1->setMinimumSize(QSize(0, 22));
        txt_SPH1->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txt_SPH1, 2, 1, 1, 1);

        txt_SPH3 = new QLineEdit(groupBox_7);
        txt_SPH3->setObjectName(QString::fromUtf8("txt_SPH3"));
        sizePolicy.setHeightForWidth(txt_SPH3->sizePolicy().hasHeightForWidth());
        txt_SPH3->setSizePolicy(sizePolicy);
        txt_SPH3->setMinimumSize(QSize(70, 22));
        txt_SPH3->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txt_SPH3, 0, 1, 1, 1);

        lbl_SPH2 = new QLabel(groupBox_7);
        lbl_SPH2->setObjectName(QString::fromUtf8("lbl_SPH2"));
        lbl_SPH2->setMinimumSize(QSize(30, 22));

        gridLayout3->addWidget(lbl_SPH2, 1, 0, 1, 1);

        lbl_SPH3 = new QLabel(groupBox_7);
        lbl_SPH3->setObjectName(QString::fromUtf8("lbl_SPH3"));
        lbl_SPH3->setMinimumSize(QSize(40, 22));

        gridLayout3->addWidget(lbl_SPH3, 0, 0, 1, 1);

        lbl_SPH1 = new QLabel(groupBox_7);
        lbl_SPH1->setObjectName(QString::fromUtf8("lbl_SPH1"));
        lbl_SPH1->setMinimumSize(QSize(30, 22));

        gridLayout3->addWidget(lbl_SPH1, 2, 0, 1, 1);


        gridLayout2->addWidget(groupBox_7, 1, 0, 1, 1);

        groupBox_6 = new QGroupBox(groupBox_4);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        sizePolicy.setHeightForWidth(groupBox_6->sizePolicy().hasHeightForWidth());
        groupBox_6->setSizePolicy(sizePolicy);
        gridLayout4 = new QGridLayout(groupBox_6);
        gridLayout4->setSpacing(6);
        gridLayout4->setContentsMargins(6, 6, 6, 6);
        gridLayout4->setObjectName(QString::fromUtf8("gridLayout4"));
        lbl_SPW3 = new QLabel(groupBox_6);
        lbl_SPW3->setObjectName(QString::fromUtf8("lbl_SPW3"));
        lbl_SPW3->setMinimumSize(QSize(40, 22));

        gridLayout4->addWidget(lbl_SPW3, 0, 0, 1, 1);

        txt_SPW3 = new QLineEdit(groupBox_6);
        txt_SPW3->setObjectName(QString::fromUtf8("txt_SPW3"));
        txt_SPW3->setMinimumSize(QSize(70, 22));
        txt_SPW3->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txt_SPW3, 0, 1, 1, 1);

        lbl_SPW1 = new QLabel(groupBox_6);
        lbl_SPW1->setObjectName(QString::fromUtf8("lbl_SPW1"));
        lbl_SPW1->setMinimumSize(QSize(0, 22));

        gridLayout4->addWidget(lbl_SPW1, 2, 0, 1, 1);

        txt_SPW1 = new QLineEdit(groupBox_6);
        txt_SPW1->setObjectName(QString::fromUtf8("txt_SPW1"));
        txt_SPW1->setMinimumSize(QSize(0, 22));
        txt_SPW1->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txt_SPW1, 2, 1, 1, 1);

        lbl_SPW2 = new QLabel(groupBox_6);
        lbl_SPW2->setObjectName(QString::fromUtf8("lbl_SPW2"));
        lbl_SPW2->setMinimumSize(QSize(0, 22));

        gridLayout4->addWidget(lbl_SPW2, 1, 0, 1, 1);

        txt_SPW2 = new QLineEdit(groupBox_6);
        txt_SPW2->setObjectName(QString::fromUtf8("txt_SPW2"));
        txt_SPW2->setMinimumSize(QSize(0, 22));
        txt_SPW2->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txt_SPW2, 1, 1, 1, 1);


        gridLayout2->addWidget(groupBox_6, 1, 1, 1, 3);


        gridLayout->addWidget(groupBox_4, 5, 3, 1, 5);

        groupBox_5 = new QGroupBox(CFormRigDefBase);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        sizePolicy2.setHeightForWidth(groupBox_5->sizePolicy().hasHeightForWidth());
        groupBox_5->setSizePolicy(sizePolicy2);
        groupBox_5->setMinimumSize(QSize(0, 0));
        gridLayout5 = new QGridLayout(groupBox_5);
        gridLayout5->setSpacing(4);
        gridLayout5->setContentsMargins(4, 4, 4, 4);
        gridLayout5->setObjectName(QString::fromUtf8("gridLayout5"));
        lbl_MS_LuffRP = new QLabel(groupBox_5);
        lbl_MS_LuffRP->setObjectName(QString::fromUtf8("lbl_MS_LuffRP"));
        sizePolicy.setHeightForWidth(lbl_MS_LuffRP->sizePolicy().hasHeightForWidth());
        lbl_MS_LuffRP->setSizePolicy(sizePolicy);
        lbl_MS_LuffRP->setMinimumSize(QSize(60, 22));
        lbl_MS_LuffRP->setFrameShape(QFrame::Box);
        lbl_MS_LuffRP->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_LuffRP, 3, 10, 1, 2);

        label = new QLabel(groupBox_5);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(20, 22));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout5->addWidget(label, 3, 9, 1, 1);

        lbl_MS_LuffR = new QLabel(groupBox_5);
        lbl_MS_LuffR->setObjectName(QString::fromUtf8("lbl_MS_LuffR"));
        sizePolicy.setHeightForWidth(lbl_MS_LuffR->sizePolicy().hasHeightForWidth());
        lbl_MS_LuffR->setSizePolicy(sizePolicy);
        lbl_MS_LuffR->setMinimumSize(QSize(60, 22));
        lbl_MS_LuffR->setFrameShape(QFrame::Box);
        lbl_MS_LuffR->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_LuffR, 3, 7, 1, 2);

        lbl_MS_TackY = new QLabel(groupBox_5);
        lbl_MS_TackY->setObjectName(QString::fromUtf8("lbl_MS_TackY"));
        sizePolicy.setHeightForWidth(lbl_MS_TackY->sizePolicy().hasHeightForWidth());
        lbl_MS_TackY->setSizePolicy(sizePolicy);
        lbl_MS_TackY->setMinimumSize(QSize(70, 22));
        lbl_MS_TackY->setFrameShape(QFrame::Box);
        lbl_MS_TackY->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_TackY, 2, 10, 1, 2);

        lbl_Y = new QLabel(groupBox_5);
        lbl_Y->setObjectName(QString::fromUtf8("lbl_Y"));
        sizePolicy.setHeightForWidth(lbl_Y->sizePolicy().hasHeightForWidth());
        lbl_Y->setSizePolicy(sizePolicy);
        lbl_Y->setMinimumSize(QSize(20, 22));
        lbl_Y->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout5->addWidget(lbl_Y, 2, 9, 1, 1);

        lbl_MS_TackX = new QLabel(groupBox_5);
        lbl_MS_TackX->setObjectName(QString::fromUtf8("lbl_MS_TackX"));
        sizePolicy.setHeightForWidth(lbl_MS_TackX->sizePolicy().hasHeightForWidth());
        lbl_MS_TackX->setSizePolicy(sizePolicy);
        lbl_MS_TackX->setMinimumSize(QSize(70, 22));
        lbl_MS_TackX->setFrameShape(QFrame::Box);
        lbl_MS_TackX->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_TackX, 2, 7, 1, 2);

        lbl_X = new QLabel(groupBox_5);
        lbl_X->setObjectName(QString::fromUtf8("lbl_X"));
        sizePolicy.setHeightForWidth(lbl_X->sizePolicy().hasHeightForWidth());
        lbl_X->setSizePolicy(sizePolicy);
        lbl_X->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout5->addWidget(lbl_X, 2, 5, 1, 2);

        lbl_Main_Tack = new QLabel(groupBox_5);
        lbl_Main_Tack->setObjectName(QString::fromUtf8("lbl_Main_Tack"));
        sizePolicy.setHeightForWidth(lbl_Main_Tack->sizePolicy().hasHeightForWidth());
        lbl_Main_Tack->setSizePolicy(sizePolicy);

        gridLayout5->addWidget(lbl_Main_Tack, 2, 4, 1, 1);

        spacerItem2 = new QSpacerItem(61, 22, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout5->addItem(spacerItem2, 2, 3, 1, 1);

        lbl_MS_LuffL = new QLabel(groupBox_5);
        lbl_MS_LuffL->setObjectName(QString::fromUtf8("lbl_MS_LuffL"));
        sizePolicy.setHeightForWidth(lbl_MS_LuffL->sizePolicy().hasHeightForWidth());
        lbl_MS_LuffL->setSizePolicy(sizePolicy);
        lbl_MS_LuffL->setMinimumSize(QSize(60, 22));
        lbl_MS_LuffL->setFrameShape(QFrame::Box);
        lbl_MS_LuffL->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_LuffL, 2, 2, 1, 1);

        lblMSLL = new QLabel(groupBox_5);
        lblMSLL->setObjectName(QString::fromUtf8("lblMSLL"));
        sizePolicy.setHeightForWidth(lblMSLL->sizePolicy().hasHeightForWidth());
        lblMSLL->setSizePolicy(sizePolicy);

        gridLayout5->addWidget(lblMSLL, 2, 1, 1, 1);

        lbl_Main_LuffL = new QLabel(groupBox_5);
        lbl_Main_LuffL->setObjectName(QString::fromUtf8("lbl_Main_LuffL"));
        sizePolicy.setHeightForWidth(lbl_Main_LuffL->sizePolicy().hasHeightForWidth());
        lbl_Main_LuffL->setSizePolicy(sizePolicy);
        lbl_Main_LuffL->setMinimumSize(QSize(60, 22));

        gridLayout5->addWidget(lbl_Main_LuffL, 2, 0, 1, 1);

        lbl_Main_Luff_Round = new QLabel(groupBox_5);
        lbl_Main_Luff_Round->setObjectName(QString::fromUtf8("lbl_Main_Luff_Round"));
        sizePolicy.setHeightForWidth(lbl_Main_Luff_Round->sizePolicy().hasHeightForWidth());
        lbl_Main_Luff_Round->setSizePolicy(sizePolicy);
        lbl_Main_Luff_Round->setMinimumSize(QSize(0, 22));

        gridLayout5->addWidget(lbl_Main_Luff_Round, 3, 4, 1, 1);

        lbl_MS_Rake = new QLabel(groupBox_5);
        lbl_MS_Rake->setObjectName(QString::fromUtf8("lbl_MS_Rake"));
        sizePolicy.setHeightForWidth(lbl_MS_Rake->sizePolicy().hasHeightForWidth());
        lbl_MS_Rake->setSizePolicy(sizePolicy);
        lbl_MS_Rake->setMinimumSize(QSize(60, 22));
        lbl_MS_Rake->setFrameShape(QFrame::Box);
        lbl_MS_Rake->setAlignment(Qt::AlignCenter);

        gridLayout5->addWidget(lbl_MS_Rake, 3, 2, 1, 1);

        lblMSR = new QLabel(groupBox_5);
        lblMSR->setObjectName(QString::fromUtf8("lblMSR"));
        sizePolicy.setHeightForWidth(lblMSR->sizePolicy().hasHeightForWidth());
        lblMSR->setSizePolicy(sizePolicy);

        gridLayout5->addWidget(lblMSR, 3, 1, 1, 1);

        lbl_Main_Rake = new QLabel(groupBox_5);
        lbl_Main_Rake->setObjectName(QString::fromUtf8("lbl_Main_Rake"));
        sizePolicy.setHeightForWidth(lbl_Main_Rake->sizePolicy().hasHeightForWidth());
        lbl_Main_Rake->setSizePolicy(sizePolicy);
        lbl_Main_Rake->setMinimumSize(QSize(60, 22));

        gridLayout5->addWidget(lbl_Main_Rake, 3, 0, 1, 1);

        spacerItem3 = new QSpacerItem(51, 25, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout5->addItem(spacerItem3, 0, 3, 1, 1);

        lbl_BAD = new QLabel(groupBox_5);
        lbl_BAD->setObjectName(QString::fromUtf8("lbl_BAD"));
        sizePolicy.setHeightForWidth(lbl_BAD->sizePolicy().hasHeightForWidth());
        lbl_BAD->setSizePolicy(sizePolicy);
        lbl_BAD->setMinimumSize(QSize(60, 22));

        gridLayout5->addWidget(lbl_BAD, 0, 0, 1, 1);

        txt_BAD = new QLineEdit(groupBox_5);
        txt_BAD->setObjectName(QString::fromUtf8("txt_BAD"));
        sizePolicy.setHeightForWidth(txt_BAD->sizePolicy().hasHeightForWidth());
        txt_BAD->setSizePolicy(sizePolicy);
        txt_BAD->setMinimumSize(QSize(60, 0));
        txt_BAD->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txt_BAD, 0, 2, 1, 1);

        lblBAD = new QLabel(groupBox_5);
        lblBAD->setObjectName(QString::fromUtf8("lblBAD"));
        sizePolicy.setHeightForWidth(lblBAD->sizePolicy().hasHeightForWidth());
        lblBAD->setSizePolicy(sizePolicy);
        lblBAD->setMinimumSize(QSize(0, 0));

        gridLayout5->addWidget(lblBAD, 0, 1, 1, 1);

        line_2 = new QFrame(groupBox_5);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout5->addWidget(line_2, 1, 0, 1, 12);

        lbl_HAD = new QLabel(groupBox_5);
        lbl_HAD->setObjectName(QString::fromUtf8("lbl_HAD"));
        sizePolicy.setHeightForWidth(lbl_HAD->sizePolicy().hasHeightForWidth());
        lbl_HAD->setSizePolicy(sizePolicy);

        gridLayout5->addWidget(lbl_HAD, 0, 4, 1, 2);

        lblHAD = new QLabel(groupBox_5);
        lblHAD->setObjectName(QString::fromUtf8("lblHAD"));
        sizePolicy.setHeightForWidth(lblHAD->sizePolicy().hasHeightForWidth());
        lblHAD->setSizePolicy(sizePolicy);

        gridLayout5->addWidget(lblHAD, 0, 6, 1, 2);

        txt_HAD = new QLineEdit(groupBox_5);
        txt_HAD->setObjectName(QString::fromUtf8("txt_HAD"));
        sizePolicy.setHeightForWidth(txt_HAD->sizePolicy().hasHeightForWidth());
        txt_HAD->setSizePolicy(sizePolicy);
        txt_HAD->setMinimumSize(QSize(60, 0));
        txt_HAD->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txt_HAD, 0, 8, 1, 3);

        spacerItem4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout5->addItem(spacerItem4, 0, 11, 1, 1);


        gridLayout->addWidget(groupBox_5, 4, 0, 1, 8);

        groupBox_2 = new QGroupBox(CFormRigDefBase);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        sizePolicy2.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy2);
        gridLayout6 = new QGridLayout(groupBox_2);
        gridLayout6->setSpacing(4);
        gridLayout6->setContentsMargins(4, 4, 4, 4);
        gridLayout6->setObjectName(QString::fromUtf8("gridLayout6"));
        lbl_MastWidth = new QLabel(groupBox_2);
        lbl_MastWidth->setObjectName(QString::fromUtf8("lbl_MastWidth"));

        gridLayout6->addWidget(lbl_MastWidth, 4, 4, 1, 1);

        lbl_MW = new QLabel(groupBox_2);
        lbl_MW->setObjectName(QString::fromUtf8("lbl_MW"));

        gridLayout6->addWidget(lbl_MW, 4, 5, 1, 1);

        txt_MW = new QLineEdit(groupBox_2);
        txt_MW->setObjectName(QString::fromUtf8("txt_MW"));
        txt_MW->setMinimumSize(QSize(70, 0));
        txt_MW->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txt_MW, 4, 6, 1, 1);

        txt_MC = new QLineEdit(groupBox_2);
        txt_MC->setObjectName(QString::fromUtf8("txt_MC"));
        txt_MC->setMinimumSize(QSize(70, 0));
        txt_MC->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txt_MC, 4, 2, 1, 1);

        lbl_MC = new QLabel(groupBox_2);
        lbl_MC->setObjectName(QString::fromUtf8("lbl_MC"));

        gridLayout6->addWidget(lbl_MC, 4, 1, 1, 1);

        lbl_MastCord = new QLabel(groupBox_2);
        lbl_MastCord->setObjectName(QString::fromUtf8("lbl_MastCord"));

        gridLayout6->addWidget(lbl_MastCord, 4, 0, 1, 1);

        lbl_MRkD = new QLabel(groupBox_2);
        lbl_MRkD->setObjectName(QString::fromUtf8("lbl_MRkD"));
        lbl_MRkD->setFrameShape(QFrame::Box);
        lbl_MRkD->setAlignment(Qt::AlignCenter);

        gridLayout6->addWidget(lbl_MRkD, 1, 6, 1, 1);

        lbl_MRkDeg = new QLabel(groupBox_2);
        lbl_MRkDeg->setObjectName(QString::fromUtf8("lbl_MRkDeg"));

        gridLayout6->addWidget(lbl_MRkDeg, 1, 5, 1, 1);

        lbl_MastRakeAngle = new QLabel(groupBox_2);
        lbl_MastRakeAngle->setObjectName(QString::fromUtf8("lbl_MastRakeAngle"));

        gridLayout6->addWidget(lbl_MastRakeAngle, 1, 4, 1, 1);

        txt_MH = new QLineEdit(groupBox_2);
        txt_MH->setObjectName(QString::fromUtf8("txt_MH"));
        sizePolicy.setHeightForWidth(txt_MH->sizePolicy().hasHeightForWidth());
        txt_MH->setSizePolicy(sizePolicy);
        txt_MH->setMinimumSize(QSize(70, 0));
        txt_MH->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txt_MH, 0, 2, 1, 1);

        txt_MRnd = new QLineEdit(groupBox_2);
        txt_MRnd->setObjectName(QString::fromUtf8("txt_MRnd"));
        txt_MRnd->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txt_MRnd, 1, 2, 1, 1);

        spacerItem5 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout6->addItem(spacerItem5, 0, 3, 1, 1);

        lbl_MastRake = new QLabel(groupBox_2);
        lbl_MastRake->setObjectName(QString::fromUtf8("lbl_MastRake"));

        gridLayout6->addWidget(lbl_MastRake, 0, 4, 1, 1);

        lbl_MRkM = new QLabel(groupBox_2);
        lbl_MRkM->setObjectName(QString::fromUtf8("lbl_MRkM"));

        gridLayout6->addWidget(lbl_MRkM, 0, 5, 1, 1);

        txt_MRkM = new QLineEdit(groupBox_2);
        txt_MRkM->setObjectName(QString::fromUtf8("txt_MRkM"));
        sizePolicy.setHeightForWidth(txt_MRkM->sizePolicy().hasHeightForWidth());
        txt_MRkM->setSizePolicy(sizePolicy);
        txt_MRkM->setMinimumSize(QSize(70, 0));
        txt_MRkM->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txt_MRkM, 0, 6, 1, 1);

        lbl_MastHeight = new QLabel(groupBox_2);
        lbl_MastHeight->setObjectName(QString::fromUtf8("lbl_MastHeight"));
        sizePolicy.setHeightForWidth(lbl_MastHeight->sizePolicy().hasHeightForWidth());
        lbl_MastHeight->setSizePolicy(sizePolicy);
        lbl_MastHeight->setMinimumSize(QSize(60, 22));

        gridLayout6->addWidget(lbl_MastHeight, 0, 0, 1, 1);

        lbl_MH = new QLabel(groupBox_2);
        lbl_MH->setObjectName(QString::fromUtf8("lbl_MH"));

        gridLayout6->addWidget(lbl_MH, 0, 1, 1, 1);

        lbl_MRnd = new QLabel(groupBox_2);
        lbl_MRnd->setObjectName(QString::fromUtf8("lbl_MRnd"));

        gridLayout6->addWidget(lbl_MRnd, 1, 1, 1, 1);

        lbl_MastRound = new QLabel(groupBox_2);
        lbl_MastRound->setObjectName(QString::fromUtf8("lbl_MastRound"));
        sizePolicy.setHeightForWidth(lbl_MastRound->sizePolicy().hasHeightForWidth());
        lbl_MastRound->setSizePolicy(sizePolicy);
        lbl_MastRound->setMinimumSize(QSize(60, 22));

        gridLayout6->addWidget(lbl_MastRound, 1, 0, 1, 1);

        lbl_MRndPos = new QLabel(groupBox_2);
        lbl_MRndPos->setObjectName(QString::fromUtf8("lbl_MRndPos"));

        gridLayout6->addWidget(lbl_MRndPos, 2, 1, 1, 1);

        lbl_MastRoundPos = new QLabel(groupBox_2);
        lbl_MastRoundPos->setObjectName(QString::fromUtf8("lbl_MastRoundPos"));
        sizePolicy.setHeightForWidth(lbl_MastRoundPos->sizePolicy().hasHeightForWidth());
        lbl_MastRoundPos->setSizePolicy(sizePolicy);
        lbl_MastRoundPos->setMinimumSize(QSize(60, 22));

        gridLayout6->addWidget(lbl_MastRoundPos, 2, 0, 1, 1);

        line = new QFrame(groupBox_2);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout6->addWidget(line, 3, 0, 1, 7);

        spinBox_MRndPos = new QSpinBox(groupBox_2);
        spinBox_MRndPos->setObjectName(QString::fromUtf8("spinBox_MRndPos"));
        spinBox_MRndPos->setAlignment(Qt::AlignHCenter);
        spinBox_MRndPos->setMinimum(20);
        spinBox_MRndPos->setMaximum(80);
        spinBox_MRndPos->setValue(50);

        gridLayout6->addWidget(spinBox_MRndPos, 2, 2, 1, 1);


        gridLayout->addWidget(groupBox_2, 3, 0, 1, 8);

        groupBox = new QGroupBox(CFormRigDefBase);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        sizePolicy2.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy2);
        gridLayout7 = new QGridLayout(groupBox);
        gridLayout7->setSpacing(4);
        gridLayout7->setContentsMargins(4, 4, 4, 4);
        gridLayout7->setObjectName(QString::fromUtf8("gridLayout7"));
        spacerItem6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout7->addItem(spacerItem6, 0, 3, 1, 1);

        txt_foreI = new QLineEdit(groupBox);
        txt_foreI->setObjectName(QString::fromUtf8("txt_foreI"));
        sizePolicy.setHeightForWidth(txt_foreI->sizePolicy().hasHeightForWidth());
        txt_foreI->setSizePolicy(sizePolicy);
        txt_foreI->setMinimumSize(QSize(70, 0));
        txt_foreI->setAlignment(Qt::AlignHCenter);

        gridLayout7->addWidget(txt_foreI, 0, 2, 1, 1);

        lbl_I = new QLabel(groupBox);
        lbl_I->setObjectName(QString::fromUtf8("lbl_I"));

        gridLayout7->addWidget(lbl_I, 0, 1, 1, 1);

        txt_foreJ = new QLineEdit(groupBox);
        txt_foreJ->setObjectName(QString::fromUtf8("txt_foreJ"));
        sizePolicy.setHeightForWidth(txt_foreJ->sizePolicy().hasHeightForWidth());
        txt_foreJ->setSizePolicy(sizePolicy);
        txt_foreJ->setMinimumSize(QSize(70, 0));
        txt_foreJ->setAlignment(Qt::AlignHCenter);

        gridLayout7->addWidget(txt_foreJ, 0, 6, 1, 1);

        lbl_J = new QLabel(groupBox);
        lbl_J->setObjectName(QString::fromUtf8("lbl_J"));

        gridLayout7->addWidget(lbl_J, 0, 5, 1, 1);

        lbl_foreJ = new QLabel(groupBox);
        lbl_foreJ->setObjectName(QString::fromUtf8("lbl_foreJ"));

        gridLayout7->addWidget(lbl_foreJ, 0, 4, 1, 1);

        lbl_foreI = new QLabel(groupBox);
        lbl_foreI->setObjectName(QString::fromUtf8("lbl_foreI"));

        gridLayout7->addWidget(lbl_foreI, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox, 2, 0, 1, 8);

        txt_RigID = new QLineEdit(CFormRigDefBase);
        txt_RigID->setObjectName(QString::fromUtf8("txt_RigID"));
        txt_RigID->setMinimumSize(QSize(400, 22));

        gridLayout->addWidget(txt_RigID, 1, 1, 1, 5);

        lbl_RigID = new QLabel(CFormRigDefBase);
        lbl_RigID->setObjectName(QString::fromUtf8("lbl_RigID"));
        sizePolicy.setHeightForWidth(lbl_RigID->sizePolicy().hasHeightForWidth());
        lbl_RigID->setSizePolicy(sizePolicy);
        lbl_RigID->setMinimumSize(QSize(60, 20));
        lbl_RigID->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lbl_RigID, 1, 0, 1, 1);

        lbl_TopFrame = new QLabel(CFormRigDefBase);
        lbl_TopFrame->setObjectName(QString::fromUtf8("lbl_TopFrame"));
        sizePolicy.setHeightForWidth(lbl_TopFrame->sizePolicy().hasHeightForWidth());
        lbl_TopFrame->setSizePolicy(sizePolicy);
        lbl_TopFrame->setMinimumSize(QSize(600, 24));
        lbl_TopFrame->setMaximumSize(QSize(650, 160));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        lbl_TopFrame->setFont(font);
        lbl_TopFrame->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        lbl_TopFrame->setMargin(1);
        lbl_TopFrame->setIndent(0);

        gridLayout->addWidget(lbl_TopFrame, 0, 0, 1, 8);

        spacerItem7 = new QSpacerItem(60, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem7, 1, 7, 1, 1);

        QWidget::setTabOrder(btnOK, btnCancel);
        QWidget::setTabOrder(btnCancel, txt_RigID);
        QWidget::setTabOrder(txt_RigID, txt_foreI);
        QWidget::setTabOrder(txt_foreI, txt_foreJ);
        QWidget::setTabOrder(txt_foreJ, txt_CSH);
        QWidget::setTabOrder(txt_CSH, txt_CSB);
        QWidget::setTabOrder(txt_CSB, txt_LSB);
        QWidget::setTabOrder(txt_LSB, txt_MH);
        QWidget::setTabOrder(txt_MH, txt_MRnd);
        QWidget::setTabOrder(txt_MRnd, spinBox_MRndPos);
        QWidget::setTabOrder(spinBox_MRndPos, txt_MRkM);
        QWidget::setTabOrder(txt_MRkM, txt_MC);
        QWidget::setTabOrder(txt_MC, txt_MW);
        QWidget::setTabOrder(txt_MW, txt_BAD);
        QWidget::setTabOrder(txt_BAD, spinBox_SPNB);
        QWidget::setTabOrder(spinBox_SPNB, txt_SPH3);
        QWidget::setTabOrder(txt_SPH3, txt_SPW3);
        QWidget::setTabOrder(txt_SPW3, txt_SPH2);
        QWidget::setTabOrder(txt_SPH2, txt_SPW2);
        QWidget::setTabOrder(txt_SPW2, txt_SPH1);
        QWidget::setTabOrder(txt_SPH1, txt_SPW1);

        retranslateUi(CFormRigDefBase);

        QMetaObject::connectSlotsByName(CFormRigDefBase);
    } // setupUi

    void retranslateUi(QDialog *CFormRigDefBase)
    {
        CFormRigDefBase->setWindowTitle(QApplication::translate("CFormRigDefBase", "Rig dimensions"));
        btnCheck->setText(QApplication::translate("CFormRigDefBase", "Check"));
        btnOK->setText(QApplication::translate("CFormRigDefBase", "OK"));
        btnCancel->setText(QApplication::translate("CFormRigDefBase", "Cancel"));
        groupBox_3->setTitle(QApplication::translate("CFormRigDefBase", "Shrouds"));
        lbl_CapShroudBase->setText(QApplication::translate("CFormRigDefBase", "Cap shroud base width"));
        lbl_CSH->setText(QApplication::translate("CFormRigDefBase", "= CSH"));
        lbl_LowerShroudBase->setText(QApplication::translate("CFormRigDefBase", "Lower shroud base width "));
        txt_LSB->setText(QApplication::translate("CFormRigDefBase", "txt_LSB"));
        txt_CSH->setText(QApplication::translate("CFormRigDefBase", "txt_CSH"));
        lbl_CSB->setText(QApplication::translate("CFormRigDefBase", "= CSB"));
        lbl_CapShroudHeight->setText(QApplication::translate("CFormRigDefBase", "Cap shroud height"));
        txt_CSB->setText(QApplication::translate("CFormRigDefBase", "txt_CSB"));
        lbl_LSB->setText(QApplication::translate("CFormRigDefBase", "= LSB"));
        groupBox_4->setTitle(QApplication::translate("CFormRigDefBase", "Spreaders"));
        spinBox_SPNB->setSuffix(QString());
        lbl_SPNB->setText(QApplication::translate("CFormRigDefBase", "= SPNB"));
        label_SpreaderNumber->setText(QApplication::translate("CFormRigDefBase", "Number of spreaders"));
        groupBox_7->setTitle(QApplication::translate("CFormRigDefBase", "Spreader height"));
        txt_SPH2->setText(QApplication::translate("CFormRigDefBase", "txt_SPH2"));
        txt_SPH1->setText(QApplication::translate("CFormRigDefBase", "txt_SPH1"));
        txt_SPH3->setText(QApplication::translate("CFormRigDefBase", "txt_SPH3"));
        lbl_SPH2->setText(QApplication::translate("CFormRigDefBase", "SPH2"));
        lbl_SPH3->setText(QApplication::translate("CFormRigDefBase", "SPH3"));
        lbl_SPH1->setText(QApplication::translate("CFormRigDefBase", "SPH1"));
        groupBox_6->setTitle(QApplication::translate("CFormRigDefBase", "Spreader length"));
        lbl_SPW3->setText(QApplication::translate("CFormRigDefBase", "SPW3"));
        txt_SPW3->setText(QApplication::translate("CFormRigDefBase", "txt_SPW3"));
        lbl_SPW1->setText(QApplication::translate("CFormRigDefBase", "SPW1"));
        txt_SPW1->setText(QApplication::translate("CFormRigDefBase", "txt_SPW1"));
        lbl_SPW2->setText(QApplication::translate("CFormRigDefBase", "SPW2"));
        txt_SPW2->setText(QApplication::translate("CFormRigDefBase", "txt_SPW2"));
        groupBox_5->setTitle(QApplication::translate("CFormRigDefBase", "Mainsail"));
        lbl_MS_LuffRP->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_LuffRP"));
        label->setText(QApplication::translate("CFormRigDefBase", "@ "));
        lbl_MS_LuffR->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_LuffR"));
        lbl_MS_TackY->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_TackY"));
        lbl_Y->setText(QApplication::translate("CFormRigDefBase", "Y ="));
        lbl_MS_TackX->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_TackX"));
        lbl_X->setText(QApplication::translate("CFormRigDefBase", "X ="));
        lbl_Main_Tack->setText(QApplication::translate("CFormRigDefBase", "Tack"));
        lbl_MS_LuffL->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_LuffL"));
        lblMSLL->setText(QApplication::translate("CFormRigDefBase", "= MSL"));
        lbl_Main_LuffL->setText(QApplication::translate("CFormRigDefBase", "Luff length "));
        lbl_Main_Luff_Round->setText(QApplication::translate("CFormRigDefBase", "Luff round"));
        lbl_MS_Rake->setText(QApplication::translate("CFormRigDefBase", "lbl_MS_Rake"));
        lblMSR->setText(QApplication::translate("CFormRigDefBase", "= MSR"));
        lbl_Main_Rake->setText(QApplication::translate("CFormRigDefBase", "Luff rake"));
        lbl_BAD->setText(QApplication::translate("CFormRigDefBase", "Tack height "));
        txt_BAD->setText(QApplication::translate("CFormRigDefBase", "txt_BAD"));
        lblBAD->setText(QApplication::translate("CFormRigDefBase", "= BAD"));
        lbl_HAD->setText(QApplication::translate("CFormRigDefBase", "Head height"));
        lblHAD->setText(QApplication::translate("CFormRigDefBase", "= HAD"));
        txt_HAD->setText(QApplication::translate("CFormRigDefBase", "txt_HAD"));
        groupBox_2->setTitle(QApplication::translate("CFormRigDefBase", "Mast"));
        lbl_MastWidth->setText(QApplication::translate("CFormRigDefBase", "Mast width"));
        lbl_MW->setText(QApplication::translate("CFormRigDefBase", "= MW"));
        txt_MW->setText(QApplication::translate("CFormRigDefBase", "txt_MW"));
        txt_MC->setText(QApplication::translate("CFormRigDefBase", "txt_MC"));
        lbl_MC->setText(QApplication::translate("CFormRigDefBase", "= MC"));
        lbl_MastCord->setText(QApplication::translate("CFormRigDefBase", "Mast cord"));
        lbl_MRkD->setText(QApplication::translate("CFormRigDefBase", "lbl_MRkD"));
        lbl_MRkDeg->setText(QApplication::translate("CFormRigDefBase", "= MRkD"));
        lbl_MastRakeAngle->setText(QApplication::translate("CFormRigDefBase", "Mast rake angle"));
        txt_MH->setText(QApplication::translate("CFormRigDefBase", "txt_MH"));
        txt_MRnd->setText(QApplication::translate("CFormRigDefBase", "txt_MRnd"));
        lbl_MastRake->setText(QApplication::translate("CFormRigDefBase", "Mast rake"));
        lbl_MRkM->setText(QApplication::translate("CFormRigDefBase", "= MRkM"));
        txt_MRkM->setText(QApplication::translate("CFormRigDefBase", "txt_MRkM"));
        lbl_MastHeight->setText(QApplication::translate("CFormRigDefBase", "Mast height"));
        lbl_MH->setText(QApplication::translate("CFormRigDefBase", "= MH"));
        lbl_MRnd->setText(QApplication::translate("CFormRigDefBase", "= MRnd"));
        lbl_MastRound->setText(QApplication::translate("CFormRigDefBase", "Mast round"));
        lbl_MRndPos->setText(QApplication::translate("CFormRigDefBase", "= MRndPos"));
        lbl_MastRoundPos->setText(QApplication::translate("CFormRigDefBase", "Mast round position "));
        groupBox->setTitle(QApplication::translate("CFormRigDefBase", "Fore triangle"));
        txt_foreI->setText(QApplication::translate("CFormRigDefBase", "txt_foreI"));
        lbl_I->setText(QApplication::translate("CFormRigDefBase", "= I"));
        txt_foreJ->setText(QApplication::translate("CFormRigDefBase", "txt_foreJ"));
        lbl_J->setText(QApplication::translate("CFormRigDefBase", "= J"));
        lbl_foreJ->setText(QApplication::translate("CFormRigDefBase", "Fore triangle base"));
        lbl_foreI->setText(QApplication::translate("CFormRigDefBase", "Fore triangle hoist"));
        txt_RigID->setText(QApplication::translate("CFormRigDefBase", "Description of rig"));
        lbl_RigID->setText(QApplication::translate("CFormRigDefBase", "Rig name"));
        lbl_TopFrame->setText(QApplication::translate("CFormRigDefBase", "All dimensions are in millimeter and angles in degrees"));
    } // retranslateUi

};

namespace Ui {
    class CFormRigDefBase: public Ui_CFormRigDefBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMRIGDEFBASE_H
