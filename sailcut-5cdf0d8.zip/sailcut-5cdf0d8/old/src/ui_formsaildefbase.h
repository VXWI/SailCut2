/********************************************************************************
** Form generated from reading UI file 'formsaildefbase.ui'
**
** Created by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMSAILDEFBASE_H
#define UI_FORMSAILDEFBASE_H

//#include <Qt3Support/Q3MimeSourceFactory>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_CFormSailDefBase
{
public:
    QGridLayout *gridLayout;
    QGroupBox *GroupSail;
    QGridLayout *gridLayout1;
    QFrame *Line2;
    QSpacerItem *spacerItem;
    QLabel *lbmm_6;
    QSpacerItem *spacerItem1;
    QLabel *lblLuffRoundPos;
    QLabel *lbmm_5;
    QLabel *lbmm_7;
    QLabel *lblLuffLen;
    QLabel *lblFootLen;
    QLabel *lbmm_9;
    QLabel *lblLeechLen;
    QLabel *lbmm_10;
    QLabel *lbmm_8;
    QLabel *lblLeechRoundPos;
    QLabel *lblGaffLen;
    QLabel *lblLeechRound;
    QLabel *lblLuffRound;
    QLabel *lblFootRound;
    QLabel *lbpercent;
    QLineEdit *txtLuffLen;
    QLineEdit *txtFootLen;
    QLineEdit *txtLeechLen;
    QLineEdit *txtLuffRound;
    QLineEdit *txtLeechRound;
    QLineEdit *txtLuffRoundPos;
    QLabel *lbdeg_2;
    QLabel *lbpercent_2;
    QLineEdit *txtLeechRoundPos;
    QLineEdit *txtFootRound;
    QLabel *lblGaffRound;
    QLabel *lblGaffAngle;
    QLabel *lbmm_12;
    QLabel *lbmm_11;
    QLineEdit *txtGaffAngle;
    QLineEdit *txtGaffLen;
    QLineEdit *txtGaffRound;
    QLabel *lblDiagonal;
    QLabel *lblmm13;
    QLabel *lbl46;
    QLabel *lbl45;
    QLabel *lblSailArea;
    QLabel *lblm2_1;
    QGroupBox *GroupSailID;
    QGridLayout *gridLayout2;
    QLineEdit *txtSailID;
    QLabel *lblSailID;
    QGroupBox *GroupRig;
    QGridLayout *gridLayout3;
    QRadioButton *radioMainSail;
    QLabel *lbl8;
    QRadioButton *radioJib;
    QRadioButton *radioWing;
    QLabel *lbdeg_2_2;
    QLabel *lbl5;
    QLabel *lblTackHeight;
    QLabel *lbl1;
    QLabel *lbl4;
    QLabel *lbl6;
    QLabel *lbmm_15;
    QLabel *lbmm_2;
    QLabel *lbmm;
    QLineEdit *txtLOA;
    QLineEdit *txtTackDist;
    QLineEdit *txtTackHeight;
    QLabel *lbmm_4;
    QSpacerItem *spacerItem2;
    QLineEdit *txtTriangBase;
    QLabel *lbmm_16;
    QLineEdit *txtRake;
    QLineEdit *txtTriangHoist;
    QLabel *lbmm_3;
    QLabel *lbl3;
    QFrame *Line3;
    QLineEdit *txtDihedral;
    QGroupBox *GroupLayout;
    QGridLayout *gridLayout4;
    QRadioButton *radioCross;
    QRadioButton *radioTwist;
    QLabel *TextLabel1;
    QLabel *TextLabel2;
    QRadioButton *radioHorizontal;
    QRadioButton *radioVertical;
    QFrame *Line7;
    QRadioButton *radioRadial;
    QLineEdit *txtSections;
    QRadioButton *radioMitre;
    QRadioButton *radioMitre2;
    QSpacerItem *spacerItem3;
    QRadioButton *radioCross2;
    QLabel *TextLabel3;
    QLineEdit *txtLuffGores;
    QLineEdit *txtGores;
    QSpacerItem *spacerItem4;
    QGroupBox *GroupCloth;
    QGridLayout *gridLayout5;
    QLineEdit *txtFootHemWidth;
    QLineEdit *txtHemsWidth;
    QLabel *lblHemsWidth;
    QLabel *lblInnerWidth;
    QLabel *lbmm_60;
    QLabel *lbmm_61;
    QLabel *lbmm_62;
    QLineEdit *txtLeechHemWidth;
    QLabel *lblClothWidth;
    QLabel *lblLeechHemWidth;
    QLabel *lblSeamWidth;
    QLineEdit *txtSeamWidth;
    QLineEdit *txtClothWidth;
    QLabel *lbmm_63;
    QLabel *lbmm_64;
    QPushButton *btnOK;
    QPushButton *btnCompute;
    QPushButton *btnCancel;
    QGroupBox *GroupShape;
    QGridLayout *gridLayout6;
    QLabel *lbpercent_3;
    QLabel *lbpercent_4;
    QLineEdit *txtTopDepth;
    QLineEdit *txtMidDepth;
    QLabel *lbpercent_5;
    QLineEdit *txtFootDepth;
    QLabel *lblTopDepth;
    QLabel *lblMidDepth;
    QLabel *lblFootDepth;
    QLineEdit *txtTwistAngle;
    QLineEdit *txtSheetAngle;
    QLabel *lblTwistAngle;
    QLabel *lblSheetAngle;
    QLabel *lbdeg_3;
    QLabel *lbdeg_4;
    QPushButton *btnAdvanced;

    void setupUi(QDialog *CFormSailDefBase)
    {
        if (CFormSailDefBase->objectName().isEmpty())
            CFormSailDefBase->setObjectName(QString::fromUtf8("CFormSailDefBase"));
        CFormSailDefBase->resize(740, 550);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CFormSailDefBase->sizePolicy().hasHeightForWidth());
        CFormSailDefBase->setSizePolicy(sizePolicy);
        CFormSailDefBase->setMinimumSize(QSize(740, 550));
        gridLayout = new QGridLayout(CFormSailDefBase);
        gridLayout->setSpacing(5);
        gridLayout->setContentsMargins(4, 4, 4, 4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        GroupSail = new QGroupBox(CFormSailDefBase);
        GroupSail->setObjectName(QString::fromUtf8("GroupSail"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(GroupSail->sizePolicy().hasHeightForWidth());
        GroupSail->setSizePolicy(sizePolicy1);
        gridLayout1 = new QGridLayout(GroupSail);
        gridLayout1->setSpacing(5);
        gridLayout1->setContentsMargins(4, 4, 4, 4);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        Line2 = new QFrame(GroupSail);
        Line2->setObjectName(QString::fromUtf8("Line2"));
        Line2->setFrameShape(QFrame::HLine);
        Line2->setFrameShadow(QFrame::Sunken);
        Line2->setLineWidth(2);
        Line2->setMidLineWidth(1);
        Line2->setFrameShape(QFrame::HLine);

        gridLayout1->addWidget(Line2, 4, 0, 1, 11);

        spacerItem = new QSpacerItem(20, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum);

        gridLayout1->addItem(spacerItem, 0, 3, 1, 1);

        lbmm_6 = new QLabel(GroupSail);
        lbmm_6->setObjectName(QString::fromUtf8("lbmm_6"));

        gridLayout1->addWidget(lbmm_6, 0, 6, 1, 1);

        spacerItem1 = new QSpacerItem(20, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum);

        gridLayout1->addItem(spacerItem1, 0, 7, 1, 1);

        lblLuffRoundPos = new QLabel(GroupSail);
        lblLuffRoundPos->setObjectName(QString::fromUtf8("lblLuffRoundPos"));

        gridLayout1->addWidget(lblLuffRoundPos, 0, 8, 1, 1);

        lbmm_5 = new QLabel(GroupSail);
        lbmm_5->setObjectName(QString::fromUtf8("lbmm_5"));

        gridLayout1->addWidget(lbmm_5, 0, 2, 1, 1);

        lbmm_7 = new QLabel(GroupSail);
        lbmm_7->setObjectName(QString::fromUtf8("lbmm_7"));

        gridLayout1->addWidget(lbmm_7, 1, 2, 1, 1);

        lblLuffLen = new QLabel(GroupSail);
        lblLuffLen->setObjectName(QString::fromUtf8("lblLuffLen"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lblLuffLen->sizePolicy().hasHeightForWidth());
        lblLuffLen->setSizePolicy(sizePolicy2);
        lblLuffLen->setMinimumSize(QSize(0, 20));

        gridLayout1->addWidget(lblLuffLen, 0, 0, 1, 1);

        lblFootLen = new QLabel(GroupSail);
        lblFootLen->setObjectName(QString::fromUtf8("lblFootLen"));
        sizePolicy2.setHeightForWidth(lblFootLen->sizePolicy().hasHeightForWidth());
        lblFootLen->setSizePolicy(sizePolicy2);
        lblFootLen->setMinimumSize(QSize(0, 20));

        gridLayout1->addWidget(lblFootLen, 1, 0, 1, 1);

        lbmm_9 = new QLabel(GroupSail);
        lbmm_9->setObjectName(QString::fromUtf8("lbmm_9"));

        gridLayout1->addWidget(lbmm_9, 2, 2, 1, 1);

        lblLeechLen = new QLabel(GroupSail);
        lblLeechLen->setObjectName(QString::fromUtf8("lblLeechLen"));
        sizePolicy2.setHeightForWidth(lblLeechLen->sizePolicy().hasHeightForWidth());
        lblLeechLen->setSizePolicy(sizePolicy2);
        lblLeechLen->setMinimumSize(QSize(0, 20));

        gridLayout1->addWidget(lblLeechLen, 2, 0, 1, 1);

        lbmm_10 = new QLabel(GroupSail);
        lbmm_10->setObjectName(QString::fromUtf8("lbmm_10"));

        gridLayout1->addWidget(lbmm_10, 2, 6, 1, 1);

        lbmm_8 = new QLabel(GroupSail);
        lbmm_8->setObjectName(QString::fromUtf8("lbmm_8"));

        gridLayout1->addWidget(lbmm_8, 1, 6, 1, 1);

        lblLeechRoundPos = new QLabel(GroupSail);
        lblLeechRoundPos->setObjectName(QString::fromUtf8("lblLeechRoundPos"));

        gridLayout1->addWidget(lblLeechRoundPos, 2, 8, 1, 1);

        lblGaffLen = new QLabel(GroupSail);
        lblGaffLen->setObjectName(QString::fromUtf8("lblGaffLen"));
        sizePolicy2.setHeightForWidth(lblGaffLen->sizePolicy().hasHeightForWidth());
        lblGaffLen->setSizePolicy(sizePolicy2);
        lblGaffLen->setMinimumSize(QSize(0, 20));

        gridLayout1->addWidget(lblGaffLen, 3, 0, 1, 1);

        lblLeechRound = new QLabel(GroupSail);
        lblLeechRound->setObjectName(QString::fromUtf8("lblLeechRound"));

        gridLayout1->addWidget(lblLeechRound, 2, 4, 1, 1);

        lblLuffRound = new QLabel(GroupSail);
        lblLuffRound->setObjectName(QString::fromUtf8("lblLuffRound"));

        gridLayout1->addWidget(lblLuffRound, 0, 4, 1, 1);

        lblFootRound = new QLabel(GroupSail);
        lblFootRound->setObjectName(QString::fromUtf8("lblFootRound"));

        gridLayout1->addWidget(lblFootRound, 1, 4, 1, 1);

        lbpercent = new QLabel(GroupSail);
        lbpercent->setObjectName(QString::fromUtf8("lbpercent"));

        gridLayout1->addWidget(lbpercent, 0, 10, 1, 1);

        txtLuffLen = new QLineEdit(GroupSail);
        txtLuffLen->setObjectName(QString::fromUtf8("txtLuffLen"));
        txtLuffLen->setMinimumSize(QSize(60, 18));
        txtLuffLen->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLuffLen, 0, 1, 1, 1);

        txtFootLen = new QLineEdit(GroupSail);
        txtFootLen->setObjectName(QString::fromUtf8("txtFootLen"));
        txtFootLen->setMinimumSize(QSize(60, 18));
        txtFootLen->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtFootLen, 1, 1, 1, 1);

        txtLeechLen = new QLineEdit(GroupSail);
        txtLeechLen->setObjectName(QString::fromUtf8("txtLeechLen"));
        txtLeechLen->setMinimumSize(QSize(60, 18));
        txtLeechLen->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLeechLen, 2, 1, 1, 1);

        txtLuffRound = new QLineEdit(GroupSail);
        txtLuffRound->setObjectName(QString::fromUtf8("txtLuffRound"));
        txtLuffRound->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLuffRound, 0, 5, 1, 1);

        txtLeechRound = new QLineEdit(GroupSail);
        txtLeechRound->setObjectName(QString::fromUtf8("txtLeechRound"));
        txtLeechRound->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLeechRound, 2, 5, 1, 1);

        txtLuffRoundPos = new QLineEdit(GroupSail);
        txtLuffRoundPos->setObjectName(QString::fromUtf8("txtLuffRoundPos"));
        txtLuffRoundPos->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLuffRoundPos, 0, 9, 1, 1);

        lbdeg_2 = new QLabel(GroupSail);
        lbdeg_2->setObjectName(QString::fromUtf8("lbdeg_2"));

        gridLayout1->addWidget(lbdeg_2, 3, 10, 1, 1);

        lbpercent_2 = new QLabel(GroupSail);
        lbpercent_2->setObjectName(QString::fromUtf8("lbpercent_2"));

        gridLayout1->addWidget(lbpercent_2, 2, 10, 1, 1);

        txtLeechRoundPos = new QLineEdit(GroupSail);
        txtLeechRoundPos->setObjectName(QString::fromUtf8("txtLeechRoundPos"));
        txtLeechRoundPos->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtLeechRoundPos, 2, 9, 1, 1);

        txtFootRound = new QLineEdit(GroupSail);
        txtFootRound->setObjectName(QString::fromUtf8("txtFootRound"));
        txtFootRound->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtFootRound, 1, 5, 1, 1);

        lblGaffRound = new QLabel(GroupSail);
        lblGaffRound->setObjectName(QString::fromUtf8("lblGaffRound"));

        gridLayout1->addWidget(lblGaffRound, 3, 4, 1, 1);

        lblGaffAngle = new QLabel(GroupSail);
        lblGaffAngle->setObjectName(QString::fromUtf8("lblGaffAngle"));

        gridLayout1->addWidget(lblGaffAngle, 3, 8, 1, 1);

        lbmm_12 = new QLabel(GroupSail);
        lbmm_12->setObjectName(QString::fromUtf8("lbmm_12"));

        gridLayout1->addWidget(lbmm_12, 3, 6, 1, 1);

        lbmm_11 = new QLabel(GroupSail);
        lbmm_11->setObjectName(QString::fromUtf8("lbmm_11"));

        gridLayout1->addWidget(lbmm_11, 3, 2, 1, 1);

        txtGaffAngle = new QLineEdit(GroupSail);
        txtGaffAngle->setObjectName(QString::fromUtf8("txtGaffAngle"));
        txtGaffAngle->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtGaffAngle, 3, 9, 1, 1);

        txtGaffLen = new QLineEdit(GroupSail);
        txtGaffLen->setObjectName(QString::fromUtf8("txtGaffLen"));
        txtGaffLen->setMinimumSize(QSize(60, 18));
        txtGaffLen->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtGaffLen, 3, 1, 1, 1);

        txtGaffRound = new QLineEdit(GroupSail);
        txtGaffRound->setObjectName(QString::fromUtf8("txtGaffRound"));
        txtGaffRound->setAlignment(Qt::AlignHCenter);

        gridLayout1->addWidget(txtGaffRound, 3, 5, 1, 1);

        lblDiagonal = new QLabel(GroupSail);
        lblDiagonal->setObjectName(QString::fromUtf8("lblDiagonal"));
        lblDiagonal->setMinimumSize(QSize(60, 18));
        lblDiagonal->setFrameShape(QFrame::Box);
        lblDiagonal->setFrameShadow(QFrame::Raised);
        lblDiagonal->setAlignment(Qt::AlignCenter);

        gridLayout1->addWidget(lblDiagonal, 5, 1, 1, 1);

        lblmm13 = new QLabel(GroupSail);
        lblmm13->setObjectName(QString::fromUtf8("lblmm13"));

        gridLayout1->addWidget(lblmm13, 5, 2, 1, 1);

        lbl46 = new QLabel(GroupSail);
        lbl46->setObjectName(QString::fromUtf8("lbl46"));
        lbl46->setMinimumSize(QSize(0, 20));

        gridLayout1->addWidget(lbl46, 5, 0, 1, 1);

        lbl45 = new QLabel(GroupSail);
        lbl45->setObjectName(QString::fromUtf8("lbl45"));

        gridLayout1->addWidget(lbl45, 5, 4, 1, 1);

        lblSailArea = new QLabel(GroupSail);
        lblSailArea->setObjectName(QString::fromUtf8("lblSailArea"));
        lblSailArea->setFrameShape(QFrame::Box);
        lblSailArea->setFrameShadow(QFrame::Raised);
        lblSailArea->setAlignment(Qt::AlignCenter);

        gridLayout1->addWidget(lblSailArea, 5, 5, 1, 1);

        lblm2_1 = new QLabel(GroupSail);
        lblm2_1->setObjectName(QString::fromUtf8("lblm2_1"));

        gridLayout1->addWidget(lblm2_1, 5, 6, 1, 1);


        gridLayout->addWidget(GroupSail, 2, 0, 1, 10);

        GroupSailID = new QGroupBox(CFormSailDefBase);
        GroupSailID->setObjectName(QString::fromUtf8("GroupSailID"));
        sizePolicy1.setHeightForWidth(GroupSailID->sizePolicy().hasHeightForWidth());
        GroupSailID->setSizePolicy(sizePolicy1);
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        GroupSailID->setFont(font);
        GroupSailID->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        gridLayout2 = new QGridLayout(GroupSailID);
        gridLayout2->setSpacing(5);
        gridLayout2->setContentsMargins(4, 4, 4, 4);
        gridLayout2->setObjectName(QString::fromUtf8("gridLayout2"));
        txtSailID = new QLineEdit(GroupSailID);
        txtSailID->setObjectName(QString::fromUtf8("txtSailID"));
        txtSailID->setMinimumSize(QSize(360, 18));
        txtSailID->setAlignment(Qt::AlignLeading);

        gridLayout2->addWidget(txtSailID, 0, 1, 1, 1);

        lblSailID = new QLabel(GroupSailID);
        lblSailID->setObjectName(QString::fromUtf8("lblSailID"));
        lblSailID->setMinimumSize(QSize(60, 20));
        lblSailID->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout2->addWidget(lblSailID, 0, 0, 1, 1);


        gridLayout->addWidget(GroupSailID, 0, 0, 1, 10);

        GroupRig = new QGroupBox(CFormSailDefBase);
        GroupRig->setObjectName(QString::fromUtf8("GroupRig"));
        sizePolicy.setHeightForWidth(GroupRig->sizePolicy().hasHeightForWidth());
        GroupRig->setSizePolicy(sizePolicy);
        GroupRig->setAlignment(Qt::AlignLeading);
        gridLayout3 = new QGridLayout(GroupRig);
        gridLayout3->setSpacing(5);
        gridLayout3->setContentsMargins(4, 4, 4, 4);
        gridLayout3->setObjectName(QString::fromUtf8("gridLayout3"));
        radioMainSail = new QRadioButton(GroupRig);
        radioMainSail->setObjectName(QString::fromUtf8("radioMainSail"));
        sizePolicy.setHeightForWidth(radioMainSail->sizePolicy().hasHeightForWidth());
        radioMainSail->setSizePolicy(sizePolicy);
        radioMainSail->setMinimumSize(QSize(100, 0));

        gridLayout3->addWidget(radioMainSail, 0, 0, 1, 1);

        lbl8 = new QLabel(GroupRig);
        lbl8->setObjectName(QString::fromUtf8("lbl8"));

        gridLayout3->addWidget(lbl8, 2, 0, 1, 1);

        radioJib = new QRadioButton(GroupRig);
        radioJib->setObjectName(QString::fromUtf8("radioJib"));
        sizePolicy.setHeightForWidth(radioJib->sizePolicy().hasHeightForWidth());
        radioJib->setSizePolicy(sizePolicy);
        radioJib->setMinimumSize(QSize(40, 0));

        gridLayout3->addWidget(radioJib, 0, 1, 1, 2);

        radioWing = new QRadioButton(GroupRig);
        radioWing->setObjectName(QString::fromUtf8("radioWing"));
        sizePolicy.setHeightForWidth(radioWing->sizePolicy().hasHeightForWidth());
        radioWing->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(radioWing, 1, 0, 1, 1);

        lbdeg_2_2 = new QLabel(GroupRig);
        lbdeg_2_2->setObjectName(QString::fromUtf8("lbdeg_2_2"));

        gridLayout3->addWidget(lbdeg_2_2, 2, 2, 1, 1);

        lbl5 = new QLabel(GroupRig);
        lbl5->setObjectName(QString::fromUtf8("lbl5"));

        gridLayout3->addWidget(lbl5, 2, 8, 1, 1);

        lblTackHeight = new QLabel(GroupRig);
        lblTackHeight->setObjectName(QString::fromUtf8("lblTackHeight"));

        gridLayout3->addWidget(lblTackHeight, 1, 8, 1, 1);

        lbl1 = new QLabel(GroupRig);
        lbl1->setObjectName(QString::fromUtf8("lbl1"));

        gridLayout3->addWidget(lbl1, 0, 8, 1, 1);

        lbl4 = new QLabel(GroupRig);
        lbl4->setObjectName(QString::fromUtf8("lbl4"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lbl4->sizePolicy().hasHeightForWidth());
        lbl4->setSizePolicy(sizePolicy3);
        lbl4->setMinimumSize(QSize(0, 18));

        gridLayout3->addWidget(lbl4, 2, 4, 1, 1);

        lbl6 = new QLabel(GroupRig);
        lbl6->setObjectName(QString::fromUtf8("lbl6"));
        sizePolicy3.setHeightForWidth(lbl6->sizePolicy().hasHeightForWidth());
        lbl6->setSizePolicy(sizePolicy3);
        lbl6->setMinimumSize(QSize(0, 18));

        gridLayout3->addWidget(lbl6, 0, 4, 1, 1);

        lbmm_15 = new QLabel(GroupRig);
        lbmm_15->setObjectName(QString::fromUtf8("lbmm_15"));

        gridLayout3->addWidget(lbmm_15, 0, 6, 1, 1);

        lbmm_2 = new QLabel(GroupRig);
        lbmm_2->setObjectName(QString::fromUtf8("lbmm_2"));

        gridLayout3->addWidget(lbmm_2, 2, 6, 1, 1);

        lbmm = new QLabel(GroupRig);
        lbmm->setObjectName(QString::fromUtf8("lbmm"));

        gridLayout3->addWidget(lbmm, 1, 6, 1, 1);

        txtLOA = new QLineEdit(GroupRig);
        txtLOA->setObjectName(QString::fromUtf8("txtLOA"));
        txtLOA->setMinimumSize(QSize(60, 0));
        txtLOA->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtLOA, 0, 5, 1, 1);

        txtTackDist = new QLineEdit(GroupRig);
        txtTackDist->setObjectName(QString::fromUtf8("txtTackDist"));
        txtTackDist->setMinimumSize(QSize(0, 0));
        txtTackDist->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtTackDist, 1, 5, 1, 1);

        txtTackHeight = new QLineEdit(GroupRig);
        txtTackHeight->setObjectName(QString::fromUtf8("txtTackHeight"));
        txtTackHeight->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtTackHeight, 1, 9, 1, 1);

        lbmm_4 = new QLabel(GroupRig);
        lbmm_4->setObjectName(QString::fromUtf8("lbmm_4"));

        gridLayout3->addWidget(lbmm_4, 1, 10, 1, 1);

        spacerItem2 = new QSpacerItem(20, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum);

        gridLayout3->addItem(spacerItem2, 0, 7, 1, 1);

        txtTriangBase = new QLineEdit(GroupRig);
        txtTriangBase->setObjectName(QString::fromUtf8("txtTriangBase"));
        txtTriangBase->setMinimumSize(QSize(0, 0));
        txtTriangBase->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtTriangBase, 2, 5, 1, 1);

        lbmm_16 = new QLabel(GroupRig);
        lbmm_16->setObjectName(QString::fromUtf8("lbmm_16"));

        gridLayout3->addWidget(lbmm_16, 0, 10, 1, 1);

        txtRake = new QLineEdit(GroupRig);
        txtRake->setObjectName(QString::fromUtf8("txtRake"));
        txtRake->setMinimumSize(QSize(60, 0));
        txtRake->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtRake, 0, 9, 1, 1);

        txtTriangHoist = new QLineEdit(GroupRig);
        txtTriangHoist->setObjectName(QString::fromUtf8("txtTriangHoist"));
        txtTriangHoist->setAlignment(Qt::AlignHCenter);

        gridLayout3->addWidget(txtTriangHoist, 2, 9, 1, 1);

        lbmm_3 = new QLabel(GroupRig);
        lbmm_3->setObjectName(QString::fromUtf8("lbmm_3"));

        gridLayout3->addWidget(lbmm_3, 2, 10, 1, 1);

        lbl3 = new QLabel(GroupRig);
        lbl3->setObjectName(QString::fromUtf8("lbl3"));
        sizePolicy3.setHeightForWidth(lbl3->sizePolicy().hasHeightForWidth());
        lbl3->setSizePolicy(sizePolicy3);
        lbl3->setMinimumSize(QSize(0, 18));

        gridLayout3->addWidget(lbl3, 1, 4, 1, 1);

        Line3 = new QFrame(GroupRig);
        Line3->setObjectName(QString::fromUtf8("Line3"));
        Line3->setFrameShape(QFrame::VLine);
        Line3->setFrameShadow(QFrame::Sunken);
        Line3->setFrameShape(QFrame::VLine);

        gridLayout3->addWidget(Line3, 0, 3, 3, 1);

        txtDihedral = new QLineEdit(GroupRig);
        txtDihedral->setObjectName(QString::fromUtf8("txtDihedral"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(txtDihedral->sizePolicy().hasHeightForWidth());
        txtDihedral->setSizePolicy(sizePolicy4);
        txtDihedral->setMinimumSize(QSize(35, 18));

        gridLayout3->addWidget(txtDihedral, 2, 1, 1, 1);


        gridLayout->addWidget(GroupRig, 1, 0, 1, 10);

        GroupLayout = new QGroupBox(CFormSailDefBase);
        GroupLayout->setObjectName(QString::fromUtf8("GroupLayout"));
        GroupLayout->setMinimumSize(QSize(300, 0));
        gridLayout4 = new QGridLayout(GroupLayout);
        gridLayout4->setSpacing(5);
        gridLayout4->setContentsMargins(4, 4, 4, 4);
        gridLayout4->setObjectName(QString::fromUtf8("gridLayout4"));
        radioCross = new QRadioButton(GroupLayout);
        radioCross->setObjectName(QString::fromUtf8("radioCross"));
        sizePolicy2.setHeightForWidth(radioCross->sizePolicy().hasHeightForWidth());
        radioCross->setSizePolicy(sizePolicy2);
        radioCross->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioCross, 0, 0, 1, 1);

        radioTwist = new QRadioButton(GroupLayout);
        radioTwist->setObjectName(QString::fromUtf8("radioTwist"));
        sizePolicy2.setHeightForWidth(radioTwist->sizePolicy().hasHeightForWidth());
        radioTwist->setSizePolicy(sizePolicy2);
        radioTwist->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioTwist, 2, 0, 1, 1);

        TextLabel1 = new QLabel(GroupLayout);
        TextLabel1->setObjectName(QString::fromUtf8("TextLabel1"));
        sizePolicy2.setHeightForWidth(TextLabel1->sizePolicy().hasHeightForWidth());
        TextLabel1->setSizePolicy(sizePolicy2);
        TextLabel1->setMinimumSize(QSize(100, 20));
        TextLabel1->setMargin(1);

        gridLayout4->addWidget(TextLabel1, 2, 2, 1, 1);

        TextLabel2 = new QLabel(GroupLayout);
        TextLabel2->setObjectName(QString::fromUtf8("TextLabel2"));
        sizePolicy2.setHeightForWidth(TextLabel2->sizePolicy().hasHeightForWidth());
        TextLabel2->setSizePolicy(sizePolicy2);
        TextLabel2->setMinimumSize(QSize(100, 40));
        TextLabel2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        TextLabel2->setWordWrap(true);
        TextLabel2->setMargin(1);

        gridLayout4->addWidget(TextLabel2, 3, 2, 1, 1);

        radioHorizontal = new QRadioButton(GroupLayout);
        radioHorizontal->setObjectName(QString::fromUtf8("radioHorizontal"));
        sizePolicy2.setHeightForWidth(radioHorizontal->sizePolicy().hasHeightForWidth());
        radioHorizontal->setSizePolicy(sizePolicy2);
        radioHorizontal->setMinimumSize(QSize(120, 20));

        gridLayout4->addWidget(radioHorizontal, 3, 0, 1, 1);

        radioVertical = new QRadioButton(GroupLayout);
        radioVertical->setObjectName(QString::fromUtf8("radioVertical"));
        sizePolicy2.setHeightForWidth(radioVertical->sizePolicy().hasHeightForWidth());
        radioVertical->setSizePolicy(sizePolicy2);
        radioVertical->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioVertical, 4, 0, 1, 1);

        Line7 = new QFrame(GroupLayout);
        Line7->setObjectName(QString::fromUtf8("Line7"));
        Line7->setFrameShape(QFrame::VLine);
        Line7->setFrameShadow(QFrame::Sunken);
        Line7->setLineWidth(2);
        Line7->setFrameShape(QFrame::VLine);

        gridLayout4->addWidget(Line7, 0, 1, 7, 1);

        radioRadial = new QRadioButton(GroupLayout);
        radioRadial->setObjectName(QString::fromUtf8("radioRadial"));
        radioRadial->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioRadial, 0, 2, 1, 1);

        txtSections = new QLineEdit(GroupLayout);
        txtSections->setObjectName(QString::fromUtf8("txtSections"));
        txtSections->setMinimumSize(QSize(28, 18));
        txtSections->setMaximumSize(QSize(40, 25));
        txtSections->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txtSections, 2, 3, 1, 1);

        radioMitre = new QRadioButton(GroupLayout);
        radioMitre->setObjectName(QString::fromUtf8("radioMitre"));
        sizePolicy2.setHeightForWidth(radioMitre->sizePolicy().hasHeightForWidth());
        radioMitre->setSizePolicy(sizePolicy2);
        radioMitre->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioMitre, 5, 0, 1, 1);

        radioMitre2 = new QRadioButton(GroupLayout);
        radioMitre2->setObjectName(QString::fromUtf8("radioMitre2"));
        sizePolicy2.setHeightForWidth(radioMitre2->sizePolicy().hasHeightForWidth());
        radioMitre2->setSizePolicy(sizePolicy2);
        radioMitre2->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioMitre2, 6, 0, 1, 1);

        spacerItem3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout4->addItem(spacerItem3, 6, 2, 1, 1);

        radioCross2 = new QRadioButton(GroupLayout);
        radioCross2->setObjectName(QString::fromUtf8("radioCross2"));
        QSizePolicy sizePolicy5(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(radioCross2->sizePolicy().hasHeightForWidth());
        radioCross2->setSizePolicy(sizePolicy5);
        radioCross2->setMinimumSize(QSize(100, 20));

        gridLayout4->addWidget(radioCross2, 1, 0, 1, 1);

        TextLabel3 = new QLabel(GroupLayout);
        TextLabel3->setObjectName(QString::fromUtf8("TextLabel3"));
        sizePolicy2.setHeightForWidth(TextLabel3->sizePolicy().hasHeightForWidth());
        TextLabel3->setSizePolicy(sizePolicy2);
        TextLabel3->setMinimumSize(QSize(0, 20));
        TextLabel3->setMargin(1);

        gridLayout4->addWidget(TextLabel3, 5, 2, 1, 1);

        txtLuffGores = new QLineEdit(GroupLayout);
        txtLuffGores->setObjectName(QString::fromUtf8("txtLuffGores"));
        txtLuffGores->setMinimumSize(QSize(28, 18));
        txtLuffGores->setMaximumSize(QSize(40, 25));
        txtLuffGores->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txtLuffGores, 5, 3, 1, 1);

        txtGores = new QLineEdit(GroupLayout);
        txtGores->setObjectName(QString::fromUtf8("txtGores"));
        txtGores->setMinimumSize(QSize(28, 18));
        txtGores->setMaximumSize(QSize(40, 25));
        txtGores->setAlignment(Qt::AlignHCenter);

        gridLayout4->addWidget(txtGores, 3, 3, 1, 1);


        gridLayout->addWidget(GroupLayout, 3, 0, 1, 1);

        spacerItem4 = new QSpacerItem(500, 27, QSizePolicy::Preferred, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem4, 5, 0, 1, 2);

        GroupCloth = new QGroupBox(CFormSailDefBase);
        GroupCloth->setObjectName(QString::fromUtf8("GroupCloth"));
        gridLayout5 = new QGridLayout(GroupCloth);
        gridLayout5->setSpacing(8);
        gridLayout5->setContentsMargins(4, 4, 4, 4);
        gridLayout5->setObjectName(QString::fromUtf8("gridLayout5"));
        gridLayout5->setHorizontalSpacing(1);
        gridLayout5->setVerticalSpacing(5);
        txtFootHemWidth = new QLineEdit(GroupCloth);
        txtFootHemWidth->setObjectName(QString::fromUtf8("txtFootHemWidth"));
        txtFootHemWidth->setMinimumSize(QSize(60, 18));
        txtFootHemWidth->setMaximumSize(QSize(80, 25));
        txtFootHemWidth->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txtFootHemWidth, 3, 1, 1, 1);

        txtHemsWidth = new QLineEdit(GroupCloth);
        txtHemsWidth->setObjectName(QString::fromUtf8("txtHemsWidth"));
        txtHemsWidth->setMinimumSize(QSize(60, 18));
        txtHemsWidth->setMaximumSize(QSize(80, 25));
        txtHemsWidth->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txtHemsWidth, 4, 1, 1, 1);

        lblHemsWidth = new QLabel(GroupCloth);
        lblHemsWidth->setObjectName(QString::fromUtf8("lblHemsWidth"));
        sizePolicy2.setHeightForWidth(lblHemsWidth->sizePolicy().hasHeightForWidth());
        lblHemsWidth->setSizePolicy(sizePolicy2);
        lblHemsWidth->setMargin(1);

        gridLayout5->addWidget(lblHemsWidth, 4, 0, 1, 1);

        lblInnerWidth = new QLabel(GroupCloth);
        lblInnerWidth->setObjectName(QString::fromUtf8("lblInnerWidth"));
        sizePolicy2.setHeightForWidth(lblInnerWidth->sizePolicy().hasHeightForWidth());
        lblInnerWidth->setSizePolicy(sizePolicy2);
        lblInnerWidth->setMargin(1);

        gridLayout5->addWidget(lblInnerWidth, 3, 0, 1, 1);

        lbmm_60 = new QLabel(GroupCloth);
        lbmm_60->setObjectName(QString::fromUtf8("lbmm_60"));

        gridLayout5->addWidget(lbmm_60, 0, 2, 1, 1);

        lbmm_61 = new QLabel(GroupCloth);
        lbmm_61->setObjectName(QString::fromUtf8("lbmm_61"));

        gridLayout5->addWidget(lbmm_61, 1, 2, 1, 1);

        lbmm_62 = new QLabel(GroupCloth);
        lbmm_62->setObjectName(QString::fromUtf8("lbmm_62"));

        gridLayout5->addWidget(lbmm_62, 2, 2, 1, 1);

        txtLeechHemWidth = new QLineEdit(GroupCloth);
        txtLeechHemWidth->setObjectName(QString::fromUtf8("txtLeechHemWidth"));
        txtLeechHemWidth->setMinimumSize(QSize(60, 18));
        txtLeechHemWidth->setMaximumSize(QSize(80, 25));
        txtLeechHemWidth->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txtLeechHemWidth, 2, 1, 1, 1);

        lblClothWidth = new QLabel(GroupCloth);
        lblClothWidth->setObjectName(QString::fromUtf8("lblClothWidth"));
        sizePolicy2.setHeightForWidth(lblClothWidth->sizePolicy().hasHeightForWidth());
        lblClothWidth->setSizePolicy(sizePolicy2);
        lblClothWidth->setMinimumSize(QSize(0, 20));
        lblClothWidth->setMargin(1);

        gridLayout5->addWidget(lblClothWidth, 0, 0, 1, 1);

        lblLeechHemWidth = new QLabel(GroupCloth);
        lblLeechHemWidth->setObjectName(QString::fromUtf8("lblLeechHemWidth"));
        sizePolicy2.setHeightForWidth(lblLeechHemWidth->sizePolicy().hasHeightForWidth());
        lblLeechHemWidth->setSizePolicy(sizePolicy2);
        lblLeechHemWidth->setMargin(1);

        gridLayout5->addWidget(lblLeechHemWidth, 2, 0, 1, 1);

        lblSeamWidth = new QLabel(GroupCloth);
        lblSeamWidth->setObjectName(QString::fromUtf8("lblSeamWidth"));
        sizePolicy2.setHeightForWidth(lblSeamWidth->sizePolicy().hasHeightForWidth());
        lblSeamWidth->setSizePolicy(sizePolicy2);
        lblSeamWidth->setMargin(1);

        gridLayout5->addWidget(lblSeamWidth, 1, 0, 1, 1);

        txtSeamWidth = new QLineEdit(GroupCloth);
        txtSeamWidth->setObjectName(QString::fromUtf8("txtSeamWidth"));
        txtSeamWidth->setMinimumSize(QSize(60, 18));
        txtSeamWidth->setMaximumSize(QSize(80, 25));
        txtSeamWidth->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txtSeamWidth, 1, 1, 1, 1);

        txtClothWidth = new QLineEdit(GroupCloth);
        txtClothWidth->setObjectName(QString::fromUtf8("txtClothWidth"));
        txtClothWidth->setMinimumSize(QSize(60, 18));
        txtClothWidth->setMaximumSize(QSize(80, 25));
        txtClothWidth->setAlignment(Qt::AlignHCenter);

        gridLayout5->addWidget(txtClothWidth, 0, 1, 1, 1);

        lbmm_63 = new QLabel(GroupCloth);
        lbmm_63->setObjectName(QString::fromUtf8("lbmm_63"));

        gridLayout5->addWidget(lbmm_63, 3, 2, 1, 1);

        lbmm_64 = new QLabel(GroupCloth);
        lbmm_64->setObjectName(QString::fromUtf8("lbmm_64"));

        gridLayout5->addWidget(lbmm_64, 4, 2, 1, 1);

        txtFootHemWidth->raise();
        txtHemsWidth->raise();
        lblHemsWidth->raise();
        lblInnerWidth->raise();
        lbmm_60->raise();
        lbmm_61->raise();
        lbmm_62->raise();
        txtLeechHemWidth->raise();
        lblClothWidth->raise();
        lblLeechHemWidth->raise();
        lblSeamWidth->raise();
        txtSeamWidth->raise();
        txtClothWidth->raise();
        lbmm_63->raise();
        lbmm_64->raise();

        gridLayout->addWidget(GroupCloth, 3, 6, 1, 4);

        btnOK = new QPushButton(CFormSailDefBase);
        btnOK->setObjectName(QString::fromUtf8("btnOK"));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        btnOK->setFont(font1);
        btnOK->setFocusPolicy(Qt::StrongFocus);

        gridLayout->addWidget(btnOK, 5, 7, 1, 1);

        btnCompute = new QPushButton(CFormSailDefBase);
        btnCompute->setObjectName(QString::fromUtf8("btnCompute"));
        btnCompute->setFont(font1);

        gridLayout->addWidget(btnCompute, 5, 6, 1, 1);

        btnCancel = new QPushButton(CFormSailDefBase);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));
        btnCancel->setFont(font1);

        gridLayout->addWidget(btnCancel, 5, 9, 1, 1);

        GroupShape = new QGroupBox(CFormSailDefBase);
        GroupShape->setObjectName(QString::fromUtf8("GroupShape"));
        sizePolicy3.setHeightForWidth(GroupShape->sizePolicy().hasHeightForWidth());
        GroupShape->setSizePolicy(sizePolicy3);
        GroupShape->setMinimumSize(QSize(0, 0));
        gridLayout6 = new QGridLayout(GroupShape);
        gridLayout6->setSpacing(8);
        gridLayout6->setContentsMargins(4, 4, 4, 4);
        gridLayout6->setObjectName(QString::fromUtf8("gridLayout6"));
        gridLayout6->setHorizontalSpacing(1);
        gridLayout6->setVerticalSpacing(5);
        lbpercent_3 = new QLabel(GroupShape);
        lbpercent_3->setObjectName(QString::fromUtf8("lbpercent_3"));

        gridLayout6->addWidget(lbpercent_3, 0, 2, 1, 1);

        lbpercent_4 = new QLabel(GroupShape);
        lbpercent_4->setObjectName(QString::fromUtf8("lbpercent_4"));

        gridLayout6->addWidget(lbpercent_4, 1, 2, 1, 1);

        txtTopDepth = new QLineEdit(GroupShape);
        txtTopDepth->setObjectName(QString::fromUtf8("txtTopDepth"));
        txtTopDepth->setMinimumSize(QSize(28, 18));
        txtTopDepth->setMaximumSize(QSize(40, 25));
        txtTopDepth->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txtTopDepth, 0, 1, 1, 1);

        txtMidDepth = new QLineEdit(GroupShape);
        txtMidDepth->setObjectName(QString::fromUtf8("txtMidDepth"));
        txtMidDepth->setMinimumSize(QSize(28, 18));
        txtMidDepth->setMaximumSize(QSize(40, 25));
        txtMidDepth->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txtMidDepth, 1, 1, 1, 1);

        lbpercent_5 = new QLabel(GroupShape);
        lbpercent_5->setObjectName(QString::fromUtf8("lbpercent_5"));

        gridLayout6->addWidget(lbpercent_5, 2, 2, 1, 1);

        txtFootDepth = new QLineEdit(GroupShape);
        txtFootDepth->setObjectName(QString::fromUtf8("txtFootDepth"));
        txtFootDepth->setMinimumSize(QSize(28, 18));
        txtFootDepth->setMaximumSize(QSize(40, 25));
        txtFootDepth->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txtFootDepth, 2, 1, 1, 1);

        lblTopDepth = new QLabel(GroupShape);
        lblTopDepth->setObjectName(QString::fromUtf8("lblTopDepth"));
        sizePolicy2.setHeightForWidth(lblTopDepth->sizePolicy().hasHeightForWidth());
        lblTopDepth->setSizePolicy(sizePolicy2);
        lblTopDepth->setMinimumSize(QSize(0, 20));
        lblTopDepth->setMargin(1);

        gridLayout6->addWidget(lblTopDepth, 0, 0, 1, 1);

        lblMidDepth = new QLabel(GroupShape);
        lblMidDepth->setObjectName(QString::fromUtf8("lblMidDepth"));
        sizePolicy2.setHeightForWidth(lblMidDepth->sizePolicy().hasHeightForWidth());
        lblMidDepth->setSizePolicy(sizePolicy2);
        lblMidDepth->setMinimumSize(QSize(0, 20));
        lblMidDepth->setMargin(1);

        gridLayout6->addWidget(lblMidDepth, 1, 0, 1, 1);

        lblFootDepth = new QLabel(GroupShape);
        lblFootDepth->setObjectName(QString::fromUtf8("lblFootDepth"));
        sizePolicy2.setHeightForWidth(lblFootDepth->sizePolicy().hasHeightForWidth());
        lblFootDepth->setSizePolicy(sizePolicy2);
        lblFootDepth->setMinimumSize(QSize(0, 20));
        lblFootDepth->setMargin(1);

        gridLayout6->addWidget(lblFootDepth, 2, 0, 1, 1);

        txtTwistAngle = new QLineEdit(GroupShape);
        txtTwistAngle->setObjectName(QString::fromUtf8("txtTwistAngle"));
        txtTwistAngle->setMinimumSize(QSize(28, 18));
        txtTwistAngle->setMaximumSize(QSize(40, 25));
        txtTwistAngle->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txtTwistAngle, 3, 1, 1, 1);

        txtSheetAngle = new QLineEdit(GroupShape);
        txtSheetAngle->setObjectName(QString::fromUtf8("txtSheetAngle"));
        txtSheetAngle->setMinimumSize(QSize(28, 18));
        txtSheetAngle->setMaximumSize(QSize(40, 25));
        txtSheetAngle->setAlignment(Qt::AlignHCenter);

        gridLayout6->addWidget(txtSheetAngle, 4, 1, 1, 1);

        lblTwistAngle = new QLabel(GroupShape);
        lblTwistAngle->setObjectName(QString::fromUtf8("lblTwistAngle"));
        sizePolicy2.setHeightForWidth(lblTwistAngle->sizePolicy().hasHeightForWidth());
        lblTwistAngle->setSizePolicy(sizePolicy2);
        lblTwistAngle->setMinimumSize(QSize(0, 20));
        lblTwistAngle->setMargin(1);

        gridLayout6->addWidget(lblTwistAngle, 3, 0, 1, 1);

        lblSheetAngle = new QLabel(GroupShape);
        lblSheetAngle->setObjectName(QString::fromUtf8("lblSheetAngle"));
        sizePolicy2.setHeightForWidth(lblSheetAngle->sizePolicy().hasHeightForWidth());
        lblSheetAngle->setSizePolicy(sizePolicy2);
        lblSheetAngle->setMinimumSize(QSize(0, 20));
        lblSheetAngle->setMargin(1);

        gridLayout6->addWidget(lblSheetAngle, 4, 0, 1, 1);

        lbdeg_3 = new QLabel(GroupShape);
        lbdeg_3->setObjectName(QString::fromUtf8("lbdeg_3"));

        gridLayout6->addWidget(lbdeg_3, 3, 2, 1, 1);

        lbdeg_4 = new QLabel(GroupShape);
        lbdeg_4->setObjectName(QString::fromUtf8("lbdeg_4"));

        gridLayout6->addWidget(lbdeg_4, 4, 2, 1, 1);


        gridLayout->addWidget(GroupShape, 3, 1, 1, 3);

        btnAdvanced = new QPushButton(CFormSailDefBase);
        btnAdvanced->setObjectName(QString::fromUtf8("btnAdvanced"));
        btnAdvanced->setFont(font1);

        gridLayout->addWidget(btnAdvanced, 5, 3, 1, 1);

        GroupSail->raise();
        GroupSailID->raise();
        GroupRig->raise();
        GroupLayout->raise();
        GroupCloth->raise();
        btnOK->raise();
        btnCancel->raise();
        btnCompute->raise();
        btnCancel->raise();
        GroupShape->raise();
        btnAdvanced->raise();
        QWidget::setTabOrder(txtSailID, radioMainSail);
        QWidget::setTabOrder(radioMainSail, radioJib);
        QWidget::setTabOrder(radioJib, radioWing);
        QWidget::setTabOrder(radioWing, txtDihedral);
        QWidget::setTabOrder(txtDihedral, txtLOA);
        QWidget::setTabOrder(txtLOA, txtTackDist);
        QWidget::setTabOrder(txtTackDist, txtTriangBase);
        QWidget::setTabOrder(txtTriangBase, txtRake);
        QWidget::setTabOrder(txtRake, txtTackHeight);
        QWidget::setTabOrder(txtTackHeight, txtTriangHoist);
        QWidget::setTabOrder(txtTriangHoist, txtLuffLen);
        QWidget::setTabOrder(txtLuffLen, txtFootLen);
        QWidget::setTabOrder(txtFootLen, txtLeechLen);
        QWidget::setTabOrder(txtLeechLen, txtGaffLen);
        QWidget::setTabOrder(txtGaffLen, txtLuffRound);
        QWidget::setTabOrder(txtLuffRound, txtFootRound);
        QWidget::setTabOrder(txtFootRound, txtLeechRound);
        QWidget::setTabOrder(txtLeechRound, txtGaffRound);
        QWidget::setTabOrder(txtGaffRound, txtLuffRoundPos);
        QWidget::setTabOrder(txtLuffRoundPos, txtLeechRoundPos);
        QWidget::setTabOrder(txtLeechRoundPos, txtGaffAngle);
        QWidget::setTabOrder(txtGaffAngle, radioCross);
        QWidget::setTabOrder(radioCross, radioCross2);
        QWidget::setTabOrder(radioCross2, radioTwist);
        QWidget::setTabOrder(radioTwist, radioHorizontal);
        QWidget::setTabOrder(radioHorizontal, radioVertical);
        QWidget::setTabOrder(radioVertical, radioMitre);
        QWidget::setTabOrder(radioMitre, radioMitre2);
        QWidget::setTabOrder(radioMitre2, radioRadial);
        QWidget::setTabOrder(radioRadial, txtSections);
        QWidget::setTabOrder(txtSections, txtTopDepth);
        QWidget::setTabOrder(txtTopDepth, txtMidDepth);
        QWidget::setTabOrder(txtMidDepth, txtFootDepth);
        QWidget::setTabOrder(txtFootDepth, txtTwistAngle);
        QWidget::setTabOrder(txtTwistAngle, txtSheetAngle);
        QWidget::setTabOrder(txtSheetAngle, txtClothWidth);
        QWidget::setTabOrder(txtClothWidth, txtSeamWidth);
        QWidget::setTabOrder(txtSeamWidth, txtLeechHemWidth);
        QWidget::setTabOrder(txtLeechHemWidth, txtFootHemWidth);
        QWidget::setTabOrder(txtFootHemWidth, txtHemsWidth);

        retranslateUi(CFormSailDefBase);

        QMetaObject::connectSlotsByName(CFormSailDefBase);
    } // setupUi

    void retranslateUi(QDialog *CFormSailDefBase)
    {
        CFormSailDefBase->setWindowTitle(QApplication::translate("CFormSailDefBase", "Sail definition"));
        GroupSail->setTitle(QApplication::translate("CFormSailDefBase", "Sail dimensions"));
        lbmm_6->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblLuffRoundPos->setText(QApplication::translate("CFormSailDefBase", "Round position"));
        lbmm_5->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_7->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblLuffLen->setText(QApplication::translate("CFormSailDefBase", "Luff length"));
        lblFootLen->setText(QApplication::translate("CFormSailDefBase", "Foot length"));
        lbmm_9->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblLeechLen->setText(QApplication::translate("CFormSailDefBase", "Leech length"));
        lbmm_10->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_8->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblLeechRoundPos->setText(QApplication::translate("CFormSailDefBase", "Round position"));
        lblGaffLen->setText(QApplication::translate("CFormSailDefBase", "Gaff length"));
        lblLeechRound->setText(QApplication::translate("CFormSailDefBase", "Leech round"));
        lblLuffRound->setText(QApplication::translate("CFormSailDefBase", "Luff round"));
        lblFootRound->setText(QApplication::translate("CFormSailDefBase", "Foot round"));
        lbpercent->setText(QApplication::translate("CFormSailDefBase", "%"));
        lbdeg_2->setText(QApplication::translate("CFormSailDefBase", "deg"));
        lbpercent_2->setText(QApplication::translate("CFormSailDefBase", "%"));
        lblGaffRound->setText(QApplication::translate("CFormSailDefBase", "Gaff round"));
        lblGaffAngle->setText(QApplication::translate("CFormSailDefBase", "Gaff angle from luff"));
        lbmm_12->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_11->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblDiagonal->setText(QString());
        lblmm13->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbl46->setText(QApplication::translate("CFormSailDefBase", "Diagonal"));
        lbl45->setText(QApplication::translate("CFormSailDefBase", "Sail area"));
        lblSailArea->setText(QString());
        lblm2_1->setText(QApplication::translate("CFormSailDefBase", "m2"));
        GroupSailID->setTitle(QApplication::translate("CFormSailDefBase", "Sail identifier"));
        lblSailID->setText(QApplication::translate("CFormSailDefBase", "Sail name"));
        GroupRig->setTitle(QApplication::translate("CFormSailDefBase", "Rig geometry"));
        radioMainSail->setText(QApplication::translate("CFormSailDefBase", "Main sail"));
        lbl8->setText(QApplication::translate("CFormSailDefBase", "Dihedral angle"));
        radioJib->setText(QApplication::translate("CFormSailDefBase", "Jib"));
        radioWing->setText(QApplication::translate("CFormSailDefBase", "Wing"));
        lbdeg_2_2->setText(QApplication::translate("CFormSailDefBase", "deg"));
        lbl5->setText(QApplication::translate("CFormSailDefBase", "Fore triangle hoist  I"));
        lblTackHeight->setText(QApplication::translate("CFormSailDefBase", "Tack height"));
        lbl1->setText(QApplication::translate("CFormSailDefBase", "Luff rake"));
        lbl4->setText(QApplication::translate("CFormSailDefBase", "Fore triangle base  J"));
        lbl6->setText(QApplication::translate("CFormSailDefBase", "Boat length LOA"));
        lbmm_15->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_2->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_4->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_16->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_3->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbl3->setText(QApplication::translate("CFormSailDefBase", "Distance tack to stem"));
        GroupLayout->setTitle(QApplication::translate("CFormSailDefBase", "Layout"));
        radioCross->setText(QApplication::translate("CFormSailDefBase", "Cross cut"));
        radioTwist->setText(QApplication::translate("CFormSailDefBase", "Twist foot"));
        TextLabel1->setText(QApplication::translate("CFormSailDefBase", "Number of sections"));
        TextLabel2->setText(QApplication::translate("CFormSailDefBase", "Number of radial gores"));
        radioHorizontal->setText(QApplication::translate("CFormSailDefBase", "Horizontal cut"));
        radioVertical->setText(QApplication::translate("CFormSailDefBase", "Vertical cut"));
        radioRadial->setText(QApplication::translate("CFormSailDefBase", "Radial cut"));
        radioMitre->setText(QApplication::translate("CFormSailDefBase", "Mitre cut"));
        radioMitre2->setText(QApplication::translate("CFormSailDefBase", "Mitre cut 2"));
        radioCross2->setText(QApplication::translate("CFormSailDefBase", "Cross cut 2"));
        TextLabel3->setText(QApplication::translate("CFormSailDefBase", "Number of luff gores"));
        GroupCloth->setTitle(QApplication::translate("CFormSailDefBase", "Cloth"));
        lblHemsWidth->setText(QApplication::translate("CFormSailDefBase", "Other hems"));
        lblInnerWidth->setText(QApplication::translate("CFormSailDefBase", "Foot hem"));
        lbmm_60->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_61->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_62->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lblClothWidth->setText(QApplication::translate("CFormSailDefBase", "Cloth width"));
        lblLeechHemWidth->setText(QApplication::translate("CFormSailDefBase", "Leech hem"));
        lblSeamWidth->setText(QApplication::translate("CFormSailDefBase", "Seam width"));
        lbmm_63->setText(QApplication::translate("CFormSailDefBase", "mm"));
        lbmm_64->setText(QApplication::translate("CFormSailDefBase", "mm"));
        btnOK->setText(QApplication::translate("CFormSailDefBase", "OK"));
        btnCompute->setText(QApplication::translate("CFormSailDefBase", "Compute"));
        btnCancel->setText(QApplication::translate("CFormSailDefBase", "Cancel"));
        GroupShape->setTitle(QApplication::translate("CFormSailDefBase", "Sail shape"));
        lbpercent_3->setText(QApplication::translate("CFormSailDefBase", "%"));
        lbpercent_4->setText(QApplication::translate("CFormSailDefBase", "%"));
        lbpercent_5->setText(QApplication::translate("CFormSailDefBase", "%"));
        lblTopDepth->setText(QApplication::translate("CFormSailDefBase", "Top depth"));
        lblMidDepth->setText(QApplication::translate("CFormSailDefBase", "Mid depth"));
        lblFootDepth->setText(QApplication::translate("CFormSailDefBase", "Foot depth"));
        lblTwistAngle->setText(QApplication::translate("CFormSailDefBase", "Twist angle"));
        lblSheetAngle->setText(QApplication::translate("CFormSailDefBase", "Sheeting angle"));
        lbdeg_3->setText(QApplication::translate("CFormSailDefBase", "deg"));
        lbdeg_4->setText(QApplication::translate("CFormSailDefBase", "deg"));
        btnAdvanced->setText(QApplication::translate("CFormSailDefBase", "Advanced"));
    } // retranslateUi

};

namespace Ui {
    class CFormSailDefBase: public Ui_CFormSailDefBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMSAILDEFBASE_H
