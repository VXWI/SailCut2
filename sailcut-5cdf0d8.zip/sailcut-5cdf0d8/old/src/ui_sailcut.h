/********************************************************************************
** Form generated from reading ui file 'sailcut.ui'
**
** Created: Sun Jun 12 11:10:09 2011
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SAILCUT_H
#define UI_SAILCUT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SailcutClass
{
public:

    void setupUi(QWidget *SailcutClass)
    {
    if (SailcutClass->objectName().isEmpty())
        SailcutClass->setObjectName(QString::fromUtf8("SailcutClass"));
    SailcutClass->resize(400, 300);

    retranslateUi(SailcutClass);

    QMetaObject::connectSlotsByName(SailcutClass);
    } // setupUi

    void retranslateUi(QWidget *SailcutClass)
    {
    SailcutClass->setWindowTitle(QApplication::translate("SailcutClass", "Sailcut", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(SailcutClass);
    } // retranslateUi

};

namespace Ui {
    class SailcutClass: public Ui_SailcutClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAILCUT_H
