/********************************************************************************
** Form generated from reading UI file 'formsaildefadvanced.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMSAILDEFADVANCED_H
#define UI_FORMSAILDEFADVANCED_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CFormSailDefAdvanced
{
public:
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *general_tab;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *splitsTextField;
    QSpinBox *footPanelsSpinBox;
    QLabel *label_2;
    QLineEdit *filletPanelWidthTextField;
    QLabel *label_4;
    QLineEdit *speedPanelWidthTextField;
    QLabel *label_5;
    QCheckBox *genSpeedSeamCheckBox;
    QSpinBox *speedSeamHeightSpinBox;
    QLabel *label_3;
    QCheckBox *printBottomSeamCheckBox;
    QLabel *luffTapeDistance;
    QLineEdit *luffTapeDistanceTextField;
    QLabel *label_10;
    QLineEdit *footTapeDistanceTextField;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QWidget *battens_tab;
    QPushButton *deleteBattenButton;
    QPushButton *addBattenButton;
    QListWidget *battenListWidget;
    QPushButton *updateBattenButton;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *battenIdLabel;
    QLineEdit *battenIdLineEdit;
    QLabel *BattenlecehPositionLabel;
    QLineEdit *battenLeechPositionLineEdit;
    QLineEdit *battenLeechAngleLineEdit;
    QLabel *battenLeechAngleLabel;
    QLineEdit *battenLengthLineEdit;
    QLabel *battenLengthLabel;
    QLabel *label_8;
    QLineEdit *inwardOffsetLineEdit;
    QWidget *leech_tab;
    QCheckBox *checkBoxStraightLineLeech;
    QCheckBox *checkBoxClothAlignLeech;
    QLabel *label_6;
    QLineEdit *leechTurnPointPos;
    QLabel *label_7;
    QCheckBox *checkBoxRadialHead;

    void setupUi(QDialog *CFormSailDefAdvanced)
    {
        if (CFormSailDefAdvanced->objectName().isEmpty())
            CFormSailDefAdvanced->setObjectName(QString::fromUtf8("CFormSailDefAdvanced"));
        CFormSailDefAdvanced->setWindowModality(Qt::WindowModal);
        CFormSailDefAdvanced->resize(500, 583);
        CFormSailDefAdvanced->setMinimumSize(QSize(70, 20));
        CFormSailDefAdvanced->setMaximumSize(QSize(16777215, 16777215));
        buttonBox = new QDialogButtonBox(CFormSailDefAdvanced);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(130, 540, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        tabWidget = new QTabWidget(CFormSailDefAdvanced);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 10, 451, 521));
        general_tab = new QWidget();
        general_tab->setObjectName(QString::fromUtf8("general_tab"));
        formLayoutWidget = new QWidget(general_tab);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 381, 461));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setIndent(5);

        formLayout->setWidget(9, QFormLayout::LabelRole, label);

        splitsTextField = new QLineEdit(formLayoutWidget);
        splitsTextField->setObjectName(QString::fromUtf8("splitsTextField"));

        formLayout->setWidget(9, QFormLayout::FieldRole, splitsTextField);

        footPanelsSpinBox = new QSpinBox(formLayoutWidget);
        footPanelsSpinBox->setObjectName(QString::fromUtf8("footPanelsSpinBox"));
        QFont font1;
        font1.setBold(false);
        font1.setWeight(50);
        footPanelsSpinBox->setFont(font1);
        footPanelsSpinBox->setMinimum(1);
        footPanelsSpinBox->setMaximum(3);

        formLayout->setWidget(11, QFormLayout::FieldRole, footPanelsSpinBox);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);
        label_2->setIndent(5);

        formLayout->setWidget(11, QFormLayout::LabelRole, label_2);

        filletPanelWidthTextField = new QLineEdit(formLayoutWidget);
        filletPanelWidthTextField->setObjectName(QString::fromUtf8("filletPanelWidthTextField"));

        formLayout->setWidget(0, QFormLayout::FieldRole, filletPanelWidthTextField);

        label_4 = new QLabel(formLayoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);
        label_4->setIndent(5);

        formLayout->setWidget(0, QFormLayout::LabelRole, label_4);

        speedPanelWidthTextField = new QLineEdit(formLayoutWidget);
        speedPanelWidthTextField->setObjectName(QString::fromUtf8("speedPanelWidthTextField"));

        formLayout->setWidget(3, QFormLayout::FieldRole, speedPanelWidthTextField);

        label_5 = new QLabel(formLayoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);
        label_5->setIndent(5);

        formLayout->setWidget(3, QFormLayout::LabelRole, label_5);

        genSpeedSeamCheckBox = new QCheckBox(formLayoutWidget);
        genSpeedSeamCheckBox->setObjectName(QString::fromUtf8("genSpeedSeamCheckBox"));
        genSpeedSeamCheckBox->setFont(font);
        genSpeedSeamCheckBox->setLayoutDirection(Qt::RightToLeft);

        formLayout->setWidget(1, QFormLayout::LabelRole, genSpeedSeamCheckBox);

        speedSeamHeightSpinBox = new QSpinBox(formLayoutWidget);
        speedSeamHeightSpinBox->setObjectName(QString::fromUtf8("speedSeamHeightSpinBox"));
        speedSeamHeightSpinBox->setMaximum(1000);
        speedSeamHeightSpinBox->setSingleStep(50);

        formLayout->setWidget(6, QFormLayout::FieldRole, speedSeamHeightSpinBox);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);
        label_3->setIndent(5);

        formLayout->setWidget(6, QFormLayout::LabelRole, label_3);

        printBottomSeamCheckBox = new QCheckBox(formLayoutWidget);
        printBottomSeamCheckBox->setObjectName(QString::fromUtf8("printBottomSeamCheckBox"));
        printBottomSeamCheckBox->setFont(font);
        printBottomSeamCheckBox->setLayoutDirection(Qt::RightToLeft);

        formLayout->setWidget(12, QFormLayout::LabelRole, printBottomSeamCheckBox);

        luffTapeDistance = new QLabel(formLayoutWidget);
        luffTapeDistance->setObjectName(QString::fromUtf8("luffTapeDistance"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Bitstream Vera Sans"));
        font2.setBold(true);
        font2.setWeight(75);
        luffTapeDistance->setFont(font2);

        formLayout->setWidget(14, QFormLayout::LabelRole, luffTapeDistance);

        luffTapeDistanceTextField = new QLineEdit(formLayoutWidget);
        luffTapeDistanceTextField->setObjectName(QString::fromUtf8("luffTapeDistanceTextField"));

        formLayout->setWidget(14, QFormLayout::FieldRole, luffTapeDistanceTextField);

        label_10 = new QLabel(formLayoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setFont(font2);

        formLayout->setWidget(16, QFormLayout::LabelRole, label_10);

        footTapeDistanceTextField = new QLineEdit(formLayoutWidget);
        footTapeDistanceTextField->setObjectName(QString::fromUtf8("footTapeDistanceTextField"));

        formLayout->setWidget(16, QFormLayout::FieldRole, footTapeDistanceTextField);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        formLayout->setItem(15, QFormLayout::LabelRole, horizontalSpacer);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        formLayout->setItem(13, QFormLayout::LabelRole, horizontalSpacer_2);

        tabWidget->addTab(general_tab, QString());
        battens_tab = new QWidget();
        battens_tab->setObjectName(QString::fromUtf8("battens_tab"));
        deleteBattenButton = new QPushButton(battens_tab);
        deleteBattenButton->setObjectName(QString::fromUtf8("deleteBattenButton"));
        deleteBattenButton->setGeometry(QRect(370, 30, 80, 27));
        addBattenButton = new QPushButton(battens_tab);
        addBattenButton->setObjectName(QString::fromUtf8("addBattenButton"));
        addBattenButton->setGeometry(QRect(370, 150, 80, 27));
        battenListWidget = new QListWidget(battens_tab);
        battenListWidget->setObjectName(QString::fromUtf8("battenListWidget"));
        battenListWidget->setGeometry(QRect(0, 0, 351, 101));
        updateBattenButton = new QPushButton(battens_tab);
        updateBattenButton->setObjectName(QString::fromUtf8("updateBattenButton"));
        updateBattenButton->setGeometry(QRect(370, 120, 80, 27));
        formLayoutWidget_2 = new QWidget(battens_tab);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(0, 120, 351, 201));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        battenIdLabel = new QLabel(formLayoutWidget_2);
        battenIdLabel->setObjectName(QString::fromUtf8("battenIdLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, battenIdLabel);

        battenIdLineEdit = new QLineEdit(formLayoutWidget_2);
        battenIdLineEdit->setObjectName(QString::fromUtf8("battenIdLineEdit"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, battenIdLineEdit);

        BattenlecehPositionLabel = new QLabel(formLayoutWidget_2);
        BattenlecehPositionLabel->setObjectName(QString::fromUtf8("BattenlecehPositionLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, BattenlecehPositionLabel);

        battenLeechPositionLineEdit = new QLineEdit(formLayoutWidget_2);
        battenLeechPositionLineEdit->setObjectName(QString::fromUtf8("battenLeechPositionLineEdit"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, battenLeechPositionLineEdit);

        battenLeechAngleLineEdit = new QLineEdit(formLayoutWidget_2);
        battenLeechAngleLineEdit->setObjectName(QString::fromUtf8("battenLeechAngleLineEdit"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, battenLeechAngleLineEdit);

        battenLeechAngleLabel = new QLabel(formLayoutWidget_2);
        battenLeechAngleLabel->setObjectName(QString::fromUtf8("battenLeechAngleLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, battenLeechAngleLabel);

        battenLengthLineEdit = new QLineEdit(formLayoutWidget_2);
        battenLengthLineEdit->setObjectName(QString::fromUtf8("battenLengthLineEdit"));

        formLayout_2->setWidget(4, QFormLayout::FieldRole, battenLengthLineEdit);

        battenLengthLabel = new QLabel(formLayoutWidget_2);
        battenLengthLabel->setObjectName(QString::fromUtf8("battenLengthLabel"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, battenLengthLabel);

        label_8 = new QLabel(formLayoutWidget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_8);

        inwardOffsetLineEdit = new QLineEdit(formLayoutWidget_2);
        inwardOffsetLineEdit->setObjectName(QString::fromUtf8("inwardOffsetLineEdit"));

        formLayout_2->setWidget(3, QFormLayout::FieldRole, inwardOffsetLineEdit);

        tabWidget->addTab(battens_tab, QString());
        leech_tab = new QWidget();
        leech_tab->setObjectName(QString::fromUtf8("leech_tab"));
        checkBoxStraightLineLeech = new QCheckBox(leech_tab);
        checkBoxStraightLineLeech->setObjectName(QString::fromUtf8("checkBoxStraightLineLeech"));
        checkBoxStraightLineLeech->setGeometry(QRect(50, 20, 201, 19));
        checkBoxStraightLineLeech->setFont(font);
        checkBoxStraightLineLeech->setLayoutDirection(Qt::RightToLeft);
        checkBoxClothAlignLeech = new QCheckBox(leech_tab);
        checkBoxClothAlignLeech->setObjectName(QString::fromUtf8("checkBoxClothAlignLeech"));
        checkBoxClothAlignLeech->setGeometry(QRect(60, 50, 191, 23));
        checkBoxClothAlignLeech->setFont(font);
        checkBoxClothAlignLeech->setLayoutDirection(Qt::RightToLeft);
        label_6 = new QLabel(leech_tab);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(50, 90, 191, 17));
        label_6->setFont(font);
        leechTurnPointPos = new QLineEdit(leech_tab);
        leechTurnPointPos->setObjectName(QString::fromUtf8("leechTurnPointPos"));
        leechTurnPointPos->setGeometry(QRect(240, 80, 51, 27));
        label_7 = new QLabel(leech_tab);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(300, 90, 21, 17));
        label_7->setFont(font);
        checkBoxRadialHead = new QCheckBox(leech_tab);
        checkBoxRadialHead->setObjectName(QString::fromUtf8("checkBoxRadialHead"));
        checkBoxRadialHead->setGeometry(QRect(120, 120, 131, 23));
        checkBoxRadialHead->setFont(font);
        checkBoxRadialHead->setLayoutDirection(Qt::RightToLeft);
        tabWidget->addTab(leech_tab, QString());

        retranslateUi(CFormSailDefAdvanced);
        QObject::connect(buttonBox, SIGNAL(accepted()), CFormSailDefAdvanced, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), CFormSailDefAdvanced, SLOT(reject()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(CFormSailDefAdvanced);
    } // setupUi

    void retranslateUi(QDialog *CFormSailDefAdvanced)
    {
        CFormSailDefAdvanced->setWindowTitle(QCoreApplication::translate("CFormSailDefAdvanced", "Advanced Settings", nullptr));
        label->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Splits", nullptr));
        label_2->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Number of Foot Panels", nullptr));
        label_4->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Fillet Panel Width", nullptr));
        label_5->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Speed Panel Width", nullptr));
        genSpeedSeamCheckBox->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Generate Speed Seam", nullptr));
        label_3->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Speed Seam Height", nullptr));
        printBottomSeamCheckBox->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Print Bottom Seam", nullptr));
        luffTapeDistance->setText(QCoreApplication::translate("CFormSailDefAdvanced", "  Luff Tape Distance", nullptr));
        label_10->setText(QCoreApplication::translate("CFormSailDefAdvanced", "  Foot Tape Distance", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(general_tab), QCoreApplication::translate("CFormSailDefAdvanced", "General", nullptr));
        deleteBattenButton->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Delete", nullptr));
        addBattenButton->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Add", nullptr));
        updateBattenButton->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Update", nullptr));
        battenIdLabel->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Batten Id", nullptr));
        BattenlecehPositionLabel->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Leech Position (%)", nullptr));
        battenLeechAngleLabel->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Angle", nullptr));
        battenLengthLabel->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Batten Length (0 = full length)", nullptr));
        label_8->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Inward Offset", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(battens_tab), QCoreApplication::translate("CFormSailDefAdvanced", "Battens", nullptr));
        checkBoxStraightLineLeech->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Straight Line Leech", nullptr));
        checkBoxClothAlignLeech->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Align Cloth with Leech", nullptr));
        label_6->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Leech Turn Point Position", nullptr));
        label_7->setText(QCoreApplication::translate("CFormSailDefAdvanced", "%", nullptr));
        checkBoxRadialHead->setText(QCoreApplication::translate("CFormSailDefAdvanced", "Radial Head", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(leech_tab), QCoreApplication::translate("CFormSailDefAdvanced", "Leech", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CFormSailDefAdvanced: public Ui_CFormSailDefAdvanced {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMSAILDEFADVANCED_H
