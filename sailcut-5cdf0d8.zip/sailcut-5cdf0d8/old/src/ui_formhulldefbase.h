/********************************************************************************
** Form generated from reading UI file 'formhulldefbase.ui'
**
** Created by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHULLDEFBASE_H
#define UI_FORMHULLDEFBASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
//#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CFormHullDefBase
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem;
    QPushButton *btnCheck;
    QPushButton *btnOK;
    QPushButton *btnCancel;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout1;
    QGroupBox *groupBox_Planking;
    QGridLayout *gridLayout2;
    QCheckBox *checkBox_AutoPlank;
    QSpacerItem *spacerItem1;
    QSpinBox *spinBox_LowPlankA;
    QLabel *label_LowPlankA;
    QSpinBox *spinBox_TopPlankA;
    QSpinBox *spinBox_NBPlank;
    QLabel *label_TopPlankA;
    QLabel *label_NBPlank;
    QGroupBox *groupBox_Bottom;
    QGridLayout *gridLayout3;
    QSpinBox *spinBox_BSweepA;
    QSpacerItem *spacerItem2;
    QLabel *label_BsweepA;
    QLabel *label_percent;
    QSpinBox *spinBox_BBWPos;
    QSpinBox *spinBox_BSlopeA;
    QSpinBox *spinBox_StemA;
    QLineEdit *txt_BBW;
    QLabel *label_BBW;
    QLineEdit *txt_BfwdHeight;
    QLineEdit *txt_BLWL;
    QLineEdit *txt_BaftW;
    QSpinBox *spinBox_BaftShape;
    QSpinBox *spinBox_BfwdShape;
    QSpinBox *spinBox_BDeadriseA;
    QLineEdit *txt_BaftHeight;
    QSpinBox *spinBox_TransomA;
    QLabel *label_BdeadriseA;
    QLabel *label_BfwdShape;
    QLabel *label_BLOA;
    QLabel *label_BfwdHeight;
    QLabel *label_BBWPos;
    QLabel *label_BSlopeA;
    QLabel *label_StemA;
    QLabel *label_TransomA;
    QLabel *label_BaftHeight;
    QLabel *label_BaftW;
    QLabel *label_BaftShape;
    QFrame *frame_5;
    QGridLayout *gridLayout4;
    QLineEdit *txt_HullID;
    QLabel *label_HullID;
    QGroupBox *groupBox_Deck;
    QGridLayout *gridLayout5;
    QSpinBox *spinBox_DSlopeA;
    QLineEdit *txt_DaftHeight;
    QLineEdit *txt_DfwdHeight;
    QLabel *label_DfwdHeight;
    QLabel *label_DSlopeA;
    QLabel *label_DaftHeight;
    QWidget *tab_2;
    QGridLayout *gridLayout6;
    QGroupBox *gBoxPlank_6;
    QGridLayout *gridLayout7;
    QLabel *label_50;
    QLabel *label_51;
    QLabel *label_52;
    QLabel *label_53;
    QLabel *label_54;
    QSpinBox *spinBox_1_26;
    QSpinBox *spinBox_1_27;
    QSpinBox *spinBox_1_28;
    QSpinBox *spinBox_1_29;
    QSpinBox *spinBox_1_30;
    QGroupBox *gBoxPlank_5;
    QGridLayout *gridLayout8;
    QLabel *label_45;
    QLabel *label_46;
    QLabel *label_47;
    QLabel *label_48;
    QLabel *label_49;
    QSpinBox *spinBox_1_21;
    QSpinBox *spinBox_1_22;
    QSpinBox *spinBox_1_23;
    QSpinBox *spinBox_1_24;
    QSpinBox *spinBox_1_25;
    QGroupBox *gBoxPlank_4;
    QGridLayout *gridLayout9;
    QLabel *label_40;
    QLabel *label_41;
    QLabel *label_42;
    QLabel *label_43;
    QLabel *label_44;
    QSpinBox *spinBox_1_16;
    QSpinBox *spinBox_1_17;
    QSpinBox *spinBox_1_18;
    QSpinBox *spinBox_1_19;
    QSpinBox *spinBox_1_20;
    QGroupBox *gBoxPlank_3;
    QGridLayout *gridLayout10;
    QLabel *label_35;
    QLabel *label_36;
    QLabel *label_37;
    QLabel *label_38;
    QLabel *label_39;
    QSpinBox *spinBox_1_11;
    QSpinBox *spinBox_1_12;
    QSpinBox *spinBox_1_13;
    QSpinBox *spinBox_1_14;
    QSpinBox *spinBox_1_15;
    QGroupBox *gBoxPlank_1;
    QGridLayout *gridLayout11;
    QLabel *label_24;
    QLabel *label_23;
    QLabel *label_22;
    QLabel *label_21;
    QLabel *label_20;
    QSpinBox *spinBox_1_1;
    QSpinBox *spinBox_1_5;
    QSpinBox *spinBox_1_4;
    QSpinBox *spinBox_1_3;
    QSpinBox *spinBox_1_2;
    QGroupBox *gBoxPlank_2;
    QGridLayout *gridLayout12;
    QSpinBox *spinBox_1_10;
    QSpinBox *spinBox_1_9;
    QSpinBox *spinBox_1_8;
    QSpinBox *spinBox_1_7;
    QSpinBox *spinBox_1_6;
    QLabel *label_29;
    QLabel *label_28;
    QLabel *label_27;
    QLabel *label_26;
    QLabel *label_25;
    QSpacerItem *spacerItem3;
    QLabel *label;

    void setupUi(QDialog *CFormHullDefBase)
    {
        if (CFormHullDefBase->objectName().isEmpty())
            CFormHullDefBase->setObjectName(QString::fromUtf8("CFormHullDefBase"));
        CFormHullDefBase->resize(641, 567);
        CFormHullDefBase->setMinimumSize(QSize(640, 555));
        gridLayout = new QGridLayout(CFormHullDefBase);
        gridLayout->setSpacing(5);
        gridLayout->setContentsMargins(5, 5, 5, 5);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        hboxLayout = new QHBoxLayout();
        hboxLayout->setSpacing(10);
        hboxLayout->setContentsMargins(4, 4, 4, 4);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        spacerItem = new QSpacerItem(381, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        btnCheck = new QPushButton(CFormHullDefBase);
        btnCheck->setObjectName(QString::fromUtf8("btnCheck"));

        hboxLayout->addWidget(btnCheck);

        btnOK = new QPushButton(CFormHullDefBase);
        btnOK->setObjectName(QString::fromUtf8("btnOK"));

        hboxLayout->addWidget(btnOK);

        btnCancel = new QPushButton(CFormHullDefBase);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));

        hboxLayout->addWidget(btnCancel);


        gridLayout->addLayout(hboxLayout, 2, 0, 1, 1);

        tabWidget = new QTabWidget(CFormHullDefBase);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        tabWidget->setFont(font);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout1 = new QGridLayout(tab);
        gridLayout1->setSpacing(6);
        gridLayout1->setContentsMargins(9, 9, 9, 9);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        groupBox_Planking = new QGroupBox(tab);
        groupBox_Planking->setObjectName(QString::fromUtf8("groupBox_Planking"));
        groupBox_Planking->setFont(font);
        gridLayout2 = new QGridLayout(groupBox_Planking);
        gridLayout2->setSpacing(6);
        gridLayout2->setContentsMargins(9, 9, 9, 9);
        gridLayout2->setObjectName(QString::fromUtf8("gridLayout2"));
        checkBox_AutoPlank = new QCheckBox(groupBox_Planking);
        checkBox_AutoPlank->setObjectName(QString::fromUtf8("checkBox_AutoPlank"));
        checkBox_AutoPlank->setChecked(true);
        checkBox_AutoPlank->setTristate(false);

        gridLayout2->addWidget(checkBox_AutoPlank, 0, 2, 1, 2);

        spacerItem1 = new QSpacerItem(31, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum);

        gridLayout2->addItem(spacerItem1, 1, 4, 1, 1);

        spinBox_LowPlankA = new QSpinBox(groupBox_Planking);
        spinBox_LowPlankA->setObjectName(QString::fromUtf8("spinBox_LowPlankA"));
        spinBox_LowPlankA->setMinimumSize(QSize(60, 22));
        spinBox_LowPlankA->setAlignment(Qt::AlignHCenter);
        spinBox_LowPlankA->setMaximum(45);
        spinBox_LowPlankA->setMinimum(30);
        spinBox_LowPlankA->setValue(40);

        gridLayout2->addWidget(spinBox_LowPlankA, 1, 3, 1, 1);

        label_LowPlankA = new QLabel(groupBox_Planking);
        label_LowPlankA->setObjectName(QString::fromUtf8("label_LowPlankA"));

        gridLayout2->addWidget(label_LowPlankA, 1, 2, 1, 1);

        spinBox_TopPlankA = new QSpinBox(groupBox_Planking);
        spinBox_TopPlankA->setObjectName(QString::fromUtf8("spinBox_TopPlankA"));
        QSizePolicy sizePolicy(static_cast<QSizePolicy::Policy>(0), static_cast<QSizePolicy::Policy>(0));
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(spinBox_TopPlankA->sizePolicy().hasHeightForWidth());
        spinBox_TopPlankA->setSizePolicy(sizePolicy);
        spinBox_TopPlankA->setMinimumSize(QSize(60, 22));
        spinBox_TopPlankA->setAlignment(Qt::AlignHCenter);
        spinBox_TopPlankA->setMinimum(45);
        spinBox_TopPlankA->setValue(85);

        gridLayout2->addWidget(spinBox_TopPlankA, 1, 1, 1, 1);

        spinBox_NBPlank = new QSpinBox(groupBox_Planking);
        spinBox_NBPlank->setObjectName(QString::fromUtf8("spinBox_NBPlank"));
        sizePolicy.setHeightForWidth(spinBox_NBPlank->sizePolicy().hasHeightForWidth());
        spinBox_NBPlank->setSizePolicy(sizePolicy);
        spinBox_NBPlank->setMinimumSize(QSize(60, 22));
        spinBox_NBPlank->setAlignment(Qt::AlignHCenter);
        spinBox_NBPlank->setMaximum(6);
        spinBox_NBPlank->setMinimum(1);
        spinBox_NBPlank->setValue(2);

        gridLayout2->addWidget(spinBox_NBPlank, 0, 1, 1, 1);

        label_TopPlankA = new QLabel(groupBox_Planking);
        label_TopPlankA->setObjectName(QString::fromUtf8("label_TopPlankA"));

        gridLayout2->addWidget(label_TopPlankA, 1, 0, 1, 1);

        label_NBPlank = new QLabel(groupBox_Planking);
        label_NBPlank->setObjectName(QString::fromUtf8("label_NBPlank"));

        gridLayout2->addWidget(label_NBPlank, 0, 0, 1, 1);


        gridLayout1->addWidget(groupBox_Planking, 3, 0, 1, 1);

        groupBox_Bottom = new QGroupBox(tab);
        groupBox_Bottom->setObjectName(QString::fromUtf8("groupBox_Bottom"));
        sizePolicy.setHeightForWidth(groupBox_Bottom->sizePolicy().hasHeightForWidth());
        groupBox_Bottom->setSizePolicy(sizePolicy);
        gridLayout3 = new QGridLayout(groupBox_Bottom);
        gridLayout3->setSpacing(6);
        gridLayout3->setContentsMargins(9, 9, 9, 9);
        gridLayout3->setObjectName(QString::fromUtf8("gridLayout3"));
        spinBox_BSweepA = new QSpinBox(groupBox_Bottom);
        spinBox_BSweepA->setObjectName(QString::fromUtf8("spinBox_BSweepA"));
        sizePolicy.setHeightForWidth(spinBox_BSweepA->sizePolicy().hasHeightForWidth());
        spinBox_BSweepA->setSizePolicy(sizePolicy);
        spinBox_BSweepA->setMinimumSize(QSize(60, 22));
        spinBox_BSweepA->setAlignment(Qt::AlignHCenter);
        spinBox_BSweepA->setMaximum(60);

        gridLayout3->addWidget(spinBox_BSweepA, 4, 3, 1, 1);

        spacerItem2 = new QSpacerItem(211, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout3->addItem(spacerItem2, 4, 4, 1, 3);

        label_BsweepA = new QLabel(groupBox_Bottom);
        label_BsweepA->setObjectName(QString::fromUtf8("label_BsweepA"));
        sizePolicy.setHeightForWidth(label_BsweepA->sizePolicy().hasHeightForWidth());
        label_BsweepA->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(label_BsweepA, 4, 2, 1, 1);

        label_percent = new QLabel(groupBox_Bottom);
        label_percent->setObjectName(QString::fromUtf8("label_percent"));
        sizePolicy.setHeightForWidth(label_percent->sizePolicy().hasHeightForWidth());
        label_percent->setSizePolicy(sizePolicy);
        label_percent->setMinimumSize(QSize(20, 22));

        gridLayout3->addWidget(label_percent, 2, 4, 1, 1);

        spinBox_BBWPos = new QSpinBox(groupBox_Bottom);
        spinBox_BBWPos->setObjectName(QString::fromUtf8("spinBox_BBWPos"));
        sizePolicy.setHeightForWidth(spinBox_BBWPos->sizePolicy().hasHeightForWidth());
        spinBox_BBWPos->setSizePolicy(sizePolicy);
        spinBox_BBWPos->setMinimumSize(QSize(60, 22));
        spinBox_BBWPos->setAlignment(Qt::AlignHCenter);
        spinBox_BBWPos->setMaximum(80);
        spinBox_BBWPos->setMinimum(20);
        spinBox_BBWPos->setValue(50);

        gridLayout3->addWidget(spinBox_BBWPos, 2, 3, 1, 1);

        spinBox_BSlopeA = new QSpinBox(groupBox_Bottom);
        spinBox_BSlopeA->setObjectName(QString::fromUtf8("spinBox_BSlopeA"));
        sizePolicy.setHeightForWidth(spinBox_BSlopeA->sizePolicy().hasHeightForWidth());
        spinBox_BSlopeA->setSizePolicy(sizePolicy);
        spinBox_BSlopeA->setMinimumSize(QSize(60, 22));
        spinBox_BSlopeA->setAlignment(Qt::AlignHCenter);
        spinBox_BSlopeA->setMaximum(50);

        gridLayout3->addWidget(spinBox_BSlopeA, 1, 3, 1, 1);

        spinBox_StemA = new QSpinBox(groupBox_Bottom);
        spinBox_StemA->setObjectName(QString::fromUtf8("spinBox_StemA"));
        sizePolicy.setHeightForWidth(spinBox_StemA->sizePolicy().hasHeightForWidth());
        spinBox_StemA->setSizePolicy(sizePolicy);
        spinBox_StemA->setMinimumSize(QSize(60, 22));
        spinBox_StemA->setAlignment(Qt::AlignHCenter);
        spinBox_StemA->setMaximum(90);
        spinBox_StemA->setMinimum(45);
        spinBox_StemA->setValue(80);

        gridLayout3->addWidget(spinBox_StemA, 0, 3, 1, 1);

        txt_BBW = new QLineEdit(groupBox_Bottom);
        txt_BBW->setObjectName(QString::fromUtf8("txt_BBW"));
        sizePolicy.setHeightForWidth(txt_BBW->sizePolicy().hasHeightForWidth());
        txt_BBW->setSizePolicy(sizePolicy);
        txt_BBW->setMinimumSize(QSize(60, 22));

        gridLayout3->addWidget(txt_BBW, 2, 1, 1, 1);

        label_BBW = new QLabel(groupBox_Bottom);
        label_BBW->setObjectName(QString::fromUtf8("label_BBW"));

        gridLayout3->addWidget(label_BBW, 2, 0, 1, 1);

        txt_BfwdHeight = new QLineEdit(groupBox_Bottom);
        txt_BfwdHeight->setObjectName(QString::fromUtf8("txt_BfwdHeight"));
        sizePolicy.setHeightForWidth(txt_BfwdHeight->sizePolicy().hasHeightForWidth());
        txt_BfwdHeight->setSizePolicy(sizePolicy);
        txt_BfwdHeight->setMinimumSize(QSize(60, 22));

        gridLayout3->addWidget(txt_BfwdHeight, 1, 1, 1, 1);

        txt_BLWL = new QLineEdit(groupBox_Bottom);
        txt_BLWL->setObjectName(QString::fromUtf8("txt_BLWL"));
        sizePolicy.setHeightForWidth(txt_BLWL->sizePolicy().hasHeightForWidth());
        txt_BLWL->setSizePolicy(sizePolicy);
        txt_BLWL->setMinimumSize(QSize(60, 22));

        gridLayout3->addWidget(txt_BLWL, 0, 1, 1, 1);

        txt_BaftW = new QLineEdit(groupBox_Bottom);
        txt_BaftW->setObjectName(QString::fromUtf8("txt_BaftW"));
        sizePolicy.setHeightForWidth(txt_BaftW->sizePolicy().hasHeightForWidth());
        txt_BaftW->setSizePolicy(sizePolicy);
        txt_BaftW->setMinimumSize(QSize(60, 22));

        gridLayout3->addWidget(txt_BaftW, 2, 6, 1, 1);

        spinBox_BaftShape = new QSpinBox(groupBox_Bottom);
        spinBox_BaftShape->setObjectName(QString::fromUtf8("spinBox_BaftShape"));
        spinBox_BaftShape->setMinimumSize(QSize(60, 22));
        spinBox_BaftShape->setAlignment(Qt::AlignHCenter);
        spinBox_BaftShape->setMaximum(9);
        spinBox_BaftShape->setMinimum(2);

        gridLayout3->addWidget(spinBox_BaftShape, 3, 6, 1, 1);

        spinBox_BfwdShape = new QSpinBox(groupBox_Bottom);
        spinBox_BfwdShape->setObjectName(QString::fromUtf8("spinBox_BfwdShape"));
        sizePolicy.setHeightForWidth(spinBox_BfwdShape->sizePolicy().hasHeightForWidth());
        spinBox_BfwdShape->setSizePolicy(sizePolicy);
        spinBox_BfwdShape->setMinimumSize(QSize(60, 22));
        spinBox_BfwdShape->setAlignment(Qt::AlignHCenter);
        spinBox_BfwdShape->setMaximum(9);
        spinBox_BfwdShape->setMinimum(2);

        gridLayout3->addWidget(spinBox_BfwdShape, 3, 1, 1, 1);

        spinBox_BDeadriseA = new QSpinBox(groupBox_Bottom);
        spinBox_BDeadriseA->setObjectName(QString::fromUtf8("spinBox_BDeadriseA"));
        sizePolicy.setHeightForWidth(spinBox_BDeadriseA->sizePolicy().hasHeightForWidth());
        spinBox_BDeadriseA->setSizePolicy(sizePolicy);
        spinBox_BDeadriseA->setMinimumSize(QSize(60, 22));
        spinBox_BDeadriseA->setAlignment(Qt::AlignHCenter);
        spinBox_BDeadriseA->setMaximum(30);
        spinBox_BDeadriseA->setValue(12);

        gridLayout3->addWidget(spinBox_BDeadriseA, 4, 1, 1, 1);

        txt_BaftHeight = new QLineEdit(groupBox_Bottom);
        txt_BaftHeight->setObjectName(QString::fromUtf8("txt_BaftHeight"));
        sizePolicy.setHeightForWidth(txt_BaftHeight->sizePolicy().hasHeightForWidth());
        txt_BaftHeight->setSizePolicy(sizePolicy);
        txt_BaftHeight->setMinimumSize(QSize(60, 22));

        gridLayout3->addWidget(txt_BaftHeight, 1, 6, 1, 1);

        spinBox_TransomA = new QSpinBox(groupBox_Bottom);
        spinBox_TransomA->setObjectName(QString::fromUtf8("spinBox_TransomA"));
        sizePolicy.setHeightForWidth(spinBox_TransomA->sizePolicy().hasHeightForWidth());
        spinBox_TransomA->setSizePolicy(sizePolicy);
        spinBox_TransomA->setMinimumSize(QSize(60, 22));
        spinBox_TransomA->setAlignment(Qt::AlignHCenter);
        spinBox_TransomA->setMaximum(99);
        spinBox_TransomA->setMinimum(45);
        spinBox_TransomA->setValue(80);

        gridLayout3->addWidget(spinBox_TransomA, 0, 6, 1, 1);

        label_BdeadriseA = new QLabel(groupBox_Bottom);
        label_BdeadriseA->setObjectName(QString::fromUtf8("label_BdeadriseA"));
        sizePolicy.setHeightForWidth(label_BdeadriseA->sizePolicy().hasHeightForWidth());
        label_BdeadriseA->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(label_BdeadriseA, 4, 0, 1, 1);

        label_BfwdShape = new QLabel(groupBox_Bottom);
        label_BfwdShape->setObjectName(QString::fromUtf8("label_BfwdShape"));

        gridLayout3->addWidget(label_BfwdShape, 3, 0, 1, 1);

        label_BLOA = new QLabel(groupBox_Bottom);
        label_BLOA->setObjectName(QString::fromUtf8("label_BLOA"));

        gridLayout3->addWidget(label_BLOA, 0, 0, 1, 1);

        label_BfwdHeight = new QLabel(groupBox_Bottom);
        label_BfwdHeight->setObjectName(QString::fromUtf8("label_BfwdHeight"));
        sizePolicy.setHeightForWidth(label_BfwdHeight->sizePolicy().hasHeightForWidth());
        label_BfwdHeight->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(label_BfwdHeight, 1, 0, 1, 1);

        label_BBWPos = new QLabel(groupBox_Bottom);
        label_BBWPos->setObjectName(QString::fromUtf8("label_BBWPos"));

        gridLayout3->addWidget(label_BBWPos, 2, 2, 1, 1);

        label_BSlopeA = new QLabel(groupBox_Bottom);
        label_BSlopeA->setObjectName(QString::fromUtf8("label_BSlopeA"));
        sizePolicy.setHeightForWidth(label_BSlopeA->sizePolicy().hasHeightForWidth());
        label_BSlopeA->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(label_BSlopeA, 1, 2, 1, 1);

        label_StemA = new QLabel(groupBox_Bottom);
        label_StemA->setObjectName(QString::fromUtf8("label_StemA"));

        gridLayout3->addWidget(label_StemA, 0, 2, 1, 1);

        label_TransomA = new QLabel(groupBox_Bottom);
        label_TransomA->setObjectName(QString::fromUtf8("label_TransomA"));

        gridLayout3->addWidget(label_TransomA, 0, 5, 1, 1);

        label_BaftHeight = new QLabel(groupBox_Bottom);
        label_BaftHeight->setObjectName(QString::fromUtf8("label_BaftHeight"));
        sizePolicy.setHeightForWidth(label_BaftHeight->sizePolicy().hasHeightForWidth());
        label_BaftHeight->setSizePolicy(sizePolicy);

        gridLayout3->addWidget(label_BaftHeight, 1, 5, 1, 1);

        label_BaftW = new QLabel(groupBox_Bottom);
        label_BaftW->setObjectName(QString::fromUtf8("label_BaftW"));

        gridLayout3->addWidget(label_BaftW, 2, 5, 1, 1);

        label_BaftShape = new QLabel(groupBox_Bottom);
        label_BaftShape->setObjectName(QString::fromUtf8("label_BaftShape"));

        gridLayout3->addWidget(label_BaftShape, 3, 5, 1, 1);


        gridLayout1->addWidget(groupBox_Bottom, 2, 0, 1, 1);

        frame_5 = new QFrame(tab);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Plain);
        gridLayout4 = new QGridLayout(frame_5);
        gridLayout4->setSpacing(6);
        gridLayout4->setContentsMargins(6, 6, 6, 6);
        gridLayout4->setObjectName(QString::fromUtf8("gridLayout4"));
        txt_HullID = new QLineEdit(frame_5);
        txt_HullID->setObjectName(QString::fromUtf8("txt_HullID"));
        txt_HullID->setMinimumSize(QSize(400, 22));

        gridLayout4->addWidget(txt_HullID, 0, 1, 1, 1);

        label_HullID = new QLabel(frame_5);
        label_HullID->setObjectName(QString::fromUtf8("label_HullID"));
        sizePolicy.setHeightForWidth(label_HullID->sizePolicy().hasHeightForWidth());
        label_HullID->setSizePolicy(sizePolicy);
        label_HullID->setMinimumSize(QSize(60, 20));

        gridLayout4->addWidget(label_HullID, 0, 0, 1, 1);


        gridLayout1->addWidget(frame_5, 0, 0, 1, 1);

        groupBox_Deck = new QGroupBox(tab);
        groupBox_Deck->setObjectName(QString::fromUtf8("groupBox_Deck"));
        gridLayout5 = new QGridLayout(groupBox_Deck);
        gridLayout5->setSpacing(6);
        gridLayout5->setContentsMargins(9, 9, 9, 9);
        gridLayout5->setObjectName(QString::fromUtf8("gridLayout5"));
        spinBox_DSlopeA = new QSpinBox(groupBox_Deck);
        spinBox_DSlopeA->setObjectName(QString::fromUtf8("spinBox_DSlopeA"));
        sizePolicy.setHeightForWidth(spinBox_DSlopeA->sizePolicy().hasHeightForWidth());
        spinBox_DSlopeA->setSizePolicy(sizePolicy);
        spinBox_DSlopeA->setMinimumSize(QSize(60, 22));
        spinBox_DSlopeA->setAlignment(Qt::AlignHCenter);
        spinBox_DSlopeA->setMaximum(24);
        spinBox_DSlopeA->setMinimum(0);
        spinBox_DSlopeA->setValue(12);

        gridLayout5->addWidget(spinBox_DSlopeA, 0, 3, 1, 1);

        txt_DaftHeight = new QLineEdit(groupBox_Deck);
        txt_DaftHeight->setObjectName(QString::fromUtf8("txt_DaftHeight"));
        sizePolicy.setHeightForWidth(txt_DaftHeight->sizePolicy().hasHeightForWidth());
        txt_DaftHeight->setSizePolicy(sizePolicy);
        txt_DaftHeight->setMinimumSize(QSize(60, 22));

        gridLayout5->addWidget(txt_DaftHeight, 0, 5, 1, 1);

        txt_DfwdHeight = new QLineEdit(groupBox_Deck);
        txt_DfwdHeight->setObjectName(QString::fromUtf8("txt_DfwdHeight"));
        sizePolicy.setHeightForWidth(txt_DfwdHeight->sizePolicy().hasHeightForWidth());
        txt_DfwdHeight->setSizePolicy(sizePolicy);
        txt_DfwdHeight->setMinimumSize(QSize(60, 22));

        gridLayout5->addWidget(txt_DfwdHeight, 0, 1, 1, 1);

        label_DfwdHeight = new QLabel(groupBox_Deck);
        label_DfwdHeight->setObjectName(QString::fromUtf8("label_DfwdHeight"));

        gridLayout5->addWidget(label_DfwdHeight, 0, 0, 1, 1);

        label_DSlopeA = new QLabel(groupBox_Deck);
        label_DSlopeA->setObjectName(QString::fromUtf8("label_DSlopeA"));

        gridLayout5->addWidget(label_DSlopeA, 0, 2, 1, 1);

        label_DaftHeight = new QLabel(groupBox_Deck);
        label_DaftHeight->setObjectName(QString::fromUtf8("label_DaftHeight"));

        gridLayout5->addWidget(label_DaftHeight, 0, 4, 1, 1);


        gridLayout1->addWidget(groupBox_Deck, 1, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout6 = new QGridLayout(tab_2);
        gridLayout6->setSpacing(6);
        gridLayout6->setContentsMargins(9, 9, 9, 9);
        gridLayout6->setObjectName(QString::fromUtf8("gridLayout6"));
        gBoxPlank_6 = new QGroupBox(tab_2);
        gBoxPlank_6->setObjectName(QString::fromUtf8("gBoxPlank_6"));
        gridLayout7 = new QGridLayout(gBoxPlank_6);
        gridLayout7->setSpacing(5);
        gridLayout7->setContentsMargins(3, 3, 3, 3);
        gridLayout7->setObjectName(QString::fromUtf8("gridLayout7"));
        label_50 = new QLabel(gBoxPlank_6);
        label_50->setObjectName(QString::fromUtf8("label_50"));

        gridLayout7->addWidget(label_50, 0, 4, 1, 1);

        label_51 = new QLabel(gBoxPlank_6);
        label_51->setObjectName(QString::fromUtf8("label_51"));

        gridLayout7->addWidget(label_51, 0, 3, 1, 1);

        label_52 = new QLabel(gBoxPlank_6);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        gridLayout7->addWidget(label_52, 0, 2, 1, 1);

        label_53 = new QLabel(gBoxPlank_6);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        gridLayout7->addWidget(label_53, 0, 1, 1, 1);

        label_54 = new QLabel(gBoxPlank_6);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        gridLayout7->addWidget(label_54, 0, 0, 1, 1);

        spinBox_1_26 = new QSpinBox(gBoxPlank_6);
        spinBox_1_26->setObjectName(QString::fromUtf8("spinBox_1_26"));
        sizePolicy.setHeightForWidth(spinBox_1_26->sizePolicy().hasHeightForWidth());
        spinBox_1_26->setSizePolicy(sizePolicy);
        spinBox_1_26->setMinimumSize(QSize(110, 22));
        spinBox_1_26->setMaximum(100);

        gridLayout7->addWidget(spinBox_1_26, 1, 0, 1, 1);

        spinBox_1_27 = new QSpinBox(gBoxPlank_6);
        spinBox_1_27->setObjectName(QString::fromUtf8("spinBox_1_27"));
        sizePolicy.setHeightForWidth(spinBox_1_27->sizePolicy().hasHeightForWidth());
        spinBox_1_27->setSizePolicy(sizePolicy);
        spinBox_1_27->setMinimumSize(QSize(60, 22));

        gridLayout7->addWidget(spinBox_1_27, 1, 4, 1, 1);

        spinBox_1_28 = new QSpinBox(gBoxPlank_6);
        spinBox_1_28->setObjectName(QString::fromUtf8("spinBox_1_28"));
        sizePolicy.setHeightForWidth(spinBox_1_28->sizePolicy().hasHeightForWidth());
        spinBox_1_28->setSizePolicy(sizePolicy);
        spinBox_1_28->setMinimumSize(QSize(60, 22));

        gridLayout7->addWidget(spinBox_1_28, 1, 3, 1, 1);

        spinBox_1_29 = new QSpinBox(gBoxPlank_6);
        spinBox_1_29->setObjectName(QString::fromUtf8("spinBox_1_29"));
        sizePolicy.setHeightForWidth(spinBox_1_29->sizePolicy().hasHeightForWidth());
        spinBox_1_29->setSizePolicy(sizePolicy);
        spinBox_1_29->setMinimumSize(QSize(60, 22));

        gridLayout7->addWidget(spinBox_1_29, 1, 2, 1, 1);

        spinBox_1_30 = new QSpinBox(gBoxPlank_6);
        spinBox_1_30->setObjectName(QString::fromUtf8("spinBox_1_30"));
        sizePolicy.setHeightForWidth(spinBox_1_30->sizePolicy().hasHeightForWidth());
        spinBox_1_30->setSizePolicy(sizePolicy);
        spinBox_1_30->setMinimumSize(QSize(110, 22));

        gridLayout7->addWidget(spinBox_1_30, 1, 1, 1, 1);


        gridLayout6->addWidget(gBoxPlank_6, 0, 0, 1, 1);

        gBoxPlank_5 = new QGroupBox(tab_2);
        gBoxPlank_5->setObjectName(QString::fromUtf8("gBoxPlank_5"));
        gridLayout8 = new QGridLayout(gBoxPlank_5);
        gridLayout8->setSpacing(5);
        gridLayout8->setContentsMargins(3, 3, 3, 3);
        gridLayout8->setObjectName(QString::fromUtf8("gridLayout8"));
        label_45 = new QLabel(gBoxPlank_5);
        label_45->setObjectName(QString::fromUtf8("label_45"));

        gridLayout8->addWidget(label_45, 0, 4, 1, 1);

        label_46 = new QLabel(gBoxPlank_5);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        gridLayout8->addWidget(label_46, 0, 3, 1, 1);

        label_47 = new QLabel(gBoxPlank_5);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        gridLayout8->addWidget(label_47, 0, 2, 1, 1);

        label_48 = new QLabel(gBoxPlank_5);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        gridLayout8->addWidget(label_48, 0, 1, 1, 1);

        label_49 = new QLabel(gBoxPlank_5);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        gridLayout8->addWidget(label_49, 0, 0, 1, 1);

        spinBox_1_21 = new QSpinBox(gBoxPlank_5);
        spinBox_1_21->setObjectName(QString::fromUtf8("spinBox_1_21"));
        sizePolicy.setHeightForWidth(spinBox_1_21->sizePolicy().hasHeightForWidth());
        spinBox_1_21->setSizePolicy(sizePolicy);
        spinBox_1_21->setMinimumSize(QSize(110, 22));
        spinBox_1_21->setMaximum(100);

        gridLayout8->addWidget(spinBox_1_21, 1, 0, 1, 1);

        spinBox_1_22 = new QSpinBox(gBoxPlank_5);
        spinBox_1_22->setObjectName(QString::fromUtf8("spinBox_1_22"));
        sizePolicy.setHeightForWidth(spinBox_1_22->sizePolicy().hasHeightForWidth());
        spinBox_1_22->setSizePolicy(sizePolicy);
        spinBox_1_22->setMinimumSize(QSize(60, 22));

        gridLayout8->addWidget(spinBox_1_22, 1, 4, 1, 1);

        spinBox_1_23 = new QSpinBox(gBoxPlank_5);
        spinBox_1_23->setObjectName(QString::fromUtf8("spinBox_1_23"));
        sizePolicy.setHeightForWidth(spinBox_1_23->sizePolicy().hasHeightForWidth());
        spinBox_1_23->setSizePolicy(sizePolicy);
        spinBox_1_23->setMinimumSize(QSize(60, 22));

        gridLayout8->addWidget(spinBox_1_23, 1, 3, 1, 1);

        spinBox_1_24 = new QSpinBox(gBoxPlank_5);
        spinBox_1_24->setObjectName(QString::fromUtf8("spinBox_1_24"));
        sizePolicy.setHeightForWidth(spinBox_1_24->sizePolicy().hasHeightForWidth());
        spinBox_1_24->setSizePolicy(sizePolicy);
        spinBox_1_24->setMinimumSize(QSize(60, 22));

        gridLayout8->addWidget(spinBox_1_24, 1, 2, 1, 1);

        spinBox_1_25 = new QSpinBox(gBoxPlank_5);
        spinBox_1_25->setObjectName(QString::fromUtf8("spinBox_1_25"));
        sizePolicy.setHeightForWidth(spinBox_1_25->sizePolicy().hasHeightForWidth());
        spinBox_1_25->setSizePolicy(sizePolicy);
        spinBox_1_25->setMinimumSize(QSize(110, 22));

        gridLayout8->addWidget(spinBox_1_25, 1, 1, 1, 1);


        gridLayout6->addWidget(gBoxPlank_5, 1, 0, 1, 1);

        gBoxPlank_4 = new QGroupBox(tab_2);
        gBoxPlank_4->setObjectName(QString::fromUtf8("gBoxPlank_4"));
        gridLayout9 = new QGridLayout(gBoxPlank_4);
        gridLayout9->setSpacing(5);
        gridLayout9->setContentsMargins(3, 3, 3, 3);
        gridLayout9->setObjectName(QString::fromUtf8("gridLayout9"));
        label_40 = new QLabel(gBoxPlank_4);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        gridLayout9->addWidget(label_40, 0, 4, 1, 1);

        label_41 = new QLabel(gBoxPlank_4);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        gridLayout9->addWidget(label_41, 0, 3, 1, 1);

        label_42 = new QLabel(gBoxPlank_4);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        gridLayout9->addWidget(label_42, 0, 2, 1, 1);

        label_43 = new QLabel(gBoxPlank_4);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        gridLayout9->addWidget(label_43, 0, 1, 1, 1);

        label_44 = new QLabel(gBoxPlank_4);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        gridLayout9->addWidget(label_44, 0, 0, 1, 1);

        spinBox_1_16 = new QSpinBox(gBoxPlank_4);
        spinBox_1_16->setObjectName(QString::fromUtf8("spinBox_1_16"));
        sizePolicy.setHeightForWidth(spinBox_1_16->sizePolicy().hasHeightForWidth());
        spinBox_1_16->setSizePolicy(sizePolicy);
        spinBox_1_16->setMinimumSize(QSize(110, 22));
        spinBox_1_16->setMaximum(100);

        gridLayout9->addWidget(spinBox_1_16, 1, 0, 1, 1);

        spinBox_1_17 = new QSpinBox(gBoxPlank_4);
        spinBox_1_17->setObjectName(QString::fromUtf8("spinBox_1_17"));
        sizePolicy.setHeightForWidth(spinBox_1_17->sizePolicy().hasHeightForWidth());
        spinBox_1_17->setSizePolicy(sizePolicy);
        spinBox_1_17->setMinimumSize(QSize(60, 22));

        gridLayout9->addWidget(spinBox_1_17, 1, 4, 1, 1);

        spinBox_1_18 = new QSpinBox(gBoxPlank_4);
        spinBox_1_18->setObjectName(QString::fromUtf8("spinBox_1_18"));
        sizePolicy.setHeightForWidth(spinBox_1_18->sizePolicy().hasHeightForWidth());
        spinBox_1_18->setSizePolicy(sizePolicy);
        spinBox_1_18->setMinimumSize(QSize(60, 22));

        gridLayout9->addWidget(spinBox_1_18, 1, 3, 1, 1);

        spinBox_1_19 = new QSpinBox(gBoxPlank_4);
        spinBox_1_19->setObjectName(QString::fromUtf8("spinBox_1_19"));
        sizePolicy.setHeightForWidth(spinBox_1_19->sizePolicy().hasHeightForWidth());
        spinBox_1_19->setSizePolicy(sizePolicy);
        spinBox_1_19->setMinimumSize(QSize(60, 22));

        gridLayout9->addWidget(spinBox_1_19, 1, 2, 1, 1);

        spinBox_1_20 = new QSpinBox(gBoxPlank_4);
        spinBox_1_20->setObjectName(QString::fromUtf8("spinBox_1_20"));
        sizePolicy.setHeightForWidth(spinBox_1_20->sizePolicy().hasHeightForWidth());
        spinBox_1_20->setSizePolicy(sizePolicy);
        spinBox_1_20->setMinimumSize(QSize(110, 22));

        gridLayout9->addWidget(spinBox_1_20, 1, 1, 1, 1);


        gridLayout6->addWidget(gBoxPlank_4, 2, 0, 1, 1);

        gBoxPlank_3 = new QGroupBox(tab_2);
        gBoxPlank_3->setObjectName(QString::fromUtf8("gBoxPlank_3"));
        gridLayout10 = new QGridLayout(gBoxPlank_3);
        gridLayout10->setSpacing(5);
        gridLayout10->setContentsMargins(3, 3, 3, 3);
        gridLayout10->setObjectName(QString::fromUtf8("gridLayout10"));
        label_35 = new QLabel(gBoxPlank_3);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        gridLayout10->addWidget(label_35, 0, 4, 1, 1);

        label_36 = new QLabel(gBoxPlank_3);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        gridLayout10->addWidget(label_36, 0, 3, 1, 1);

        label_37 = new QLabel(gBoxPlank_3);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        gridLayout10->addWidget(label_37, 0, 2, 1, 1);

        label_38 = new QLabel(gBoxPlank_3);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        gridLayout10->addWidget(label_38, 0, 1, 1, 1);

        label_39 = new QLabel(gBoxPlank_3);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        gridLayout10->addWidget(label_39, 0, 0, 1, 1);

        spinBox_1_11 = new QSpinBox(gBoxPlank_3);
        spinBox_1_11->setObjectName(QString::fromUtf8("spinBox_1_11"));
        sizePolicy.setHeightForWidth(spinBox_1_11->sizePolicy().hasHeightForWidth());
        spinBox_1_11->setSizePolicy(sizePolicy);
        spinBox_1_11->setMinimumSize(QSize(110, 22));
        spinBox_1_11->setMaximum(100);

        gridLayout10->addWidget(spinBox_1_11, 1, 0, 1, 1);

        spinBox_1_12 = new QSpinBox(gBoxPlank_3);
        spinBox_1_12->setObjectName(QString::fromUtf8("spinBox_1_12"));
        sizePolicy.setHeightForWidth(spinBox_1_12->sizePolicy().hasHeightForWidth());
        spinBox_1_12->setSizePolicy(sizePolicy);
        spinBox_1_12->setMinimumSize(QSize(60, 22));

        gridLayout10->addWidget(spinBox_1_12, 1, 4, 1, 1);

        spinBox_1_13 = new QSpinBox(gBoxPlank_3);
        spinBox_1_13->setObjectName(QString::fromUtf8("spinBox_1_13"));
        sizePolicy.setHeightForWidth(spinBox_1_13->sizePolicy().hasHeightForWidth());
        spinBox_1_13->setSizePolicy(sizePolicy);
        spinBox_1_13->setMinimumSize(QSize(60, 22));

        gridLayout10->addWidget(spinBox_1_13, 1, 3, 1, 1);

        spinBox_1_14 = new QSpinBox(gBoxPlank_3);
        spinBox_1_14->setObjectName(QString::fromUtf8("spinBox_1_14"));
        sizePolicy.setHeightForWidth(spinBox_1_14->sizePolicy().hasHeightForWidth());
        spinBox_1_14->setSizePolicy(sizePolicy);
        spinBox_1_14->setMinimumSize(QSize(60, 22));

        gridLayout10->addWidget(spinBox_1_14, 1, 2, 1, 1);

        spinBox_1_15 = new QSpinBox(gBoxPlank_3);
        spinBox_1_15->setObjectName(QString::fromUtf8("spinBox_1_15"));
        sizePolicy.setHeightForWidth(spinBox_1_15->sizePolicy().hasHeightForWidth());
        spinBox_1_15->setSizePolicy(sizePolicy);
        spinBox_1_15->setMinimumSize(QSize(110, 22));

        gridLayout10->addWidget(spinBox_1_15, 1, 1, 1, 1);


        gridLayout6->addWidget(gBoxPlank_3, 3, 0, 1, 1);

        gBoxPlank_1 = new QGroupBox(tab_2);
        gBoxPlank_1->setObjectName(QString::fromUtf8("gBoxPlank_1"));
        gridLayout11 = new QGridLayout(gBoxPlank_1);
        gridLayout11->setSpacing(5);
        gridLayout11->setContentsMargins(3, 3, 3, 3);
        gridLayout11->setObjectName(QString::fromUtf8("gridLayout11"));
        label_24 = new QLabel(gBoxPlank_1);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout11->addWidget(label_24, 0, 4, 1, 1);

        label_23 = new QLabel(gBoxPlank_1);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout11->addWidget(label_23, 0, 3, 1, 1);

        label_22 = new QLabel(gBoxPlank_1);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout11->addWidget(label_22, 0, 2, 1, 1);

        label_21 = new QLabel(gBoxPlank_1);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        gridLayout11->addWidget(label_21, 0, 1, 1, 1);

        label_20 = new QLabel(gBoxPlank_1);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout11->addWidget(label_20, 0, 0, 1, 1);

        spinBox_1_1 = new QSpinBox(gBoxPlank_1);
        spinBox_1_1->setObjectName(QString::fromUtf8("spinBox_1_1"));
        sizePolicy.setHeightForWidth(spinBox_1_1->sizePolicy().hasHeightForWidth());
        spinBox_1_1->setSizePolicy(sizePolicy);
        spinBox_1_1->setMinimumSize(QSize(110, 22));
        spinBox_1_1->setMaximum(100);

        gridLayout11->addWidget(spinBox_1_1, 1, 0, 1, 1);

        spinBox_1_5 = new QSpinBox(gBoxPlank_1);
        spinBox_1_5->setObjectName(QString::fromUtf8("spinBox_1_5"));
        sizePolicy.setHeightForWidth(spinBox_1_5->sizePolicy().hasHeightForWidth());
        spinBox_1_5->setSizePolicy(sizePolicy);
        spinBox_1_5->setMinimumSize(QSize(60, 22));

        gridLayout11->addWidget(spinBox_1_5, 1, 4, 1, 1);

        spinBox_1_4 = new QSpinBox(gBoxPlank_1);
        spinBox_1_4->setObjectName(QString::fromUtf8("spinBox_1_4"));
        sizePolicy.setHeightForWidth(spinBox_1_4->sizePolicy().hasHeightForWidth());
        spinBox_1_4->setSizePolicy(sizePolicy);
        spinBox_1_4->setMinimumSize(QSize(60, 22));

        gridLayout11->addWidget(spinBox_1_4, 1, 3, 1, 1);

        spinBox_1_3 = new QSpinBox(gBoxPlank_1);
        spinBox_1_3->setObjectName(QString::fromUtf8("spinBox_1_3"));
        sizePolicy.setHeightForWidth(spinBox_1_3->sizePolicy().hasHeightForWidth());
        spinBox_1_3->setSizePolicy(sizePolicy);
        spinBox_1_3->setMinimumSize(QSize(60, 22));

        gridLayout11->addWidget(spinBox_1_3, 1, 2, 1, 1);

        spinBox_1_2 = new QSpinBox(gBoxPlank_1);
        spinBox_1_2->setObjectName(QString::fromUtf8("spinBox_1_2"));
        sizePolicy.setHeightForWidth(spinBox_1_2->sizePolicy().hasHeightForWidth());
        spinBox_1_2->setSizePolicy(sizePolicy);
        spinBox_1_2->setMinimumSize(QSize(110, 22));

        gridLayout11->addWidget(spinBox_1_2, 1, 1, 1, 1);


        gridLayout6->addWidget(gBoxPlank_1, 5, 0, 1, 1);

        gBoxPlank_2 = new QGroupBox(tab_2);
        gBoxPlank_2->setObjectName(QString::fromUtf8("gBoxPlank_2"));
        gridLayout12 = new QGridLayout(gBoxPlank_2);
        gridLayout12->setSpacing(5);
        gridLayout12->setContentsMargins(3, 3, 3, 3);
        gridLayout12->setObjectName(QString::fromUtf8("gridLayout12"));
        spinBox_1_10 = new QSpinBox(gBoxPlank_2);
        spinBox_1_10->setObjectName(QString::fromUtf8("spinBox_1_10"));
        sizePolicy.setHeightForWidth(spinBox_1_10->sizePolicy().hasHeightForWidth());
        spinBox_1_10->setSizePolicy(sizePolicy);
        spinBox_1_10->setMinimumSize(QSize(110, 22));

        gridLayout12->addWidget(spinBox_1_10, 1, 1, 1, 1);

        spinBox_1_9 = new QSpinBox(gBoxPlank_2);
        spinBox_1_9->setObjectName(QString::fromUtf8("spinBox_1_9"));
        sizePolicy.setHeightForWidth(spinBox_1_9->sizePolicy().hasHeightForWidth());
        spinBox_1_9->setSizePolicy(sizePolicy);
        spinBox_1_9->setMinimumSize(QSize(60, 22));

        gridLayout12->addWidget(spinBox_1_9, 1, 2, 1, 1);

        spinBox_1_8 = new QSpinBox(gBoxPlank_2);
        spinBox_1_8->setObjectName(QString::fromUtf8("spinBox_1_8"));
        sizePolicy.setHeightForWidth(spinBox_1_8->sizePolicy().hasHeightForWidth());
        spinBox_1_8->setSizePolicy(sizePolicy);
        spinBox_1_8->setMinimumSize(QSize(60, 21));

        gridLayout12->addWidget(spinBox_1_8, 1, 3, 1, 1);

        spinBox_1_7 = new QSpinBox(gBoxPlank_2);
        spinBox_1_7->setObjectName(QString::fromUtf8("spinBox_1_7"));
        sizePolicy.setHeightForWidth(spinBox_1_7->sizePolicy().hasHeightForWidth());
        spinBox_1_7->setSizePolicy(sizePolicy);
        spinBox_1_7->setMinimumSize(QSize(60, 22));

        gridLayout12->addWidget(spinBox_1_7, 1, 4, 1, 1);

        spinBox_1_6 = new QSpinBox(gBoxPlank_2);
        spinBox_1_6->setObjectName(QString::fromUtf8("spinBox_1_6"));
        sizePolicy.setHeightForWidth(spinBox_1_6->sizePolicy().hasHeightForWidth());
        spinBox_1_6->setSizePolicy(sizePolicy);
        spinBox_1_6->setMinimumSize(QSize(110, 22));
        spinBox_1_6->setMaximum(100);

        gridLayout12->addWidget(spinBox_1_6, 1, 0, 1, 1);

        label_29 = new QLabel(gBoxPlank_2);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        gridLayout12->addWidget(label_29, 0, 0, 1, 1);

        label_28 = new QLabel(gBoxPlank_2);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout12->addWidget(label_28, 0, 1, 1, 1);

        label_27 = new QLabel(gBoxPlank_2);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout12->addWidget(label_27, 0, 2, 1, 1);

        label_26 = new QLabel(gBoxPlank_2);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout12->addWidget(label_26, 0, 3, 1, 1);

        label_25 = new QLabel(gBoxPlank_2);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout12->addWidget(label_25, 0, 4, 1, 1);


        gridLayout6->addWidget(gBoxPlank_2, 4, 0, 1, 1);

        spacerItem3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout6->addItem(spacerItem3, 6, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 1, 0, 1, 1);

        label = new QLabel(CFormHullDefBase);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(620, 25));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setFrameShape(QFrame::StyledPanel);
        label->setFrameShadow(QFrame::Raised);
        label->setAlignment(Qt::AlignCenter);
        label->setMargin(4);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        QWidget::setTabOrder(tabWidget, txt_HullID);
        QWidget::setTabOrder(txt_HullID, txt_BLWL);
        QWidget::setTabOrder(txt_BLWL, txt_DfwdHeight);
        QWidget::setTabOrder(txt_DfwdHeight, txt_DaftHeight);
        QWidget::setTabOrder(txt_DaftHeight, txt_BBW);
        QWidget::setTabOrder(txt_BBW, spinBox_BBWPos);
        QWidget::setTabOrder(spinBox_BBWPos, txt_BaftW);
        QWidget::setTabOrder(txt_BaftW, spinBox_StemA);
        QWidget::setTabOrder(spinBox_StemA, txt_BfwdHeight);
        QWidget::setTabOrder(txt_BfwdHeight, txt_BaftHeight);
        QWidget::setTabOrder(txt_BaftHeight, spinBox_BDeadriseA);
        QWidget::setTabOrder(spinBox_BDeadriseA, spinBox_BSweepA);
        QWidget::setTabOrder(spinBox_BSweepA, spinBox_NBPlank);
        QWidget::setTabOrder(spinBox_NBPlank, checkBox_AutoPlank);
        QWidget::setTabOrder(checkBox_AutoPlank, spinBox_TopPlankA);
        QWidget::setTabOrder(spinBox_TopPlankA, spinBox_LowPlankA);
        QWidget::setTabOrder(spinBox_LowPlankA, btnOK);
        QWidget::setTabOrder(btnOK, btnCancel);
        QWidget::setTabOrder(btnCancel, spinBox_1_1);
        QWidget::setTabOrder(spinBox_1_1, spinBox_1_2);
        QWidget::setTabOrder(spinBox_1_2, spinBox_1_3);
        QWidget::setTabOrder(spinBox_1_3, spinBox_1_4);
        QWidget::setTabOrder(spinBox_1_4, spinBox_1_5);
        QWidget::setTabOrder(spinBox_1_5, spinBox_1_6);
        QWidget::setTabOrder(spinBox_1_6, spinBox_1_10);
        QWidget::setTabOrder(spinBox_1_10, spinBox_1_9);
        QWidget::setTabOrder(spinBox_1_9, spinBox_1_8);
        QWidget::setTabOrder(spinBox_1_8, spinBox_1_7);
        QWidget::setTabOrder(spinBox_1_7, spinBox_1_11);
        QWidget::setTabOrder(spinBox_1_11, spinBox_1_15);
        QWidget::setTabOrder(spinBox_1_15, spinBox_1_14);
        QWidget::setTabOrder(spinBox_1_14, spinBox_1_13);
        QWidget::setTabOrder(spinBox_1_13, spinBox_1_12);
        QWidget::setTabOrder(spinBox_1_12, spinBox_1_16);
        QWidget::setTabOrder(spinBox_1_16, spinBox_1_20);
        QWidget::setTabOrder(spinBox_1_20, spinBox_1_19);
        QWidget::setTabOrder(spinBox_1_19, spinBox_1_18);
        QWidget::setTabOrder(spinBox_1_18, spinBox_1_17);
        QWidget::setTabOrder(spinBox_1_17, spinBox_1_21);
        QWidget::setTabOrder(spinBox_1_21, spinBox_1_25);
        QWidget::setTabOrder(spinBox_1_25, spinBox_1_24);
        QWidget::setTabOrder(spinBox_1_24, spinBox_1_23);
        QWidget::setTabOrder(spinBox_1_23, spinBox_1_22);
        QWidget::setTabOrder(spinBox_1_22, spinBox_1_26);
        QWidget::setTabOrder(spinBox_1_26, spinBox_1_30);
        QWidget::setTabOrder(spinBox_1_30, spinBox_1_29);
        QWidget::setTabOrder(spinBox_1_29, spinBox_1_28);
        QWidget::setTabOrder(spinBox_1_28, spinBox_1_27);

        retranslateUi(CFormHullDefBase);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(CFormHullDefBase);
    } // setupUi

    void retranslateUi(QDialog *CFormHullDefBase)
    {
        CFormHullDefBase->setWindowTitle(QApplication::translate("CFormHullDefBase", "Dialog"));
        btnCheck->setText(QApplication::translate("CFormHullDefBase", "Check"));
        btnOK->setText(QApplication::translate("CFormHullDefBase", "OK"));
        btnCancel->setText(QApplication::translate("CFormHullDefBase", "Cancel"));
        groupBox_Planking->setTitle(QApplication::translate("CFormHullDefBase", "Planking"));
        checkBox_AutoPlank->setText(QApplication::translate("CFormHullDefBase", "Automatic planking"));
        label_LowPlankA->setText(QApplication::translate("CFormHullDefBase", "lower plank angle"));
        label_TopPlankA->setText(QApplication::translate("CFormHullDefBase", "top plank angle"));
        label_NBPlank->setText(QApplication::translate("CFormHullDefBase", "Number of planks"));
        groupBox_Bottom->setTitle(QApplication::translate("CFormHullDefBase", "Bottom"));
        label_BsweepA->setText(QApplication::translate("CFormHullDefBase", "Bottom sweep angle"));
        label_percent->setText(QApplication::translate("CFormHullDefBase", "%"));
        txt_BBW->setText(QApplication::translate("CFormHullDefBase", "txt_BBW"));
        label_BBW->setText(QApplication::translate("CFormHullDefBase", "Max Width"));
        txt_BfwdHeight->setText(QApplication::translate("CFormHullDefBase", "txt_BfwdHeight"));
        txt_BLWL->setText(QApplication::translate("CFormHullDefBase", "txt_BLWL"));
        txt_BaftW->setText(QApplication::translate("CFormHullDefBase", "txt_BaftW"));
        txt_BaftHeight->setText(QApplication::translate("CFormHullDefBase", "txt_BaftHeight"));
        label_BdeadriseA->setText(QApplication::translate("CFormHullDefBase", "Dead rise angle"));
        label_BfwdShape->setText(QApplication::translate("CFormHullDefBase", "Forward shape"));
        label_BLOA->setText(QApplication::translate("CFormHullDefBase", "Length"));
        label_BfwdHeight->setText(QApplication::translate("CFormHullDefBase", "Forward height "));
        label_BBWPos->setText(QApplication::translate("CFormHullDefBase", "Max Width position"));
        label_BSlopeA->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_StemA->setText(QApplication::translate("CFormHullDefBase", "Stem angle"));
        label_TransomA->setText(QApplication::translate("CFormHullDefBase", "Transom angle"));
        label_BaftHeight->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_BaftW->setText(QApplication::translate("CFormHullDefBase", "Aft width"));
        label_BaftShape->setText(QApplication::translate("CFormHullDefBase", "Aft shape"));
        txt_HullID->setText(QApplication::translate("CFormHullDefBase", "txt_HullID"));
        label_HullID->setText(QApplication::translate("CFormHullDefBase", "Hull name"));
        groupBox_Deck->setTitle(QApplication::translate("CFormHullDefBase", "Deck"));
        txt_DaftHeight->setText(QApplication::translate("CFormHullDefBase", "txt_DaftHeight"));
        txt_DfwdHeight->setText(QApplication::translate("CFormHullDefBase", "txt_DfwdHeight"));
        label_DfwdHeight->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        label_DSlopeA->setText(QApplication::translate("CFormHullDefBase", "Side angle"));
        label_DaftHeight->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("CFormHullDefBase", "Deck and bottom"));
        gBoxPlank_6->setTitle(QApplication::translate("CFormHullDefBase", "Plank 6"));
        label_50->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_51->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_52->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_53->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_54->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        gBoxPlank_5->setTitle(QApplication::translate("CFormHullDefBase", "Plank 5"));
        label_45->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_46->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_47->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_48->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_49->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        gBoxPlank_4->setTitle(QApplication::translate("CFormHullDefBase", "Plank 4"));
        label_40->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_41->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_42->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_43->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_44->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        gBoxPlank_3->setTitle(QApplication::translate("CFormHullDefBase", "Plank 3"));
        label_35->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_36->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_37->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_38->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_39->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        gBoxPlank_1->setTitle(QApplication::translate("CFormHullDefBase", "Plank 1"));
        label_24->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        label_23->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_22->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_21->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_20->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        gBoxPlank_2->setTitle(QApplication::translate("CFormHullDefBase", "Plank 2"));
        label_29->setText(QApplication::translate("CFormHullDefBase", "Forward height"));
        label_28->setText(QApplication::translate("CFormHullDefBase", "Aft height"));
        label_27->setText(QApplication::translate("CFormHullDefBase", "Plank angle"));
        label_26->setText(QApplication::translate("CFormHullDefBase", "Sweep angle"));
        label_25->setText(QApplication::translate("CFormHullDefBase", "Chine angle"));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("CFormHullDefBase", "Planks"));
        label->setText(QApplication::translate("CFormHullDefBase", "Dimensions are in millimeters and angles in degrees measured from horizontal"));
    } // retranslateUi

};

namespace Ui {
    class CFormHullDefBase: public Ui_CFormHullDefBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHULLDEFBASE_H
