/********************************************************************************
** Form generated from reading UI file 'batteninfodialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BATTENINFODIALOG_H
#define UI_BATTENINFODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CBattenInfoDialog
{
public:
    QDialogButtonBox *buttonBox;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QTextEdit *textEdit;

    void setupUi(QDialog *CBattenInfoDialog)
    {
        if (CBattenInfoDialog->objectName().isEmpty())
            CBattenInfoDialog->setObjectName(QString::fromUtf8("CBattenInfoDialog"));
        CBattenInfoDialog->resize(400, 361);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CBattenInfoDialog->sizePolicy().hasHeightForWidth());
        CBattenInfoDialog->setSizePolicy(sizePolicy);
        buttonBox = new QDialogButtonBox(CBattenInfoDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(40, 320, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);
        scrollArea = new QScrollArea(CBattenInfoDialog);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(9, 20, 381, 291));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 377, 287));
        textEdit = new QTextEdit(scrollAreaWidgetContents);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(0, 0, 371, 291));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier"));
        textEdit->setFont(font);
        scrollArea->setWidget(scrollAreaWidgetContents);

        retranslateUi(CBattenInfoDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), CBattenInfoDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), CBattenInfoDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(CBattenInfoDialog);
    } // setupUi

    void retranslateUi(QDialog *CBattenInfoDialog)
    {
        CBattenInfoDialog->setWindowTitle(QApplication::translate("CBattenInfoDialog", "Batten Details"));
    } // retranslateUi

};

namespace Ui {
    class CBattenInfoDialog: public Ui_CBattenInfoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BATTENINFODIALOG_H
